#!/usr/bin/env bash
set -Eeuo pipefail

# Run only BAM on the original Dantzig matrix (1,050 grid + 139 process runs).
# From the repository root:
#   bash run_bam_dantzig.sh setup
#   BAM_LICENSE_FILE=/absolute/path/bamlice.txt bash run_bam_dantzig.sh run
#
# Optional setup override: BAM_SPEC=/absolute/path/new_bam_solver.whl
# Optional paths: DANTZIG_BASE_ENV, DANTZIG_REFERENCE (original run folder or ZIP).
# The reference defaults to the original results folder, then the committed ZIP.
# Setup clones the original conda environment and reinstalls only BAM and this
# editable project. It does not upgrade NumPy/SciPy or change the original env.
# A BAM native solver dated 2026-09-10 or later is required (not just a new
# Python wrapper version). If PyPI still serves an older solver, setup stops;
# supply BAM_SPEC pointing to the new official wheel and repeat setup.

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
BASE_ENV="${DANTZIG_BASE_ENV:-$ROOT/.venv-dantzig}"
ENV_DIR="$ROOT/.venv-dantzig-bam"
REFERENCE="${DANTZIG_REFERENCE:-}"
MODE="${1:-run}"
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
case "$MODE" in
  setup|run|check) ;;
  help|-h|--help)
    sed -n '4,16p' "${BASH_SOURCE[0]}"
    printf '\ncheck: verify the installed BAM version and original starting designs without solving.\n'
    exit 0 ;;
  *) fail "Usage: bash run_bam_dantzig.sh {setup|check|run}" ;;
esac
[[ "$(uname -s)" == Linux ]] || fail "Run this script on the Linux Dantzig server."
[[ -f "$ROOT/case_study_benchmark.py" ]] || fail "Save this script in the repository root."
command -v git >/dev/null || fail "git is required to verify the original grid data."
if [[ -z "$REFERENCE" ]]; then
  REFERENCE="$ROOT/results/dantzig_20260910_170759_slN8tv"
  if [[ ! -d "$REFERENCE" ]]; then
    REFERENCE="$ROOT/results/archives/dantzig_20260910_170759_slN8tv.zip"
  fi
fi
[[ -e "$REFERENCE" ]] || fail "Set DANTZIG_REFERENCE to the original Dantzig run folder or ZIP."

# Match the original single-CPU, single-thread execution policy.
export OMP_NUM_THREADS=1 OMP_THREAD_LIMIT=1 OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1 BLIS_NUM_THREADS=1 GOTO_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 NUMEXPR_MAX_THREADS=1
export OMP_DYNAMIC=FALSE MKL_DYNAMIC=FALSE MPLBACKEND=Agg
export PYTHONUNBUFFERED=1 PYTHONNOUSERSITE=1

CONDA_CMD="${CONDA_EXE:-}"
if [[ ! -x "$CONDA_CMD" ]]; then CONDA_CMD="$(command -v conda || true)"; fi
if [[ ! -x "$CONDA_CMD" ]]; then CONDA_CMD="$ROOT/.venv-miniforge/bin/conda"; fi
[[ -x "$CONDA_CMD" ]] || fail "Cannot find conda. Set CONDA_EXE to its executable."
if [[ "$MODE" == setup && ! -d "$ENV_DIR/conda-meta" ]]; then
  [[ -d "$BASE_ENV/conda-meta" ]] ||
    fail "Set DANTZIG_BASE_ENV to the conda environment used for the original run."
  "$CONDA_CMD" create -y -p "$ENV_DIR" --clone "$BASE_ENV"
fi
[[ -x "$ENV_DIR/bin/python" ]] || fail "First run: bash run_bam_dantzig.sh setup"
if [[ -d "$BASE_ENV" ]] &&
   [[ "$(cd "$ENV_DIR" && pwd -P)" == "$(cd "$BASE_ENV" && pwd -P)" ]]; then
  fail "The BAM environment must be separate from the original environment."
fi
CONDA_BASE="$("$CONDA_CMD" info --base)"
set +u
source "$CONDA_BASE/etc/profile.d/conda.sh"
conda activate "$ENV_DIR"
set -u
export PYTHONPATH="$ROOT"
REFERENCE="$(python -c 'import pathlib, sys; print(pathlib.Path(sys.argv[1]).resolve())' "$REFERENCE")"

if [[ "$MODE" == setup ]]; then
  python -m pip install --no-deps -e "$ROOT"
  python -m pip install --upgrade --force-reinstall --no-cache-dir --no-deps \
    --only-binary=:all: "${BAM_SPEC:-bam-solver}"
  python -m pip check
fi

# Validate the native library as well as the Python package: their versions
# differ. The previous run used bam-solver 4.1.1 / native solver 2026-05-30.
python - <<'BAM_VERSION'
import importlib.metadata
import bam

native = tuple(bam.Bam.get_solver_version())
print("BAM Python package:", importlib.metadata.version("bam-solver"))
print("BAM native solver:", ".".join(map(str, native)))
if native < (2026, 9, 10):
    raise SystemExit(
        "The installed native BAM solver predates the new release. "
        "Set BAM_SPEC to the new official wheel and repeat setup."
    )
BAM_VERSION

# Check actual design hashes, input files, and initial objective histories.
# Same seeds alone are insufficient if the LHC implementation or its
# NumPy/SciPy dependencies have changed.
audit() {
  python - "$ROOT" "$REFERENCE" "$1" "${2:-}" <<'DESIGN_AUDIT'
import csv
import hashlib
import importlib.metadata
import io
import json
import math
import subprocess
import sys
import zipfile
from pathlib import Path

import benchmark as grid_benchmark
import case_study_benchmark as cases
from case_studies.common import generate_lhc_starting_points

root, reference, phase, output = sys.argv[1:]
root, reference = Path(root), Path(reference)

def require(condition, message):
    if not condition:
        raise SystemExit(message)

def read_reference(name):
    if reference.is_dir():
        return (reference / name).read_bytes()
    with zipfile.ZipFile(reference) as archive:
        matches = [p for p in archive.namelist() if p.endswith("/" + name) or p == name]
        require(len(matches) == 1, f"Expected one {name} in {reference}")
        return archive.read(matches[0])

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read_rows(data):
    return list(csv.DictReader(io.StringIO(data.decode("utf-8"))))

manifest_bytes = read_reference("process_case_studies.manifest.json")
manifest = json.loads(manifest_bytes)
require(manifest["run"]["status"] == "completed", "Reference process run is incomplete")
old_cases_bytes = read_reference("process_case_studies.csv")
require(digest(old_cases_bytes) == manifest["output"]["csv_sha256"],
        "Reference process CSV checksum does not match its manifest")
old_grid_bytes = read_reference("benchmark.csv")
old_cases, old_grids = read_rows(old_cases_bytes), read_rows(old_grid_bytes)
for name in ("numpy", "scipy"):
    expected = manifest["software"]["distributions"][name]
    require(importlib.metadata.version(name) == expected,
            f"{name} must match the original run ({expected}); clone its original environment")
for section in ("source_files_sha256", "data_files_sha256"):
    for relative, expected in manifest["provenance"][section].items():
        require(digest((root / relative).read_bytes()) == expected,
                f"Original benchmark source/data changed: {relative}")

matrix = cases.build_run_matrix(
    cases=("column", "cstr", "small_batch", "dynamic"),
    seeds=range(10), column_seeds=range(1, 10), column_budgets=(16,),
    cstr_grid_sizes=(5, 10, 15, 20, 25, 30), small_batch_budgets=(10,),
    dynamic_budgets=(12, 15, 20, 30, 37, 50),
)
designs = cases._initial_design_hashes(matrix, 3)
require(designs == manifest["provenance"]["initial_design"]["designs"],
        "Regenerated process starting points differ from the original 89 designs")
require(cases._planned_run_keys(matrix, ("dsda", "rbfopt", "bam"), 3)
        == manifest["run"]["completed_run_keys"], "Process run matrix differs from reference")

def key(row):
    return (row["csv_name"], int(row["seed"]), int(row["n_starts"]), int(row["max_evals"]))

def bam_rows(rows):
    selected = [r for r in rows if r["method"].lower() == "bam"]
    indexed = {key(r): r for r in selected}
    require(len(indexed) == len(selected), "Duplicate BAM run keys")
    return indexed

def same_prefix(left, right):
    def normalized(value):
        return float(value) if value is not None else math.inf
    a, b = map(json.loads, (left["incumbent_trajectory"], right["incumbent_trajectory"]))
    return len(a) >= 3 and len(b) >= 3 and all(
        normalized(x) == normalized(y) for x, y in zip(a[:3], b[:3])
    )

reference_commit = manifest["provenance"]["git"]["commit"]
grids = grid_benchmark.discover_grid_paths(root / "benchmark_grids")
require(len(grids) == 21, "Expected the original 21 grid problems")
grid_designs, expected_grid_keys = [], set()
for path in grids:
    relative = path.relative_to(root).as_posix()
    original = subprocess.run(
        ["git", "-C", str(root), "show", f"{reference_commit}:{relative}"],
        check=True, capture_output=True,
    ).stdout
    require(digest(path.read_bytes()) == digest(original), f"Original grid changed: {relative}")
    _, grid = grid_benchmark.load_grid_csv(path)
    lb, ub = grid_benchmark.grid_bounds(grid)
    for seed in range(10):
        points = generate_lhc_starting_points(len(lb), 3, lb, ub, seed)
        prefix = []
        for point in points:
            prefix.append(min(grid[point], prefix[-1] if prefix else math.inf))
        grid_designs.append({"csv_name": path.name, "seed": seed, "starting_points": points})
        for budget in (10, 30, 50, 70, 100):
            expected_grid_keys.add((path.name, seed, 3, budget))
        for row in (r for r in old_grids if r["csv_name"] == path.name and int(r["seed"]) == seed):
            require(same_prefix(row, {"incumbent_trajectory": json.dumps(prefix)}),
                    f"Original grid initial values differ: {path.name}, seed {seed}")
require(set(bam_rows(old_grids)) == expected_grid_keys, "Grid run matrix differs from reference")
require(len(bam_rows(old_cases)) == 139, "Expected 139 original BAM process runs")

report = {
    "reference": str(reference), "reference_commit": reference_commit,
    "reference_manifest_sha256": digest(manifest_bytes),
    "reference_grid_csv_sha256": digest(old_grid_bytes),
    "reference_case_csv_sha256": digest(old_cases_bytes),
    "numpy": importlib.metadata.version("numpy"),
    "scipy": importlib.metadata.version("scipy"),
    "process_designs": designs, "grid_designs": grid_designs,
    "expected_grid_runs": 1050, "expected_process_runs": 139,
}
if phase == "after":
    for filename, old_rows, expected_count in (
        ("benchmark.csv", old_grids, 1050),
        ("process_case_studies.csv", old_cases, 139),
    ):
        data = (Path(output) / filename).read_bytes()
        new_rows = read_rows(data)
        require(len(new_rows) == expected_count, f"Unexpected row count in {filename}")
        new, old = bam_rows(new_rows), bam_rows(old_rows)
        require(set(new) == set(old), f"BAM run keys differ in {filename}")
        for run_key, row in new.items():
            require(int(row["initial_evals"]) == 3, f"Wrong initial budget: {run_key}")
            require(3 <= int(row["total_evals"]) <= int(row["max_evals"]),
                    f"Evaluation budget exceeded: {run_key}")
            require(same_prefix(row, old[run_key]), f"Initial values changed: {run_key}")
        report[filename + "_sha256"] = digest(data)
    new_manifest = json.loads((Path(output) / "process_case_studies.manifest.json").read_text())
    require(new_manifest["run"]["status"] == "completed", "New process run is incomplete")
    require(new_manifest["run"]["completed_rows"] == 139
            and new_manifest["protocol"]["methods"] == ["bam"]
            and new_manifest["run"]["completed_run_keys"]
            == cases._planned_run_keys(matrix, ("bam",), 3),
            "New process manifest must describe exactly 139 BAM-only runs")
    require(new_manifest["output"]["csv_sha256"] == report["process_case_studies.csv_sha256"],
            "New process manifest checksum mismatch")
    require(new_manifest["provenance"]["initial_design"]["designs"] == designs,
            "New process run used different initial designs")
if output:
    name = "comparison_audit.json" if phase == "after" else "initial_design_audit.json"
    (Path(output) / name).write_text(json.dumps(report, indent=2) + "\n")
print("Verified: 89 process starting designs, 210 grid starting designs, "
      "and the original 1,189 BAM run configurations.")
DESIGN_AUDIT
}

if [[ "$MODE" != run ]]; then
  audit before
  printf 'Checks passed. Run: BAM_LICENSE_FILE=/absolute/path/bamlice.txt bash run_bam_dantzig.sh run\n'
  exit 0
fi

[[ -n "${BAM_LICENSE_FILE:-}" && -r "$BAM_LICENSE_FILE" && -f "$BAM_LICENSE_FILE" ]] ||
  fail "Set BAM_LICENSE_FILE to a readable license file; small_batch is 3D."
export BAM_LICENSE_FILE="$(python -c 'import os; print(os.path.abspath(os.environ["BAM_LICENSE_FILE"]))')"
export BENCH_CPU="${BENCH_CPU:-$(python -c 'import os; print(min(os.sched_getaffinity(0)))')}"
py() {
  python -c 'import os, sys
cpu = int(os.environ["BENCH_CPU"])
if cpu not in os.sched_getaffinity(0):
    raise SystemExit("BENCH_CPU is outside the permitted CPU set")
os.sched_setaffinity(0, {cpu})
os.execv(sys.executable, [sys.executable, "-u", *sys.argv[1:]])' "$@"
}

run_stage() {
  local stage_label="$1"
  shift
  py - "$RUN_DIR/run.log" "$stage_label" "$@" <<'SUPERVISOR'
import math
import os
import selectors
import signal
import subprocess
import sys
import time

log_path, label, *arguments = sys.argv[1:]
heartbeat = float(os.environ.get("DANTZIG_HEARTBEAT_SECONDS", "30"))
if not math.isfinite(heartbeat) or heartbeat <= 0:
    raise SystemExit("DANTZIG_HEARTBEAT_SECONDS must be a positive number")

with open(log_path, "ab", buffering=0) as logfile:
    def emit(data):
        logfile.write(data)
        try:
            sys.stdout.buffer.write(data)
            sys.stdout.buffer.flush()
        except OSError:
            pass

    def message(text):
        emit(("\n" + time.strftime("%Y-%m-%d %H:%M:%S") + " " + text + "\n").encode())

    def interrupted(*_):
        raise KeyboardInterrupt

    message(f"[START] {label}")
    child = subprocess.Popen(
        [sys.executable, "-u", *arguments], stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True,
    )
    started = last_output = last_heartbeat = time.monotonic()
    selector = selectors.DefaultSelector()
    selector.register(child.stdout, selectors.EVENT_READ)
    old_term = signal.signal(signal.SIGTERM, interrupted)
    exit_code = 1
    try:
        while True:
            events = selector.select(timeout=0.2)
            for key, _ in events:
                data = os.read(key.fd, 65536)
                if data:
                    emit(data)
                    last_output = time.monotonic()
                else:
                    selector.unregister(key.fileobj)
            if child.poll() is not None and not events:
                break
            now = time.monotonic()
            if child.poll() is None and now - last_heartbeat >= heartbeat:
                message(f"[HEARTBEAT] {label}: process alive; elapsed={now-started:.0f}s; "
                        f"last solver output={now-last_output:.0f}s ago; pid={child.pid}")
                last_heartbeat = now
        result = child.wait()
        exit_code = result if result >= 0 else 128 - result
        message(f"[EXIT] {label}: status={exit_code}; elapsed={time.monotonic()-started:.0f}s")
    except KeyboardInterrupt:
        message(f"[STOP] {label}: terminating this benchmark and its solver children")
        exit_code = 130
    finally:
        # Terminate only this stage's isolated process group.
        for sig in (signal.SIGTERM, signal.SIGKILL):
            try:
                os.killpg(child.pid, sig)
            except ProcessLookupError:
                break
            if sig == signal.SIGTERM:
                time.sleep(0.5)
        child.wait()
        child.stdout.close()
        selector.close()
        signal.signal(signal.SIGTERM, old_term)
    sys.exit(exit_code)
SUPERVISOR
}

mkdir -p "$ROOT/results"
RUN_DIR="$(mktemp -d "$ROOT/results/dantzig_bam_$(date +%Y%m%d_%H%M%S)_XXXXXX")"
mkdir -p "$RUN_DIR/work"
export MPLCONFIGDIR="$RUN_DIR/matplotlib-cache"
log() { printf '%s\n' "$*"; printf '%s\n' "$*" >> "$RUN_DIR/run.log"; }
trap 'log "Stopped at line $LINENO. Results/log: $RUN_DIR"' ERR
log "Results: $RUN_DIR"
log "BAM only: 1,050 grid runs and 139 process runs; 3 shared LHC starts per run."
log "CPU: $BENCH_CPU; numerical-library threads: 1."
git -C "$ROOT" rev-parse HEAD > "$RUN_DIR/git-commit.txt"
git -C "$ROOT" status --short > "$RUN_DIR/git-status.txt"
python -m pip freeze > "$RUN_DIR/python-packages.txt"
uname -a > "$RUN_DIR/platform.txt"
cp "${BASH_SOURCE[0]}" "$RUN_DIR/run-script.sh"
python -c 'import bam, importlib.metadata, json
print(json.dumps({"package": importlib.metadata.version("bam-solver"),
                  "native_solver": list(bam.Bam.get_solver_version())}, indent=2))' \
  > "$RUN_DIR/bam-version.json"
audit before "$RUN_DIR" | tee -a "$RUN_DIR/run.log"
cd "$RUN_DIR/work"

PREFLIGHT_CODE="$(cat <<'PREFLIGHT'
import math
import os
from case_studies.bam_common import run_bam_with_initial_design

result = run_bam_with_initial_design(
    objective=lambda x: float(sum((v - 1) ** 2 for v in x)),
    lower_bounds=[0, 0, 0], upper_bounds=[2, 2, 2],
    starting_points=[(0, 0, 0), (1, 1, 1), (2, 2, 2)],
    max_evaluations=7, bam_license_file=os.environ["BAM_LICENSE_FILE"],
)
if not math.isfinite(result["best_value"]) or not 3 <= result["tracked_evals"] <= 7:
    raise SystemExit("BAM warm-start/license/evaluation-budget check failed")
print("BAM 3D warm-start preflight passed.")
PREFLIGHT
)"
run_stage "BAM preflight" -c "$PREFLIGHT_CODE"

run_stage "[1/2] BAM grids" "$ROOT/benchmark.py" \
  --methods bam --seeds 0-9 --n-starts 3 --max-evals 10,30,50,70,100 \
  --grids-dir "$ROOT/benchmark_grids" --output "$RUN_DIR/benchmark.csv" \
  --bam-license-file "$BAM_LICENSE_FILE" --verbose

run_stage "[2/2] BAM process cases" "$ROOT/case_study_benchmark.py" \
  --cases column,cstr,small_batch,dynamic --methods bam \
  --seeds 0-9 --column-seeds 1-9 --n-starts 3 \
  --column-budgets 16 --cstr-grid-sizes 5,10,15,20,25,30 \
  --small-batch-budgets 10 --dynamic-budgets 12,15,20,30,37,50 \
  --max-run-seconds 1800 --output "$RUN_DIR/process_case_studies.csv" \
  --bam-license-file "$BAM_LICENSE_FILE" --verbose

audit after "$RUN_DIR" | tee -a "$RUN_DIR/run.log"
log "Finished. New BAM results and comparison audit: $RUN_DIR"
log "The original DSDA/RBFOpt/BAM results remain the reference for later comparisons."

