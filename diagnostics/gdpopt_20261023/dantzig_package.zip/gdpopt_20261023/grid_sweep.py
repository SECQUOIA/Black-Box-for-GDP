"""No solver: compare original/patched presolve with archived feasible callbacks."""
import csv
import json
import logging
import time
from grid_probe import ROOT, setup, p, preprocess_subproblem
from patches import apply_sin_patch


def sweep():
    started = time.monotonic()
    config = p.SolverFactory('gdpopt.gloa').config
    base, util = setup((0, 0))
    for d in util.disjunct_list:
        d.activate()
        d.binary_indicator_var.unfix()
    historical = {}
    for method in ['ric', 'gloa', 'loa']:
        events = [json.loads(x) for x in (ROOT / f'inputs/grid/benchmark/michalewicz/{method}/incumbents.jsonl').read_text().splitlines()]
        historical[method] = {
            tuple(int(s.split('[')[1][:-1]) for s in e['selected_disjuncts']): e['iteration']
            for e in events if e['iteration'] is not None}
    results = []
    for patched in [False, True]:
        restore = apply_sin_patch() if patched else lambda: None
        for i in range(31):
            for j in range(31):
                m = base.clone()
                u = m.find_component(util.name)
                for axis, selected in zip((m.Xchoice, m.Ychoice), (i, j)):
                    for index, d in axis.items():
                        d.binary_indicator_var.fix(int(index == selected))
                        if index != selected:
                            d.deactivate()
                with preprocess_subproblem(u, config) as ok:
                    results.append({'x': i, 'y': j, 'patched': patched, 'presolve_allows_solver': ok,
                                    **{f'{method}_historical_feasible_iteration': historical[method].get((i,j), '기록 없음')
                                       for method in historical}})
        restore()
    with (ROOT / 'grid_presolve_sweep.csv').open('w') as f:
        writer = csv.DictWriter(f, fieldnames=results[0]);writer.writeheader();writer.writerows(results)
    original = {(r['x'], r['y']) for r in results if not r['patched'] and r['presolve_allows_solver']}
    patched = {(r['x'], r['y']) for r in results if r['patched'] and r['presolve_allows_solver']}
    summary = {'solver_calls': 0, 'wall_s': time.monotonic()-started,
               'original_pass_count': len(original), 'patched_pass_count': len(patched),
               'historical_set_exact_match': {method: original == set(points) for method, points in historical.items()},
               'patched_failures': sorted(set((i,j) for i in range(31) for j in range(31))-patched)}
    (ROOT/'grid_presolve_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))


if __name__ == '__main__':
    logging.getLogger('pyomo').setLevel(logging.ERROR)
    sweep()
