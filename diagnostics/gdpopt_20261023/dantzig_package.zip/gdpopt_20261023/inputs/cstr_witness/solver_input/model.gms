$offlisting
$offdigit

EQUATIONS
	c1
	c2
	c3
	c4
	c5
	c6
	c7
	c8
	c9
	c10
	c11
	c12
	c13
	c14
	c15
	c16
	c17
	c18
	c19
	c20
	c21
	c22
	c23
	c24
	c25
	c26
	c27
	c28
	c29
	c30
	c31
	c32
	c33
	c34
	c35
	c36
	c37
	c38
	c39
	c40
	c41
	c42
	c43
	c44
	c45
	c46
	c47
	c48
	c49
	c50
	c51
	c52
	c53
	c54
	c55
	c56
	c57
	c58
	c59
	c60
	c61
	c62
	c63
	c64
	c65
	c66
	c67
	c68
	c69
	c70
	c71
	c72
	c73
	c74
	c75
	c76
	c77
	c78
	c79
	c80
	c81
	c82
	c83
	c84
	c85
	c86
	c87
	c88
	c89
	c90
	c91
	c92
	c93
	c94
	c95
	c96
	c97
	c98
	c99
	c100
	c101
	c102
	c103
	c104
	c105
	c106
	c107
	c108
	c109
	c110
	c111
	c112
	c113
	c114
	c115
	c116
	c117
	c118
	c119
	c120
	c121
	c122
	c123
	c124
	c125
	c126
	c127
	c128
	c129
	c130
	c131
	c132
	c133
	c134
	c135
	c136
	c137
	c138
	c139
	c140
	c141
	c142
	c143
	c144
	c145
	c146
	c147
	c148
	c149
	c150
	c151
	c152
	c153
	c154
	c155
	c156_lo
	c157_lo
	c158_lo
	c159_lo
	c160_lo
	c161_lo
	c162_lo
	c163_lo
	c164_lo
	c165_lo
	c166_lo
	c167_lo
	c168_lo
	c169_lo
	c170_lo
	c171_lo
	c172_lo
	c173_lo
	c174_lo
	c175_lo
	c176_lo
	c177_lo
	c178_lo
	c179_lo
	c180_lo
	c181_lo
	c182_lo
	c183_lo
	c184_lo
	c185_lo
	c186_lo
	c187_lo
	c188_lo
	c189_lo
	c190_lo
	c191_lo
	c192_lo
	c193_lo
	c194_lo
	c195_lo
	c196_lo
	c197_lo
	c198_lo
	c199_lo
	c200_lo
	c201_lo
	c202_lo
	c203_lo
	c204_lo
	c205_lo
	c206_lo
	c207_lo
	c208_lo
	c209_lo
	c210_lo
	c211_lo
	c212_lo
	c213_lo
	c214_lo
	c215_lo
	c216_lo
	c217_lo
	c218_lo
	c219_lo
	c220_lo
	c221_lo
	c222_lo
	c223_lo
	c224_lo
	c225_lo
	c226_lo
	c227_lo
	c228_lo
	c229_lo
	c230_lo
	c231_lo
	c232_lo
	c233_lo
	c234_lo
	c235_lo
	c236_lo
	c237_lo
	c238_lo
	c239_lo
	c240_lo
	c241_lo
	c242_lo
	c243_lo
	c244_lo
	c245_lo
	c246_lo
	c247_lo
	c248_lo
	c249_lo
	c250_lo
	c251_lo
	c252_lo
	c253_lo
	c254_lo
	c255_lo
	c256_lo
	c257_lo
	c258_lo
	c259_lo
	c260_lo
	c261_lo
	c262_lo
	c263_lo
	c264_lo
	c265_lo
	c266_lo
	c267_lo
	c268_lo
	c269_lo
	c270_lo
	c271_lo
	c272_lo
	c273_lo
	c274_lo
	c275_lo
	c276_lo
	c277_lo
	c278_lo
	c279_lo
	c280_lo
	c281_lo
	c282_lo
	c283_lo
	c284_lo
	c285_lo
	c286_lo
	c287_lo
	c288_lo
	c289_lo
	c290_lo
	c291_lo
	c292_lo
	c293_lo
	c294_lo
	c295_lo
	c296_lo
	c297_lo
	c298_lo
	c299_lo
	c300_lo
	c301_lo
	c302_lo
	c303_lo
	c304;

POSITIVE VARIABLES
	x1
	x2
	x4
	x5
	x6
	x8
	x10
	x11
	x12
	x14
	x15
	x16
	x18
	x19
	x20
	x22
	x23
	x24
	x26
	x27
	x28
	x30
	x31
	x32
	x34
	x35
	x36
	x38
	x39
	x40
	x42
	x43
	x44
	x46
	x47
	x48
	x50
	x51
	x52
	x54
	x55
	x56
	x58
	x59
	x60
	x62
	x63
	x65
	x66
	x67
	x68
	x70
	x71
	x73
	x74
	x76
	x77
	x79
	x80
	x82
	x83
	x85
	x86
	x88
	x89
	x91
	x92
	x94
	x95
	x97
	x98
	x100
	x101
	x103
	x104
	x106
	x109
	x112
	x114
	x116
	x118
	x120
	x122
	x124
	x126
	x128
	x130
	x132
	x134
	x135
	x136
	x137
	x138
	x139
	x140
	x141
	x142
	x143
	x144
	x145
	x146
	x147
	x148
	x149
	x150
	x151
	x152
	x153
	x154
	x155
	x156;

VARIABLES
	GAMS_OBJECTIVE
	x3
	x7
	x9
	x13
	x17
	x21
	x25
	x29
	x33
	x37
	x41
	x45
	x49
	x53
	x57
	x61
	x64
	x69
	x72
	x75
	x78
	x81
	x84
	x87
	x90
	x93
	x96
	x99
	x102
	x105
	x107
	x108
	x110
	x111
	x113
	x115
	x117
	x119
	x121
	x123
	x125
	x127
	x129
	x131
	x133;


c1.. 0.98999999999999999 + x1 - x2 + x3*x4 =e= 0 ;
c2.. 0.01 + x5 - x6 + x7*x4 =e= 0 ;
c3.. 1 + x8 - x9 =e= 0 ;
c4.. x10 + x11 - x12 + x13*x14 =e= 0 ;
c5.. x15 + x16 - x10 + x17*x18 =e= 0 ;
c6.. x19 + x20 - x15 + x21*x22 =e= 0 ;
c7.. x23 + x24 - x19 + x25*x26 =e= 0 ;
c8.. x27 + x28 - x23 + x29*x30 =e= 0 ;
c9.. x31 + x32 - x27 + x33*x34 =e= 0 ;
c10.. x35 + x36 - x31 + x37*x38 =e= 0 ;
c11.. x39 + x40 - x35 + x41*x42 =e= 0 ;
c12.. x43 + x44 - x39 + x45*x46 =e= 0 ;
c13.. x47 + x48 - x43 + x49*x50 =e= 0 ;
c14.. x51 + x52 - x47 + x53*x54 =e= 0 ;
c15.. x55 + x56 - x51 + x57*x58 =e= 0 ;
c16.. x59 + x60 - x55 + x61*x62 =e= 0 ;
c17.. x2 + x63 - x59 + x64*x65 =e= 0 ;
c18.. x66 + x67 - x68 + x69*x14 =e= 0 ;
c19.. x70 + x71 - x66 + x72*x18 =e= 0 ;
c20.. x73 + x74 - x70 + x75*x22 =e= 0 ;
c21.. x76 + x77 - x73 + x78*x26 =e= 0 ;
c22.. x79 + x80 - x76 + x81*x30 =e= 0 ;
c23.. x82 + x83 - x79 + x84*x34 =e= 0 ;
c24.. x85 + x86 - x82 + x87*x38 =e= 0 ;
c25.. x88 + x89 - x85 + x90*x42 =e= 0 ;
c26.. x91 + x92 - x88 + x93*x46 =e= 0 ;
c27.. x94 + x95 - x91 + x96*x50 =e= 0 ;
c28.. x97 + x98 - x94 + x99*x54 =e= 0 ;
c29.. x100 + x101 - x97 + x102*x58 =e= 0 ;
c30.. x103 + x104 - x100 + x105*x62 =e= 0 ;
c31.. x6 + x106 - x103 + x107*x65 =e= 0 ;
c32.. x108 + x109 - x110 =e= 0 ;
c33.. x111 + x112 - x108 =e= 0 ;
c34.. x113 + x114 - x111 =e= 0 ;
c35.. x115 + x116 - x113 =e= 0 ;
c36.. x117 + x118 - x115 =e= 0 ;
c37.. x119 + x120 - x117 =e= 0 ;
c38.. x121 + x122 - x119 =e= 0 ;
c39.. x123 + x124 - x121 =e= 0 ;
c40.. x125 + x126 - x123 =e= 0 ;
c41.. x127 + x128 - x125 =e= 0 ;
c42.. x129 + x130 - x127 =e= 0 ;
c43.. x131 + x132 - x129 =e= 0 ;
c44.. x133 + x134 - x131 =e= 0 ;
c45.. x9 + x135 - x133 =e= 0 ;
c46.. x12 - x136 - x137 =e= 0 ;
c47.. x68 - x138 - x139 =e= 0 ;
c48.. x110 - x140 - x141 =e= 0 ;
c49.. x136*x110 - x12*x140 =e= 0 ;
c50.. x138*x110 - x68*x140 =e= 0 ;
c51.. 0.94999999999999996*x140 - x138 =e= 0 ;
c52.. x18 - x14 =e= 0 ;
c53.. x22 - x18 =e= 0 ;
c54.. x26 - x22 =e= 0 ;
c55.. x30 - x26 =e= 0 ;
c56.. x34 - x30 =e= 0 ;
c57.. x38 - x34 =e= 0 ;
c58.. x42 - x38 =e= 0 ;
c59.. x46 - x42 =e= 0 ;
c60.. x50 - x46 =e= 0 ;
c61.. x54 - x50 =e= 0 ;
c62.. x58 - x54 =e= 0 ;
c63.. x62 - x58 =e= 0 ;
c64.. x65 - x62 =e= 0 ;
c65.. x4 - x65 =e= 0 ;
c66.. x1 - x137 =e= 0 ;
c67.. x5 - x139 =e= 0 ;
c68.. x8 - x141 =e= 0 ;
c69.. x11 =e= 0 ;
c70.. x67 =e= 0 ;
c71.. x109 =e= 0 ;
c72.. x16 =e= 0 ;
c73.. x71 =e= 0 ;
c74.. x112 =e= 0 ;
c75.. x20 =e= 0 ;
c76.. x74 =e= 0 ;
c77.. x114 =e= 0 ;
c78.. x24 =e= 0 ;
c79.. x77 =e= 0 ;
c80.. x116 =e= 0 ;
c81.. x28 =e= 0 ;
c82.. x80 =e= 0 ;
c83.. x118 =e= 0 ;
c84.. x32 =e= 0 ;
c85.. x83 =e= 0 ;
c86.. x120 =e= 0 ;
c87.. x36 =e= 0 ;
c88.. x86 =e= 0 ;
c89.. x122 =e= 0 ;
c90.. x40 =e= 0 ;
c91.. x89 =e= 0 ;
c92.. x124 =e= 0 ;
c93.. x44 =e= 0 ;
c94.. x92 =e= 0 ;
c95.. x126 =e= 0 ;
c96.. x48 =e= 0 ;
c97.. x95 =e= 0 ;
c98.. x128 =e= 0 ;
c99.. x52 =e= 0 ;
c100.. x98 =e= 0 ;
c101.. x130 =e= 0 ;
c102.. x56 =e= 0 ;
c103.. x101 =e= 0 ;
c104.. x132 =e= 0 ;
c105.. x60 =e= 0 ;
c106.. x104 =e= 0 ;
c107.. x134 =e= 0 ;
c108.. x63 =e= 0 ;
c109.. x106 =e= 0 ;
c110.. x135 =e= 0 ;
c111.. x13*x110*x110 + 2*x12*x68 =e= 0 ;
c112.. x69 + x13 =e= 0 ;
c113.. x142 - x14 =e= 0 ;
c114.. x17*x108*x108 + 2*x10*x66 =e= 0 ;
c115.. x72 + x17 =e= 0 ;
c116.. x143 - x18 =e= 0 ;
c117.. x21*x111*x111 + 2*x15*x70 =e= 0 ;
c118.. x75 + x21 =e= 0 ;
c119.. x144 - x22 =e= 0 ;
c120.. x25*x113*x113 + 2*x19*x73 =e= 0 ;
c121.. x78 + x25 =e= 0 ;
c122.. x145 - x26 =e= 0 ;
c123.. x29*x115*x115 + 2*x23*x76 =e= 0 ;
c124.. x81 + x29 =e= 0 ;
c125.. x146 - x30 =e= 0 ;
c126.. x33*x117*x117 + 2*x27*x79 =e= 0 ;
c127.. x84 + x33 =e= 0 ;
c128.. x147 - x34 =e= 0 ;
c129.. x37*x119*x119 + 2*x31*x82 =e= 0 ;
c130.. x87 + x37 =e= 0 ;
c131.. x148 - x38 =e= 0 ;
c132.. x41*x121*x121 + 2*x35*x85 =e= 0 ;
c133.. x90 + x41 =e= 0 ;
c134.. x149 - x42 =e= 0 ;
c135.. x45*x123*x123 + 2*x39*x88 =e= 0 ;
c136.. x93 + x45 =e= 0 ;
c137.. x150 - x46 =e= 0 ;
c138.. x49*x125*x125 + 2*x43*x91 =e= 0 ;
c139.. x96 + x49 =e= 0 ;
c140.. x151 - x50 =e= 0 ;
c141.. x53*x127*x127 + 2*x47*x94 =e= 0 ;
c142.. x99 + x53 =e= 0 ;
c143.. x152 - x54 =e= 0 ;
c144.. x57*x129*x129 + 2*x51*x97 =e= 0 ;
c145.. x102 + x57 =e= 0 ;
c146.. x153 - x58 =e= 0 ;
c147.. x61*x131*x131 + 2*x55*x100 =e= 0 ;
c148.. x105 + x61 =e= 0 ;
c149.. x154 - x62 =e= 0 ;
c150.. x64*x133*x133 + 2*x59*x103 =e= 0 ;
c151.. x107 + x64 =e= 0 ;
c152.. x155 - x65 =e= 0 ;
c153.. x3*x9*x9 + 2*x2*x6 =e= 0 ;
c154.. x7 + x3 =e= 0 ;
c155.. x156 - x4 =e= 0 ;
c156_lo.. 1 =l= 1 + 0 + 1 ;
c157_lo.. 1 =l= 1 + 0 + 1 ;
c158_lo.. 1 =l= 1 + 0 + 1 ;
c159_lo.. 1 =l= 1 + 0 + 1 ;
c160_lo.. 1 =l= 1 + 0 + 1 ;
c161_lo.. 1 =l= 1 + 0 + 1 ;
c162_lo.. 1 =l= 1 + 0 + 1 ;
c163_lo.. 1 =l= 1 + 0 + 1 ;
c164_lo.. 1 =l= 1 + 0 + 1 ;
c165_lo.. 1 =l= 1 + 0 + 1 ;
c166_lo.. 1 =l= 1 + 0 + 1 ;
c167_lo.. 1 =l= 1 + 0 + 1 ;
c168_lo.. 1 =l= 1 + 0 + 1 ;
c169_lo.. 1 =l= 1 + 0 + 1 ;
c170_lo.. 1 =l= 1 + (-1) + 1 ;
c171_lo.. 1 =l= 1 + 0 ;
c172_lo.. 1 =l= 1 + 0 + 1 ;
c173_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c174_lo.. 1 =l= 1 + 0 + 1 ;
c175_lo.. 1 =l= 1 + 0 + 0 ;
c176_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c177_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c178_lo.. 1 =l= 1 + 0 + 1 ;
c179_lo.. 1 =l= 1 + 0 + 0 + 0 ;
c180_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c181_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c182_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c183_lo.. 1 =l= 1 + 0 + 1 ;
c184_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c185_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c186_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c187_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c188_lo.. 1 =l= 1 + 0 + 0 + 0 + 0 ;
c189_lo.. 1 =l= 1 + 0 + 1 ;
c190_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c191_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c192_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c193_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c194_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c195_lo.. 1 =l= 1 + 0 + 0 + 0 + 0 + 0 ;
c196_lo.. 1 =l= 1 + 0 + 1 ;
c197_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c198_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c199_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c200_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c201_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c202_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c203_lo.. 1 =l= 1 + 0 + 0 + 0 + 0 + 0 + 0 ;
c204_lo.. 1 =l= 1 + 0 + 1 ;
c205_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c206_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c207_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c208_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c209_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c210_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c211_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c212_lo.. 1 =l= 1 + 0 + 0 + 0 + 0 + 0 + 0 + 0 ;
c213_lo.. 1 =l= 1 + 0 + 1 ;
c214_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c215_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c216_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c217_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c218_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c219_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c220_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c221_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c222_lo.. 1 =l= 1 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 ;
c223_lo.. 1 =l= 1 + 0 + 1 ;
c224_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c225_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c226_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c227_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c228_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c229_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c230_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c231_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c232_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c233_lo.. 1 =l= 1 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 ;
c234_lo.. 1 =l= 1 + 0 + 1 ;
c235_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c236_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c237_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c238_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c239_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c240_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c241_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c242_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c243_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c244_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c245_lo.. 1 =l= 1 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 ;
c246_lo.. 1 =l= 1 + 0 + 1 ;
c247_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c248_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c249_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c250_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c251_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c252_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c253_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c254_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c255_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c256_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c257_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c258_lo.. 1 =l= 1 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 ;
c259_lo.. 1 =l= 1 + 0 + 1 ;
c260_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c261_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c262_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c263_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c264_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c265_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c266_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c267_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c268_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c269_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c270_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c271_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c272_lo.. 1 =l= 1 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 ;
c273_lo.. 1 =l= 1 + 0 + 1 ;
c274_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c275_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c276_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c277_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c278_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c279_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c280_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c281_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c282_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c283_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c284_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c285_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c286_lo.. 1 =l= 1 + (-1) + 0 + 1 + 0 ;
c287_lo.. 1 =l= 1 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 ;
c288_lo.. 1 =l= 1 + (-1) + 1 ;
c289_lo.. 1 =l= 1 + (-1) + 1 + 1 + 0 ;
c290_lo.. 1 =l= 1 + (-1) + 1 + 1 + 0 ;
c291_lo.. 1 =l= 1 + (-1) + 1 + 1 + 0 ;
c292_lo.. 1 =l= 1 + (-1) + 1 + 1 + 0 ;
c293_lo.. 1 =l= 1 + (-1) + 1 + 1 + 0 ;
c294_lo.. 1 =l= 1 + (-1) + 1 + 1 + 0 ;
c295_lo.. 1 =l= 1 + (-1) + 1 + 1 + 0 ;
c296_lo.. 1 =l= 1 + (-1) + 1 + 1 + 0 ;
c297_lo.. 1 =l= 1 + (-1) + 1 + 1 + 0 ;
c298_lo.. 1 =l= 1 + (-1) + 1 + 1 + 0 ;
c299_lo.. 1 =l= 1 + (-1) + 1 + 1 + 0 ;
c300_lo.. 1 =l= 1 + (-1) + 1 + 1 + 0 ;
c301_lo.. 1 =l= 1 + (-1) + 1 + 1 + 0 ;
c302_lo.. 1 =l= 1 + (-1) + 1 + 1 + 0 ;
c303_lo.. 1 =l= 1 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 + 0 ;
c304.. GAMS_OBJECTIVE =e= x142 + x143 + x144 + x145 + x146 + x147 + x148 + x149 + x150 + x151 + x152 + x153 + x154 + x155 + x156 ;

x1.up = 10;
x1.l = 0.012276409955186;
x2.up = 10;
x2.l = 0.93108149212920299;
x4.up = 10;
x4.l = 0.18862337454907599;
x5.up = 10;
x5.l = 0.23324199491819;
x6.up = 10;
x6.l = 0.314437035685385;
x8.up = 9;
x8.l = 0.24551780537241799;
x10.up = 10;
x10.l = 0.080197985894675999;
x11.up = 10;
x11.l = 0;
x12.up = 10;
x12.l = 0.062278060199071998;
x14.up = 10;
x14.l = 0.18862337454907599;
x15.up = 10;
x15.l = 0.10292470695733;
x16.up = 10;
x16.l = 0;
x18.up = 10;
x18.l = 0.18862337454907599;
x19.up = 10;
x19.l = 0.13152295607900699;
x20.up = 10;
x20.l = 0;
x22.up = 10;
x22.l = 0.18862337454907599;
x23.up = 10;
x23.l = 0.167152722810683;
x24.up = 10;
x24.l = 0;
x26.up = 10;
x26.l = 0.18862337454907599;
x27.up = 10;
x27.l = 0.210986363370071;
x28.up = 10;
x28.l = 0;
x30.up = 10;
x30.l = 0.18862337454907599;
x31.up = 10;
x31.l = 0.26406581027207299;
x32.up = 10;
x32.l = 0;
x34.up = 10;
x34.l = 0.18862337454907599;
x35.up = 10;
x35.l = 0.327090335160582;
x36.up = 10;
x36.l = 0;
x38.up = 10;
x38.l = 0.18862337454907599;
x39.up = 10;
x39.l = 0.400143822588917;
x40.up = 10;
x40.l = 0;
x42.up = 10;
x42.l = 0.18862337454907599;
x43.up = 10;
x43.l = 0.482404712242046;
x44.up = 10;
x44.l = 0;
x46.up = 10;
x46.l = 0.18862337454907599;
x47.up = 10;
x47.l = 0.571926528611842;
x48.up = 10;
x48.l = 0;
x50.up = 10;
x50.l = 0.18862337454907599;
x51.up = 10;
x51.l = 0.6656104707909169;
x52.up = 10;
x52.l = 0;
x54.up = 10;
x54.l = 0.18862337454907599;
x55.up = 10;
x55.l = 0.759476244352939;
x56.up = 10;
x56.l = 0;
x58.up = 10;
x58.l = 0.18862337454907599;
x59.up = 10;
x59.l = 0.849243127341302;
x60.up = 10;
x60.l = 0;
x62.up = 10;
x62.l = 0.18862337454907599;
x63.up = 10;
x63.l = 0;
x65.up = 10;
x65.l = 0.18862337454907599;
x66.up = 10;
x66.l = 1.165321930154751;
x67.up = 10;
x67.l = 0;
x68.up = 10;
x68.l = 1.183241928722817;
x70.up = 10;
x70.l = 1.142595124391784;
x71.up = 10;
x71.l = 0;
x73.up = 10;
x73.l = 1.113996784160153;
x74.up = 10;
x74.l = 0;
x76.up = 10;
x76.l = 1.078366891318518;
x77.up = 10;
x77.l = 0;
x79.up = 10;
x79.l = 1.034533154022015;
x80.up = 10;
x80.l = 0;
x82.up = 10;
x82.l = 0.981453606947987;
x83.up = 10;
x83.l = 0;
x85.up = 10;
x85.l = 0.91842897896276698;
x86.up = 10;
x86.l = 0;
x88.up = 10;
x88.l = 0.845375385880735;
x89.up = 10;
x89.l = 0;
x91.up = 10;
x91.l = 0.7631143882667249;
x92.up = 10;
x92.l = 0;
x94.up = 10;
x94.l = 0.6735924617762949;
x95.up = 10;
x95.l = 0;
x97.up = 10;
x97.l = 0.57990840519529496;
x98.up = 10;
x98.l = 0;
x100.up = 10;
x100.l = 0.486042519426135;
x101.up = 10;
x101.l = 0;
x103.up = 10;
x103.l = 0.39627551975115999;
x104.up = 10;
x104.l = 0;
x106.up = 10;
x106.l = 0;
x109.up = 9;
x109.l = 0;
x112.up = 9;
x112.l = 0;
x114.up = 9;
x114.l = 0;
x116.up = 9;
x116.l = 0;
x118.up = 9;
x118.l = 0;
x120.up = 9;
x120.l = 0;
x122.up = 9;
x122.l = 0;
x124.up = 9;
x124.l = 0;
x126.up = 9;
x126.l = 0;
x128.up = 9;
x128.l = 0;
x130.up = 9;
x130.l = 0;
x132.up = 9;
x132.l = 0;
x134.up = 9;
x134.l = 0;
x135.up = 9;
x135.l = 0;
x136.up = 10;
x136.l = 0.050001706008645;
x137.up = 10;
x137.l = 0.012276409955186;
x138.up = 9.5;
x138.l = 0.94999999999999996;
x139.up = 10;
x139.l = 0.23324199491819;
x140.up = 10;
x140.l = 1;
x141.up = 10;
x141.l = 0.24551780537241799;
x142.up = 10;
x142.l = 0.18862337454907599;
x143.up = 10;
x143.l = 0.18862337454907599;
x144.up = 10;
x144.l = 0.18862337454907599;
x145.up = 10;
x145.l = 0.18862337454907599;
x146.up = 10;
x146.l = 0.18862337454907599;
x147.up = 10;
x147.l = 0.18862337454907599;
x148.up = 10;
x148.l = 0.18862337454907599;
x149.up = 10;
x149.l = 0.18862337454907599;
x150.up = 10;
x150.l = 0.18862337454907599;
x151.up = 10;
x151.l = 0.18862337454907599;
x152.up = 10;
x152.l = 0.18862337454907599;
x153.up = 10;
x153.l = 0.18862337454907599;
x154.up = 10;
x154.l = 0.18862337454907599;
x155.up = 10;
x155.l = 0.18862337454907599;
x156.up = 10;
x156.l = 0.18862337454907599;
x3.lo = -10;
x3.up = 10;
x3.l = -0.37744311091770599;
x7.lo = -10;
x7.up = 10;
x7.l = 0.37744311091770599;
x9.lo = 1;
x9.up = 10;
x9.l = 1.245517805372418;
x13.lo = -10;
x13.up = 10;
x13.l = -0.095003341135379;
x17.lo = -10;
x17.up = 10;
x17.l = -0.120486821640815;
x21.lo = -10;
x21.up = 10;
x21.l = -0.15161495007814399;
x25.lo = -10;
x25.up = 10;
x25.l = -0.188892943555139;
x29.lo = -10;
x29.up = 10;
x29.l = -0.232386084026629;
x33.lo = -10;
x33.up = 10;
x33.l = -0.28140312500109399;
x37.lo = -10;
x37.up = 10;
x37.l = -0.334127380694455;
x41.lo = -10;
x41.up = 10;
x41.l = -0.38729609412397598;
x45.lo = -10;
x45.up = 10;
x45.l = -0.436109784732075;
x49.lo = -10;
x49.up = 10;
x49.l = -0.47460389592489799;
x53.lo = -10;
x53.up = 10;
x53.l = -0.496669912317388;
x57.lo = -10;
x57.up = 10;
x57.l = -0.497633565002774;
x61.lo = -10;
x61.up = 10;
x61.l = -0.475903142895273;
x64.lo = -10;
x64.up = 10;
x64.l = -0.433869779144965;
x69.lo = -10;
x69.up = 10;
x69.l = 0.095003341135379;
x72.lo = -10;
x72.up = 10;
x72.l = 0.120486821640815;
x75.lo = -10;
x75.up = 10;
x75.l = 0.15161495007814399;
x78.lo = -10;
x78.up = 10;
x78.l = 0.188892943555139;
x81.lo = -10;
x81.up = 10;
x81.l = 0.232386084026629;
x84.lo = -10;
x84.up = 10;
x84.l = 0.28140312500109399;
x87.lo = -10;
x87.up = 10;
x87.l = 0.334127380694455;
x90.lo = -10;
x90.up = 10;
x90.l = 0.38729609412397598;
x93.lo = -10;
x93.up = 10;
x93.l = 0.436109784732075;
x96.lo = -10;
x96.up = 10;
x96.l = 0.47460389592489799;
x99.lo = -10;
x99.up = 10;
x99.l = 0.496669912317388;
x102.lo = -10;
x102.up = 10;
x102.l = 0.497633565002774;
x105.lo = -10;
x105.up = 10;
x105.l = 0.475903142895273;
x107.lo = -10;
x107.up = 10;
x107.l = 0.433869779144965;
x108.lo = 1;
x108.up = 10;
x108.l = 1.245517805372418;
x110.lo = 1;
x110.up = 10;
x110.l = 1.245517805372418;
x111.lo = 1;
x111.up = 10;
x111.l = 1.245517805372418;
x113.lo = 1;
x113.up = 10;
x113.l = 1.245517805372418;
x115.lo = 1;
x115.up = 10;
x115.l = 1.245517805372418;
x117.lo = 1;
x117.up = 10;
x117.l = 1.245517805372418;
x119.lo = 1;
x119.up = 10;
x119.l = 1.245517805372418;
x121.lo = 1;
x121.up = 10;
x121.l = 1.245517805372418;
x123.lo = 1;
x123.up = 10;
x123.l = 1.245517805372418;
x125.lo = 1;
x125.up = 10;
x125.l = 1.245517805372418;
x127.lo = 1;
x127.up = 10;
x127.l = 1.245517805372418;
x129.lo = 1;
x129.up = 10;
x129.l = 1.245517805372418;
x131.lo = 1;
x131.up = 10;
x131.l = 1.245517805372418;
x133.lo = 1;
x133.up = 10;
x133.l = 1.245517805372418;

MODEL GAMS_MODEL /all/ ;
option nlp=ipopt;
option solprint=off;
option limrow=0;
option limcol=0;
option solvelink=5;

* START USER ADDITIONAL OPTIONS

option reslim=290;
option iterlim=3000;
option threads=1;
GAMS_MODEL.optfile=1;

* END USER ADDITIONAL OPTIONS

SOLVE GAMS_MODEL USING nlp minimizing GAMS_OBJECTIVE;

Scalars MODELSTAT 'model status', SOLVESTAT 'solve status';
MODELSTAT = GAMS_MODEL.modelstat;
SOLVESTAT = GAMS_MODEL.solvestat;

Scalar OBJEST 'best objective', OBJVAL 'objective value';
OBJEST = GAMS_MODEL.objest;
OBJVAL = GAMS_MODEL.objval;

Scalar NUMVAR 'number of variables';
NUMVAR = GAMS_MODEL.numvar

Scalar NUMEQU 'number of equations';
NUMEQU = GAMS_MODEL.numequ

Scalar NUMDVAR 'number of discrete variables';
NUMDVAR = GAMS_MODEL.numdvar

Scalar NUMNZ 'number of nonzeros';
NUMNZ = GAMS_MODEL.numnz

Scalar ETSOLVE 'time to execute solve statement';
ETSOLVE = GAMS_MODEL.etsolve


file results /'results.dat'/;
results.nd=17;
results.nw=26;
put results;
put 'SYMBOL  :  LEVEL  :  MARGINAL' /;
put x1 ' ' x1.l ' ' x1.m /;
put x2 ' ' x2.l ' ' x2.m /;
put x3 ' ' x3.l ' ' x3.m /;
put x4 ' ' x4.l ' ' x4.m /;
put x5 ' ' x5.l ' ' x5.m /;
put x6 ' ' x6.l ' ' x6.m /;
put x7 ' ' x7.l ' ' x7.m /;
put x8 ' ' x8.l ' ' x8.m /;
put x9 ' ' x9.l ' ' x9.m /;
put x10 ' ' x10.l ' ' x10.m /;
put x11 ' ' x11.l ' ' x11.m /;
put x12 ' ' x12.l ' ' x12.m /;
put x13 ' ' x13.l ' ' x13.m /;
put x14 ' ' x14.l ' ' x14.m /;
put x15 ' ' x15.l ' ' x15.m /;
put x16 ' ' x16.l ' ' x16.m /;
put x17 ' ' x17.l ' ' x17.m /;
put x18 ' ' x18.l ' ' x18.m /;
put x19 ' ' x19.l ' ' x19.m /;
put x20 ' ' x20.l ' ' x20.m /;
put x21 ' ' x21.l ' ' x21.m /;
put x22 ' ' x22.l ' ' x22.m /;
put x23 ' ' x23.l ' ' x23.m /;
put x24 ' ' x24.l ' ' x24.m /;
put x25 ' ' x25.l ' ' x25.m /;
put x26 ' ' x26.l ' ' x26.m /;
put x27 ' ' x27.l ' ' x27.m /;
put x28 ' ' x28.l ' ' x28.m /;
put x29 ' ' x29.l ' ' x29.m /;
put x30 ' ' x30.l ' ' x30.m /;
put x31 ' ' x31.l ' ' x31.m /;
put x32 ' ' x32.l ' ' x32.m /;
put x33 ' ' x33.l ' ' x33.m /;
put x34 ' ' x34.l ' ' x34.m /;
put x35 ' ' x35.l ' ' x35.m /;
put x36 ' ' x36.l ' ' x36.m /;
put x37 ' ' x37.l ' ' x37.m /;
put x38 ' ' x38.l ' ' x38.m /;
put x39 ' ' x39.l ' ' x39.m /;
put x40 ' ' x40.l ' ' x40.m /;
put x41 ' ' x41.l ' ' x41.m /;
put x42 ' ' x42.l ' ' x42.m /;
put x43 ' ' x43.l ' ' x43.m /;
put x44 ' ' x44.l ' ' x44.m /;
put x45 ' ' x45.l ' ' x45.m /;
put x46 ' ' x46.l ' ' x46.m /;
put x47 ' ' x47.l ' ' x47.m /;
put x48 ' ' x48.l ' ' x48.m /;
put x49 ' ' x49.l ' ' x49.m /;
put x50 ' ' x50.l ' ' x50.m /;
put x51 ' ' x51.l ' ' x51.m /;
put x52 ' ' x52.l ' ' x52.m /;
put x53 ' ' x53.l ' ' x53.m /;
put x54 ' ' x54.l ' ' x54.m /;
put x55 ' ' x55.l ' ' x55.m /;
put x56 ' ' x56.l ' ' x56.m /;
put x57 ' ' x57.l ' ' x57.m /;
put x58 ' ' x58.l ' ' x58.m /;
put x59 ' ' x59.l ' ' x59.m /;
put x60 ' ' x60.l ' ' x60.m /;
put x61 ' ' x61.l ' ' x61.m /;
put x62 ' ' x62.l ' ' x62.m /;
put x63 ' ' x63.l ' ' x63.m /;
put x64 ' ' x64.l ' ' x64.m /;
put x65 ' ' x65.l ' ' x65.m /;
put x66 ' ' x66.l ' ' x66.m /;
put x67 ' ' x67.l ' ' x67.m /;
put x68 ' ' x68.l ' ' x68.m /;
put x69 ' ' x69.l ' ' x69.m /;
put x70 ' ' x70.l ' ' x70.m /;
put x71 ' ' x71.l ' ' x71.m /;
put x72 ' ' x72.l ' ' x72.m /;
put x73 ' ' x73.l ' ' x73.m /;
put x74 ' ' x74.l ' ' x74.m /;
put x75 ' ' x75.l ' ' x75.m /;
put x76 ' ' x76.l ' ' x76.m /;
put x77 ' ' x77.l ' ' x77.m /;
put x78 ' ' x78.l ' ' x78.m /;
put x79 ' ' x79.l ' ' x79.m /;
put x80 ' ' x80.l ' ' x80.m /;
put x81 ' ' x81.l ' ' x81.m /;
put x82 ' ' x82.l ' ' x82.m /;
put x83 ' ' x83.l ' ' x83.m /;
put x84 ' ' x84.l ' ' x84.m /;
put x85 ' ' x85.l ' ' x85.m /;
put x86 ' ' x86.l ' ' x86.m /;
put x87 ' ' x87.l ' ' x87.m /;
put x88 ' ' x88.l ' ' x88.m /;
put x89 ' ' x89.l ' ' x89.m /;
put x90 ' ' x90.l ' ' x90.m /;
put x91 ' ' x91.l ' ' x91.m /;
put x92 ' ' x92.l ' ' x92.m /;
put x93 ' ' x93.l ' ' x93.m /;
put x94 ' ' x94.l ' ' x94.m /;
put x95 ' ' x95.l ' ' x95.m /;
put x96 ' ' x96.l ' ' x96.m /;
put x97 ' ' x97.l ' ' x97.m /;
put x98 ' ' x98.l ' ' x98.m /;
put x99 ' ' x99.l ' ' x99.m /;
put x100 ' ' x100.l ' ' x100.m /;
put x101 ' ' x101.l ' ' x101.m /;
put x102 ' ' x102.l ' ' x102.m /;
put x103 ' ' x103.l ' ' x103.m /;
put x104 ' ' x104.l ' ' x104.m /;
put x105 ' ' x105.l ' ' x105.m /;
put x106 ' ' x106.l ' ' x106.m /;
put x107 ' ' x107.l ' ' x107.m /;
put x108 ' ' x108.l ' ' x108.m /;
put x109 ' ' x109.l ' ' x109.m /;
put x110 ' ' x110.l ' ' x110.m /;
put x111 ' ' x111.l ' ' x111.m /;
put x112 ' ' x112.l ' ' x112.m /;
put x113 ' ' x113.l ' ' x113.m /;
put x114 ' ' x114.l ' ' x114.m /;
put x115 ' ' x115.l ' ' x115.m /;
put x116 ' ' x116.l ' ' x116.m /;
put x117 ' ' x117.l ' ' x117.m /;
put x118 ' ' x118.l ' ' x118.m /;
put x119 ' ' x119.l ' ' x119.m /;
put x120 ' ' x120.l ' ' x120.m /;
put x121 ' ' x121.l ' ' x121.m /;
put x122 ' ' x122.l ' ' x122.m /;
put x123 ' ' x123.l ' ' x123.m /;
put x124 ' ' x124.l ' ' x124.m /;
put x125 ' ' x125.l ' ' x125.m /;
put x126 ' ' x126.l ' ' x126.m /;
put x127 ' ' x127.l ' ' x127.m /;
put x128 ' ' x128.l ' ' x128.m /;
put x129 ' ' x129.l ' ' x129.m /;
put x130 ' ' x130.l ' ' x130.m /;
put x131 ' ' x131.l ' ' x131.m /;
put x132 ' ' x132.l ' ' x132.m /;
put x133 ' ' x133.l ' ' x133.m /;
put x134 ' ' x134.l ' ' x134.m /;
put x135 ' ' x135.l ' ' x135.m /;
put x136 ' ' x136.l ' ' x136.m /;
put x137 ' ' x137.l ' ' x137.m /;
put x138 ' ' x138.l ' ' x138.m /;
put x139 ' ' x139.l ' ' x139.m /;
put x140 ' ' x140.l ' ' x140.m /;
put x141 ' ' x141.l ' ' x141.m /;
put x142 ' ' x142.l ' ' x142.m /;
put x143 ' ' x143.l ' ' x143.m /;
put x144 ' ' x144.l ' ' x144.m /;
put x145 ' ' x145.l ' ' x145.m /;
put x146 ' ' x146.l ' ' x146.m /;
put x147 ' ' x147.l ' ' x147.m /;
put x148 ' ' x148.l ' ' x148.m /;
put x149 ' ' x149.l ' ' x149.m /;
put x150 ' ' x150.l ' ' x150.m /;
put x151 ' ' x151.l ' ' x151.m /;
put x152 ' ' x152.l ' ' x152.m /;
put x153 ' ' x153.l ' ' x153.m /;
put x154 ' ' x154.l ' ' x154.m /;
put x155 ' ' x155.l ' ' x155.m /;
put x156 ' ' x156.l ' ' x156.m /;
put c1 ' ' c1.l ' ' c1.m /;
put c2 ' ' c2.l ' ' c2.m /;
put c3 ' ' c3.l ' ' c3.m /;
put c4 ' ' c4.l ' ' c4.m /;
put c5 ' ' c5.l ' ' c5.m /;
put c6 ' ' c6.l ' ' c6.m /;
put c7 ' ' c7.l ' ' c7.m /;
put c8 ' ' c8.l ' ' c8.m /;
put c9 ' ' c9.l ' ' c9.m /;
put c10 ' ' c10.l ' ' c10.m /;
put c11 ' ' c11.l ' ' c11.m /;
put c12 ' ' c12.l ' ' c12.m /;
put c13 ' ' c13.l ' ' c13.m /;
put c14 ' ' c14.l ' ' c14.m /;
put c15 ' ' c15.l ' ' c15.m /;
put c16 ' ' c16.l ' ' c16.m /;
put c17 ' ' c17.l ' ' c17.m /;
put c18 ' ' c18.l ' ' c18.m /;
put c19 ' ' c19.l ' ' c19.m /;
put c20 ' ' c20.l ' ' c20.m /;
put c21 ' ' c21.l ' ' c21.m /;
put c22 ' ' c22.l ' ' c22.m /;
put c23 ' ' c23.l ' ' c23.m /;
put c24 ' ' c24.l ' ' c24.m /;
put c25 ' ' c25.l ' ' c25.m /;
put c26 ' ' c26.l ' ' c26.m /;
put c27 ' ' c27.l ' ' c27.m /;
put c28 ' ' c28.l ' ' c28.m /;
put c29 ' ' c29.l ' ' c29.m /;
put c30 ' ' c30.l ' ' c30.m /;
put c31 ' ' c31.l ' ' c31.m /;
put c32 ' ' c32.l ' ' c32.m /;
put c33 ' ' c33.l ' ' c33.m /;
put c34 ' ' c34.l ' ' c34.m /;
put c35 ' ' c35.l ' ' c35.m /;
put c36 ' ' c36.l ' ' c36.m /;
put c37 ' ' c37.l ' ' c37.m /;
put c38 ' ' c38.l ' ' c38.m /;
put c39 ' ' c39.l ' ' c39.m /;
put c40 ' ' c40.l ' ' c40.m /;
put c41 ' ' c41.l ' ' c41.m /;
put c42 ' ' c42.l ' ' c42.m /;
put c43 ' ' c43.l ' ' c43.m /;
put c44 ' ' c44.l ' ' c44.m /;
put c45 ' ' c45.l ' ' c45.m /;
put c46 ' ' c46.l ' ' c46.m /;
put c47 ' ' c47.l ' ' c47.m /;
put c48 ' ' c48.l ' ' c48.m /;
put c49 ' ' c49.l ' ' c49.m /;
put c50 ' ' c50.l ' ' c50.m /;
put c51 ' ' c51.l ' ' c51.m /;
put c52 ' ' c52.l ' ' c52.m /;
put c53 ' ' c53.l ' ' c53.m /;
put c54 ' ' c54.l ' ' c54.m /;
put c55 ' ' c55.l ' ' c55.m /;
put c56 ' ' c56.l ' ' c56.m /;
put c57 ' ' c57.l ' ' c57.m /;
put c58 ' ' c58.l ' ' c58.m /;
put c59 ' ' c59.l ' ' c59.m /;
put c60 ' ' c60.l ' ' c60.m /;
put c61 ' ' c61.l ' ' c61.m /;
put c62 ' ' c62.l ' ' c62.m /;
put c63 ' ' c63.l ' ' c63.m /;
put c64 ' ' c64.l ' ' c64.m /;
put c65 ' ' c65.l ' ' c65.m /;
put c66 ' ' c66.l ' ' c66.m /;
put c67 ' ' c67.l ' ' c67.m /;
put c68 ' ' c68.l ' ' c68.m /;
put c69 ' ' c69.l ' ' c69.m /;
put c70 ' ' c70.l ' ' c70.m /;
put c71 ' ' c71.l ' ' c71.m /;
put c72 ' ' c72.l ' ' c72.m /;
put c73 ' ' c73.l ' ' c73.m /;
put c74 ' ' c74.l ' ' c74.m /;
put c75 ' ' c75.l ' ' c75.m /;
put c76 ' ' c76.l ' ' c76.m /;
put c77 ' ' c77.l ' ' c77.m /;
put c78 ' ' c78.l ' ' c78.m /;
put c79 ' ' c79.l ' ' c79.m /;
put c80 ' ' c80.l ' ' c80.m /;
put c81 ' ' c81.l ' ' c81.m /;
put c82 ' ' c82.l ' ' c82.m /;
put c83 ' ' c83.l ' ' c83.m /;
put c84 ' ' c84.l ' ' c84.m /;
put c85 ' ' c85.l ' ' c85.m /;
put c86 ' ' c86.l ' ' c86.m /;
put c87 ' ' c87.l ' ' c87.m /;
put c88 ' ' c88.l ' ' c88.m /;
put c89 ' ' c89.l ' ' c89.m /;
put c90 ' ' c90.l ' ' c90.m /;
put c91 ' ' c91.l ' ' c91.m /;
put c92 ' ' c92.l ' ' c92.m /;
put c93 ' ' c93.l ' ' c93.m /;
put c94 ' ' c94.l ' ' c94.m /;
put c95 ' ' c95.l ' ' c95.m /;
put c96 ' ' c96.l ' ' c96.m /;
put c97 ' ' c97.l ' ' c97.m /;
put c98 ' ' c98.l ' ' c98.m /;
put c99 ' ' c99.l ' ' c99.m /;
put c100 ' ' c100.l ' ' c100.m /;
put c101 ' ' c101.l ' ' c101.m /;
put c102 ' ' c102.l ' ' c102.m /;
put c103 ' ' c103.l ' ' c103.m /;
put c104 ' ' c104.l ' ' c104.m /;
put c105 ' ' c105.l ' ' c105.m /;
put c106 ' ' c106.l ' ' c106.m /;
put c107 ' ' c107.l ' ' c107.m /;
put c108 ' ' c108.l ' ' c108.m /;
put c109 ' ' c109.l ' ' c109.m /;
put c110 ' ' c110.l ' ' c110.m /;
put c111 ' ' c111.l ' ' c111.m /;
put c112 ' ' c112.l ' ' c112.m /;
put c113 ' ' c113.l ' ' c113.m /;
put c114 ' ' c114.l ' ' c114.m /;
put c115 ' ' c115.l ' ' c115.m /;
put c116 ' ' c116.l ' ' c116.m /;
put c117 ' ' c117.l ' ' c117.m /;
put c118 ' ' c118.l ' ' c118.m /;
put c119 ' ' c119.l ' ' c119.m /;
put c120 ' ' c120.l ' ' c120.m /;
put c121 ' ' c121.l ' ' c121.m /;
put c122 ' ' c122.l ' ' c122.m /;
put c123 ' ' c123.l ' ' c123.m /;
put c124 ' ' c124.l ' ' c124.m /;
put c125 ' ' c125.l ' ' c125.m /;
put c126 ' ' c126.l ' ' c126.m /;
put c127 ' ' c127.l ' ' c127.m /;
put c128 ' ' c128.l ' ' c128.m /;
put c129 ' ' c129.l ' ' c129.m /;
put c130 ' ' c130.l ' ' c130.m /;
put c131 ' ' c131.l ' ' c131.m /;
put c132 ' ' c132.l ' ' c132.m /;
put c133 ' ' c133.l ' ' c133.m /;
put c134 ' ' c134.l ' ' c134.m /;
put c135 ' ' c135.l ' ' c135.m /;
put c136 ' ' c136.l ' ' c136.m /;
put c137 ' ' c137.l ' ' c137.m /;
put c138 ' ' c138.l ' ' c138.m /;
put c139 ' ' c139.l ' ' c139.m /;
put c140 ' ' c140.l ' ' c140.m /;
put c141 ' ' c141.l ' ' c141.m /;
put c142 ' ' c142.l ' ' c142.m /;
put c143 ' ' c143.l ' ' c143.m /;
put c144 ' ' c144.l ' ' c144.m /;
put c145 ' ' c145.l ' ' c145.m /;
put c146 ' ' c146.l ' ' c146.m /;
put c147 ' ' c147.l ' ' c147.m /;
put c148 ' ' c148.l ' ' c148.m /;
put c149 ' ' c149.l ' ' c149.m /;
put c150 ' ' c150.l ' ' c150.m /;
put c151 ' ' c151.l ' ' c151.m /;
put c152 ' ' c152.l ' ' c152.m /;
put c153 ' ' c153.l ' ' c153.m /;
put c154 ' ' c154.l ' ' c154.m /;
put c155 ' ' c155.l ' ' c155.m /;
put c156_lo ' ' c156_lo.l ' ' c156_lo.m /;
put c157_lo ' ' c157_lo.l ' ' c157_lo.m /;
put c158_lo ' ' c158_lo.l ' ' c158_lo.m /;
put c159_lo ' ' c159_lo.l ' ' c159_lo.m /;
put c160_lo ' ' c160_lo.l ' ' c160_lo.m /;
put c161_lo ' ' c161_lo.l ' ' c161_lo.m /;
put c162_lo ' ' c162_lo.l ' ' c162_lo.m /;
put c163_lo ' ' c163_lo.l ' ' c163_lo.m /;
put c164_lo ' ' c164_lo.l ' ' c164_lo.m /;
put c165_lo ' ' c165_lo.l ' ' c165_lo.m /;
put c166_lo ' ' c166_lo.l ' ' c166_lo.m /;
put c167_lo ' ' c167_lo.l ' ' c167_lo.m /;
put c168_lo ' ' c168_lo.l ' ' c168_lo.m /;
put c169_lo ' ' c169_lo.l ' ' c169_lo.m /;
put c170_lo ' ' c170_lo.l ' ' c170_lo.m /;
put c171_lo ' ' c171_lo.l ' ' c171_lo.m /;
put c172_lo ' ' c172_lo.l ' ' c172_lo.m /;
put c173_lo ' ' c173_lo.l ' ' c173_lo.m /;
put c174_lo ' ' c174_lo.l ' ' c174_lo.m /;
put c175_lo ' ' c175_lo.l ' ' c175_lo.m /;
put c176_lo ' ' c176_lo.l ' ' c176_lo.m /;
put c177_lo ' ' c177_lo.l ' ' c177_lo.m /;
put c178_lo ' ' c178_lo.l ' ' c178_lo.m /;
put c179_lo ' ' c179_lo.l ' ' c179_lo.m /;
put c180_lo ' ' c180_lo.l ' ' c180_lo.m /;
put c181_lo ' ' c181_lo.l ' ' c181_lo.m /;
put c182_lo ' ' c182_lo.l ' ' c182_lo.m /;
put c183_lo ' ' c183_lo.l ' ' c183_lo.m /;
put c184_lo ' ' c184_lo.l ' ' c184_lo.m /;
put c185_lo ' ' c185_lo.l ' ' c185_lo.m /;
put c186_lo ' ' c186_lo.l ' ' c186_lo.m /;
put c187_lo ' ' c187_lo.l ' ' c187_lo.m /;
put c188_lo ' ' c188_lo.l ' ' c188_lo.m /;
put c189_lo ' ' c189_lo.l ' ' c189_lo.m /;
put c190_lo ' ' c190_lo.l ' ' c190_lo.m /;
put c191_lo ' ' c191_lo.l ' ' c191_lo.m /;
put c192_lo ' ' c192_lo.l ' ' c192_lo.m /;
put c193_lo ' ' c193_lo.l ' ' c193_lo.m /;
put c194_lo ' ' c194_lo.l ' ' c194_lo.m /;
put c195_lo ' ' c195_lo.l ' ' c195_lo.m /;
put c196_lo ' ' c196_lo.l ' ' c196_lo.m /;
put c197_lo ' ' c197_lo.l ' ' c197_lo.m /;
put c198_lo ' ' c198_lo.l ' ' c198_lo.m /;
put c199_lo ' ' c199_lo.l ' ' c199_lo.m /;
put c200_lo ' ' c200_lo.l ' ' c200_lo.m /;
put c201_lo ' ' c201_lo.l ' ' c201_lo.m /;
put c202_lo ' ' c202_lo.l ' ' c202_lo.m /;
put c203_lo ' ' c203_lo.l ' ' c203_lo.m /;
put c204_lo ' ' c204_lo.l ' ' c204_lo.m /;
put c205_lo ' ' c205_lo.l ' ' c205_lo.m /;
put c206_lo ' ' c206_lo.l ' ' c206_lo.m /;
put c207_lo ' ' c207_lo.l ' ' c207_lo.m /;
put c208_lo ' ' c208_lo.l ' ' c208_lo.m /;
put c209_lo ' ' c209_lo.l ' ' c209_lo.m /;
put c210_lo ' ' c210_lo.l ' ' c210_lo.m /;
put c211_lo ' ' c211_lo.l ' ' c211_lo.m /;
put c212_lo ' ' c212_lo.l ' ' c212_lo.m /;
put c213_lo ' ' c213_lo.l ' ' c213_lo.m /;
put c214_lo ' ' c214_lo.l ' ' c214_lo.m /;
put c215_lo ' ' c215_lo.l ' ' c215_lo.m /;
put c216_lo ' ' c216_lo.l ' ' c216_lo.m /;
put c217_lo ' ' c217_lo.l ' ' c217_lo.m /;
put c218_lo ' ' c218_lo.l ' ' c218_lo.m /;
put c219_lo ' ' c219_lo.l ' ' c219_lo.m /;
put c220_lo ' ' c220_lo.l ' ' c220_lo.m /;
put c221_lo ' ' c221_lo.l ' ' c221_lo.m /;
put c222_lo ' ' c222_lo.l ' ' c222_lo.m /;
put c223_lo ' ' c223_lo.l ' ' c223_lo.m /;
put c224_lo ' ' c224_lo.l ' ' c224_lo.m /;
put c225_lo ' ' c225_lo.l ' ' c225_lo.m /;
put c226_lo ' ' c226_lo.l ' ' c226_lo.m /;
put c227_lo ' ' c227_lo.l ' ' c227_lo.m /;
put c228_lo ' ' c228_lo.l ' ' c228_lo.m /;
put c229_lo ' ' c229_lo.l ' ' c229_lo.m /;
put c230_lo ' ' c230_lo.l ' ' c230_lo.m /;
put c231_lo ' ' c231_lo.l ' ' c231_lo.m /;
put c232_lo ' ' c232_lo.l ' ' c232_lo.m /;
put c233_lo ' ' c233_lo.l ' ' c233_lo.m /;
put c234_lo ' ' c234_lo.l ' ' c234_lo.m /;
put c235_lo ' ' c235_lo.l ' ' c235_lo.m /;
put c236_lo ' ' c236_lo.l ' ' c236_lo.m /;
put c237_lo ' ' c237_lo.l ' ' c237_lo.m /;
put c238_lo ' ' c238_lo.l ' ' c238_lo.m /;
put c239_lo ' ' c239_lo.l ' ' c239_lo.m /;
put c240_lo ' ' c240_lo.l ' ' c240_lo.m /;
put c241_lo ' ' c241_lo.l ' ' c241_lo.m /;
put c242_lo ' ' c242_lo.l ' ' c242_lo.m /;
put c243_lo ' ' c243_lo.l ' ' c243_lo.m /;
put c244_lo ' ' c244_lo.l ' ' c244_lo.m /;
put c245_lo ' ' c245_lo.l ' ' c245_lo.m /;
put c246_lo ' ' c246_lo.l ' ' c246_lo.m /;
put c247_lo ' ' c247_lo.l ' ' c247_lo.m /;
put c248_lo ' ' c248_lo.l ' ' c248_lo.m /;
put c249_lo ' ' c249_lo.l ' ' c249_lo.m /;
put c250_lo ' ' c250_lo.l ' ' c250_lo.m /;
put c251_lo ' ' c251_lo.l ' ' c251_lo.m /;
put c252_lo ' ' c252_lo.l ' ' c252_lo.m /;
put c253_lo ' ' c253_lo.l ' ' c253_lo.m /;
put c254_lo ' ' c254_lo.l ' ' c254_lo.m /;
put c255_lo ' ' c255_lo.l ' ' c255_lo.m /;
put c256_lo ' ' c256_lo.l ' ' c256_lo.m /;
put c257_lo ' ' c257_lo.l ' ' c257_lo.m /;
put c258_lo ' ' c258_lo.l ' ' c258_lo.m /;
put c259_lo ' ' c259_lo.l ' ' c259_lo.m /;
put c260_lo ' ' c260_lo.l ' ' c260_lo.m /;
put c261_lo ' ' c261_lo.l ' ' c261_lo.m /;
put c262_lo ' ' c262_lo.l ' ' c262_lo.m /;
put c263_lo ' ' c263_lo.l ' ' c263_lo.m /;
put c264_lo ' ' c264_lo.l ' ' c264_lo.m /;
put c265_lo ' ' c265_lo.l ' ' c265_lo.m /;
put c266_lo ' ' c266_lo.l ' ' c266_lo.m /;
put c267_lo ' ' c267_lo.l ' ' c267_lo.m /;
put c268_lo ' ' c268_lo.l ' ' c268_lo.m /;
put c269_lo ' ' c269_lo.l ' ' c269_lo.m /;
put c270_lo ' ' c270_lo.l ' ' c270_lo.m /;
put c271_lo ' ' c271_lo.l ' ' c271_lo.m /;
put c272_lo ' ' c272_lo.l ' ' c272_lo.m /;
put c273_lo ' ' c273_lo.l ' ' c273_lo.m /;
put c274_lo ' ' c274_lo.l ' ' c274_lo.m /;
put c275_lo ' ' c275_lo.l ' ' c275_lo.m /;
put c276_lo ' ' c276_lo.l ' ' c276_lo.m /;
put c277_lo ' ' c277_lo.l ' ' c277_lo.m /;
put c278_lo ' ' c278_lo.l ' ' c278_lo.m /;
put c279_lo ' ' c279_lo.l ' ' c279_lo.m /;
put c280_lo ' ' c280_lo.l ' ' c280_lo.m /;
put c281_lo ' ' c281_lo.l ' ' c281_lo.m /;
put c282_lo ' ' c282_lo.l ' ' c282_lo.m /;
put c283_lo ' ' c283_lo.l ' ' c283_lo.m /;
put c284_lo ' ' c284_lo.l ' ' c284_lo.m /;
put c285_lo ' ' c285_lo.l ' ' c285_lo.m /;
put c286_lo ' ' c286_lo.l ' ' c286_lo.m /;
put c287_lo ' ' c287_lo.l ' ' c287_lo.m /;
put c288_lo ' ' c288_lo.l ' ' c288_lo.m /;
put c289_lo ' ' c289_lo.l ' ' c289_lo.m /;
put c290_lo ' ' c290_lo.l ' ' c290_lo.m /;
put c291_lo ' ' c291_lo.l ' ' c291_lo.m /;
put c292_lo ' ' c292_lo.l ' ' c292_lo.m /;
put c293_lo ' ' c293_lo.l ' ' c293_lo.m /;
put c294_lo ' ' c294_lo.l ' ' c294_lo.m /;
put c295_lo ' ' c295_lo.l ' ' c295_lo.m /;
put c296_lo ' ' c296_lo.l ' ' c296_lo.m /;
put c297_lo ' ' c297_lo.l ' ' c297_lo.m /;
put c298_lo ' ' c298_lo.l ' ' c298_lo.m /;
put c299_lo ' ' c299_lo.l ' ' c299_lo.m /;
put c300_lo ' ' c300_lo.l ' ' c300_lo.m /;
put c301_lo ' ' c301_lo.l ' ' c301_lo.m /;
put c302_lo ' ' c302_lo.l ' ' c302_lo.m /;
put c303_lo ' ' c303_lo.l ' ' c303_lo.m /;
put c304 ' ' c304.l ' ' c304.m /;
put GAMS_OBJECTIVE ' ' GAMS_OBJECTIVE.l ' ' GAMS_OBJECTIVE.m;

file statresults /'resultsstat.dat'/;
statresults.nd=17;
statresults.nw=26;
put statresults;
put 'SYMBOL   :   VALUE' /;
put 'MODELSTAT' ' ' MODELSTAT /;

put 'SOLVESTAT' ' ' SOLVESTAT /;

put 'OBJEST' ' ' OBJEST /;

put 'OBJVAL' ' ' OBJVAL /;

put 'NUMVAR' ' ' NUMVAR /;

put 'NUMEQU' ' ' NUMEQU /;

put 'NUMDVAR' ' ' NUMDVAR /;

put 'NUMNZ' ' ' NUMNZ /;

put 'ETSOLVE' ' ' ETSOLVE /;
