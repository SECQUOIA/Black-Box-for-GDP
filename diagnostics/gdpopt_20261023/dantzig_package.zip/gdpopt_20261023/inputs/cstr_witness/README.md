# CSTR15 W03 GAMS/IPOPT single-call check

The actual charged NLP call count is 1 and the assessment status is `passed`.
Returned objective: `2.8293940632857595`; maximum unscaled original-GDP violation: `1.1102230246251565e-16`.
The `1e-8` numerical check passed: `True`; requested environment/options confirmed: `True`.
The original W03 vector was the start; the retained local polished vector was used only in the comparison table.
Historical benchmark records, point costs and execution-provider revisions are unchanged, and this diagnostic time is not added to performance comparisons.
See `environment.json`, `historical_environment.json`, `solver_input/gams.log`, the listing, raw DAT files and `summary.json` for environment differences and raw statuses.
The old local experiment used AMPL/IPOPT 3.12.13 on macOS; this allocation requests the recorded Dantzig GAMS/IPOPT/MUMPS installation and does not require matching objectives or iterations.
Model-level and writer-level row/variable counts are recorded separately in `input_evidence.json` and `gams_mapping.json`.
Fixed values substituted in GAMS are explicitly mapped; missing free values are never filled from the starting vector.

## Draft reviewer/manuscript wording

A single additional fixed-configuration GAMS/IPOPT check from the retained CSTR15 W03 start returned objective 2.8293940632857595 with maximum unscaled original-GDP violation 1.1102230246251565e-16, below the numerical threshold of 1e-8.
For the retained GLOA lower bound, delta=0.6931579445174347, tau=2.8293940632857597e-05 and rho=24498.458999114257; rho>1 is True.
For the retained HULL lower bound, delta=1.456320752879492e-08, tau=2.8293940632857597e-05 and rho=0.0005147111785440996; rho>1 is False.
This is numerical evidence for one fixed configuration, not a proof of exact feasibility, global optimality or a solver defect.
These are draft sentences only; no manuscript or Overleaf file was edited.

## Solver-free recheck

```bash
python -m review_diagnostics.cstr15_gams verify --directory /path/to/returned/result --output /path/to/new/verification.json
```
