# Grid GDP benchmark and exhaustive IPOPT point costs

The execution ZIP contains all 21 analytic GDP models, their 31-by-31 reference
CSVs, a full-GDP benchmark driver, and an exhaustive IPOPT point-timing driver.
The grid definition and original analytic objective are unchanged. Default
`run` first measures **20,181 points** (21 × 961), then attempts **105 full-GDP
jobs** (21 × 5 methods). Everything runs sequentially on one selected CPU.

## Solver profile matched to the current process comparison

| Method | Solver | Internal/master configuration |
|---|---|---|
| Big-M, Hull | GAMS BARON | CPLEX (`LPSol 3`), IPOPT (`NLPSol 9`), no warm start |
| GDPopt RIC, GLOA, LOA | BARON NLP + HiGHS MILP | BARON CLP/CBC (`LPSol 8`), IPOPT (`NLPSol 9`) |
| Every fixed grid point | GAMS IPOPT | MUMPS, `tol=1e-8`, `bound_relax_factor=0`, `max_iter=3000`, no NLP warm start |

The profile is taken from the final selected process experiments: September 25
Big-M/Hull and October 1 BARON/HiGHS RIC/GLOA/LOA. `grid_gdp_process_profile.json`
records their source-manifest hashes and settings. Full-GDP jobs reuse the
existing `gdp_models.comparison.solve_method` implementation and watchdog:
1,800 seconds per method, including transformation, search and validation;
all subsolver calls share the remaining budget. GAMS uses `optcr=1e-5`,
`optca=0`, `threads=1`; GDPopt bound tolerance is `1e-5`. The Column-specific
`LBTTDo 0` workaround does not apply to grid models.

The expected Dantzig runtime is GAMS 52.2 and Pyomo 6.10.0 with the existing
MC++ build. Numerical-library thread counts are forced to one before import;
workers and GAMS processes inherit CPU affinity. CPU 6 is the wrapper default,
leaving the existing RBFOpt CPU 0 and BAM CPU 2 runs separate; verify that the
chosen CPUs belong to different physical cores and are available.

## BARON expression compatibility

GAMS/BARON 52 does not support sine/cosine. Sixteen original grid objectives
contain those functions. Their Big-M/Hull jobs explicitly record
`unsupported_expression`, preserving the original analytic formulation and
not replacing BARON or using a CSV lookup. The five objectives without sine
or cosine are camel3, hosaki, rosenbrock, styblinski_tang and sum_of_squares.
GDPopt jobs are attempted with the specified solvers; any subproblem or
relaxation failure is preserved in its result and logs. This package does not
promise that all 105 jobs obtain solutions. IPOPT point timings cover all 21
grids regardless of BARON compatibility.

See [GAMS 52 BARON functions](https://www.gams.com/52/docs/S_BARON.html#BARON_ALLOWABLE_NONLINEAR_FUNCTIONS).

## Upload and execute

On the Mac:

```bash
cd /Users/albertlee0125/Repos/RBFopt_Test
scp results/runners/grid_gdp_runner.zip results/runners/grid_gdp_runner.zip.sha256 \
  lee4382@dantzig.ecn.purdue.edu:/local/scratch/a/lee4382/repository/RBFopt_Test/
ssh lee4382@dantzig.ecn.purdue.edu
```

On Dantzig:

```bash
cd /local/scratch/a/lee4382/repository/RBFopt_Test
sha256sum -c grid_gdp_runner.zip.sha256 &&
unzip grid_gdp_runner.zip &&
cd grid_gdp_runner &&
sha256sum -c SHA256SUMS

../.venv-dantzig-gdp/bin/python cpu_affinity.py --check-pair 0 6 &&
../.venv-dantzig-gdp/bin/python cpu_affinity.py --check-pair 2 6 &&
GRID_GDP_CPU=6 bash run_grid_gdp_dantzig.sh check

GRID_GDP_CPU=6 nohup bash run_grid_gdp_dantzig.sh run > ../grid_gdp_benchmark.log 2>&1 &
tail -f ../grid_gdp_benchmark.log
```

The existing GDP Python environment and solver installations are reused. Only
if required, `bash run_grid_gdp_dantzig.sh setup` installs the process comparison
requirements and builds its pinned MC++ interface. Override `GRID_GDP_PYTHON`,
`GRID_GDP_REPOSITORY`, `GAMS_BIN`, `GDP_GAMS_VERSION`, or `PYOMO_CONFIG_DIR` when
using another installation. An override is recorded in the experiment.

For separate phases, run one of these instead of the combined `run`:

```bash
GRID_GDP_CPU=6 nohup bash run_grid_gdp_dantzig.sh points > ../grid_ipopt_points.log 2>&1 &
# After that job finishes, if desired:
GRID_GDP_CPU=6 nohup bash run_grid_gdp_dantzig.sh benchmark > ../grid_gdp_methods.log 2>&1 &
```

`pilot` measures five points per grid (105 calls) to estimate time before a
full point sweep. It is explicitly labeled a sample. `--grids ackley` selects
one grid; `--point-indices 0,480,960` selects indices `31*i+j`; `--methods hull`
selects a full-GDP method. Without selection flags, every point is measured
once. `--point-seconds 60` is a solver safety cap, not a claim that a point
requires 60 seconds. The external watchdog allows another 120 seconds for
GAMS startup, result handling and cleanup before stopping a stuck point worker.

## What is timed

Every point builds a fresh analytic GDP, fixes its two discrete coordinates,
eliminates disjunctions, and actually invokes GAMS/IPOPT. All original variables
are fixed. The standard GAMS writer creates an objective variable/equation,
so IPOPT is still called without inventing an extra physical optimization
problem. Solver logs must demonstrate the invocation; a formula-only shortcut
is not accepted as an IPOPT timing.
Solver availability and version checks occur before timing; each timed point
has one actual IPOPT invocation, without a hidden GAMS availability-test solve.

The result separates:

- `preparation_wall_s`: fresh GDP construction, point fixing and transformation.
- `solver_call_wall_s`: GAMS model writing, process startup, IPOPT execution and
  result reading (the measured external evaluation call).
- `gams_solve_s`: raw GAMS `ETSOLVE`, nested inside the preceding timer.
- `ipopt_reported_s`: IPOPT's own reported duration, also nested.
- `verification_wall_s`: objective and solver-status checks.
- `point_wall_s`: full evaluation clock including preparation, call and checks.
- `recording_and_cleanup_wall_s`: log archival and temporary-file cleanup,
  outside `point_wall_s`.

Do not sum nested solver timers. The per-point budget for replacing a recorded
DFO lookup is `point_wall_s`. Formula/CSV agreement uses `1e-12`; the returned
GAMS scalar is compared at `1e-7`, accounting for solver tolerance/output.
Normalization constants and all-961-point audits are computed once before
each grid's timing loop and recorded separately as preparation. No reference
optimal coordinates are supplied to full-GDP searches.

Grid-fixed NLPs have zero original continuous degrees of freedom. Their measured
cost will primarily describe preparation and the solver invocation. This is
reported explicitly rather than presented as a difficult continuous search.

## Output, resume and download

Each invocation prints `RUN_DIR`, then ultimately `RESULT_ZIP`. Results live
under `results/grid_gdp_benchmark/` and include source snapshots and checksums.

- `point_timings.csv`: one row per accepted IPOPT evaluation, indexed by grid
  and coordinate, with raw statuses and timing components.
- `point_budget_summary.csv/.json`: per-grid mean, median, p95, p99, maximum
  and sum; estimated costs for 10/30/50/70/100 DFO evaluations.
- `suggested_timeout_s`: twice the observed maximum rounded up to a second;
  this is an engineering margin, not a guaranteed runtime bound.
- `points/<grid>/evaluations.jsonl`: immediately flushed, checksummed records.
- `points/<grid>/ipopt.log`: solver invocation evidence for every measured point.
- `points/<grid>/failures.jsonl`: failed attempts, retained separately and
  retried on resume; completed accepted points are not rerun.
- `benchmark.csv` and `benchmark/<grid>/<method>/`: original process runner
  results, solver calls, validated solution coordinates, reference gaps and
  success/failure/unsupported statuses. A target hit is distinct from a global
  optimality certificate; GDPopt bounds retain the process audit's caveats.

Aggregate CSVs are updated after each grid or method and when packing. Progress
updates every 25 points. After an interruption, from this extraction:

```bash
bash run_grid_gdp_dantzig.sh status --run-dir /absolute/path/from/RUN_DIR
nohup bash run_grid_gdp_dantzig.sh resume --run-dir /absolute/path/from/RUN_DIR > ../grid_gdp_resume.log 2>&1 &
```

Resume checks the original source, runtime, CPU, point-record hashes and grid
identities. No active coordinator/point worker may be duplicated. Failed point
attempts remain in their own journal. To pack a stopped run, use
`bash run_grid_gdp_dantzig.sh pack --run-dir /absolute/path/from/RUN_DIR`.

From a Mac terminal, after completion:

```bash
mkdir -p ~/Downloads/grid_gdp_benchmark
scp 'lee4382@dantzig.ecn.purdue.edu:/local/scratch/a/lee4382/repository/RBFopt_Test/results/grid_gdp_benchmark/grid_gdp_*.zip' \
    'lee4382@dantzig.ecn.purdue.edu:/local/scratch/a/lee4382/repository/RBFopt_Test/results/grid_gdp_benchmark/grid_gdp_*.zip.sha256' \
    ~/Downloads/grid_gdp_benchmark/
cd ~/Downloads/grid_gdp_benchmark
shasum -a 256 -c *.zip.sha256
```

Local validation runs are labeled with their actual host/GAMS version. Their
timings are not substituted for measurements on Dantzig.
