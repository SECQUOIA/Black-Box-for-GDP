"""No optimizer is invoked by these tests."""
import importlib
import json
import math
import unittest
from unittest.mock import patch

import pyomo.environ as p
from pyomo.common.errors import InfeasibleConstraintException
from grid_probe import ROOT, setup
from patches import apply_sin_patch
from pyomo.contrib.fbbt.fbbt import fbbt
from pyomo.contrib.gdpopt import solve_subproblem as sp
from pyomo.opt import TerminationCondition as tc


class TestDataFlow(unittest.TestCase):
    def test_original_presolve_discards_zero_objective_before_solver(self):
        model, util = setup((21, 15))
        config=p.SolverFactory('gdpopt.gloa').config
        with patch.object(sp, 'call_appropriate_subproblem_solver', side_effect=AssertionError('must not be called')):
            status = sp.solve_subproblem(util, object(), config)
        self.assertIs(status, tc.infeasible)

    def test_patched_presolve_reaches_solver_without_changing_objective(self):
        model, util = setup((21, 15))
        config=p.SolverFactory('gdpopt.gloa').config
        restore=apply_sin_patch()
        seen=[]
        def sentinel(u, solver, config):
            seen.append((p.value(model.obj.expr),model.x.fixed,model.y.fixed))
            return tc.optimal
        try:
            with patch.object(sp, 'call_appropriate_subproblem_solver', sentinel):
                self.assertIs(sp.solve_subproblem(util, object(), config), tc.optimal)
        finally:
            restore()
        self.assertEqual(len(seen),1)
        self.assertAlmostEqual(seen[0][0],0,places=12)
        self.assertTrue(seen[0][1] and seen[0][2])

    def test_patch_does_not_accept_genuinely_infeasible_sine(self):
        m=p.ConcreteModel();m.x=p.Var(bounds=(2.2,2.2));m.c=p.Constraint(expr=p.sin(m.x)<=0.1)
        restore=apply_sin_patch()
        try:
            with self.assertRaises(InfeasibleConstraintException):
                fbbt(m,feasibility_tol=1e-6)
        finally:
            restore()

    def test_no_good_cut_really_excludes_target_assignment(self):
        from gdp_models.grid import build_grid_gdp
        from pyomo.contrib.gdpopt import create_oa_subproblems as c
        from pyomo.contrib.gdpopt.cut_generation import add_no_good_cut
        m=build_grid_gdp('michalewicz');u=c.add_util_block(m)
        c.add_disjunct_list(u);c.add_boolean_variable_lists(u);c.add_algebraic_variable_list(u);c.add_discrete_variable_list(u)
        c.add_transformed_boolean_variable_list(u)
        u.no_good_cuts=p.ConstraintList()
        for axis,selected in [(m.Xchoice,21),(m.Ychoice,15)]:
            for i,d in axis.items():d.indicator_var.set_value(i==selected)
        add_no_good_cut(u,p.SolverFactory('gdpopt.gloa').config)
        cut=u.no_good_cuts[1]
        self.assertLess(p.value(cut.body),p.value(cut.lower))
        m.Xchoice[21].indicator_var.set_value(False);m.Xchoice[22].indicator_var.set_value(True)
        self.assertGreaterEqual(p.value(cut.body),p.value(cut.lower))

    def test_saved_witness_survives_only_corrected_cut_generator(self):
        # Run the actual cut generator in a separate interpreter to keep archived
        # Grid and CSTR package imports independent.
        import os,subprocess,sys
        result=subprocess.run([sys.executable,str(ROOT/'cstr_probe.py')],check=True,capture_output=True,env=os.environ.copy(),text=True)
        (ROOT/'cstr_probe.log').write_text(result.stdout+result.stderr)
        original, corrected=json.loads((ROOT/'cstr_probe.json').read_text())
        bad=[c for c in original['cuts'] if c['applicable_to_W03'] and c['violation']>1e-8]
        self.assertEqual(len(bad),15)
        self.assertTrue(all(c['scope'].startswith('YP_is_cstr[') for c in bad))
        self.assertGreater(max(c['violation'] for c in bad),30)
        self.assertEqual(corrected['transformed_witness_violations'],[])
        self.assertEqual(original['W03_initial_master_bound_violations'],[])
        self.assertGreaterEqual(original['W03_no_good_body'],original['no_good_lower_bound'])


if __name__=='__main__':
    unittest.main(verbosity=2)
