"""Verify immutable inputs and package the diagnostic without invoking solvers."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    checks=[]
    for record in json.loads((ROOT/'archive_inventory.json').read_text()):
        archive=REPO/record['archive']
        assert digest(archive)==record['sha256']
        checks.append({'path':str(archive),'sha256':record['sha256'],'unchanged':True})
        for member in record['members']:
            relative=member['member'].split('/',1)[1]
            assert digest(ROOT/'inputs'/record['label']/relative)==member['sha256']
    witness=json.loads((ROOT/'witness_inventory.json').read_text())
    assert digest(Path(witness['archive']))==witness['sha256']
    checks.append({'path':witness['archive'],'sha256':witness['sha256'],'unchanged':True})
    for member in witness['members']:
        assert digest(ROOT/'inputs/cstr_witness'/member['member'].split('/',1)[1])==member['sha256']
    for copy in (ROOT/'inputs/local_snapshot').rglob('*'):
        if copy.is_file():
            original=REPO/copy.relative_to(ROOT/'inputs/local_snapshot')
            assert digest(original)==digest(copy)
            checks.append({'path':str(original),'sha256':digest(original),'unchanged_since_snapshot':True})
    assert subprocess.check_output(['git','diff','--binary'],cwd=REPO)==(ROOT/'preserved_user_changes.diff').read_bytes()
    status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=REPO,text=True)
    old=(ROOT/'initial_git_status.txt').read_text()
    without_diag=lambda text:[s for s in text.splitlines() if s!='?? diagnostics/']
    assert without_diag(status)==without_diag(old)
    (ROOT/'preservation_check.json').write_text(json.dumps({'checks':checks,'user_diff_unchanged_since_capture':True,
                                                          'initial_status_preserved_except_diagnostics':True,
                                                          'final_status':status},indent=2)+'\n')
    skip={'dantzig_package.zip','dantzig_package.zip.sha256','SHA256SUMS','package_manifest.json'}
    files=[p for p in ROOT.rglob('*') if p.is_file() and p.name not in skip and '__pycache__' not in p.parts]
    members={str(p.relative_to(ROOT)):digest(p) for p in files}
    package=ROOT/'dantzig_package.zip'
    with zipfile.ZipFile(package,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,'gdpopt_20261023/'+str(p.relative_to(ROOT)))
        z.writestr('gdpopt_20261023/PACKAGE_SHA256SUMS',''.join(f'{h}  {n}\n' for n,h in sorted(members.items())))
    with zipfile.ZipFile(package) as z:
        assert z.testzip() is None
        for name,h in members.items():assert hashlib.sha256(z.read('gdpopt_20261023/'+name)).hexdigest()==h
    (ROOT/'package_manifest.json').write_text(json.dumps({'package':package.name,'sha256':digest(package),'bytes':package.stat().st_size,
                                                       'member_sha256':members,'new_solver_calls':0},indent=2)+'\n')
    (ROOT/'dantzig_package.zip.sha256').write_text(digest(package)+'  dantzig_package.zip\n')
    all_files=[p for p in ROOT.rglob('*') if p.is_file() and p.name!='SHA256SUMS' and '__pycache__' not in p.parts]
    (ROOT/'SHA256SUMS').write_text(''.join(f'{digest(p)}  {p.relative_to(ROOT)}\n' for p in sorted(all_files)))
    print(json.dumps({'package':str(package),'bytes':package.stat().st_size,'sha256':digest(package),
                      'files_checked':len(all_files),'solver_calls':0}))


if __name__=='__main__':main()
