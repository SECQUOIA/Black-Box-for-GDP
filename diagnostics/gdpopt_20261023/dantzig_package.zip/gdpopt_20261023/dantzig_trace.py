"""Instrument archived GLOA; refuse environment substitution; at most two runs."""
import argparse
import functools
import hashlib
import importlib.metadata
import json
import logging
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
EXPECTED_GAMS='11bd33943b5b2542afa73cbf3eb8a1f1b27eb1bde1ba56e85f8a262cfdd29245'
EXPECTED_MCPP='05082e93380fd595c65d1b5ecd5cd36a381ff6d28abb8023c556e52cf944c2c6'


def save(path,data):
    path.write_text(json.dumps(data,indent=2,default=str)+'\n')


def environment(args):
    errors=[]
    exe=Path(args.gams)
    gams_hash=hashlib.sha256(exe.read_bytes()).hexdigest() if exe.is_file() else None
    if gams_hash!=EXPECTED_GAMS:errors.append('GAMS binary is not the archived 52.2 binary')
    if sys.version_info[:2]!=(3,11):errors.append('Python is not archived 3.11')
    versions={}
    for name,expected in {'pyomo':'6.10.0','numpy':'2.4.6','sympy':'1.14.0','networkx':'3.6.1'}.items():
        try:versions[name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:versions[name]=None
        if versions[name]!=expected:errors.append(f'{name} differs: {versions[name]} != {expected}')
    from pyomo.contrib.mcpp.pyomo_mcpp import _MCPP_lib, mcpp_available
    # find_library does not call a solver.
    from pyomo.common.fileutils import find_library
    mcpp=find_library('mcppInterface')
    mcpp_hash=hashlib.sha256(Path(mcpp).read_bytes()).hexdigest() if mcpp and Path(mcpp).is_file() else None
    if mcpp_hash!=EXPECTED_MCPP:errors.append('MC++ binary differs from archived Linux library')
    run=json.loads((ROOT/f'inputs/{args.case}/run.json').read_text())
    for name,expected in run['source_sha256'].items():
        if hashlib.sha256((ROOT/f'inputs/{args.case}/source'/name).read_bytes()).hexdigest()!=expected:
            errors.append('Archive source differs: '+name)
    import pyomo
    site_root=Path(pyomo.__file__).resolve().parent.parent
    analyzed=json.loads((ROOT/'analysis_source_inventory.json').read_text())['source_files']
    for name,record in analyzed.items():
        if name.startswith('pyomo/'):
            f=site_root/name
            if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=record['sha256']:
                errors.append('Installed Pyomo source differs from analyzed 6.10.0: '+name)
    if args.case=='cstr':
        external=Path(os.environ.get('RBFOPT_GDP_SOURCES','external'))/'dsda-gdp'
        expected_sources=json.loads((ROOT/'inputs/cstr/jobs/cstr_15/gloa/result.json').read_text())['source']
        try:
            revision=subprocess.check_output(['git','-C',str(external),'rev-parse','HEAD'],text=True).strip()
        except (OSError,subprocess.CalledProcessError):revision=None
        if revision!=expected_sources['commit']:errors.append('CSTR upstream checkout revision differs')
        for name,expected in expected_sources['files_sha256'].items():
            f=external/name
            if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=expected:
                errors.append('CSTR upstream source differs: '+name)
    return {'errors':errors,'python':sys.version,'executable':sys.executable,'versions':versions,
            'gams':str(exe),'gams_sha256':gams_hash,'mcpp':mcpp,'mcpp_sha256':mcpp_hash,
            'solver_calls':0,'check_only':not args.execute}


def worker(args,out):
    run_manifest=json.loads((ROOT/f'inputs/{args.case}/run.json').read_text())
    cpu=run_manifest['config']['cpu'] if args.case=='grid' else run_manifest['cpu']
    os.sched_setaffinity(0,{cpu})
    sys.path.insert(0,str(ROOT/f'inputs/{args.case}/source'))
    import pyomo.environ as p
    from pyomo.gdp import Disjunct
    from gdp_models import comparison
    from pyomo.contrib.gdpopt import solve_subproblem as sp, solve_discrete_problem as dp, gloa, discrete_problem_initialize as init
    from pyomo.contrib.gdpopt.algorithm_base_class import _GDPoptAlgorithm
    from pyomo.contrib.gdpopt.oa_algorithm_utils import _OAAlgorithmMixIn
    from patches import apply_sin_patch, apply_gloa_patch
    if args.variant=='sin-singleton':apply_sin_patch()
    if args.variant=='convex-slope':apply_gloa_patch()
    started=time.monotonic()
    state={'iteration':0,'last_solver_result':None}
    def emit(event,**kw):
        with (out/'events.jsonl').open('a') as f:
            f.write(json.dumps({'event':event,'elapsed_s':time.monotonic()-started,**state,**kw},default=str)+'\n')
    def snapshot(m):
        variables={v.name:{'value':v.value,'lb':v.lb,'ub':v.ub,'fixed':v.fixed}
                   for v in m.component_data_objects(p.Var,descend_into=(p.Block,Disjunct))}
        selected=[v.name for v in m.component_data_objects(p.Var,descend_into=(p.Block,Disjunct))
                  if v.is_binary() and v.value is not None and v.value>0.5]
        return {'variables':variables,'selected_binaries':selected,
                'active_constraints':[c.name for c in m.component_data_objects(p.Constraint,active=True)]}
    def wrap_fbbt(module):
        original=module.fbbt
        @functools.wraps(original)
        def wrapped(m,*a,**kw):
            emit(module.__name__+'.fbbt.before',model=snapshot(m))
            try:
                result=original(m,*a,**kw)
            except Exception as e:
                emit(module.__name__+'.fbbt.exception',error=repr(e),model=snapshot(m))
                raise
            emit(module.__name__+'.fbbt.after',model=snapshot(m))
            return result
        module.fbbt=wrapped
    wrap_fbbt(sp);wrap_fbbt(dp)
    original_master=gloa.solve_MILP_discrete_problem
    def master(u,solver,config):
        state['iteration']=solver.iteration
        emit('master.before',LB=solver.LB,UB=solver.UB)
        result=original_master(u,solver,config)
        emit('master.after',status=str(result),model=snapshot(u.parent_block()))
        return result
    gloa.solve_MILP_discrete_problem=master;init.solve_MILP_discrete_problem=master
    original_pre=sp.preprocess_subproblem.__enter__
    def pre(self):
        emit('subproblem.presolve.enter',model=snapshot(self.util_block.parent_block()))
        result=original_pre(self)
        emit('subproblem.presolve.result',allows_solver=result,model=snapshot(self.util_block.parent_block()))
        return result
    sp.preprocess_subproblem.__enter__=pre
    original_sub=_OAAlgorithmMixIn._fix_discrete_soln_solve_subproblem_and_add_cuts
    def sub(self,du,su,config):
        state['iteration']=self.iteration
        emit('candidate.before',model=snapshot(du.parent_block()),LB=self.LB,UB=self.UB)
        result=original_sub(self,du,su,config)
        emit('candidate.after',feasible=result,LB=self.LB,UB=self.UB,model=snapshot(su.parent_block()))
        return result
    _OAAlgorithmMixIn._fix_discrete_soln_solve_subproblem_and_add_cuts=sub
    original_cuts=gloa.GDP_GLOA_Solver._add_cuts_to_discrete_problem
    def cuts(self,su,du,*a):
        m=du.parent_block()
        before={c.name for c in m.component_data_objects(p.Constraint,active=None,descend_into=(p.Block,Disjunct))}
        original_cuts(self,su,du,*a)
        new=[{'name':c.name,'parent':c.parent_block().name,'active':c.active,'expression':str(c.expr)}
             for c in m.component_data_objects(p.Constraint,active=None,descend_into=(p.Block,Disjunct)) if c.name not in before]
        emit('affine_cuts.added',cuts=new,model=snapshot(m))
    gloa.GDP_GLOA_Solver._add_cuts_to_discrete_problem=cuts
    original_ng=gloa.add_no_good_cut
    def ng(u,config):
        emit('no_good.before',model=snapshot(u.parent_block()))
        original_ng(u,config)
        emit('no_good.after',cut=str(u.no_good_cuts[len(u.no_good_cuts)].expr))
    gloa.add_no_good_cut=ng;init.add_no_good_cut=ng
    original_update=_GDPoptAlgorithm._update_bounds_after_discrete_problem_solve
    def update(self,status,obj,logger):
        state['iteration']=self.iteration
        emit('master.status',status=str(status),LB=self.LB,UB=self.UB)
        result=original_update(self,status,obj,logger)
        emit('master.bounds',LB=self.LB,UB=self.UB)
        return result
    _GDPoptAlgorithm._update_bounds_after_discrete_problem_solve=update
    original_inc=_GDPoptAlgorithm.update_incumbent
    def inc(self,u):
        emit('incumbent.before',LB=self.LB,UB=self.UB,model=snapshot(u.parent_block()))
        return original_inc(self,u)
    _GDPoptAlgorithm.update_incumbent=inc
    original_solve=comparison.TimedGAMS.solve
    def solve(self,m,**kw):
        emit('wrapper.before',arguments=kw,model=snapshot(m))
        result=original_solve(self,m,**kw)
        state['last_solver_result']={'termination':str(result.solver.termination_condition),
                                     'LB':comparison.finite(result.problem.lower_bound),
                                     'UB':comparison.finite(result.problem.upper_bound)}
        emit('wrapper.after',model=snapshot(m))
        return result
    comparison.TimedGAMS.solve=solve
    # Preserve raw GAMS files before archived TimedGAMS deletes its temporary directory.
    from pyomo.solvers.plugins.solvers.GAMS import GAMSShell
    original_shell=GAMSShell.solve
    def shell(self,m,**kw):
        import shutil
        try:return original_shell(self,m,**kw)
        finally:
            tmp=kw.get('tmpdir')
            if tmp and Path(tmp).exists():
                dest=out/'raw_calls'/f'{len(comparison.CONTEXT.calls)+1:05d}'
                dest.mkdir(parents=True,exist_ok=True)
                for f in Path(tmp).iterdir():
                    if f.is_file() and f.suffix in {'.gms','.lst','.dat','.opt','.log'}:
                        shutil.copy2(f,dest/f.name)
    GAMSShell.solve=shell
    config=json.loads((ROOT/f'inputs/{args.case}/run.json').read_text())['config']
    config.update(executable=args.gams,time_limit=1800)
    if args.case=='grid':
        from gdp_models.grid_benchmark import grid_template
        template=grid_template('michalewicz')
        config.update(nlp_solver='baron',mip_solver='highs',baron_lp_solver='clp')
    else:template=comparison.build_template('cstr',cstr_size=15)
    logging.getLogger('pyomo.contrib.gdpopt').setLevel(logging.DEBUG)
    before=time.monotonic()
    save(out/'actual_settings.json',{'config':config,'variant':args.variant,'cpu':cpu,
                                   'thread_environment':{k:v for k,v in os.environ.items() if k.endswith('NUM_THREADS') or k.startswith('OMP_')},
                                   'hypothesis':'singleton sine FBBT rejection' if args.case=='grid' else 'convex cut uses concave slope',
                                   'changes':['diagnostic logging and raw-file retention']+([] if args.variant=='baseline' else [args.variant])})
    result=comparison.solve_method(template,'gloa',out,config,time.monotonic()+1800)
    if args.case=='grid':
        from gdp_models.grid_benchmark import check_grid_solution
        report=json.loads((out/'result.json').read_text())
        save(out/'grid_validation.json',check_grid_solution(template,out,report))
    emit('run.end',report=result,solver_calls=len(comparison.CONTEXT.calls),solve_wall_s=time.monotonic()-before)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--case',choices=['grid','cstr'],required=True)
    parser.add_argument('--variant',choices=['baseline','sin-singleton','convex-slope'],default='baseline')
    parser.add_argument('--gams',default='/package/gams/52.2/gams')
    parser.add_argument('--execute',action='store_true')
    parser.add_argument('--worker-output',type=Path)
    args=parser.parse_args()
    if (args.case,args.variant) not in {('grid','baseline'),('grid','sin-singleton'),('cstr','baseline'),('cstr','convex-slope')}:
        parser.error('Patch is not applicable to this case')
    if args.worker_output:
        slot=os.environ.get('GDP_DIAG_ALLOCATED_SLOT')
        if slot not in {'1','2'}:raise SystemExit('Worker requires a controller allocation')
        ledger=ROOT/'execution_ledger'/f'full_run_{slot}.json'
        if not ledger.is_file():raise SystemExit('Missing allocation')
        record=json.loads(ledger.read_text())
        if record['case']!=args.case or record['variant']!=args.variant:
            raise SystemExit('Worker allocation mismatch')
        fd=os.open(ROOT/'execution_ledger'/f'worker_started_{slot}',os.O_CREAT|os.O_EXCL|os.O_WRONLY)
        os.close(fd)
        checked=environment(args)
        if checked['errors']:raise SystemExit(str(checked['errors']))
        worker(args,args.worker_output);return
    checked=environment(args)
    save(ROOT/f'environment_check_{args.case}.json',checked)
    print(json.dumps(checked,indent=2))
    if not args.execute or checked['errors']:return
    ledger=ROOT/'execution_ledger';ledger.mkdir(exist_ok=True)
    slot=None
    for i in (1,2):
        try:
            fd=os.open(ledger/f'full_run_{i}.json',os.O_CREAT|os.O_EXCL|os.O_WRONLY)
            os.close(fd);slot=i;break
        except FileExistsError:continue
    if slot is None:raise SystemExit('GDPopt full-run limit (2) reached; refusing execution')
    out=ROOT/'executions'/f'{slot}_{args.case}_{args.variant}';out.mkdir(parents=True)
    config={'case':args.case,'variant':args.variant,'full_run':slot,'time_limit_s':1800,
            'fixed_subproblem_calls':0,'environment':checked,'status':'started'}
    save(ledger/f'full_run_{slot}.json',config)
    started=time.monotonic()
    command=[sys.executable,str(Path(__file__).resolve()),'--case',args.case,'--variant',args.variant,
             '--gams',args.gams,'--worker-output',str(out)]
    with (out/'run.log').open('w') as log:
        env=os.environ.copy();env['GDP_DIAG_ALLOCATED_SLOT']=str(slot)
        run=json.loads((ROOT/f'inputs/{args.case}/run.json').read_text())
        env.update(run['runtime']['thread_environment'] if args.case=='grid' else run['thread_environment'])
        proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=env)
        try:code=proc.wait(timeout=1800)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL);code=proc.wait();config['timeout']=True
    config.update(status='finished',returncode=code,wall_s=time.monotonic()-started,command=command)
    calls=out/'solver_calls.jsonl'
    config['GDPopt_internal_wrapper_calls']=len(calls.read_text().splitlines()) if calls.exists() else 0
    save(ledger/f'full_run_{slot}.json',config)


if __name__=='__main__':main()
