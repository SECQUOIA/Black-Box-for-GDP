"""Extract historical events without inventing unrecorded candidate identities."""
import csv
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
UNKNOWN = '기록 없음'


def write_csv(name, rows):
    with (ROOT / name).open('w') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def parse_run(path, case, method):
    events = {x['iteration']: x for x in map(json.loads, (path/'incumbents.jsonl').read_text().splitlines())
              if x['iteration'] is not None}
    calls = list(map(json.loads, (path/'solver_calls.jsonl').read_text().splitlines()))
    rows = []
    # A GAMS job start corresponds one-for-one to a retained wrapper call.
    call_index = 0
    pending_calls = []
    for line_number, line in enumerate((path/'run.log').read_text().splitlines(), 1):
        if line.startswith('--- Job model.gms Start'):
            call_index += 1
            pending_calls.append(call_index)
        match = re.match(r'^\s*(\d+)\s+(discrete|subproblem)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s*(\*)?\s*$', line)
        terminal = re.match(r'^\s*(\d+)\s+(\S+)\s+(\S+)\s+(\S+%)\s+(\S+)\s*$', line)
        if not match and not terminal:
            continue
        if match:
            iteration, phase, lb, ub, gap, time, star = match.groups()
        else:
            iteration, lb, ub, gap, time = terminal.groups()
            phase, star = 'termination', None
        iteration = int(iteration)
        e = events.get(iteration)
        callrows = [calls[i-1] for i in pending_calls]
        rows.append({'case': case, 'method': method, 'iteration': iteration, 'phase': phase,
                     'configuration': ';'.join(e['selected_disjuncts']) if e else UNKNOWN,
                     'configuration_evidence': 'same-iteration feasible callback' if e else UNKNOWN,
                     'preprocess': UNKNOWN,
                     'wrapper_call_indices': ';'.join(map(str,pending_calls)) or '0',
                     'solver': ';'.join(x['solver'] for x in callrows) or UNKNOWN,
                     'solver_termination': ';'.join(x['termination'] for x in callrows) or UNKNOWN,
                     'subproblem_objective': e['candidate_objective'] if e and phase == 'subproblem' else UNKNOWN,
                     'call_lower_bounds': ';'.join(str(x.get('lower_bound')) for x in callrows) or UNKNOWN,
                     'call_upper_bounds': ';'.join(str(x.get('upper_bound')) for x in callrows) or UNKNOWN,
                     'gdpopt_incumbent_update': bool(star) if phase == 'subproblem' else UNKNOWN,
                     'exclusion_observation': UNKNOWN,
                     'gdpopt_lower_bound_printed': lb, 'gdpopt_upper_bound_printed': ub,
                     'log_elapsed_s': time, 'log_line': line_number})
        pending_calls = []
    assert call_index == len(calls), (path, call_index, len(calls))
    return rows, events, calls


def main():
    summaries = {}
    for method in ['ric', 'gloa', 'loa']:
        path = ROOT/f'inputs/grid/benchmark/michalewicz/{method}'
        rows, events, calls = parse_run(path, 'grid_michalewicz', method)
        write_csv(f'grid_{method}_events.csv', rows)
        pairs = [tuple(int(s.split('[')[1][:-1]) for s in e['selected_disjuncts']) for e in events.values()]
        summaries[method] = {'callback_count': len(events), 'distinct_callback_points':len(set(pairs)),
                             'wrapper_calls':len(calls), 'all_calls_highs':all(c['solver']=='highs' for c in calls),
                             'target_point_callback':(21,15) in pairs,
                             'discrete_rows':sum(r['phase']=='discrete' for r in rows),
                             'subproblem_rows':sum(r['phase']=='subproblem' for r in rows),
                             'unidentified_iterations':[r['iteration'] for r in rows if r['phase']=='discrete' and r['configuration']==UNKNOWN]}
    rows, _, _ = parse_run(ROOT/'inputs/cstr/jobs/cstr_15/gloa', 'cstr15_A12', 'gloa')
    write_csv('cstr_events.csv', rows)
    (ROOT/'historical_summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
    for label in ['grid','cstr']:
        p=ROOT/f'inputs/{label}'
        run=json.loads((p/'run.json').read_text())
        for name,expected in run['source_sha256'].items():
            assert hashlib.sha256((p/'source'/name).read_bytes()).hexdigest()==expected, (label,name)
    print({k:{n:v for n,v in s.items() if n!='unidentified_iterations'} for k,s in summaries.items()})


if __name__ == '__main__':
    main()
