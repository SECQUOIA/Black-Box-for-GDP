"""Reconstruct initial GLOA cuts from the saved A12 incumbent without a solver."""
import inspect
import json
import logging
import sys
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'inputs/cstr/source'))
import pyomo.environ as p
from pyomo.gdp import Disjunct
from gdp_models.comparison import build_template, reformulate
from pyomo.contrib.gdpopt import create_oa_subproblems as create
from pyomo.contrib.gdpopt import gloa
from pyomo.contrib.gdpopt.util import move_nonlinear_objective_to_constraints
from pyomo.contrib.fbbt.fbbt import fbbt
from pyomo.contrib.gdpopt.cut_generation import add_no_good_cut
from patches import apply_gloa_patch


def load_values(m, values):
    for name, value in values.items():
        v = m.find_component(name)
        if v is not None:
            v.set_value(value, skip_validation=True)
    for d in m.component_data_objects(Disjunct, descend_into=(p.Block, Disjunct)):
        d.indicator_var.set_value(bool(round(p.value(d.binary_indicator_var))))


def reconstruct(corrected=False):
    template = build_template('cstr', cstr_size=15)
    m = template.model
    reformulate(m, 'gloa')
    u = create.add_util_block(m)
    create.add_disjunct_list(u)
    create.add_boolean_variable_lists(u)
    create.add_algebraic_variable_list(u)
    create.add_constraints_by_disjunct(u)
    create.add_global_constraint_list(u)
    create.add_discrete_variable_list(u)
    move_nonlinear_objective_to_constraints(u, logging.getLogger('probe'))
    sub, su = create.get_subproblem(m, u)
    discrete = m.clone()
    du = discrete.find_component(u.name)
    for c in discrete.component_data_objects(p.Constraint, active=True, descend_into=(p.Block, Disjunct)):
        if c.body.polynomial_degree() not in (0, 1):
            c.deactivate()
    p.TransformationFactory('gdp.bigm').apply_to(discrete)
    create.add_transformed_boolean_variable_list(du)
    du.no_good_cuts = p.ConstraintList()
    # The archived set-covering MIP applies this presolve before the first solve.
    # Its objective change does not affect FBBT.
    fbbt(discrete, integer_tol=1e-5, deactivate_satisfied_constraints=False)
    saved = json.loads((ROOT / 'inputs/cstr/jobs/cstr_15/gloa/solution.json').read_text())['variables']
    load_values(discrete, saved)
    load_values(sub, saved)
    solver = p.SolverFactory('gdpopt.gloa')
    restore = apply_gloa_patch() if corrected else lambda: None
    solver._add_cuts_to_discrete_problem(su, du, p.minimize, solver.config, solver.timing)
    restore()
    add_no_good_cut(du, solver.config)
    witness = json.loads((ROOT / 'inputs/cstr_witness/solution.json').read_text())['variables']
    load_values(discrete, witness)
    no_good_witness_value = p.value(du.no_good_cuts[1].body)
    bound_violations = []
    for v in discrete.component_data_objects(p.Var, descend_into=(p.Block, Disjunct)):
        if v.value is None:
            continue
        violation = max(0, v.lb-v.value if v.has_lb() else 0, v.value-v.ub if v.has_ub() else 0)
        if violation > 1e-8:
            bound_violations.append({'variable':v.name,'violation':violation})
    rows = []
    for parent, block in du.aff_utils_blocks.items():
        applicable = not isinstance(parent, Disjunct) or bool(p.value(parent.indicator_var))
        for c in block.component_data_objects(p.Constraint, active=None):
            body = p.value(c.body)
            violation = max(0, p.value(c.lower)-body if c.has_lb() else 0,
                            body-p.value(c.upper) if c.has_ub() else 0)
            rows.append({'cut': c.name, 'scope': parent.name, 'applicable_to_W03': applicable,
                         'violation': violation, 'expression': str(c.expr)})
    transformed_violations = []
    for c in discrete.component_data_objects(p.Constraint, active=True):
        body = p.value(c.body)
        v = max(0, p.value(c.lower)-body if c.has_lb() else 0,
                body-p.value(c.upper) if c.has_ub() else 0)
        if v > 1e-8:
            transformed_violations.append({'constraint': c.name, 'violation': v})
    try:
        fbbt(discrete, integer_tol=solver.config.integer_tolerance, deactivate_satisfied_constraints=False)
        presolve = 'passed'
    except Exception as e:
        presolve = repr(e)
    return {'corrected_convex_slope': corrected, 'cuts': rows,
            'W03_no_good_body': no_good_witness_value, 'no_good_lower_bound': 1,
            'W03_initial_master_bound_violations': bound_violations,
            'transformed_witness_violations': transformed_violations,
            'initial_cuts_mip_fbbt': presolve,
            'limitations': 'Saved final incumbent equals initialization incumbent; later nonincumbent continuous vector was not retained; local MC++ binary differs from Dantzig.'}


if __name__ == '__main__':
    results = [reconstruct(False), reconstruct(True)]
    (ROOT / 'cstr_probe.json').write_text(json.dumps(results, indent=2) + '\n')
    for r in results:
        print({k: v for k, v in r.items() if k != 'cuts'})
        print('Applicable violated cuts', [c for c in r['cuts'] if c['applicable_to_W03'] and c['violation'] > 1e-8])
