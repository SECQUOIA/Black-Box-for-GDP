# 실행 방법

조사 결론은 [REPORT.md](REPORT.md)에 있다.
모든 명령은 원자료 복사본과 별도 진단 출력만 사용한다.
실험 성능표를 생성하지 않는다.
`inputs/*/source`는 archive에서 추출한 실행 소스이며 변경하지 않는다.
`analysis_sources`는 사용한 Pyomo 소스와 pinned CSTR 모델의 감사용 복사본이다.
실행은 manifest로 확인한 설치 환경의 Pyomo를 사용한다.

로컬 solver-free 검사는 아래 환경에서 수행했다.

```sh
cd /Users/albertlee0125/Repos/RBFopt_Test
export RBFOPT_GDP_SOURCES="$PWD/external"
export PYOMO_CONFIG_DIR="$PWD/.pyomo-gdp-comparison"
export PYTHONDONTWRITEBYTECODE=1
export MPLCONFIGDIR=/tmp/gdpopt-diag-mpl
DIAG_PY=/private/tmp/pr48-local-ci-854a1a7/fmqa-env/bin/python
"$DIAG_PY" diagnostics/gdpopt_20261023/analyze_records.py
"$DIAG_PY" diagnostics/gdpopt_20261023/grid_probe.py
"$DIAG_PY" diagnostics/gdpopt_20261023/grid_sweep.py
"$DIAG_PY" diagnostics/gdpopt_20261023/test_regressions.py
```

`grid_probe.py`는 세 구성의 목적함수 이동과 FBBT를 검사한다.
`grid_sweep.py`는 원본과 singleton-sine 후보 패치를 각각 961개 구성에 적용하며 solver를 부르지 않는다.
`test_regressions.py`의 마지막 검사는 별도 프로세스에서 `cstr_probe.py`의 실제 cut 생성 함수를 호출한다.
이는 이미 완료된 W03 실행 가능성 최적화를 반복하는 검사가 아니다.
`cstr_probe.json`에는 disjunct 적용 범위, cut 식, 위반량, no-good 만족 여부가 있다.
`grid_*_events.csv`와 `cstr_events.csv`는 원로그의 행 번호와 wrapper 호출 번호를 연결한다.
저장되지 않은 항목은 `기록 없음`이다.
원로그의 반올림된 GDPopt 하한·상한과 wrapper의 원래 정밀도 값을 별도 열에 보존한다.

Dantzig에서는 이 디렉터리를 복사하거나 제공된 ZIP을 새 위치에 풀어 사용한다.
기존 Dantzig 저장소에서 아래 환경을 설정한 후 명령을 실행한다.

```sh
export RBFOPT_GDP_SOURCES="$PWD/external"
export PYOMO_CONFIG_DIR="$PWD/.pyomo-gdp-comparison"
export PYTHONDONTWRITEBYTECODE=1
export MPLCONFIGDIR=/tmp/gdpopt-diag-mpl
DIAG_PY="$PWD/.venv-dantzig-gdp/bin/python"
cd /path/to/new/gdpopt_20261023
"$DIAG_PY" dantzig_trace.py --case grid
"$DIAG_PY" dantzig_trace.py --case cstr
```

기본 명령은 환경 확인만 하며 solver를 실행하지 않는다.
GAMS 실행파일, MC++ 바이너리, Python·의존성 버전, archive 소스 해시가 다르면 전체 실행을 거부한다.
CSTR은 pinned upstream checkout과 세 원본 파일의 해시도 확인한다.
원래 GAMS 경로는 `/package/gams/52.2/gams`다.
원래 CPU affinity는 Grid 6, CSTR 2이며 worker가 이를 적용한다.
원래 단일 스레드 환경은 manifest에서 읽어 worker에 전달한다.
원래 GAMS 호출 제한과 wrapper reserve 로직을 보존하고 controller는 1,800초에 프로세스 그룹을 종료한다.
로그 저장 비용은 진단 시간에 포함되므로 새 시간은 성능 비교에 사용하지 않는다.

첫 실행은 Grid에서 목적값 0인 구성이 FBBT 예외 후 no-good으로 제외된다는 가설을 확인한다.
원래 설정에 기록만 추가한다.

```sh
"$DIAG_PY" dantzig_trace.py --case grid --variant baseline --execute
```

먼저 결과에서 `(21,15)`의 선택, FBBT 예외, wrapper 호출 유무, incumbent, no-good을 확인한다.
추적에는 후보별 변수 값과 경계, 전처리 전후 상태, raw GAMS 파일, 새 cut 식, 하한·상한 갱신이 포함된다.
원래 환경에서 현재 가설이 반박되면 두 번째 실행을 바로 시작하지 않는다.

CSTR은 우선 같은 환경에서 solver-free cut 재구성을 수행한다.

```sh
"$DIAG_PY" cstr_probe.py > cstr_same_environment_probe.log 2>&1
```

두 번째 전체 실행은 기존 A12를 대조군으로 두고 convex 기울기만 바꾸는 후보 명령이다.
기존 초기 cut이 W03을 배제하며 기울기 교체가 이를 없앤다는 가설을 검증한다.

```sh
"$DIAG_PY" dantzig_trace.py --case cstr --variant convex-slope --execute
```

대신 Grid의 수정 효과를 검증할 필요가 생기면 두 번째 슬롯에 `--case grid --variant sin-singleton`을 사용할 수 있다.
두 대안을 모두 실행하면 안 된다.
`execution_ledger`는 두 슬롯까지만 허용하며 실패·중단도 사용한 실행으로 센다.
ledger를 삭제하거나 패키지를 새로 복사해 상한을 우회하지 않는다.
독립 고정 구성 하위문제 runner는 제공하지 않았으며 추가 최적화가 필요하면 남은 상한 4회와 각 120초를 별도로 관리해야 한다.

`fbbt_fbbt.patch`와 `gdpopt_gloa.patch`는 검토용 최소 diff다.
프로덕션 환경이나 원자료에 적용하지 않았다.
진단 runner의 패치는 선택한 한 요소만 해당 프로세스 안에 적용한다.
전체 benchmark의 재실행 명령은 포함하지 않았다.
