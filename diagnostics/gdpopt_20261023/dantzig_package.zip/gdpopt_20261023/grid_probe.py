"""Solver-free replay of archived grid objective transformation and presolve."""
import json
import logging
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'inputs/grid/source'))
import pyomo.environ as p
from gdp_models.grid import build_grid_gdp, _assign_point
from pyomo.contrib.gdpopt import create_oa_subproblems as create
from pyomo.contrib.gdpopt.util import move_nonlinear_objective_to_constraints
from pyomo.contrib.gdpopt.solve_subproblem import preprocess_subproblem
from pyomo.contrib.fbbt.fbbt import fbbt


def setup(point):
    m = build_grid_gdp('michalewicz')
    u = create.add_util_block(m)
    create.add_disjunct_list(u)
    create.add_boolean_variable_lists(u)
    create.add_algebraic_variable_list(u)
    move_nonlinear_objective_to_constraints(u, logging.getLogger('probe'))
    m, u = create.get_subproblem(m, u)
    for axis, selected in zip((m.Xchoice, m.Ychoice), point):
        for i, d in axis.items():
            d.indicator_var.fix(i == selected)
            if i != selected:
                d.deactivate()
    return m, u


def snapshot(m, u):
    return {v.name: {'value': v.value, 'bounds': list(v.bounds), 'fixed': v.fixed}
            for v in (m.x, m.y, u.objective_value)}


def probe(point):
    m, u = setup(point)
    config = p.SolverFactory('gdpopt.gloa').config
    config.logger = logging.getLogger('probe')
    result = {'point': point, 'initial': snapshot(m, u)}
    _assign_point(m, point)
    result['original_objective_at_point'] = p.value(m.obj.expr)
    try:
        fbbt(m, integer_tol=config.integer_tolerance,
             feasibility_tol=config.constraint_tolerance,
             max_iter=config.max_fbbt_iterations)
        result['fbbt'] = snapshot(m, u)
    except Exception as e:
        result['fbbt_error'] = repr(e)
        result['fbbt_at_exception'] = snapshot(m, u)
    m, u = setup(point)
    with preprocess_subproblem(u, config) as ok:
        result['presolve_allows_solver'] = ok
        result['inside_presolve'] = snapshot(m, u)
        result['active_constraints'] = [c.name for c in m.component_data_objects(p.Constraint, active=True)]
    result['after_presolve'] = snapshot(m, u)
    return result


if __name__ == '__main__':
    started = time.monotonic()
    logging.basicConfig(level=logging.DEBUG)
    logging.getLogger('pyomo.core').setLevel(logging.WARNING)
    from pyomo.contrib.fbbt import interval
    original_asin = interval.asin
    asin_events = []
    def traced_asin(*args):
        result = original_asin(*args)
        asin_events.append({'input': args, 'output': result})
        return result
    interval.asin = traced_asin
    results = [probe(point) for point in [(21, 15), (22, 15), (0, 0)]]
    interval.asin = original_asin
    (ROOT / 'grid_probe.json').write_text(json.dumps(results, indent=2) + '\n')
    (ROOT / 'grid_asin_trace.json').write_text(json.dumps(asin_events, indent=2) + '\n')
    (ROOT / 'grid_probe_accounting.json').write_text(json.dumps({'solver_calls':0,'wall_s':time.monotonic()-started},indent=2)+'\n')
    print(json.dumps(results, indent=2))
