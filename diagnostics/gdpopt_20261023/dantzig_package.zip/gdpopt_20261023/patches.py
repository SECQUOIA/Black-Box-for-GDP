"""Opt-in, process-local candidate patches; installed dependencies stay unchanged."""
import difflib
import importlib
import inspect
import textwrap
from pathlib import Path


def patched_sin_source(source):
    old = '    _lb1, _ub1 = interval.asin(lb0, ub0, lb1, ub1, feasibility_tol)'
    new = '''    # A singleton argument cannot be tightened further.
    # Do not jump to another sine branch for roundoff within the existing tolerance.
    if lb1 == ub1 and lb0 - feasibility_tol <= math.sin(lb1) <= ub0 + feasibility_tol:
        return
''' + old
    assert source.count(old) == 1
    return source.replace(old, new)


def patched_gloa_source(source):
    old = '                convex_cut = cut_body + cvStart <= ub_int'
    new = '''                convex_body = sum(
                    cvSlope[var] * (var - var.value)
                    for var in vars_in_constr
                    if not var.fixed
                )
                convex_cut = convex_body + cvStart <= ub_int'''
    assert source.count(old) == 1
    return source.replace(old, new)


def apply_sin_patch():
    module = importlib.import_module('pyomo.contrib.fbbt.fbbt')
    source = patched_sin_source(inspect.getsource(module._prop_bnds_root_to_leaf_sin))
    scope = dict(vars(module))
    exec(compile(source, '<candidate-singleton-sin-patch>', 'exec'), scope)
    original = module._unary_root_to_leaf_map['sin']
    module._unary_root_to_leaf_map['sin'] = scope['_prop_bnds_root_to_leaf_sin']
    return lambda: module._unary_root_to_leaf_map.__setitem__('sin', original)


def apply_gloa_patch():
    from pyomo.contrib.gdpopt import gloa
    source = patched_gloa_source(inspect.getsource(gloa))
    # Compile just the changed method, avoiding class registration side effects.
    import ast
    tree = ast.parse(source)
    cls = next(x for x in tree.body if isinstance(x, ast.ClassDef))
    fn = next(x for x in cls.body if isinstance(x, ast.FunctionDef) and x.name == '_add_cuts_to_discrete_problem')
    scope = dict(vars(gloa))
    exec(compile(ast.Module(body=[fn], type_ignores=[]), '<candidate-gloa-patch>', 'exec'), scope)
    original = gloa.GDP_GLOA_Solver._add_cuts_to_discrete_problem
    gloa.GDP_GLOA_Solver._add_cuts_to_discrete_problem = scope[fn.name]
    return lambda: setattr(gloa.GDP_GLOA_Solver, fn.name, original)


if __name__ == '__main__':
    root = Path(__file__).resolve().parent
    for name, transform in [('fbbt/fbbt', patched_sin_source), ('gdpopt/gloa', patched_gloa_source)]:
        module = importlib.import_module('pyomo.contrib.' + name.replace('/', '.'))
        source = inspect.getsource(module)
        diff = ''.join(difflib.unified_diff(source.splitlines(True), transform(source).splitlines(True),
                                          fromfile='a/pyomo/contrib/' + name + '.py',
                                          tofile='b/pyomo/contrib/' + name + '.py'))
        (root / (name.replace('/', '_') + '.patch')).write_text(diff)
