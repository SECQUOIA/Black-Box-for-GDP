#!/usr/bin/env bash
set -Eeuo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
export PYTHONUNBUFFERED=1 PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=1 OMP_THREAD_LIMIT=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export BLIS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 NUMEXPR_MAX_THREADS=1 VECLIB_MAXIMUM_THREADS=1 GOTO_NUM_THREADS=1
export OMP_DYNAMIC=FALSE MKL_DYNAMIC=FALSE CUDA_VISIBLE_DEVICES=""
BASE=${DSDA_PYTHON:-${PR56_REPOSITORY:-/local/scratch/a/lee4382/repository/RBFopt_Test}/.venv-dantzig/bin/python}
test -x "$BASE" || { echo "Existing D-SDA Python missing: $BASE" >&2; exit 1; }
exec "$BASE" "$ROOT/launch.py" start "$@"
