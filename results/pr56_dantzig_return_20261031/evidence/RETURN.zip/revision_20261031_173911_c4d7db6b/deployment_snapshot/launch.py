#!/usr/bin/env python3
"""Detached, offline setup and launch for the frozen PR56 experiment package."""

import argparse
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import platform
import resource
import shutil
import signal
import subprocess
import sys
import time
import traceback

import campaign

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source"
EXISTING = Path(
    os.environ.get("PR56_REPOSITORY", "/local/scratch/a/lee4382/repository/RBFopt_Test")
)
BASE = Path(os.environ.get("DSDA_PYTHON", str(EXISTING / ".venv-dantzig/bin/python")))
ENVIRONMENT = ROOT / ".venv-mi-dfo"
STATE = ROOT / "bootstrap.json"


def host_guard():
    if platform.system() != "Linux" or platform.node().split(".")[0] != "dantzig":
        raise RuntimeError(
            "Run this package on Dantzig. No experiments may run on this computer."
        )
    if platform.machine() not in ("x86_64", "amd64"):
        raise RuntimeError("The bundled wheels require Linux x86_64")


def verify_package():
    expected = json.loads((ROOT / "PACKAGE_SHA256.json").read_text())
    for name, digest in expected.items():
        if campaign.sha(ROOT / name) != digest:
            raise RuntimeError(f"Package hash mismatch: {name}")
    source = json.loads((ROOT / "SOURCE_MANIFEST.json").read_text())
    if source["revision"] != campaign.REVISION:
        raise RuntimeError("Unexpected source revision")
    for name, digest in source["files"].items():
        if campaign.sha(SOURCE / name) != digest:
            raise RuntimeError(f"Original source changed: {name}")
    campaign.snapshot(SOURCE)
    return len(expected)


def shell_read(argv, cwd=None):
    try:
        result = subprocess.run(
            argv,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=30,
            env={**os.environ, "GIT_OPTIONAL_LOCKS": "0"},
        )
        return dict(
            command=argv,
            returncode=result.returncode,
            stdout=result.stdout,
            stderr=result.stderr,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return dict(command=argv, error=str(exc))


def conflicting_processes():
    conflicts = []
    for path in Path("/proc").glob("[0-9]*"):
        try:
            if path.stat().st_uid != os.getuid():
                continue
            cmd = (
                (path / "cmdline")
                .read_bytes()
                .replace(b"\0", b" ")
                .decode(errors="replace")
            )
            if any(
                s in cmd
                for s in (
                    "dsda_process_multistart/run.py",
                    "mixed_integer_dfo/run.py",
                    "experiments/run_revision_dantzig.sh",
                )
            ):
                conflicts.append(dict(pid=int(path.name), command=cmd))
        except (OSError, ValueError):
            pass
    return conflicts


def inventory():
    record = dict(
        host=platform.node(),
        recorded_utc=campaign.now(),
        uid=os.getuid(),
        affinity=sorted(os.sched_getaffinity(0)),
        existing_repository=str(EXISTING),
        source_repository=str(SOURCE),
        existing_git={},
        agents={},
        scheduler={},
        outputs=[],
        competing_experiments=conflicting_processes(),
    )
    if EXISTING.is_dir():
        for key, args in (
            ("head", ["rev-parse", "HEAD"]),
            ("branch", ["branch", "--show-current"]),
            ("remotes", ["remote", "-v"]),
            ("status", ["status", "--porcelain"]),
            ("worktrees", ["worktree", "list"]),
            ("stash", ["stash", "list"]),
        ):
            record["existing_git"][key] = shell_read(
                ["git", "-C", str(EXISTING), *args]
            )
        if (EXISTING / "results").is_dir():
            record["outputs"] = sorted(
                str(p)
                for p in (EXISTING / "results").iterdir()
                if any(
                    s in p.name
                    for s in (
                        "revision",
                        "multistart",
                        "mixed_integer",
                        "nomad",
                        "miso",
                    )
                )
            )
    for root in {EXISTING, SOURCE, ROOT, *EXISTING.parents, *ROOT.parents}:
        path = root / "AGENTS.md"
        if path.is_file():
            record["agents"][str(path)] = path.read_text()
    for key in (
        "SLURM_JOB_ID",
        "SLURM_CPUS_ON_NODE",
        "SLURM_CPUS_PER_TASK",
        "PBS_JOBID",
        "PBS_NODEFILE",
        "JOB_ID",
        "NSLOTS",
    ):
        if key in os.environ:
            record["scheduler"][key] = os.environ[key]
    record["scheduler"]["commands"] = {
        cmd: shutil.which(cmd) for cmd in ("srun", "scontrol", "qstat", "qsub")
    }
    record["cpu_topology"] = shell_read(["lscpu", "-e=CPU,CORE,SOCKET,ONLINE"])
    record["user_processes"] = shell_read(
        ["ps", "-u", str(os.getuid()), "-o", "pid,ppid,psr,pcpu,etime,args"]
    )
    record["cgroup"] = Path("/proc/self/cgroup").read_text()
    return record


def status(verbose=False):
    if not STATE.exists():
        print("NOT_STARTED — run: bash RUN.sh")
        return
    state = campaign.read(STATE)
    alive = campaign.alive(state)
    phase = state["state"]
    if phase not in ("finished", "finished_with_issues", "abnormal_exit") and not alive:
        phase = "abnormal_exit (launcher no longer exists)"
    print(
        f"STATE={phase}; launcher_alive={alive}; PID={state.get('pid')}; exit_code={state.get('exit_code')}"
    )
    print("REVISION=" + campaign.REVISION)
    print("LOG=" + str(ROOT / "launcher.log"))
    out = Path(state["output"])
    print("OUTPUT=" + str(out))
    if state.get("error"):
        print("ERROR=" + state["error"].splitlines()[-1])
    if (out / "plan.json").exists():
        details = campaign.status(out, emit=False)
        print(f"D-SDA: results={details['dsda_results']}/420")
        if (out / "dsda_validation.json").exists():
            dsda = campaign.read(out / "dsda_validation.json")
            print(
                f"D-SDA replay={dsda['replay_matched']}/{dsda['replay_checked']}; passed={dsda['passed']}; changed_outcomes={len(dsda['changed_outcomes'])}"
            )
        for method, row in details["methods"].items():
            print(
                f"{method.upper()}: results={row['results']}/1190; target_hits={row['hits']}; execution_failures={row['execution_failures']}; statuses={json.dumps(row['statuses'], sort_keys=True)}"
            )
        for group in details["groups"]:
            if verbose or group["state"] in ("running", "starting", "abnormal_exit"):
                print(
                    f"{group['name']}: {group['state']}; results={group['results']}/{group['expected']}; cpu={group['cpu']}; pid={group['pid']}; affinity={group.get('effective_cpus')}; exit={group['exit_code']}"
                )
    if (ROOT / "RETURN.zip").is_file():
        print("RETURN_ARCHIVE=" + str(ROOT / "RETURN.zip"))
        print((ROOT / "RETURN.zip.sha256").read_text().strip())


def start():
    host_guard()
    if not BASE.is_file():
        raise RuntimeError(
            f"Existing D-SDA Python not found: {BASE}; set DSDA_PYTHON explicitly"
        )
    for cmd in ("git", "taskset", "lscpu"):
        if not shutil.which(cmd):
            raise RuntimeError(f"Required command missing: {cmd}")
    # Claim the package once. Never overwrite a completed or interrupted attempt.
    lock = (ROOT / "start.lock").open("a+")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    if STATE.exists():
        status()
        raise RuntimeError(
            "This package already has a launch attempt. Existing results are preserved; do not restart it wholesale."
        )
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    out = ROOT / "output" / f"revision_{stamp}_{campaign.REVISION[:8]}"
    record = dict(
        state="starting",
        created_utc=campaign.now(),
        output=str(out),
        revision=campaign.REVISION,
        exit_code=None,
    )
    campaign.write(STATE, record)
    with (ROOT / "launcher.log").open("xb") as log:
        process = subprocess.Popen(
            [str(BASE), str(ROOT / "launch.py"), "background"],
            cwd=ROOT,
            stdin=subprocess.DEVNULL,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
            env={**os.environ, **campaign.THREADS},
        )
    # The child owns subsequent state writes; avoid racing its phase transitions.
    print(f"LAUNCHER_STARTED PID={process.pid}")
    print("LOG=" + str(ROOT / "launcher.log"))
    print("OUTPUT=" + str(out))
    print(
        "The launcher will prepare the private environment, run the required preflight and D-SDA, then start the queue."
    )
    print("Check: bash STATUS.sh   (or: tail -f launcher.log)")


def background():
    signal.signal(signal.SIGHUP, signal.SIG_IGN)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    host_guard()
    record = campaign.read(STATE)
    record.update(
        pid=os.getpid(),
        proc_start=campaign.proc_start(os.getpid()),
        started_utc=campaign.now(),
    )
    out = Path(record["output"])

    def phase(name):
        record["state"] = name
        campaign.write(STATE, record)
        print(f"PHASE={name} UTC={campaign.now()}", flush=True)

    lease_path = Path(f"/tmp/pr56_dantzig_{os.getuid()}_{campaign.REVISION[:8]}.lock")
    lease_fd = os.open(lease_path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    lease = os.fdopen(lease_fd, "a+")
    try:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        phase("verifying_package")
        print(f"PACKAGE_HASHES_VERIFIED={verify_package()}", flush=True)
        inspection = inventory()
        campaign.write(ROOT / "server_inventory.json", inspection)
        if inspection["competing_experiments"]:
            raise RuntimeError(
                "Another PR56 experiment runner is active: "
                + json.dumps(inspection["competing_experiments"])
            )
        for path, content in inspection["agents"].items():
            print(f"AGENTS_SOURCE={path}\n{content}", flush=True)
        scheduler = inspection["scheduler"]
        if (
            Path("/etc/slurm/slurm.conf").exists() or scheduler["commands"]["scontrol"]
        ) and not os.environ.get("SLURM_JOB_ID"):
            raise RuntimeError(
                "Slurm is configured; run inside an authorized allocation so its CPU restrictions take precedence"
            )
        if (Path("/etc/pbs.conf").exists() or scheduler["commands"]["qsub"]) and not (
            os.environ.get("PBS_JOBID") or os.environ.get("JOB_ID")
        ):
            raise RuntimeError(
                "A batch scheduler is configured; run inside an authorized allocation"
            )
        version_script = "import json,platform,importlib.metadata as m; print(json.dumps({'python':platform.python_version(),'packages':{x:m.version(x) for x in ['numpy','pandas','scipy']}}))"
        baseline = json.loads(
            subprocess.check_output([str(BASE), "-c", version_script], text=True)
        )
        campaign.write(ROOT / "dsda_environment.json", baseline)
        if sys.version_info[:2] != (3, 11):
            raise RuntimeError(
                "Bundled wheels require the documented Dantzig Python 3.11 environment"
            )
        expected = {"numpy": "2.4.6", "pandas": "2.3.3", "scipy": "1.17.1"}
        if baseline["packages"] != expected:
            raise RuntimeError(
                "Existing D-SDA numerical environment differs from the archived reference; preserved without installation: "
                + json.dumps(baseline)
            )
        phase("preparing_environment")
        if ENVIRONMENT.exists():
            raise RuntimeError(
                "Private environment already exists; preserve it and inspect before a separate setup attempt"
            )
        with (ROOT / "installation.log").open("xb") as log:
            subprocess.run(
                [str(BASE), "-m", "venv", str(ENVIRONMENT)],
                stdout=log,
                stderr=subprocess.STDOUT,
                check=True,
            )
            py = ENVIRONMENT / "bin/python"
            subprocess.run(
                [
                    str(py),
                    "-m",
                    "pip",
                    "install",
                    "--no-index",
                    "--find-links",
                    str(ROOT / "wheelhouse"),
                    "--require-hashes",
                    "-r",
                    str(ROOT / "requirements-runtime.lock"),
                ],
                stdout=log,
                stderr=subprocess.STDOUT,
                check=True,
            )
            subprocess.run(
                [str(py), "-m", "pip", "check"],
                stdout=log,
                stderr=subprocess.STDOUT,
                check=True,
            )
        frozen = subprocess.check_output(
            [str(py), "-m", "pip", "freeze", "--all"], text=True
        )
        (ROOT / "installed_packages.txt").write_text(frozen)
        phase("waiting_for_idle_cores")
        workers = min(6, max(1, int(os.environ.get("PR56_WORKERS", "6"))))
        if os.environ.get("SLURM_CPUS_PER_TASK"):
            workers = min(workers, int(os.environ["SLURM_CPUS_PER_TASK"]))
        if os.environ.get("NSLOTS"):
            workers = min(workers, int(os.environ["NSLOTS"]))
        command = [
            str(BASE),
            str(ROOT / "select_idle_cpus.py"),
            "--output",
            str(ROOT / "cpu_selection.json"),
            "--max-workers",
            str(workers),
        ]
        if os.environ.get("PR56_CPUS"):
            command += ["--allowed", *os.environ["PR56_CPUS"].replace(",", " ").split()]
        while True:
            selection = subprocess.run(command, capture_output=True, text=True)
            if selection.returncode == 0:
                cpus = [int(x) for x in selection.stdout.split()]
                break
            if not (ROOT / "cpu_selection.json").exists():
                raise RuntimeError("CPU selection failed: " + selection.stderr)
            print(
                "WAIT_CPU: no allowed physical core was idle on all SMT siblings. Retrying in 30 seconds.",
                flush=True,
            )
            time.sleep(30)
        print("ASSIGNED_CPUS=" + json.dumps(campaign.topology(cpus)), flush=True)
        campaign.plan(SOURCE, out)
        for name in (
            "server_inventory.json",
            "dsda_environment.json",
            "installation.log",
            "installed_packages.txt",
            "cpu_selection.json",
            "requirements-runtime.lock",
            "WHEEL_MANIFEST.json",
            "SOURCE_MANIFEST.json",
        ):
            shutil.copy2(ROOT / name, out / name)
        phase("campaign_running")
        argv = [
            "taskset",
            "-c",
            ",".join(map(str, cpus)),
            str(py),
            str(ROOT / "campaign.py"),
            "run",
            "--repo",
            str(SOURCE),
            "--output",
            str(out),
            "--dsda-python",
            str(BASE),
            "--mi-python",
            str(py),
            "--cpus",
            *map(str, cpus),
        ]
        child = subprocess.Popen(argv, stdin=subprocess.DEVNULL)
        record.update(
            campaign_pid=child.pid,
            campaign_proc_start=campaign.proc_start(child.pid),
            cpus=cpus,
            command=argv,
        )
        campaign.write(STATE, record)
        rc = child.wait()
        record["exit_code"] = rc
        archive = out.with_name(out.name + "_return.zip")
        if rc != 0 or not archive.is_file():
            raise RuntimeError(
                f"Campaign exited {rc}; inspect preserved result/check files and launcher.log"
            )
        publish_return(archive)
        campaign_state = campaign.read(out / "campaign.json")["state"]
        record.update(
            state=campaign_state,
            finished_utc=campaign.now(),
            exit_code=0,
            return_archive=str(ROOT / "RETURN.zip"),
        )
        campaign.write(STATE, record)
        print("RETURN_ARCHIVE=" + str(ROOT / "RETURN.zip"), flush=True)
        print((ROOT / "RETURN.zip.sha256").read_text().strip(), flush=True)
    except BaseException:
        record.update(
            state="abnormal_exit",
            finished_utc=campaign.now(),
            exit_code=1,
            error=traceback.format_exc(),
        )
        campaign.write(STATE, record)
        print(record["error"], flush=True)
        raise


def publish_return(archive):
    digest = campaign.sha(archive)
    link = ROOT / "RETURN.zip"
    if link.exists() or link.is_symlink():
        raise FileExistsError("RETURN.zip exists; it will not be overwritten")
    link.symlink_to(archive.relative_to(ROOT))
    (ROOT / "RETURN.zip.sha256").write_text(digest + "  RETURN.zip\n")


def collect():
    state = campaign.read(STATE)
    if campaign.alive(state):
        raise RuntimeError(
            "Launcher still exists; automatic collection must finish first"
        )
    out = Path(state["output"])
    py = ENVIRONMENT / "bin/python"
    archive = out.with_name(out.name + "_return.zip")
    if not archive.exists():
        subprocess.run(
            [
                str(py),
                str(ROOT / "campaign.py"),
                "collect",
                "--repo",
                str(SOURCE),
                "--output",
                str(out),
            ],
            check=True,
        )
    if not (ROOT / "RETURN.zip").exists():
        publish_return(archive)
    status()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "action", choices=("start", "background", "status", "collect", "verify")
    )
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()
    if args.action == "start":
        start()
    elif args.action == "background":
        background()
    elif args.action == "status":
        status(args.verbose)
    elif args.action == "collect":
        collect()
    else:
        print(f"VERIFIED {verify_package()} packaged files; no experiment executed")


if __name__ == "__main__":
    main()
