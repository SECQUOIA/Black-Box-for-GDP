#!/usr/bin/env python3
"""Observe all SMT siblings. Does not reserve, move, or terminate processes."""

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import time


def expand(text):
    values = []
    for part in text.strip().split(","):
        endpoints = part.split("-")
        values.extend(range(int(endpoints[0]), int(endpoints[-1]) + 1))
    return values


def sample():
    data = {}
    for line in Path("/proc/stat").read_text().splitlines():
        fields = line.split()
        if fields and fields[0].startswith("cpu") and fields[0][3:].isdigit():
            # Guest times are included in user/nice, not added a second time.
            values = list(map(int, fields[1:9]))
            data[int(fields[0][3:])] = (values[3] + values[4], sum(values))
    return data


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--allowed",
        type=int,
        nargs="+",
        help="Restrict to policy-approved CPUs; always intersect with effective cpuset",
    )
    parser.add_argument("--max-workers", type=int, default=6)
    a = parser.parse_args()
    allowed = set(os.sched_getaffinity(0))
    if a.allowed is not None:
        allowed.intersection_update(a.allowed)
    cores = {}
    for cpu in sorted(allowed):
        root = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        key = (
            int((root / "physical_package_id").read_text()),
            int((root / "core_id").read_text()),
        )
        cores.setdefault(
            key,
            dict(
                socket=key[0],
                core=key[1],
                allowed=[],
                siblings=expand((root / "thread_siblings_list").read_text()),
            ),
        )["allowed"].append(cpu)
    snapshots = [sample()]
    for _ in range(2):
        time.sleep(5)
        snapshots.append(sample())
    choices = []
    for row in cores.values():
        fractions = []
        for cpu in row["siblings"]:
            for before, after in zip(snapshots, snapshots[1:]):
                if cpu not in before or cpu not in after:
                    fractions.append(0)
                    continue
                fractions.append(
                    (after[cpu][0] - before[cpu][0])
                    / max(1, after[cpu][1] - before[cpu][1])
                )
        row.update(minimum_idle_fraction=min(fractions), cpu=min(row["allowed"]))
        if row["minimum_idle_fraction"] > 0.95:
            choices.append(row)
    choices.sort(key=lambda row: (-row["minimum_idle_fraction"], row["cpu"]))
    selected = choices[: min(a.max_workers, 6)]
    record = dict(
        observed_utc=datetime.now(timezone.utc).isoformat(),
        intervals_seconds=[5, 5],
        allowed_cpus=sorted(allowed),
        selected=selected,
        observed_cores=list(cores.values()),
        exclusive_reservation=False,
        policy="Use only after server policy/allocations have been inspected; observed idleness does not constitute an exclusive reservation.",
    )
    a.output.write_text(json.dumps(record, indent=2) + "\n")
    if not selected:
        raise SystemExit("No idle allowed physical core observed; not launching")
    print(" ".join(str(row["cpu"]) for row in selected))


if __name__ == "__main__":
    main()
