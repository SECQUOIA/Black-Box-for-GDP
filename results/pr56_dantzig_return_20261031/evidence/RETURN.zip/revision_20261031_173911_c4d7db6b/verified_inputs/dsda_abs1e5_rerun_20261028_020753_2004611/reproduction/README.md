# Prepared D-SDA absolute improvement tolerance experiment

This is a new sealed input snapshot prepared inside the Dantzig repository.
The retained reference preserves the previously validated 1190-pair cohort.
The experiment uses absolute improvement 1e-5, unchanged ties and target stopping, stored responses only, and one CPU selected after an idle-core check with one numerical-library thread.
Preparation does not launch the full experiment or call NLP solvers.
The permanent workflow and usage instructions are in experiments/dsda_abs1e5/README.md.
