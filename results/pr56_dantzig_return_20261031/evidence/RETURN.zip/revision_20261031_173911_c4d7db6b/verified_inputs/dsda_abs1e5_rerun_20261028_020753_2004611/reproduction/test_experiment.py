"""Small scientific protocol tests, runnable without pytest on Dantzig."""
import csv
import importlib.util
import math
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import grid_dsda as d
from instrumentation import TrackedObjective


T=1e-5
ROOT=Path(__file__).resolve().parent


def search(values,**kw):
    return d.dsda_from_csv('unused',(0,),grid={(i,):v for i,v in enumerate(values)},
                           verbose=False,improvement_abs_tol=T,**kw)


def stable(obj):
    if isinstance(obj,dict):return {k:stable(v) for k,v in obj.items() if k not in ('wall_time_s','objective_wall_times')}
    if isinstance(obj,(list,tuple)):return [stable(v) for v in obj]
    return obj


class ProtocolTests(unittest.TestCase):
    def test_strict_boundary_and_neighbor(self):
        for delta,expected in [(math.nextafter(T,0),False),(T,False),(math.nextafter(T,math.inf),True)]:
            self.assertEqual(d.improves(-delta,0,improvement_abs_tol=T),expected)
            result=search([0,-delta])
            self.assertEqual((1,) in result['path'],expected)

    def test_boundary_uses_actual_float_subtraction(self):
        old=1.0;new=old-T
        actual=old-new
        self.assertNotEqual(actual,T)  # Decimal-looking equality is not float equality.
        self.assertEqual(d.improves(new,old,improvement_abs_tol=T),actual>T)

    def test_direction_uses_same_strict_boundary(self):
        for delta,expected in [(math.nextafter(T,0),False),(T,False),(math.nextafter(T,math.inf),True)]:
            result=search([4*T,0,-delta])
            self.assertIn((1,),result['path'])
            self.assertEqual((2,) in result['path'],expected)

    def test_no_relative_improvement(self):
        self.assertTrue(d.improves(1e9-1e-3,1e9,improvement_abs_tol=T))
        self.assertFalse(d.improves(-1e-6,0,improvement_abs_tol=T))

    def test_tie_tolerance_unchanged(self):
        grid={(1,1):1.0,(0,0):0.5+1e-10,(0,1):0.5}
        r=d.dsda_from_csv('unused',(1,1),grid=grid,diagonal=True,verbose=False,improvement_abs_tol=T,tol=1e-12)
        self.assertEqual(r['path'][1],(0,1))
        grid[(0,0)]=0.5+1e-13
        r=d.dsda_from_csv('unused',(1,1),grid=grid,diagonal=True,verbose=False,improvement_abs_tol=T,tol=1e-12)
        self.assertEqual(r['path'][1],(0,0))

    def test_grid_target_tolerance_unchanged(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'grid.csv'
            for value,runs in [(5e-6,3),(5e-13,1)]:
                with p.open('w',newline='') as f:
                    w=csv.writer(f);w.writerow(['x','y','z_norm']);w.writerows((i,0,value) for i in range(3))
                r=d.run_dsda_from_best_starting_points(p,[(0,0),(1,0),(2,0)],verbose=False,
                                                      improvement_abs_tol=T,tol=1e-12,target_value=0,max_points_explored=100)
                self.assertEqual(len(r['runs']),runs)

    def test_default_matches_original_function(self):
        spec=importlib.util.spec_from_file_location('original_dsda',ROOT/'original/grid_dsda.py')
        original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
        for values in [[1,1-T,1-2*T],[0,-T,-2*T],[1,.8,.2,0],[1,1,1]]:
            kwargs=dict(csv_path='unused',start_point=(0,),grid={(i,):v for i,v in enumerate(values)},verbose=False,max_points_explored=10)
            self.assertEqual(stable(d.dsda_from_csv(**kwargs)),stable(original.dsda_from_csv(**kwargs)))

    def test_observed_incumbent_not_thresholded(self):
        r=search([0,-T/2])
        self.assertEqual(r['path'],[(0,)])
        self.assertEqual(r['best_value'],0)
        self.assertEqual(r['incumbent_trajectory'][-1],-T/2)

    def test_cached_start_not_recharged_and_repeats_are_charged(self):
        points=[]
        grid={(0,):2.,(1,):1.,(2,):3.}
        def objective(p):points.append(p);return grid[p]
        tracker=TrackedObjective(objective)
        tracker((0,))
        r=d.dsda_from_csv('unused',(0,),grid=grid,tracked_objective=tracker,start_value=2.,
                         improvement_abs_tol=T,max_points_explored=4,verbose=False)
        self.assertEqual(points,[(0,),(1,),(2,),(0,),(2,)])
        self.assertEqual(r['point_evaluations'],4)
        self.assertEqual(tracker.call_count,5)

    def test_process_initial_order_budget_and_penalty(self):
        import run
        jobs=run.read(ROOT/'inputs/jobs.json')
        j=next(j for j in jobs if j['spec']['case']=='column')
        with tempfile.TemporaryDirectory() as tmp:
            result,ev=run.execute(j,Path(tmp)/'smoke')
        self.assertEqual([e['point'] for e in ev[:3]],j['spec']['starts'])
        self.assertEqual(len(ev),j['spec']['budget'])
        self.assertEqual(ev[-1]['callback_exit'],'budget_stop')
        self.assertFalse(ev[-1]['value_returned_to_optimizer'])
        self.assertTrue(all(e['method_value']==1e6 for e in ev if not e['accepted']))
        self.assertEqual(result['process_nlp_calls'],0)
        self.assertFalse(result['blocked_solver_or_process_attempts'])

    def test_missing_lookup_aborts_without_fallback(self):
        import run
        j=next(j for j in run.read(ROOT/'inputs/jobs.json') if j['spec']['case']=='column')
        original=run.table
        def missing(p):return [] if str(p).endswith('_full.csv') else original(p)
        with tempfile.TemporaryDirectory() as tmp,patch.object(run,'table',missing):
            result,ev=run.execute(j,Path(tmp)/'missing')
        self.assertEqual(result['status'],'missing_lookup')
        self.assertEqual(ev,[])
        self.assertEqual(result['process_nlp_calls'],0)


if __name__=='__main__':unittest.main(verbosity=2)
