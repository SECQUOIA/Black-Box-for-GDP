"""Build an isolated, solver-free Dantzig transfer package from retained evidence."""
import argparse
import csv
import gzip
import hashlib
import io
import itertools
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def rows(data):
    return list(csv.DictReader(io.StringIO(data.decode())))


class Archive:
    def __init__(self, relative, manifest):
        self.relative = relative
        self.z = zipfile.ZipFile(ROOT / relative)
        self.root = self.z.namelist()[0].split('/')[0] + '/'
        manifest['archives'][relative] = sha((ROOT / relative).read_bytes())

    def read(self, member):
        return self.z.read(self.root + member)

    def json(self, member):
        return json.loads(self.read(member))


def changed_source(source):
    """Keep all existing arithmetic when the new optional setting is absent."""
    source = source.replace('    start_value=None,\n):', '    start_value=None,\n    improvement_abs_tol=None,\n):', 1)
    source = source.replace('    max_points_explored=100,\n):', '    max_points_explored=100,\n    improvement_abs_tol=None,\n):', 1)
    old = '''        if maximize:
            return new_val > current_val + tol
        return new_val < current_val - tol'''
    assert source.count(old) == 1
    source = source.replace(old, '''        return improves(new_val, current_val, maximize, tol, improvement_abs_tol)''')
    source = source.replace('            start_value=starting_value_by_point[pt],', '            start_value=starting_value_by_point[pt],\n            improvement_abs_tol=improvement_abs_tol,')
    source = source.replace('if run_result["best_value"] > best_value + tol:', 'if improves(run_result["best_value"], best_value, True, tol, improvement_abs_tol):')
    source = source.replace('if run_result["best_value"] < best_value - tol:', 'if improves(run_result["best_value"], best_value, False, tol, improvement_abs_tol):')
    source = source.replace('        Improvement tolerance.', '        Legacy improvement, tie and target tolerance; unchanged by improvement_abs_tol.')
    helper = '''
def improves(new_value, old_value, maximize=False, tol=1e-12, improvement_abs_tol=None):
    """Strict absolute improvement; no relative term or fuzzy boundary test."""
    if improvement_abs_tol is None:
        return new_value > old_value + tol if maximize else new_value < old_value - tol
    if not 0 <= improvement_abs_tol < float("inf"):
        raise ValueError("improvement_abs_tol must be finite and nonnegative")
    difference = new_value - old_value if maximize else old_value - new_value
    return difference > improvement_abs_tol


'''
    return source.replace('def dsda_from_csv(', helper + 'def dsda_from_csv(', 1)


def build(out):
    out.mkdir(parents=True, exist_ok=False)
    manifest = dict(experiment='D-SDA 절대 개선 허용오차 변경 실험', repository='SECQUOIA/Black-Box-for-GDP',
                    working_start_revision='2d1e2e49158d924f1fe589a55f7d7f210bf5f28b',
                    pr_number=52, adopted_branch='review/cstr15-dantzig-results',
                    source_base_revision=subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip(),
                    execution_source_uncommitted=True, archives={}, inputs={},
                    source_revision_note='Uncommitted experiment additions are identified by SHA256, not a fabricated revision.',
                    process_nlp_calls=0)
    def save(relative, data, provenance=None):
        dest=out / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        if provenance:
            manifest['inputs'][relative]={'origin':provenance, 'sha256':sha(data)}
    def local(relative, dest=None):
        save(dest or relative, (ROOT / relative).read_bytes(), relative)
    def member(a, name, dest):
        save(dest, a.read(name), a.relative + ':' + name)
    for p in HERE.glob('*.py'):
        save(p.name, p.read_bytes())
    for p in HERE.glob('*.md'):
        save(p.name,p.read_bytes())
    import difflib
    local('experiments/column_logical_b13/cpu_guard.py', 'cpu_guard.py')
    local('experiments/column_logical_b13/common.py', 'adopted_analysis.py')
    for name in ['grid_dsda.py', 'instrumentation.py', 'evaluation_trace.py']:
        local(name, 'original/' + name)
        if name != 'grid_dsda.py':
            local(name, name)
    base=(ROOT/'grid_dsda.py').read_text()
    assert sha(base.encode()) == '7873a2344eb9b40e9bc3f35354448494e9d8230d0879377e8934fa2cc517a77a'
    save('grid_dsda.py', changed_source(base).encode())
    save('source_change.diff',''.join(difflib.unified_diff(base.splitlines(True),changed_source(base).splitlines(True),fromfile='original/grid_dsda.py',tofile='grid_dsda.py')).encode())
    adopted='results/column_publication_20261025/tables/run_records.csv'
    local(adopted, 'inputs/adopted_all_methods.csv')
    authoritative=rows((ROOT/adopted).read_bytes())
    baseline={(r['scope'],r['case'],int(r['budget']),int(r['seed'])):r for r in authoritative if r['method']=='dsda'}
    assert len(baseline)==1190
    assert sum(k[0]=='grid' for k in baseline)==1050
    for source in ['results/column_publication_20261025/manifest.json','results/cstr30_publication_20261025/manifest.json']:
        local(source, 'provenance/'+Path(source).parent.name+'.json')
    ga=Archive('results/archives/dantzig_20260910_170759_slN8tv.zip',manifest)
    for name in ['git-commit.txt','git-status.txt','run-script.sh','python-packages.txt','platform.txt']:
        member(ga,name,'provenance/grid/'+name)
    grid_revision=ga.read('git-commit.txt').decode().strip()
    historical=subprocess.check_output(['git','-C',str(ROOT),'show',grid_revision+':grid_dsda.py'])
    assert sha(historical)==sha(base.encode())
    manifest['grid_execution_revision']=grid_revision
    designs_path='fmqa_benchmark/reference/grid/comparison_audit.json'
    local(designs_path,'inputs/grid_designs.json')
    designs={(Path(d['csv_name']).stem,d['seed']):d['starting_points'] for d in json.loads((ROOT/designs_path).read_text())['grid_designs']}
    grid_old={}
    with gzip.open(ROOT/'results/grid_gdp_dfo_20261011/point_charges.csv.gz','rt') as f:
        for r in csv.DictReader(f):
            if r['method']=='dsda':
                grid_old.setdefault((r['grid_name'],int(r['max_evals']),int(r['seed'])),[]).append(r)
    manifest['inputs']['grid_old_callbacks']={'origin':'results/grid_gdp_dfo_20261011/point_charges.csv.gz','sha256':sha((ROOT/'results/grid_gdp_dfo_20261011/point_charges.csv.gz').read_bytes())}
    jobs=[]
    for key,b in sorted(baseline.items()):
        scope,case,budget,seed=key
        if scope!='grid':continue
        filename='benchmark_grids/'+case+'.csv'
        local(filename,'inputs/grids/'+case+'.csv')
        values=[float(r['z_norm']) for r in rows((ROOT/filename).read_bytes())]
        ev=grid_old[case,budget,seed]
        assert [json.loads(e['point']) for e in ev[:3]]==designs[case,seed]
        spec=dict(job_id=f'grid_{case}_B{budget}_seed{seed}_dsda',scope=scope,case=case,budget=budget,seed=seed,
                  starts=designs[case,seed],lower=[0,0],upper=[30,30],method='dsda',settings=dict(diagonal=True,tie_break='first',tol=1e-12))
        jobs.append(dict(spec=spec,target=min(values),hard_seconds=None,baseline=b,
                         baseline_events=[dict(index=int(e['evaluation_index']),point=json.loads(e['point']),raw_objective=float(e['value']),accepted=True,phase=e['phase']) for e in ev],
                         baseline_result=None,baseline_termination='not_explicitly_archived; callback count and coordinates retained',cohort='grid'))
    penalty=Archive('results/archives/cstr_penalty_1e6_20261022_045249_vn111_rf.zip',manifest)
    non=Archive('results/archives/ipopt_dfo_non_cstr_20261015_172428_o671edu_.zip',manifest)
    c30=Archive('results/archives/cstr30_init_20261025_060540_98uz54ol.zip',manifest)
    col=Archive('results/column_logical_b13_analysis_20261025/source/column_logical_b13_20261025_193902_31iulfak_snapshot_1792957295361892009.zip',manifest)
    review=Archive('results/archives/review_comparison_20261020_124949_return_1792527395393579314.zip',manifest)
    cohorts=[('penalty',penalty,'reproduction/',lambda s:s['case']!='cstr_30'),
             ('non',non,'reproduction/',lambda s:s['case'] in ('dynamic','small_batch')),
             ('c30',c30,'reproduction/frozen/penalty/',lambda s:True),
             ('column',col,'reproduction/frozen/original/',lambda s:True)]
    for cohort,a,prefix,select in cohorts:
        core='ipopt_dfo_cstr.py' if cohort in ('penalty','c30') else 'ipopt_dfo_non_cstr.py'
        member(a,prefix+core,'frozen/'+cohort+'.py')
        assert sha(a.read(prefix+'grid_dsda.py'))==sha(base.encode())
        member(a,'reproduction/plan.json','provenance/'+cohort+'_plan.json')
        plan=a.json('reproduction/plan.json')
        for job in plan:
            spec=job.get('spec',job)
            if spec['method']!='dsda' or not select(spec):continue
            case=spec['case']; key=('process',case,spec['budget'],spec['seed'])
            assert key in baseline
            if cohort=='penalty':
                original='reproduction/inputs/'+case+'/evaluations.csv'
                full='reproduction/data/cost_table_'+case+'.csv'; full_a=a
                olddir='jobs/'+spec['job_id']+'/'
            elif cohort=='non':
                original='reproduction/inputs/'+case+'/evaluations.csv'
                full='reproduction/data/cost_table_'+case+'.csv';full_a=review
                olddir='jobs/'+spec['job_id']+'/'
            elif cohort=='c30':
                original=full='evaluations.csv';full_a=a
                olddir='searches/'+spec['job_id']+'/'
            else:
                original=full='reproduction/provenance/original_column/evaluations.csv';full_a=a
                olddir='jobs/'+spec['job_id']+'/attempt_0001/'
            member(a,original,'inputs/process/'+case+'_oracle.csv')
            member(full_a,full,'inputs/process/'+case+'_full.csv')
            table=rows(full_a.read(full))
            coordinates=[tuple(json.loads(r['point'])) for r in table]
            domain=set(itertools.product(*(range(lo,hi+1) for lo,hi in zip(spec['lower'],spec['upper']))))
            assert len(set(coordinates))==len(coordinates) and set(coordinates)==domain,(case,'missing or duplicate lookup')
            target=min(float(r['objective']) for r in table if r['accepted']=='True')
            if 'target' in job:assert job['target']==target
            ev=[json.loads(l) for l in a.read(olddir+'callbacks.jsonl').splitlines()]
            result=a.json(olddir+('effective_result.json' if cohort=='c30' else 'result.json'))
            runtime=a.json(olddir+'runtime.json')
            assert [e['point'] for e in ev[:3]]==spec['starts']
            assert len(ev)==int(baseline[key]['evaluations'])
            member(a,olddir+'actual_settings.json','provenance/settings/'+spec['job_id']+'.json')
            jobs.append(dict(spec={**spec,'scope':'process'},cohort=cohort,target=target,hard_seconds=job.get('hard_seconds',2100),
                             baseline=baseline[key],baseline_events=ev,baseline_result=result,
                             baseline_termination=result['status'],reference_runtime=runtime,original_job=job,
                             baseline_source=a.relative+':'+olddir))
    keys=[(j['spec']['scope'],j['spec']['case'],j['spec']['budget'],j['spec']['seed']) for j in jobs]
    assert len(keys)==len(set(keys))==1190 and set(keys)==set(baseline)
    assert len({(k[1],k[2]) for k in keys if k[0]=='process'})==14
    write(out/'inputs/jobs.json',jobs)
    manifest['counts']={'grid':1050,'process':140,'total':1190}
    manifest['changes']={'improvement_abs_tol':1e-5,'legacy_tol':1e-12,'relative_improvement':False,'unaccepted_response':1e6}
    write(out/'manifest.json',manifest)
    hashes={str(p.relative_to(out)):sha(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file()}
    write(out/'SHA256SUMS.json',hashes)
    print(json.dumps({'package':str(out),'jobs':len(jobs),'files':len(hashes)},indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    build(parser.parse_args().output.resolve())
