#!/usr/bin/env python3
"""PR56 orchestration only. Calls the frozen experiment runners unchanged."""

import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import queue
import shutil
import subprocess
import threading
import traceback
import xml.etree.ElementTree as ET
import zipfile

REVISION = "c4d7db6b671bbe92a314be524a650d75cd49529c"
THREADS = {
    k: "1"
    for k in (
        "OMP_NUM_THREADS",
        "OMP_THREAD_LIMIT",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "BLIS_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
        "GOTO_NUM_THREADS",
        "NUMEXPR_MAX_THREADS",
    )
}
THREADS.update(
    OMP_DYNAMIC="FALSE",
    MKL_DYNAMIC="FALSE",
    CUDA_VISIBLE_DEVICES="",
    PYTHONUNBUFFERED="1",
    PYTHONNOUSERSITE="1",
    PYTHONDONTWRITEBYTECODE="1",
)
os.environ.update(THREADS)
os.environ["GIT_OPTIONAL_LOCKS"] = "0"
GUARDED = [
    "experiments/dsda_process_multistart/run.py",
    "experiments/dsda_process_multistart/run_dantzig.sh",
    "experiments/mixed_integer_dfo/run.py",
    "experiments/mixed_integer_dfo/run_dantzig.sh",
    "experiments/run_revision_dantzig.sh",
    "requirements-mi-dfo.txt",
    "tests/test_dsda_process_multistart.py",
    "tests/test_mixed_integer_dfo.py",
    "results/archives/dsda_abs1e5_rerun_20261028_020753_2004611.zip",
    "results/grid_gdp_20261009/raw/point_timings.csv",
    "results/dsda_publication_20261028/tables/configuration_coverage.csv",
    "results/dsda_publication_20261028/tables/run_records.csv",
]


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".{os.getpid()}.{threading.get_ident()}.tmp")
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    os.replace(tmp, path)


def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()


def runner(repo):
    spec = importlib.util.spec_from_file_location(
        "pr56_frozen_mi", repo / "experiments/mixed_integer_dfo/run.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def snapshot(repo):
    if git(repo, "rev-parse", "HEAD") != REVISION:
        raise RuntimeError("Revision differs from the reviewed/frozen revision")
    for path in GUARDED:
        if git(repo, "diff", "HEAD", "--", path):
            raise RuntimeError(f"Tracked source/input changed: {path}")
    return {p: sha(repo / p) for p in GUARDED}


def verify_retained_inputs(p):
    package = Path(p["package"])
    for name, digest in read(package / "SHA256SUMS.json").items():
        if sha(package / name) != digest:
            raise RuntimeError(f"Retained sealed input changed: {name}")
    if sha(package / "inputs/jobs.json") != p["jobs_sha256"]:
        raise RuntimeError("Retained job plan changed")


def plan(repo, out):
    if out.exists():
        raise FileExistsError(out)
    hashes = snapshot(repo)
    m = runner(repo)
    if sha(m.GRID_COSTS) != m.GRID_COSTS_SHA256:
        raise RuntimeError("Grid cost hash mismatch")
    out.mkdir(parents=True)
    package, archived = m.shared.extract_package(
        m.shared.ARCHIVE, out / "verified_inputs"
    )
    jobs = read(package / "inputs/jobs.json")
    ids = [j["spec"]["job_id"].rsplit("_dsda", 1)[0] for j in jobs]
    assert len(jobs) == len(set(ids)) == 1190
    grid = [j for j in jobs if j["spec"]["scope"] == "grid"]
    process = [j for j in jobs if j["spec"]["scope"] == "process"]
    assert len(grid) == 1050 and len(process) == 140
    assert len({j["spec"]["case"] for j in grid}) == 21
    assert len({(j["spec"]["case"], j["spec"]["budget"]) for j in process}) == 14
    expected = {(method, jid) for method in ("nomad", "miso") for jid in ids}
    groups = []

    def add(name, method, selected):
        selected_ids = [j["spec"]["job_id"].rsplit("_dsda", 1)[0] for j in selected]
        groups.append(dict(name=name, method=method, jobs=selected_ids))

    # Expensive B100 shards enter first; NOMAD and Process can report early too.
    for budget in (100, 70, 50, 30, 10):
        selected = [j for j in grid if j["spec"]["budget"] == budget]
        assert len(selected) == 210
        add(f"nomad_grid_B{budget}", "nomad", selected)
        for seed in range(10):
            selected = [
                j
                for j in grid
                if j["spec"]["budget"] == budget and j["spec"]["seed"] == seed
            ]
            assert len(selected) == 21
            add(f"miso_grid_B{budget}_seed{seed}", "miso", selected)
    groups.insert(
        1,
        dict(
            name="nomad_process",
            method="nomad",
            jobs=[j["spec"]["job_id"].rsplit("_dsda", 1)[0] for j in process],
        ),
    )
    for seed in range(10):
        selected = [j for j in process if j["spec"]["seed"] == seed]
        assert len(selected) == 14
        add(f"miso_process_seed{seed}", "miso", selected)
    # Put one short Process shard near the start, while keeping most workers on B100.
    groups.insert(2, groups.pop(-10))
    flattened = [(g["method"], jid) for g in groups for jid in g["jobs"]]
    assert len(flattened) == len(set(flattened)) == 2380 and set(flattened) == expected
    for g in groups:
        write(out / "job_lists" / (g["name"] + ".json"), g)
    for name in GUARDED:
        destination = out / "source_snapshot" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(repo / name, destination)
    write(
        out / "plan.json",
        dict(
            revision=REVISION,
            branch="review/manuscript-revision-20261030",
            repository=str(repo),
            created_utc=now(),
            groups=groups,
            expected_methods={"nomad": 1190, "miso": 1190},
            expected_dsda=420,
            group_count=len(groups),
            jobs_sha256=sha(package / "inputs/jobs.json"),
            hashes=hashes,
            package=str(package),
            archived_runs=str(archived),
            wrapper_sha256=sha(__file__),
            input_hash_files=len(read(package / "SHA256SUMS.json")),
            source_status=git(repo, "status", "--porcelain"),
            policy="Original runner parameters and crash policy unchanged. No automatic retries. Every bundle uses attempt_01; any later recovery must receive a separate attempt and explicit selection.",
        ),
    )
    print(
        json.dumps(
            {
                "plan": str(out / "plan.json"),
                "groups": len(groups),
                "nomad": 1190,
                "miso": 1190,
                "dsda": 420,
                "internal_hashes_verified": len(read(package / "SHA256SUMS.json")),
            }
        ),
        flush=True,
    )


def proc_start(pid):
    try:
        return Path(f"/proc/{pid}/stat").read_text().split(")", 1)[1].split()[19]
    except (OSError, IndexError):
        return None


def alive(record):
    pid = record.get("pid")
    return bool(
        pid and proc_start(pid) == record.get("proc_start") and record.get("proc_start")
    )


def topology(cpus):
    rows = []
    allowed = os.sched_getaffinity(0)
    for cpu in cpus:
        if cpu not in allowed:
            raise RuntimeError(f"CPU {cpu} is outside the allowed cpuset")
        root = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        rows.append(
            dict(
                cpu=cpu,
                socket=int((root / "physical_package_id").read_text()),
                core=int((root / "core_id").read_text()),
                siblings=(root / "thread_siblings_list").read_text().strip(),
            )
        )
    if len({(r["socket"], r["core"]) for r in rows}) != len(rows):
        raise RuntimeError("Workers share a physical core")
    return rows


def launch_record(argv, log, record_path, cpu, cwd, env=None):
    log.parent.mkdir(parents=True, exist_ok=True)
    record = dict(
        command=argv,
        cwd=str(cwd),
        cpu=cpu,
        started_utc=now(),
        state="starting",
        log=str(log),
        exit_code=None,
    )
    write(record_path, record)
    with log.open("xb") as stream:
        process = subprocess.Popen(
            argv,
            cwd=cwd,
            stdout=stream,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            env={**os.environ, **THREADS, **(env or {})},
        )
        record.update(
            state="running", pid=process.pid, proc_start=proc_start(process.pid)
        )
        write(record_path, record)
        rc = process.wait()
    record.update(
        state="completed" if rc == 0 else "abnormal_exit",
        exit_code=rc,
        finished_utc=now(),
    )
    write(record_path, record)
    return record


def run(repo, out, dsda_python, mi_python, cpus):
    if platform.system() != "Linux" or platform.node().split(".")[0] != "dantzig":
        raise RuntimeError("Experiment launch is permitted only on Dantzig")
    p = read(out / "plan.json")
    if p["hashes"] != snapshot(repo):
        raise RuntimeError("Frozen sources changed after planning")
    verify_retained_inputs(p)
    if not 1 <= len(cpus) <= 6:
        raise ValueError("Need one to six distinct physical cores")
    topo = topology(cpus)
    lock = (out / "campaign.lock").open("a+")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    if (out / "campaign.json").exists():
        raise RuntimeError(
            "Campaign already attempted. Inspect status; never restart completed jobs wholesale."
        )
    shutil.copy2(__file__, out / "campaign_wrapper.py")
    state = dict(
        state="preflight",
        pid=os.getpid(),
        proc_start=proc_start(os.getpid()),
        started_utc=now(),
        revision=REVISION,
        repository=str(repo),
        cpus=topo,
        threads=THREADS,
        dsda_python=str(dsda_python),
        mi_python=str(mi_python),
        exit_code=None,
    )
    write(out / "campaign.json", state)
    try:
        version_code = "import json,platform,importlib.metadata as m; import PyNomad,soogo,numpy,pandas,scipy,pytest; print(json.dumps({'python':platform.python_version(),'packages':{x:m.version(x) for x in ['PyNomadBBO','soogo','numpy','pandas','scipy','pytest']}},indent=2)); assert m.version('PyNomadBBO')=='4.6.0'; assert m.version('soogo')=='2.1.0'"
        versions = subprocess.check_output(
            ["taskset", "-c", str(cpus[0]), str(mi_python), "-c", version_code],
            text=True,
            env={**os.environ, **THREADS},
        )
        write(out / "environment_actual.json", json.loads(versions))
        preflight = out / "preflight"
        preflight.mkdir()
        argv = [
            "taskset",
            "-c",
            str(cpus[0]),
            str(mi_python),
            "-m",
            "pytest",
            "-q",
            "-rs",
            "-p",
            "no:cacheprovider",
            "tests/test_dsda_process_multistart.py",
            "tests/test_mixed_integer_dfo.py",
            "--basetemp",
            str(preflight / "pytest_tmp"),
            "--junitxml",
            str(preflight / "junit.xml"),
        ]
        rec = launch_record(
            argv, preflight / "pytest.log", preflight / "execution.json", cpus[0], repo
        )
        tree = ET.parse(preflight / "junit.xml")
        cases = list(tree.iter("testcase"))
        bad = [
            x.attrib.get("name")
            for x in cases
            if x.find("skipped") is not None
            or x.find("failure") is not None
            or x.find("error") is not None
        ]
        required = (
            "test_solver_runs_are_valid_and_reproducible[nomad-PyNomad]",
            "test_solver_runs_are_valid_and_reproducible[miso-soogo]",
            "test_miso_design_spans_three_dimensional_space",
            "test_nomad_crash_on_every_identical_attempt_is_scored_on_its_evaluations",
        )
        names = {x.attrib.get("name") for x in cases}
        if rec["exit_code"] or bad or len(cases) < 12 or not set(required) <= names:
            raise RuntimeError(
                f"Required preflight did not pass without skips: {len(cases)} tests, {bad}"
            )
        write(
            preflight / "validation.json",
            dict(
                passed=True,
                tests=len(cases),
                skipped=0,
                required_solver_tests=list(required),
                excluded_from_campaign=True,
            ),
        )
        state["state"] = "dsda_running"
        write(out / "campaign.json", state)
        dsda_out = out / "dsda" / "attempt_01"
        argv = [
            "taskset",
            "-c",
            str(cpus[0]),
            "bash",
            "experiments/dsda_process_multistart/run_dantzig.sh",
        ]
        rec = launch_record(
            argv,
            out / "dsda" / "launcher.log",
            out / "dsda" / "execution.json",
            cpus[0],
            repo,
            dict(
                DSDA_PYTHON=str(dsda_python),
                DSDA_CPU=str(cpus[0]),
                DSDA_OUTPUT=str(dsda_out),
            ),
        )
        checks = read(dsda_out / "checks.json")
        if (
            rec["exit_code"]
            or not checks["replay_passed"]
            or len(checks["replay"]) != 140
            or not checks["first_descent_matches_single"]
            or checks["execution_failures"]
            or len(list((dsda_out / "runs").glob("*/result.json"))) != 420
        ):
            raise RuntimeError(
                "D-SDA replay/420-result verification failed; NOMAD/MISO not started"
            )
        audit_dsda(out, runner(repo))
        state["state"] = "mi_running"
        write(out / "campaign.json", state)
        tasks = queue.Queue()
        for group in p["groups"]:
            tasks.put(group)

        def worker(cpu):
            while True:
                try:
                    group = tasks.get_nowait()
                except queue.Empty:
                    return
                directory = out / "batches" / group["name"]
                directory.mkdir(parents=True)
                write(
                    directory / "selection.json",
                    dict(
                        selected_attempt="attempt_01",
                        method=group["method"],
                        jobs=group["jobs"],
                    ),
                )
                destination = directory / "attempt_01"
                argv = [
                    "taskset",
                    "-c",
                    str(cpu),
                    str(mi_python),
                    "experiments/mixed_integer_dfo/run.py",
                    "--output",
                    str(destination),
                    "--cpu",
                    str(cpu),
                    "--no-zip",
                    "--methods",
                    group["method"],
                    "--jobs",
                    *group["jobs"],
                ]
                try:
                    rec = launch_record(
                        argv,
                        directory / "attempt_01.log",
                        directory / "execution.json",
                        cpu,
                        repo,
                    )
                    actual = list((destination / "runs").glob("*/result.json"))
                    rec.update(
                        expected_results=len(group["jobs"]), result_count=len(actual)
                    )
                    if len(actual) != len(group["jobs"]):
                        rec["state"] = "abnormal_exit"
                    write(directory / "execution.json", rec)
                except Exception:
                    error = traceback.format_exc()
                    write(
                        directory / "wrapper_error.json",
                        dict(time=now(), traceback=error),
                    )
                    rec_path = directory / "execution.json"
                    rec = (
                        read(rec_path)
                        if rec_path.exists()
                        else dict(
                            command=argv, cpu=cpu, log=str(directory / "attempt_01.log")
                        )
                    )
                    rec.update(
                        state="abnormal_exit",
                        exit_code=-999,
                        finished_utc=now(),
                        wrapper_error=error,
                    )
                    write(rec_path, rec)
                finally:
                    tasks.task_done()

        with ThreadPoolExecutor(max_workers=len(cpus)) as pool:
            futures = [pool.submit(worker, cpu) for cpu in cpus]
            for future in futures:
                future.result()
        state.update(state="jobs_finished", finished_utc=now(), exit_code=0)
        write(out / "campaign.json", state)
        collect(repo, out)
    except BaseException:
        state.update(
            state="abnormal_exit",
            finished_utc=now(),
            exit_code=1,
            error=traceback.format_exc(),
        )
        write(out / "campaign.json", state)
        raise


def events(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def audit_dsda(out, m):
    p = read(out / "plan.json")
    package = Path(p["package"])
    jobs = {
        j["spec"]["job_id"]: j
        for j in read(package / "inputs/jobs.json")
        if j["spec"]["scope"] == "process"
    }
    directory = out / "dsda/attempt_01"
    results, failures, replay, changes = [], [], [], []
    for jid, job in jobs.items():
        by_variant = {}
        for variant in m.shared.VARIANTS:
            folder = directory / "runs" / f"{jid}__{variant}"
            try:
                r, ev = read(folder / "result.json"), events(folder / "callbacks.jsonl")
                if (
                    r["spec"] != job["spec"]
                    or r["target"] != job["target"]
                    or len(ev) != r["evaluations"]
                    or len(ev) > job["spec"]["budget"]
                    or [e["point"] for e in ev[:3]] != job["spec"]["starts"]
                    or r["process_nlp_calls"] != 0
                    or r["category"] == "execution_failed"
                ):
                    failures.append(f"{jid}__{variant}: spec/budget/order/status")
                full = {
                    tuple(json.loads(row["point"])): row
                    for row in m.shared.read_csv(
                        package / f"inputs/process/{job['spec']['case']}_full.csv"
                    )
                }
                for index, e in enumerate(ev, 1):
                    point = tuple(e["point"])
                    if (
                        point not in full
                        or e["index"] != index
                        or e.get("budget_overrun")
                    ):
                        failures.append(
                            f"{jid}__{variant}: invalid coordinate/index/budget"
                        )
                        continue
                    row = full[point]
                    accepted = row["accepted"] == "True"
                    objective = float(row["objective"]) if accepted else None
                    if (
                        e["accepted"] != accepted
                        or e["raw_objective"] != objective
                        or e["method_value"] != (objective if accepted else 1e6)
                    ):
                        failures.append(f"{jid}__{variant}: stored response mismatch")
                accepted_events = [e for e in ev if e["accepted"]]
                best = (
                    min(accepted_events, key=lambda e: e["raw_objective"])
                    if accepted_events
                    else None
                )
                if r["best_objective"] != (
                    best["raw_objective"] if best else None
                ) or r["best_point"] != (best["point"] if best else None):
                    failures.append(f"{jid}__{variant}: best-result mismatch")
                with m.shared.sealed_modules(package) as (_, hit):
                    success = bool(
                        r["status"] in ("completed", "budget_completed")
                        and best
                        and hit(best["raw_objective"], job["target"])
                    )
                    first = (
                        next(
                            (
                                e["index"]
                                for e in accepted_events
                                if hit(e["raw_objective"], job["target"])
                            ),
                            None,
                        )
                        if success
                        else None
                    )
                if r["hit"] != success or r["first_hit"] != first:
                    failures.append(f"{jid}__{variant}: hit/first-hit mismatch")
                point_cost = math.fsum(
                    float(full[tuple(e["point"])]["total_wall_s"]) for e in ev
                )
                lookup = math.fsum(e["lookup_wall_s"] for e in ev)
                expected_time = (
                    r["search_s"]
                    - lookup
                    + point_cost
                    + float(job["baseline"]["prep_s"])
                )
                for field, value in (
                    ("point_cost_s", point_cost),
                    ("lookup_s", lookup),
                    ("completion_s", expected_time),
                ):
                    if not math.isclose(r[field], value, rel_tol=1e-12, abs_tol=1e-12):
                        failures.append(f"{jid}__{variant}: {field} mismatch")
                by_variant[variant] = (r, ev)
                results.append(r)
            except (OSError, ValueError, KeyError) as exc:
                failures.append(f"{jid}__{variant}: {exc}")
        if "single" in by_variant:
            r, ev = by_variant["single"]
            check = m.shared.replay_check(job, r, ev, Path(p["archived_runs"]))
            replay.append(check)
            for variant in ("ranked", "ranked_random"):
                if variant in by_variant:
                    other, other_ev = by_variant[variant]
                    if [e["point"] for e in other_ev[: len(ev)]] != [
                        e["point"] for e in ev
                    ]:
                        failures.append(f"{jid}__{variant}: prefix mismatch")
                    if (r["hit"], r["best_objective"]) != (
                        other["hit"],
                        other["best_objective"],
                    ):
                        changes.append(
                            dict(
                                job_id=jid,
                                variant=variant,
                                single_hit=r["hit"],
                                restart_hit=other["hit"],
                                single_objective=r["best_objective"],
                                restart_objective=other["best_objective"],
                            )
                        )
    report = dict(
        expected=420,
        results=len(results),
        replay_checked=len(replay),
        replay_matched=sum(c["passed"] for c in replay),
        failures=failures,
        changed_outcomes=changes,
        hits={
            v: sum(r["hit"] for r in results if r["variant"] == v)
            for v in m.shared.VARIANTS
        },
        original_checks=read(directory / "checks.json"),
    )
    report["passed"] = (
        len(results) == 420
        and len(replay) == 140
        and all(c["passed"] for c in replay)
        and not failures
    )
    write(out / "dsda_validation.json", report)
    if not report["passed"]:
        raise RuntimeError("Independent D-SDA audit failed")
    return report


def status(out, emit=True):
    p = read(out / "plan.json")
    campaign = (
        read(out / "campaign.json")
        if (out / "campaign.json").exists()
        else {"state": "not_started"}
    )
    result = dict(
        campaign=campaign["state"],
        launcher_alive=alive(campaign),
        cpus=campaign.get("cpus"),
        dsda_results=len(list((out / "dsda/attempt_01/runs").glob("*/result.json"))),
        methods={},
        groups=[],
    )
    for method in ("nomad", "miso"):
        found = []
        for g in p["groups"]:
            if g["method"] != method:
                continue
            folder = out / "batches" / g["name"]
            rec = (
                read(folder / "execution.json")
                if (folder / "execution.json").exists()
                else {"state": "not_started"}
            )
            running = alive(rec) and rec.get("exit_code") is None
            state = rec["state"]
            if state in ("starting", "running") and not running:
                state = "abnormal_exit" if rec.get("pid") else "starting"
            files = list((folder / "attempt_01/runs").glob("*/result.json"))
            for f in files:
                try:
                    found.append(read(f))
                except ValueError:
                    pass
            item = dict(
                name=g["name"],
                state=state,
                alive=running,
                pid=rec.get("pid"),
                cpu=rec.get("cpu"),
                exit_code=rec.get("exit_code"),
                results=len(files),
                expected=len(g["jobs"]),
                log=rec.get("log"),
            )
            if running:
                try:
                    item["effective_cpus"] = sorted(os.sched_getaffinity(rec["pid"]))
                except ProcessLookupError:
                    item["effective_cpus"] = None
            result["groups"].append(item)
        result["methods"][method] = dict(
            expected=1190,
            results=len(found),
            hits=sum(r["hit"] for r in found),
            statuses=dict(Counter(r["status"] for r in found)),
            execution_failures=sum(r["category"] == "execution_failed" for r in found),
        )
    if emit:
        print(json.dumps(result, indent=2))
    return result


def collect(repo, out):
    p = read(out / "plan.json")
    verify_retained_inputs(p)
    records = []
    for g in p["groups"]:
        path = out / "batches" / g["name"] / "execution.json"
        if not path.exists():
            raise RuntimeError(f"Unstarted/unterminated bundle: {g['name']}")
        rec = read(path)
        if rec.get("exit_code") is None or alive(rec):
            raise RuntimeError(f"Bundle has not terminated: {g['name']}")
        records.append(rec)
    # Full accounting uses individual result/callback records, never batch aggregates.
    m = runner(repo)
    dsda = audit_dsda(out, m)
    jobs = {
        j["spec"]["job_id"].rsplit("_dsda", 1)[0]: j
        for j in read(Path(p["package"]) / "inputs/jobs.json")
    }
    grid_costs = {
        (r["grid_name"], tuple(json.loads(r["point"]))): float(r["point_wall_s"])
        for r in m.shared.read_csv(m.GRID_COSTS)
    }
    coverage = {
        (r["case"], tuple(json.loads(r["coordinates"]))): r["status"]
        for r in m.shared.read_csv(m.COVERAGE)
    }
    results, errors, missing, selected, seen = [], [], [], [], []
    with m.shared.sealed_modules(Path(p["package"])) as (_, hit):
        for group in p["groups"]:
            method = group["method"]
            for jid in group["jobs"]:
                job = jobs[jid]
                folder = (
                    out
                    / "batches"
                    / group["name"]
                    / "attempt_01/runs"
                    / f"{jid}__{method}"
                )
                if not (folder / "result.json").exists():
                    missing.append(f"{jid}_{method}")
                    continue
                try:
                    r, ev = (
                        read(folder / "result.json"),
                        events(folder / "callbacks.jsonl"),
                    )
                    seen.append(r["spec"]["job_id"])
                    result_spec = {
                        **job["spec"],
                        "method": method,
                        "job_id": f"{jid}_{method}",
                    }
                    if r["spec"] != result_spec or r["target"] != job["target"]:
                        errors.append(f"{jid}_{method}: changed spec/target")
                    if (
                        [e["point"] for e in ev[:3]] != job["spec"]["starts"]
                        or len(ev) > job["spec"]["budget"]
                        or r["overruns"]
                        or r["invalid_points"]
                        or r["process_nlp_calls"] != 0
                    ):
                        errors.append(
                            f"{jid}_{method}: order/budget/coordinates/solver-call violation"
                        )
                    responses, costs, nlp_status = m.load_responses(
                        job, Path(p["package"]), grid_costs, coverage
                    )
                    for index, e in enumerate(ev, 1):
                        point = tuple(e["point"])
                        if point not in responses or e["index"] != index:
                            errors.append(f"{jid}_{method}: invalid event {index}")
                            continue
                        accepted, objective = responses[point]
                        if (
                            e["accepted"] != accepted
                            or e["raw_objective"] != (objective if accepted else None)
                            or e["method_value"]
                            != (objective if accepted else m.PENALTY)
                            or e["point_cost_s"] != costs[point]
                            or bool(e["nlp_solve"]) != bool(nlp_status(point))
                        ):
                            errors.append(
                                f"{jid}_{method}: stored response/cost mismatch {index}"
                            )
                    timing_ev = ev
                    rebuild_status = r["status"]
                    if r["status"] == "completed_after_verified_rerun":
                        rebuild_status = "completed"
                        completed_reruns = [
                            folder / f"rerun_{k}"
                            for k, h in enumerate(r["solver"]["reruns"][1:], 1)
                            if h["status"] == "completed"
                            and h.get("same_path_as_crash")
                        ]
                        if not completed_reruns:
                            errors.append(f"{jid}_{method}: missing accepted rerun")
                        else:
                            timing_ev = events(completed_reruns[-1] / "callbacks.jsonl")
                            if [e["point"] for e in timing_ev] != [
                                e["point"] for e in ev
                            ]:
                                errors.append(
                                    f"{jid}_{method}: accepted rerun path differs"
                                )
                    if r["status"] == "crashed_identical_reruns":
                        if r["search_s"] is not None or len(r["solver"]["reruns"]) != 3:
                            errors.append(
                                f"{jid}_{method}: crash timing/history violation"
                            )
                        for k in (1, 2):
                            if [
                                e["point"]
                                for e in events(
                                    folder / f"rerun_{k}" / "callbacks.jsonl"
                                )
                            ] != [e["point"] for e in ev]:
                                errors.append(
                                    f"{jid}_{method}: repeated crash path differs"
                                )
                    rebuilt = m.build_result(
                        job,
                        method,
                        rebuild_status,
                        r["error"],
                        r["solver"],
                        timing_ev,
                        r["search_s"],
                        r["invalid_points"],
                        r["overruns"],
                        hit,
                    )
                    for key in (
                        "category",
                        "hit",
                        "best_objective",
                        "best_point",
                        "evaluations",
                        "nlp_solves",
                        "first_hit",
                        "lookup_s",
                        "point_cost_s",
                        "prep_s",
                        "retained_search_s",
                        "completion_s",
                    ):
                        a, b = r[key], rebuilt[key]
                        if isinstance(a, float) and isinstance(b, (float, int)):
                            same = math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12)
                        else:
                            same = a == b
                        if not same:
                            errors.append(
                                f"{jid}_{method}: recomputation mismatch {key}"
                            )
                    results.append(r)
                    selected.append(
                        dict(
                            job_id=r["spec"]["job_id"],
                            attempt="attempt_01",
                            result=str((folder / "result.json").relative_to(out)),
                            callbacks=str(
                                (folder / "callbacks.jsonl").relative_to(out)
                            ),
                        )
                    )
                except (OSError, ValueError, KeyError, TypeError) as exc:
                    errors.append(f"{jid}_{method}: {exc}")
    duplicates = [k for k, n in Counter(seen).items() if n > 1]
    all_primary = {
        str(f.relative_to(out))
        for f in (out / "batches").glob("*/attempt_01/runs/*/result.json")
    }
    unexpected_files = sorted(all_primary - {s["result"] for s in selected})
    if unexpected_files:
        errors.append(
            f"Unexpected or unreadable primary result files: {unexpected_files}"
        )
    aggregate = out / "aggregate"
    aggregate.mkdir(exist_ok=True)
    if results:
        rows, summary = m.summarize(results)
        m.shared.write_csv(aggregate / "runs.csv", rows)
        m.shared.write_csv(aggregate / "condition_summary.csv", summary)
        m.shared.write_csv(aggregate / "comparison_hits.csv", m.comparison(summary))
    write(aggregate / "selected_attempts.json", selected)
    source_ok = p["hashes"] == snapshot(repo)
    report = dict(
        revision=REVISION,
        collected_utc=now(),
        results=len(results),
        expected=2380,
        missing=missing,
        duplicates=duplicates,
        validation_errors=errors,
        sources_unchanged=source_ok,
        dsda_passed=dsda["passed"],
        abnormal_bundles=[r for r in records if r["state"] != "completed"],
        methods={
            method: dict(
                results=sum(r["spec"]["method"] == method for r in results),
                target_hits=sum(
                    r["hit"] for r in results if r["spec"]["method"] == method
                ),
                execution_failures=sum(
                    r["category"] == "execution_failed"
                    for r in results
                    if r["spec"]["method"] == method
                ),
                statuses=dict(
                    Counter(
                        r["status"] for r in results if r["spec"]["method"] == method
                    )
                ),
                missing_times=sum(
                    r["completion_s"] is None
                    for r in results
                    if r["spec"]["method"] == method
                ),
            )
            for method in ("nomad", "miso")
        },
    )
    report["validation_passed"] = (
        len(results) == 2380
        and not missing
        and not duplicates
        and not errors
        and source_ok
        and dsda["passed"]
    )
    write(aggregate / "validation.json", report)
    state = read(out / "campaign.json")
    has_crashes = any(
        any(
            status.startswith(("crashed", "timeout")) and count
            for status, count in v["statuses"].items()
        )
        for v in report["methods"].values()
    )
    state.update(
        state="finished_with_issues"
        if not report["validation_passed"]
        or report["abnormal_bundles"]
        or any(v["execution_failures"] for v in report["methods"].values())
        or has_crashes
        else "finished",
        collected_utc=now(),
    )
    write(out / "campaign.json", state)
    deployment = repo.parent
    if (deployment / "SOURCE_MANIFEST.json").exists():
        snapshots = out / "deployment_snapshot"
        snapshots.mkdir(exist_ok=True)
        for name in (
            "bootstrap.json",
            "launcher.log",
            "launch.py",
            "RUN.sh",
            "STATUS.sh",
            "COLLECT.sh",
            "select_idle_cpus.py",
            "PACKAGE_SHA256.json",
        ):
            if (deployment / name).is_file():
                shutil.copy2(deployment / name, snapshots / name)
        write(
            snapshots / "SNAPSHOT.json",
            dict(
                captured_utc=now(),
                note="Launcher log captured after experiment jobs terminated and before final archive messages. Per-bundle and native solver logs are complete.",
            ),
        )
    archive, digest = seal_return(out)
    print("RETURN_ARCHIVE", archive, flush=True)
    print("RETURN_SHA256", digest, flush=True)
    print(json.dumps(report, indent=2), flush=True)


def seal_return(out):
    archive = out.with_name(out.name + "_return.zip")
    if archive.exists():
        raise FileExistsError("Return archive already exists; preserve it")
    files = sorted(
        f
        for f in out.rglob("*")
        if f.is_file() and f.name not in ("SHA256SUMS", "campaign.lock")
    )
    (out / "SHA256SUMS").write_text(
        "".join(f"{sha(f)}  {f.relative_to(out).as_posix()}\n" for f in files)
    )
    with zipfile.ZipFile(
        archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6
    ) as z:
        for f in sorted(out.rglob("*")):
            if f.is_file() and f.name != "campaign.lock":
                z.write(f, out.name + "/" + f.relative_to(out).as_posix())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise RuntimeError("ZIP CRC verification failed")
    digest = sha(archive)
    archive.with_suffix(archive.suffix + ".sha256").write_text(
        f"{digest}  {archive.name}\n"
    )
    return archive, digest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("plan", "run", "status", "collect"))
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--dsda-python", type=Path)
    parser.add_argument("--mi-python", type=Path)
    parser.add_argument("--cpus", type=int, nargs="+")
    a = parser.parse_args()
    repo, out = a.repo.resolve(), a.output.resolve()
    if a.action == "plan":
        plan(repo, out)
    elif a.action == "status":
        status(out)
    elif a.action == "collect":
        collect(repo, out)
    else:
        run(repo, out, a.dsda_python, a.mi_python, a.cpus)


if __name__ == "__main__":
    main()
