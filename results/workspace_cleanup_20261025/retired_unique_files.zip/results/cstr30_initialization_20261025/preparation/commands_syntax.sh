scp \
  /Users/albertlee0125/Repos/RBFopt_Test/results/cstr30_initialization_20261025/cstr30_initialization_dantzig_20261025.zip \
  /Users/albertlee0125/Repos/RBFopt_Test/results/cstr30_initialization_20261025/cstr30_initialization_dantzig_20261025.zip.sha256 \
  lee4382@dantzig.ecn.purdue.edu:/local/scratch/a/lee4382/repository/RBFopt_Test/

cd /local/scratch/a/lee4382/repository/RBFopt_Test
sha256sum -c cstr30_initialization_dantzig_20261025.zip.sha256
unzip -n cstr30_initialization_dantzig_20261025.zip
cd cstr30_initialization_runner_20261025
sha256sum -c SHA256SUMS > verify.log
nohup bash run_dantzig.sh run --cpu 10 > launch.log 2>&1 < /dev/null &
echo $! > launcher.pid

tail -n 40 -F /local/scratch/a/lee4382/repository/RBFopt_Test/cstr30_initialization_runner_20261025/launch.log

RUN_DIR=$(cat /local/scratch/a/lee4382/repository/RBFopt_Test/results/cstr30_initialization/latest_run.txt)
find "$RUN_DIR/preflight" -name run.log -print -exec tail -n 12 {} +

RUN_DIR=$(cat /local/scratch/a/lee4382/repository/RBFopt_Test/results/cstr30_initialization/latest_run.txt)
tail -n 40 -F "$RUN_DIR/points/30_30/run.log"

RESULT_ZIP=$(ssh lee4382@dantzig.ecn.purdue.edu 'cat /local/scratch/a/lee4382/repository/RBFopt_Test/results/cstr30_initialization/result_zip.txt')
scp "lee4382@dantzig.ecn.purdue.edu:${RESULT_ZIP}" "lee4382@dantzig.ecn.purdue.edu:${RESULT_ZIP}.sha256" ~/Downloads/
cd ~/Downloads
shasum -a 256 -c "$(basename "$RESULT_ZIP").sha256"

cd /local/scratch/a/lee4382/repository/RBFopt_Test/cstr30_initialization_runner_20261025
RUN_DIR=$(cat /local/scratch/a/lee4382/repository/RBFopt_Test/results/cstr30_initialization/latest_run.txt)
bash run_dantzig.sh resume --run-dir "$RUN_DIR"
