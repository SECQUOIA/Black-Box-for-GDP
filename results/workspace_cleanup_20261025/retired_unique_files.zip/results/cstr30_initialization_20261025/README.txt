CSTR30 initialization follow-up: prepared for manual Dantzig execution

The user selected a ZIP and commands for manual execution after automated Dantzig authentication was unavailable.
No new NLP evaluation or experimental search has been executed.
Actual new NLP calls: 0.
Actual new search runs: 0 of 50 planned.
The new accepted count, objective changes, success counts and computation costs remain unmeasured.
The baseline is the manuscript selection with the explicitly requested finite-1e6 D-SDA and genetic RBFOpt records.
The original manuscript manifest predates this finite-penalty overlay and remains unchanged.
Baseline accepted coordinates: 458 of 900, with 465 logical configurations and 435 structural rejections.
Baseline reference coordinate: [30, 30], with objective 2.7695697198995095.

Method | CSTR30 baseline hits | Six-size baseline hits
--- | --- | ---
dsda | 3/10 | 15/60
rbfopt | 9/10 | 45/60
bam | 2/10 | 18/60
fmqa_sa | 1/10 | 9/60
uniform_without_replacement | 1/10 | 11/60

The finite-penalty baseline totals 98/300 successes.
The separately preserved original manuscript inventory totals 109/300 successes.
That pre-existing difference is due to baseline selection and is not an initialization result.
The primary follow-up uses the manuscript final-best absolute target formula and the original reference.
Any-hit outcomes and better-than-reference absolute-target misses are reported separately.
All 900 original model preparation paths were checked without a solver.
Every one of the 465 allowed models kept identical objective, constraint and bound fingerprints after initialization.
The largest initialized primal violation was 2.6645352591003757e-15.
The seven new protocol tests passed, including an identity comparison of all 50 runs and retention of the other 250 CSTR runs.
The existing related suite passed 59 tests and seven subtests.
One existing watchdog test failed because macOS denied os.killpg, including an escalated run.
The Dantzig controller tests owned-worker cleanup before scientific evaluation and stops if it fails.
The actual GAMS/IPOPT environment has not yet been checked because server authentication was unavailable.
The package requires GAMS 52.2.0, IPOPT 3.14.19, MUMPS 5.8.1, the historical runtime dependencies, a 60-second solve limit and one thread.
An environment mismatch stops the run without solver substitution.
The isolated source branch is experiment/cstr30-initialization-followup.
The execution source revision is 750169cdaa42dc46577b7c267837da54e7b99c35.
The branch has not been pushed.
Existing raw data, manuscript, Overleaf sources and figures were preserved.
COMMANDS.txt contains separate upload, execution, log and download commands.
After the Dantzig run, the returned archive contains the new evaluation table, raw logs, paired comparisons and an English report.
Adoption as a representative manuscript result remains a later decision.
