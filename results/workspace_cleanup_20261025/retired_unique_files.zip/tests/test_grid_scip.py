"""SCIP substitution, complete job selection, independent bundles and paths."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import zipfile

import pyomo.environ as pyo
from pyomo.opt import SolverResults, TerminationCondition as tc
import pytest

import grid_gdp_benchmark as runner
import grid_scip_package as package
from gdp_models import comparison as impl, grid_benchmark as core
from gdp_models.grid import GRID_NAMES, build_grid_gdp


def test_scip_replaces_only_baron_and_selects_exact_corrections():
    corrected = []
    for grid in GRID_NAMES:
        for method in core.METHODS:
            config = core.method_config({"solver_profile": "scip-v1", "grid_name": grid}, method)
            policy = impl.solver_policy(config, method)
            if method in {"bigm", "hull"}:
                assert policy["minlp"] == "scip"
            else:
                assert policy["nlp"] == "scip" and policy["mip"] == "highs"
            if config["retry_fix_profile"]:
                corrected.append((grid, method))
            old = core.method_config({}, method)
            old_policy = impl.solver_policy(old, method)
            assert old_policy.get("nlp", old_policy.get("minlp")) == "baron"
    assert len(corrected) == 10
    assert ("alpine1", "loa") in corrected


@pytest.mark.parametrize("limited", [False, True])
def test_scip_options_and_global_subproblem_guard(tmp_path, monkeypatch, limited):
    context = impl.SolveContext("/configured/gams", tmp_path, time.monotonic() + 20,
                                strict_subproblems=True)
    monkeypatch.setattr(impl, "CONTEXT", context)

    def solve(self, model, **kw):
        assert kw["solver"] == "scip" and not kw["warmstart"]
        assert "option threads=1;" in kw["add_options"]
        path = Path(kw["tmpdir"])
        assert (path / "scip.opt").read_text().splitlines() == list(impl.SCIP_OPTIONS)
        path.joinpath("resultsstat.dat").write_text(
            f"name value\nSOLVESTAT {3 if limited else 1}\nMODELSTAT 7\nOBJVAL 1\nOBJEST 1\n")
        result = SolverResults()
        result.solver.status = "ok"
        result.solver.termination_condition = tc.locallyOptimal
        return result

    monkeypatch.setattr(impl.GAMSShell, "solve", solve)
    model = pyo.ConcreteModel()
    if limited:
        with pytest.raises(impl.IncompleteSubproblem):
            impl.TimedGAMS().solve(model, solver="scip", mtype="nlp")
    else:
        impl.TimedGAMS().solve(model, solver="scip", mtype="nlp")
    assert context.calls[0]["global_subproblem_complete"] is not limited
    assert len((tmp_path / "solver_calls.jsonl").read_text().splitlines()) == 1


def test_scip_feasible_status_requires_global_bound_convergence():
    call = {"solver": "scip", "gams_statistics": {
        "SOLVESTAT": 1, "MODELSTAT": 7, "OBJVAL": 1, "OBJEST": 0.5}}
    assert not impl.subproblem_complete(call, 1e-5)
    call["gams_statistics"]["OBJEST"] = 0.999999
    assert impl.subproblem_complete(call, 1e-5)


def test_scip_all_105_jobs_attempted_and_resume_does_not_repeat(tmp_path, monkeypatch):
    import gdp_compare

    config = {"solver_profile": "scip-v1", "grids": list(GRID_NAMES),
              "methods": list(core.METHODS), "phases": ["benchmark"], "point_indices": []}
    run = {"config": config, "source_sha256": {}, "runtime": {}}
    runner.save(tmp_path / "run.json", run)
    monkeypatch.setattr(runner, "runtime", lambda *a, **kw: {})
    monkeypatch.setattr(runner, "source_hashes", lambda: {})
    calls = []

    def job(template, method, directory, settings, **kw):
        calls.append((template.model.grid_name, method))
        assert settings["minlp_solver"] == settings["nlp_solver"] == "scip"
        runner.save(directory / "result.json", {"status": "finished", "method": method,
                    "has_feasible_solution": False})

    monkeypatch.setattr(gdp_compare, "run_job", job)
    runner.execute(tmp_path, run)
    assert len(calls) == 105 and len(set(calls)) == 105
    assert ("ackley", "hull") in calls
    summary = runner.read(tmp_path / "summary.json")
    assert summary["planned_points"] == 0
    assert summary["finished_benchmarks"] == 105
    assert summary["unsupported_benchmarks"] == 0
    runner.execute(tmp_path, run)
    assert len(calls) == 105
    pointer = runner.read(tmp_path.parent / "latest_result.json")
    assert pointer["all_jobs_finished"] and Path(pointer["result_zip"]).exists()


def test_coordinates_record_selected_indices_separately_from_start_values():
    model = build_grid_gdp("ackley", verify_csv=False)
    for name, chosen in (("Xchoice", 4), ("Ychoice", 9)):
        for i, disjunct in model.find_component(name).items():
            disjunct.indicator_var.set_value(i == chosen)
    model.x.set_value(0)
    model.y.set_value(1)
    record = impl.grid_coordinates(model)
    assert record["grid_point"] == [4, 9]
    assert record["physical_point"] == [0, 1]


def test_watchdog_result_retains_checked_grid_incumbent(tmp_path, monkeypatch):
    import gdp_compare
    from gdp_models.grid import fix_grid_point

    config = {"solver_profile": "scip-v1", "grids": ["ackley"],
              "methods": ["hull"], "phases": ["benchmark"], "point_indices": []}
    run = {"config": config, "source_sha256": {}, "runtime": {}}
    runner.save(tmp_path / "run.json", run)
    monkeypatch.setattr(runner, "runtime", lambda *a, **kw: {})
    monkeypatch.setattr(runner, "source_hashes", lambda: {})

    def job(template, method, directory, settings, **kw):
        model = fix_grid_point(template.model.clone(), [15, 15])
        runner.save(directory / "solution.json", {"variables": {
            v.name: v.value for v in model.component_data_objects(pyo.Var, descend_into=impl.DESCEND)
        }})
        runner.save(directory / "result.json", {"status": "hard_time_limit",
                    "has_feasible_solution": True, "global_optimality_certified": False})

    monkeypatch.setattr(gdp_compare, "run_job", job)
    runner.execute(tmp_path, run)
    result = runner.read(tmp_path / "benchmark/ackley/hull/result.json")
    assert result["status"] == "hard_time_limit"
    assert result["grid_point"] == [15, 15] and result["target_hit"]
    assert result["grid_validation"] == "passed"
    assert not result["global_optimality_certified"]


def test_four_archives_are_independent_and_complete(tmp_path):
    package.build(tmp_path, "test")
    methods = []
    for key in package.PACKAGES:
        path = tmp_path / f"grid_scip_{key}_dantzig_test.zip"
        assert path.with_suffix(".zip.sha256").read_text().startswith(runner.sha(path))
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            prefix = f"grid_scip_{key}_test/"
            for line in archive.read(prefix + "SHA256SUMS").decode().splitlines():
                digest, name = line.split("  ", 1)
                assert hashlib.sha256(archive.read(prefix + name)).hexdigest() == digest
            config = json.loads(archive.read(prefix + "grid_scip_package.json"))
            methods.extend(config["methods"])
            assert len([n for n in archive.namelist() if "/benchmark_grids/" in n]) == 21
            archive.extractall(tmp_path / "extracted")
        extracted = tmp_path / "extracted" / prefix
        result = subprocess.run([sys.executable, str(extracted / "grid_scip_package.py"), "plan"],
                                cwd=tmp_path, capture_output=True, text=True, check=True)
        assert json.loads(result.stdout)["package"] == key
    assert sorted(methods) == sorted(core.METHODS)
    with pytest.raises(FileExistsError):
        package.build(tmp_path, "test")
