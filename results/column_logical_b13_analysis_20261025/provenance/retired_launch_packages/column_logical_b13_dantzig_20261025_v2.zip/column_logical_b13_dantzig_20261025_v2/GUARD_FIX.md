# CPU occupancy guard correction, v2

The original package stopped before environment preflight and before any search job in column_logical_b13_20261025_191943_vx2lehgw.
The user reported that Linux CPU 2 has SMT sibling 50, all process inspections succeeded and no scheduler command was detected.
The six reported intervals peaked at 1.3824884792626728% busy on CPU 2 and 2.7522935779816513% on CPU 50.
The original guard also reported activity from process IDs 1748860 and 4017061.
The supplied summary does not include their complete affinity masks, commands or observed CPUs, so it cannot establish that the core is available.

The previous code treated any active Python or solver process whose allowed CPU set overlapped the core as occupancy, even if its affinity was unrestricted and it was observed elsewhere.
Its 1% per-interval limit also rejected the reported light load independently of that process classification.
Version 2 distinguishes a fully unrestricted online-CPU mask from a constrained compute allocation, and uses observed CPU activity as an independent blocker.
A constrained compute affinity overlapping CPU 2 or 50 remains a blocker even for a sleeping process.
A running thread observed on the core, or an active thread whose previous or current observed CPU is on the core, remains a blocker regardless of the load thresholds.
The low-load policy is explicitly revised to no more than 5% busy in any interval and no more than 2% busy over the complete observation window for each sibling.
This is a launch policy rather than a claim that the sampled CPU will remain exclusive or idle in the future.
CPU affinity does not reserve a core.

The runner repeats all occupancy checks on the actual server when v2 is launched, and does not infer current availability from the pasted diagnostic summary.
The controller now prints blocking reasons, interval and full-window load, relevant process details and the saved record path directly to launch.log.
No process is terminated or reassigned by the occupancy check, and no alternative CPU is selected.
The original blocked run and original ZIP are preserved.
The old package hash prevents accidentally resuming the old directory with the corrected package, so v2 starts in a new result directory.
The unchanged 50-job plan, three initial points per seed, original IPOPT inputs, optimizer source bytes, versions, stopping rules and objective response policies are checked against the first package by SHA256.
No formal optimization or original process NLP computation is performed during this correction.
