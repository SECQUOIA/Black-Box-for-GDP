"""Finish independent coordinate-validation runs; times are not benchmark data."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/albertlee0125/Repos/RBFopt_Test')
RUN = Path(__file__).resolve().parent
manifest = json.loads((RUN/'rbfopt.partial.manifest.json').read_text())
# 122 rows were observed complete before attempting to interrupt the parent.
# RBFOpt swallowed SIGINT; exclude and rerun all later rows, even if checkpointed.
prefix_rows = 122
remaining = manifest['protocol']['planned_run_keys'][prefix_rows:]
assert all(k['case_name'] == 'dynamic' and k['method'] == 'rbfopt' for k in remaining)
directory = RUN/'rbfopt_remaining'
directory.mkdir(exist_ok=False)
(directory/'plan.json').write_text(json.dumps({'prefix_rows':prefix_rows,
    'remaining_keys':remaining,'workers':4,'purpose':'coordinate validation only; concurrent local timing is not a performance comparison'}, indent=2)+'\n')
environment = dict(os.environ, PYTHONPATH=str(ROOT), OMP_NUM_THREADS='1',
                   OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')

def run(key):
    stem = f"dynamic_B{key['max_evaluations']}_seed{key['seed']}"
    work = directory/(stem+'_work')
    work.mkdir()
    csv_path = directory/(stem+'.csv')
    command = [sys.executable, str(ROOT/'case_study_benchmark.py'), '--cases','dynamic',
        '--methods','rbfopt','--seeds',str(key['seed']), '--dynamic-budgets',str(key['max_evaluations']),
        '--trace-evaluations','--solver-dir','/Users/albertlee0125/Solvers/ampl.macos64',
        '--output',str(csv_path)]
    started=time.perf_counter()
    with (directory/(stem+'.log')).open('w') as logfile:
        completed=subprocess.run(command,cwd=work,env=environment,stdout=logfile,stderr=subprocess.STDOUT)
    result={'key':key,'returncode':completed.returncode,'elapsed_s':time.perf_counter()-started,'csv_path':str(csv_path)}
    print(json.dumps(result),flush=True)
    return result

results=[]
with ThreadPoolExecutor(max_workers=4) as pool:
    for future in as_completed([pool.submit(run,key) for key in remaining]):
        results.append(future.result())
        (directory/'execution.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(r['returncode']==0 for r in results), 'Some runs failed; inspect per-run logs'
print(f'Completed {len(results)} remaining RBFOpt traces',flush=True)
