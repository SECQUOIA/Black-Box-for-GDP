"""Publish the audited local coordinate-validation artifacts without git writes."""
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path('/Users/albertlee0125/Repos/RBFopt_Test')
RUN = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import case_study_benchmark as cases
from trace_analysis import analyze, read_completed_runs

finished = json.loads((RUN/'rbfopt_remaining/execution.json').read_text())
assert len(finished) == 17 and all(r['returncode'] == 0 for r in finished)
inputs = [RUN/'dsda_bam.csv', RUN/'rbfopt_validated_prefix.csv',
          *sorted((RUN/'rbfopt_remaining').glob('dynamic_*.csv'))]
assert len(inputs) == 19
actual = [key for path in inputs for key, _, _ in read_completed_runs(path)]
canonical = lambda key: json.dumps(key, sort_keys=True)
expected = cases._planned_run_keys(cases.build_run_matrix(), cases.DEFAULT_METHODS, 3)
assert len(actual) == 417 and set(map(canonical,actual)) == set(map(canonical,expected))
OUTPUT = ROOT/'results/process_evaluation_traces_20260917'
summary = analyze(inputs, OUTPUT)
summary['original_matrix_coverage'] = '417/417 distinct run keys; 89 initial designs verified'
summary['purpose'] = 'New local lookup trajectories and NLP cost inventory; not a Dantzig timing comparison'
(OUTPUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
shutil.copyfile(RUN/'reference_audit.json',OUTPUT/'reference_audit.json')

with (OUTPUT/'run_summary.csv').open() as handle: rows=list(csv.DictReader(handle))
with (OUTPUT/'nlp_point_requests.csv').open() as handle: points=list(csv.DictReader(handle))
groups=[]
for case in cases.DEFAULT_CASES:
    rs=[r for r in rows if r['case_name']==case]
    ps=[p for p in points if p['case_name']==case]
    groups.append(dict(case=case,runs=len(rs),objective_calls=sum(int(r['total_evals']) for r in rs),
        distinct_problem_points=len(ps),points_with_legacy_cost=sum(p['legacy_solver_user_time_s']!='' for p in ps),
        runs_with_complete_legacy_cost=sum(r['legacy_full_call_cost_estimate_s']!='' for r in rs)))
with (OUTPUT/'case_summary.csv').open('w',newline='') as handle:
    writer=csv.DictWriter(handle,fieldnames=list(groups[0]));writer.writeheader();writer.writerows(groups)

initial = json.loads((RUN/'probe_gdp_models_before_cstr_presolve.json').read_text())
probe = {'purpose':'One-point model-connection probes, not a timing benchmark or global-optimality certificate',
    'dsda_gdp_commit':'3e469dbeea8931670b8cd6752014ab7a767d3af5',
    'dynamic_commit':'482e14ebf9caabbd35d959986942cb028778a1d7',
    'policy':'IPOPT 3.12.13, max_cpu_time=30, max_iter=3000, bound_relax_factor=0, tol=1e-8 for Column/Small Batch/Dynamic. Static cases use upstream initialization and FBBT; Dynamic uses nfe=30,ncp=3. CSTR additionally uses stronger equivalent presolve and GAMS/BARON with reslim=60,optcr=1e-5.',
    'compatibility':'Original function bodies loaded via AST; unused obsolete MasterProblemResult import bypassed. No mathematical model edits.',
    'primary_attempts':initial,
    'cstr_full_presolve_attempt':json.loads((RUN/'probe_cstr_ipopt_presolve.json').read_text()),
    'cstr_gams_baron_attempt':json.loads((RUN/'probe_gdp_models.json').read_text()),
    'conclusion':'All four witness objectives match at relative tolerance 1e-5 with max primal violation below 1e-6. CSTR required BARON: IPOPT failed; GAMS worked after license-network access was permitted. Solver termination is retained verbatim, including locallyOptimal; these probes do not certify global optimality. No new objective replaces a lookup table value.'}
(OUTPUT/'gdp_model_probe.json').write_text(json.dumps(probe,indent=2)+'\n')

archive_path=OUTPUT/'lookup_trace_bundle.zip'
written=set()
def add(archive,path,name):
    if name not in written:
        archive.write(path,name);written.add(name)
with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in inputs:
        manifest=json.loads(path.with_suffix('.manifest.json').read_text())
        for artifact in [path,path.with_suffix('.manifest.json')]:
            add(archive,artifact,'raw/'+artifact.relative_to(RUN).as_posix())
        for artifact in manifest['evaluation_traces']:
            target=path.parent/artifact['path']
            add(archive,target,'raw/'+target.relative_to(RUN).as_posix())
        for relative in manifest['provenance']['source_files_sha256']:
            add(archive,ROOT/relative,'source/'+relative)
        for relative in manifest['provenance']['data_files_sha256']:
            add(archive,ROOT/relative,'source/'+relative)
    for name in ['trace_analysis.py','run_traced_cases_dantzig.sh','pyproject.toml','docs/evaluation_tracing.md']:
        add(archive,ROOT/name,'source/'+name)
    for path in RUN.glob('probe*'):
        if path.is_file():add(archive,path,'diagnostics/'+path.name)
    for directory in ['dsda_bam.traces','rbfopt.traces']:
        for path in (RUN/directory).glob('*.partial.jsonl'):
            add(archive,path,'diagnostics/'+directory+'/'+path.name)
    for path in (RUN/'rbfopt_remaining').glob('*.json'):
        if path.name in ['plan.json','execution.json']:
            add(archive,path,'diagnostics/'+path.name)
    for name in ['finish_rbfopt_traces.py','package_results.py','reference_audit.json']:
        add(archive,RUN/name,'diagnostics/'+name)
    for name in ['rbfopt.partial.csv','rbfopt.partial.manifest.json']:
        add(archive,RUN/name,'diagnostics/original_rbfopt_checkpoint/'+name)
    archive.writestr('input_paths.json',json.dumps(['raw/'+p.relative_to(RUN).as_posix() for p in inputs],indent=2)+'\n')
with zipfile.ZipFile(archive_path) as archive:assert archive.testzip() is None
checksum=hashlib.sha256(archive_path.read_bytes()).hexdigest()
(OUTPUT/'SHA256SUMS').write_text(f'{checksum}  {archive_path.name}\n')

table='\n'.join('| {case} | {runs} | {objective_calls} | {distinct_problem_points} | {points_with_legacy_cost} | {runs_with_complete_legacy_cost} |'.format(**g) for g in groups)
(OUTPUT/'README.md').write_text(f'''# Local process evaluation traces (started 2026-09-17)

All **417 original process run keys** were rerun: 139 each for DSDA, RBFOpt,
and BAM 5.0.0. The **89 original initial designs match exactly**. The traces
contain **{summary['objective_calls']:,} objective calls** at **{summary['distinct_problem_points']:,}
distinct problem/point combinations**, including initial, repeated, and
nonfinite evaluations.

These are new lookup trajectories on macOS arm64, Python 3.13.12, RBFOpt 4.3.0,
BAM wrapper 5.0.0 / native 2026.9.10. They do not reconstruct the ambiguous
old Dantzig paths. Local jobs overlapped, and the last 17 RBFOpt runs used four
independent workers. **Do not use these elapsed times for method rankings or
replace the published Dantzig time profiles with them.**

| Case | Runs | Objective calls | Distinct problem/points | Points with legacy time | Runs with full legacy cost |
| --- | ---: | ---: | ---: | ---: | ---: |
{table}

## Files

- [evaluation_points.csv](evaluation_points.csv): every evaluated coordinate in order, raw objective, phase, repeat flag, callback timestamp, and historical cost join.
- [nlp_point_requests.csv](nlp_point_requests.csv): distinct coordinates for the next GDP/NLP measurement experiment.
- [run_summary.csv](run_summary.csv): callback counts, lookup first-hit timestamps, and timing coverage per run.
- [lookup_trace_bundle.zip](lookup_trace_bundle.zip): original CSV/manifest files, complete JSONL sidecars, source/data snapshots, and interruption diagnostics.
- [reference_audit.json](reference_audit.json): original-start/data/method-code audit.
- [gdp_model_probe.json](gdp_model_probe.json): preliminary original-model connection probes and limitations.

Every final trace was checked against the result callback count and incumbent
history, exact lookup objective, repeated-point flags, and regenerated initial
coordinates. The union contains exactly the original 417 run keys, without
duplicates. All 216 repository tests passed; shell syntax and Ruff checks passed.

## Interpretation of costs

Legacy `Time` is the original solver's reported `user_time`. `Global_Time` is
cumulative and is never summed. `Status=Final` is the upstream writer's extra
best-point solve after enumeration, so that row is excluded. Other duplicates,
missing records, and invalid times stay missing. **{summary['runs_with_all_legacy_costs']}
runs have complete historical point-cost coverage**; their sums are estimates
under the old solver/machine policy, not new measured GDP wall times.
`legacy_known_cost_sum_s` is only a partial sum when coverage is incomplete.

The original writer can label non-infeasible terminations `Optimal`, including
time limits; that text is not proof of global optimality. The CSV lookup
objectives were retained unchanged. Dynamic has objective values but no
point-time table in this repository.

Original-model probes fixed all discrete variables and removed active
disjunctions. Column (13,4), Small Batch (2,2,1), and Dynamic (1,4) solved with
IPOPT. CSTR (3,1) solved with GAMS/BARON after permitting its license-network
connection; its objective differed from the lookup value by about 4.8e-14.
All four witness objectives matched within the benchmark tolerance, with
maximum primal residual below 1e-6. These isolated checks use different solvers
and do not establish all-point equivalence, comparable timings, or global
optimality. CSTR's BARON termination was `locallyOptimal`; earlier IPOPT
failures and the initially blocked GAMS availability check are retained in
the diagnostics. No new objective replaces a lookup table value.

## Interruptions and provenance

The first BAM pass exited with SIGILL at Dynamic, budget 30, seed 1 after 28
callbacks. Its partial file was retained. Strict resume validated 221 completed
rows and then completed all 278 DSDA/BAM runs.

For RBFOpt, 122 rows known complete before interrupt attempts were retained.
SIGINT was handled inside the optimizer, so all subsequently checkpointed rows
were excluded; the process was stopped with SIGTERM. The remaining 17 run keys
were rerun independently, each with its own work directory and complete trace.
`rbfopt_validated_prefix.manifest.json` records the subset selection and source
CSV checksum. A running status on that prefix reflects the interrupted original
plan; full coverage is established by the validated union with the 17 completed
single-run manifests.

To reproduce the joined tables after extracting the bundle:

```bash
python trace_analysis.py \\
  extracted/raw/dsda_bam.csv \\
  extracted/raw/rbfopt_validated_prefix.csv \\
  extracted/raw/rbfopt_remaining/dynamic_*.csv \\
  --output results/rechecked_process_traces
```

For formal Dantzig timing, use the sequential wrapper in
[the tracing workflow](../../docs/evaluation_tracing.md). Remote execution was
not performed in this session because SSH authentication was unavailable.
Next, establish one validated NLP solver/initialization policy and measure the
requested points, including missing/infeasible points; replay warm-started paths
in order instead of treating their costs as fixed per point.
''')
print(json.dumps(summary,indent=2))
print('Artifacts:',OUTPUT)
print('Bundle SHA256:',checksum)
