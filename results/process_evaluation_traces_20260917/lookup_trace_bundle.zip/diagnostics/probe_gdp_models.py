"""Four-point local feasibility probe; not the formal GDP timing experiment."""
import importlib.util
import ast
import copy
import os
import json
from pathlib import Path
import sys
import time

import pyomo.environ as pyo
from pyomo.gdp import Disjunct, Disjunction
from pyomo.contrib.fbbt.fbbt import fbbt

ROOT = Path('/Users/albertlee0125/Repos/RBFopt_Test')
SOURCE = Path('/private/tmp/rbfopt-trace-dsda-gdp-20260917')
DYNAMIC = Path('/private/tmp/rbfopt-trace-dynamic-20260917')
sys.path[:0] = [str(ROOT), str(SOURCE)]
from gdp.dsda.model_serializer import StoreSpec, from_json
from gdp.cstr.gdp_reactor import build_cstrs
from gdp.small_batch.gdp_small_batch import build_small_batch

column_path = SOURCE/'gdp/column/gdp_column.py'
column_ast = ast.parse(column_path.read_text())
column_ast.body = [node for node in column_ast.body if not (
    isinstance(node, ast.ImportFrom) and node.module == 'pyomo.contrib.gdpopt.data_class')]
column_scope = {'__file__': str(column_path), '__name__': 'column_probe_model'}
exec(compile(column_ast, str(column_path), 'exec'), column_scope)
build_column = column_scope['build_column']

# Load the original function ASTs unchanged, bypassing obsolete imports for
# unrelated GDPopt algorithms. No upstream model or function body is edited.
def original_functions(path, names):
    module = ast.parse(path.read_text())
    definitions = [node for node in module.body if isinstance(node, ast.FunctionDef) and node.name in names]
    assert {node.name for node in definitions} == set(names)
    scope = dict(pe=pyo, pyo=pyo, os=os, copy=copy, StoreSpec=StoreSpec,
                 from_json=from_json, __file__=str(path))
    exec(compile(ast.Module(body=definitions, type_ignores=[]), str(path), 'exec'), scope)
    return [scope[name] for name in names]

external_ref, get_external_information, initialize_model = original_functions(
    SOURCE/'gdp/dsda/dsda_functions.py', ['external_ref','get_external_information','initialize_model'])
problem_logic_cstr, = original_functions(SOURCE/'main_cstr.py', ['problem_logic_cstr'])
problem_logic_column, = original_functions(SOURCE/'main_column.py', ['problem_logic_column'])
problem_logic_batch, = original_functions(SOURCE/'main_small_batch.py', ['problem_logic_batch'])
from case_studies.column_case import KNOWN_BEST_POINT as COL_POINT, KNOWN_BEST_VALUE as COL_VALUE
from case_studies.small_batch_case import KNOWN_BEST_POINT as SB_POINT, KNOWN_BEST_VALUE as SB_VALUE
from case_studies.cstr_case import load_cstr_case_data


def static_case(case):
    if case == 'cstr':
        m = build_cstrs(5)
        ref, logic, point, label = {m.YF: m.N, m.YR: m.N}, problem_logic_cstr, (3, 1), 'cstr_5'
        target = load_cstr_case_data(5)['feasible_objectives'][point]
    elif case == 'column':
        m = build_column(min_trays=8, max_trays=17, xD=.95, xB=.95)
        ref, logic, point, label = {m.YB: m.intTrays, m.YR: m.intTrays}, problem_logic_column, COL_POINT, 'column_17'
        target = COL_VALUE
    else:
        m = build_small_batch()
        ref, logic, point, label = {m.Y: m.k}, problem_logic_batch, SB_POINT, 'small_batch'
        target = SB_VALUE
    reformulation, *_ = get_external_information(m, ref)
    m = initialize_model(m, from_feasible=True, feasible_model=label)
    m = external_ref(m, list(point), logic, reformulation)
    return m, list(point), target


def dynamic_case():
    source = DYNAMIC / 'models/nine_stage_dynamic_model_switching_nonlinear.py'
    spec = importlib.util.spec_from_file_location('dynamic_probe_model', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    m = module.build_model(False)
    pyo.TransformationFactory('dae.collocation').apply_to(m, nfe=30, ncp=3, scheme='LAGRANGE-RADAU')
    for disjunct in m.component_data_objects(Disjunct):
        for constraint in disjunct.component_objects(pyo.Constraint):
            constraint._constructed = False
            constraint.construct()
    for var in m.component_data_objects(pyo.Var, descend_into=True):
        if 'dxdt' in var.name:
            var.setlb(-300)
            var.setub(300)
    point = [1, 4]
    for stage in m.stage:
        selected = 1 if stage <= point[0] else (2 if stage <= point[1] else 3)
        for mode in m.mode:
            m.stage_mode[stage, mode].indicator_var.fix(mode == selected)
    pyo.TransformationFactory('core.logical_to_linear').apply_to(m)
    pyo.TransformationFactory('gdp.fix_disjuncts').apply_to(m)
    return m, point, -212.00878719112268


reports = []
for case in (sys.argv[1:] or ['cstr', 'small_batch', 'column', 'dynamic']):
    started = time.perf_counter()
    try:
        m, point, target = dynamic_case() if case == 'dynamic' else static_case(case)
        if case != 'dynamic':
            fbbt(m)
        original_constraints = list(m.component_data_objects(pyo.Constraint, active=True, descend_into=True))
        if case == 'cstr':
            for name in ['detect_fixed_vars', 'propagate_fixed_vars', 'remove_zero_terms',
                         'propagate_zero_sum', 'constraints_to_var_bounds',
                         'detect_fixed_vars', 'propagate_zero_sum']:
                pyo.TransformationFactory('contrib.' + name).apply_to(m)
            pyo.TransformationFactory('contrib.deactivate_trivial_constraints').apply_to(
                m, tmp=False, ignore_infeasible=False)
        setup = time.perf_counter() - started
        unfixed = [v.name for v in m.component_data_objects(pyo.Var, active=True, descend_into=True)
                   if (v.is_binary() or v.is_integer()) and not v.fixed]
        disjunctions = [d.name for d in m.component_data_objects(Disjunction, active=True)]
        assert not unfixed and not disjunctions, (unfixed, disjunctions)
        solve_start = time.perf_counter()
        use_baron = os.environ.get('GDP_PROBE_SOLVER') == 'baron'
        if use_baron:
            solver = pyo.SolverFactory('gams')
            result = solver.solve(m, solver='baron', add_options=[
                'option reslim=60;', 'option optcr=0.00001;'], tee=False)
        else:
            solver = pyo.SolverFactory('ipopt', executable='/Users/albertlee0125/Solvers/ampl.macos64/ipopt')
            result = solver.solve(m, options={'max_cpu_time': 30, 'max_iter': 3000,
                                             'bound_relax_factor': 0, 'tol': 1e-8}, tee=False)
        solve_wall = time.perf_counter() - solve_start
        objective = pyo.value(m.obj, exception=False)
        violation = 0.0
        for c in original_constraints:
            body = pyo.value(c.body)
            if c.has_lb(): violation = max(violation, pyo.value(c.lower) - body)
            if c.has_ub(): violation = max(violation, body - pyo.value(c.upper))
        for v in m.component_data_objects(pyo.Var, active=True, descend_into=True):
            if v.value is None: continue
            if v.has_lb(): violation = max(violation, pyo.value(v.lb) - v.value)
            if v.has_ub(): violation = max(violation, v.value - pyo.value(v.ub))
        report = dict(case=case, point=point, lookup_objective=target,
                      solver='GAMS/BARON' if use_baron else 'IPOPT 3.12.13',
                      objective=objective, absolute_gap=abs(objective-target) if objective is not None else None,
                      termination=str(result.solver.termination_condition),
                      solver_message=str(result.solver.message),
                      setup_wall_s=setup, solve_wall_s=solve_wall,
                      total_wall_s=time.perf_counter()-started,
                      unfixed_discrete_variables=unfixed, active_disjunctions=disjunctions,
                      max_primal_violation=violation)
    except Exception as exc:
        report = dict(case=case, error_type=type(exc).__name__, error=str(exc))
    print(json.dumps(report), flush=True)
    reports.append(report)
    Path(__file__).with_suffix('.json').write_text(json.dumps(reports, indent=2)+'\n')
