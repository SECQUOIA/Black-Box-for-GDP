"""Two frozen Dantzig GDPopt experiments: SCIP Grid MIP and SCIP Process NLP."""

import argparse
from collections import Counter
from contextlib import redirect_stdout, redirect_stderr
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import time
import zipfile

ROOT = Path(__file__).resolve().parent
METHODS = ['gloa', 'loa', 'ric']
KIND = 'gdpopt_actual_scip_20261024_v1'
PACKAGES = {
    'grid': {'mip_solver': 'scip', 'nlp_solver': 'scip', 'cpu': 6, 'peer_cpu': 8},
    'process': {'mip_solver': 'highs', 'nlp_solver': 'scip', 'cpu': 8, 'peer_cpu': 6},
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def save(path, data):
    from grid_gdp_benchmark import save as atomic_save
    atomic_save(path, data)


def package_inventory():
    """Verify every shipped byte before imports can execute model code."""
    manifest = read(ROOT / 'PACKAGE_MANIFEST.json')
    for row in manifest['files']:
        path = (ROOT / row['path']).resolve()
        if not path.is_relative_to(ROOT) or sha(path.read_bytes()) != row['sha256']:
            raise ValueError(f"Package file changed: {row['path']}")
    return {r['path']: r['sha256'] for r in manifest['files']} | {
        'PACKAGE_MANIFEST.json': sha((ROOT / 'PACKAGE_MANIFEST.json').read_bytes())}


def build(output, tag):
    import grid_gdp_benchmark as grid
    import gdp_compare
    from gdp_models._sources import PINS, source_root
    from gdp_models.models import MODELS, initialization_info

    if not tag or not all(c.isalnum() or c in '_-' for c in tag):
        raise ValueError('Use a simple alphanumeric tag')
    output.mkdir(parents=True, exist_ok=True)
    names = {key: f'{key}_gdpopt_scip_dantzig_{tag}' for key in PACKAGES}
    if any((output / (name + suffix)).exists() for name in names.values() for suffix in ('.zip', '.zip.sha256')):
        raise FileExistsError('Packages are immutable; choose a fresh output/tag')
    files = set(grid.source_files() + gdp_compare.source_files())
    files.update(ROOT / name for name in ('gdp_scip_experiments.py', 'run_gdp_scip_experiment.sh',
                                        'docs/gdp_scip_experiments.md', 'tests/test_gdp_scip_experiments.py'))
    common = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in sorted(files)}
    # Exact model definitions and initialization files, at their existing relative paths.
    upstream = {}
    for case, (repo, relative, _) in MODELS.items():
        upstream[f'external/{repo}/{relative}'] = (source_root(repo) / relative).read_bytes()
        for size in ((5, 10, 15, 20, 25, 30) if case == 'cstr' else (30,)):
            _, needed = initialization_info(case, size, 'auto')
            for relative in needed:
                upstream[f'external/dsda-gdp/{relative}'] = (source_root('dsda-gdp') / relative).read_bytes()
    for repo in PINS:
        for relative in ('LICENSE', 'LICENSE.md', 'LICENSE.txt'):
            path = source_root(repo) / relative
            if path.is_file():
                upstream[f'external/{repo}/{relative}'] = path.read_bytes()
    for key, specification in PACKAGES.items():
        payload = dict(common)
        if key == 'process':
            payload.update(upstream)
        package = {'kind': KIND, 'package': key, 'tag': tag, 'methods': METHODS,
                   'time_limit': 1800, 'relative_gap': 1e-5, 'threads': 1,
                   'planned_jobs': 63 if key == 'grid' else 27,
                   'cases': ['cstr', 'column', 'small_batch', 'dynamic'],
                   'cstr_sizes': [5, 10, 15, 20, 25, 30], **specification}
        payload['gdp_scip_package.json'] = (json.dumps(package, indent=2) + '\n').encode()
        payload['README.md'] = (ROOT / 'docs/gdp_scip_experiments.md').read_bytes()
        manifest = {'kind': KIND, 'package': key,
                    'submodules': {f'external/{n}': pin for n, pin in PINS.items()} if key == 'process' else {},
                    'files': [{'path': n, 'sha256': sha(d)} for n, d in sorted(payload.items())]}
        payload['PACKAGE_MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
        payload['SHA256SUMS'] = ''.join(f'{sha(d)}  {n}\n' for n, d in sorted(payload.items())).encode()
        path = output / (names[key] + '.zip')
        with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
            for name, data in sorted(payload.items()):
                archive.writestr(f'{names[key]}/{name}', data)
        with zipfile.ZipFile(path) as archive:
            if archive.testzip():
                raise ValueError('Bundle CRC failure')
        path.with_suffix('.zip.sha256').write_text(f'{sha(path.read_bytes())}  {path.name}\n')
        print(path.resolve())


def make_config(package, args):
    from gdp_models.grid import GRID_NAMES
    methods = args.methods.split(',') if args.methods else package['methods']
    if not methods or len(methods) != len(set(methods)) or not set(methods) <= set(METHODS):
        raise ValueError('Choose distinct GLOA/LOA/RIC methods')
    if args.time_limit <= 0 or not __import__('math').isfinite(args.time_limit):
        raise ValueError('Time limit must be finite and positive')
    cases = args.cases.split(',') if args.cases else package['cases']
    sizes = [int(s) for s in args.cstr_sizes.split(',')] if args.cstr_sizes else package['cstr_sizes']
    grids = args.grids.split(',') if args.grids else list(GRID_NAMES)
    for selected, allowed in ((cases, package['cases']), (sizes, package['cstr_sizes']), (grids, GRID_NAMES)):
        if not selected or len(selected) != len(set(selected)) or not set(selected) <= set(allowed):
            raise ValueError('Subset contains unsupported or duplicate cases/sizes/grids')
    cpu = args.cpu if args.cpu is not None else package['cpu'] if sys.platform == 'linux' else None
    return {**package, 'cases': cases, 'cstr_sizes': sizes, 'grids': grids, 'methods': methods,
            'cpu': cpu, 'time_limit': args.time_limit, 'phases': ['benchmark'],
            'expected_gams_version': os.environ.get('GDP_GAMS_VERSION', '52.2'),
            'executable': os.environ.get('GAMS_BIN', '/package/gams/52.2/gams'),
            'record_grid_path': package['package'] == 'grid', 'record_gdp_path': True}


def specs(config):
    if config['package'] == 'grid':
        return [{'case': 'grid', 'instance_id': g, 'grid_name': g} for g in config['grids']]
    import gdp_compare
    return gdp_compare.planned_instances(config)


def template_for(spec):
    if spec['case'] == 'grid':
        from gdp_models.grid_benchmark import grid_template
        return grid_template(spec['grid_name'])
    from gdp_models.comparison import build_template
    return build_template(spec['case'], cstr_size=spec['cstr_size'] or 30, instance_id=spec['instance_id'])


def worker(template, method, directory, config, deadline):
    from gdp_models import comparison as impl
    from gdp_models.grid_retry_fixes import corrected_gdpopt, PROFILE, FBBT_GRIDS
    from grid_gdp_benchmark import process_identity
    os.setsid()
    save(directory / 'process.json', process_identity(os.getpid()))
    name = template.metadata.get('grid_name')
    profile = PROFILE if name in FBBT_GRIDS or name == 'alpine1' and method == 'loa' else None
    with (directory / 'run.log').open('w', buffering=1) as log:
        os.dup2(log.fileno(), 1)
        os.dup2(log.fileno(), 2)
        with corrected_gdpopt(profile, name, method) as corrections:
            result = impl.solve_method(template, method, directory, config, deadline)
        result.update(corrections)
        save(directory / 'result.json', result)


def preflight(config, directory):
    from grid_gdp_benchmark import runtime
    from gdp_models import comparison as impl
    identity = runtime(config)
    checks = ['scip_mip', 'scip_nlp', 'scip_trig'] if config['package'] == 'grid' else ['highs', 'scip_nlp']
    directory.mkdir(parents=True, exist_ok=True)
    with (directory / 'preflight.log').open('w') as log, redirect_stdout(log), redirect_stderr(log):
        identity['solver_checks'] = impl.smoke_solvers(config['executable'], directory, checks)
    templates = {}
    for spec in specs(config):
        template = template_for(spec)
        templates[spec['instance_id']] = template
        save(directory / 'templates' / (spec['instance_id'] + '.json'), template.metadata)
    return identity, templates


def summarize(directory):
    from grid_gdp_benchmark import benchmark_complete, csv_file
    run = read(directory / 'run.json')
    rows, totals = [], Counter()
    for spec in specs(run['config']):
        for method in run['config']['methods']:
            job = directory / 'benchmark' / spec['instance_id'] / method
            if not (job / 'result.json').exists():
                continue
            result = read(job / 'result.json')
            calls_path = job / 'solver_calls.jsonl'
            calls = [json.loads(line) for line in calls_path.read_text().splitlines()] if calls_path.exists() else []
            counts = Counter(f"{c['solver']}/{c['mtype']}" for c in calls)
            totals.update(counts)
            rows.append({**result, 'terminal_verified': benchmark_complete(job),
                         'solution_returned': (job / 'solution.json').exists(),
                         'actual_solver_calls': dict(counts),
                         'active_call_at_stop': read(job / 'active_solver_call.json') if (job / 'active_solver_call.json').exists() else None})
    report = {'planned_jobs': len(specs(run['config'])) * len(run['config']['methods']),
              'completed_jobs': sum(r['terminal_verified'] for r in rows),
              'feasible_jobs': sum(r.get('has_feasible_solution', False) for r in rows),
              'solutions_returned': sum(r['solution_returned'] for r in rows),
              'actual_benchmark_solver_calls': dict(totals),
              'nlp_scip_called': bool(totals['scip/nlp']),
              'scip_called': any(k.startswith('scip/') and v for k, v in totals.items()),
              'preflight_excluded_from_benchmark_counts': True, 'results': rows}
    report['all_jobs_finished'] = report['completed_jobs'] == report['planned_jobs']
    save(directory / 'summary.json', report)
    csv_file(directory / 'summary.csv', rows)
    return report


def pack(directory):
    from grid_gdp_benchmark import ensure_stopped
    ensure_stopped(directory)
    summary = summarize(directory)
    files = sorted(p for p in directory.rglob('*') if p.is_file() and not p.is_symlink()
                   and p.name != '.lock' and not p.name.endswith('.tmp')
                   and not any(s.startswith('gams-') for s in p.relative_to(directory).parts))
    output = directory.with_suffix('.zip')
    temp = output.with_suffix('.zip.tmp')
    with zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, f'{directory.name}/{path.relative_to(directory).as_posix()}')
        archive.writestr(f'{directory.name}/SHA256SUMS', ''.join(
            f'{sha(p.read_bytes())}  {p.relative_to(directory).as_posix()}\n' for p in files))
    with zipfile.ZipFile(temp) as archive:
        if archive.testzip():
            raise ValueError('Result CRC failure')
    temp.replace(output)
    output.with_suffix('.zip.sha256').write_text(f'{sha(output.read_bytes())}  {output.name}\n')
    save(directory.parent / 'latest_result.json', {'run_dir': str(directory), 'result_zip': str(output),
                                                 'all_jobs_finished': summary['all_jobs_finished']})
    pointer = directory.parent / 'result_zip.txt'
    temporary = pointer.with_suffix('.tmp')
    temporary.write_text(str(output) + '\n')
    temporary.replace(pointer)
    print('RESULT_ZIP=' + str(output), flush=True)
    return summary


def execute(directory, run, templates):
    from gdp_compare import run_job
    from grid_gdp_benchmark import benchmark_complete, seal_benchmark, ensure_stopped
    from gdp_models.grid_benchmark import check_grid_solution
    ensure_stopped(directory)
    for spec in specs(run['config']):
        template = templates.get(spec['instance_id']) or template_for(spec)
        for method in run['config']['methods']:
            job = directory / 'benchmark' / spec['instance_id'] / method
            if job.exists():
                if benchmark_complete(job):
                    continue
                old = directory / 'previous_attempts' / spec['instance_id'] / f'{method}_{time.time_ns()}'
                old.parent.mkdir(parents=True, exist_ok=True)
                job.rename(old)
            print(f"START {spec['instance_id']}/{method}", flush=True)
            result = run_job(template, method, job, run['config'], target=worker)
            if spec['case'] == 'grid':
                result = check_grid_solution(template, job, result)
                save(job / 'result.json', result)
            seal_benchmark(job)
            summary = summarize(directory)
            print(f"DONE {spec['instance_id']}/{method}: {result['status']}, objective={result.get('objective')}; "
                  f"{summary['completed_jobs']}/{summary['planned_jobs']}", flush=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('build', 'plan', 'check', 'run', 'resume', 'status', 'pack'))
    parser.add_argument('--output', type=Path, default=ROOT / 'results/runners/gdp_scip_20261024')
    parser.add_argument('--tag', default='20261024')
    parser.add_argument('--output-root', type=Path)
    parser.add_argument('--run-dir', type=Path)
    parser.add_argument('--cpu', type=int)
    parser.add_argument('--time-limit', type=float, default=1800)
    for option in ('grids', 'cases', 'cstr-sizes', 'methods'):
        parser.add_argument('--' + option)
    args = parser.parse_args(argv)
    if args.mode == 'build':
        build(args.output, args.tag)
        return 0
    inventory = package_inventory()
    package = read(ROOT / 'gdp_scip_package.json')
    if package['kind'] != KIND or package['package'] not in PACKAGES:
        raise ValueError('Unknown package identity')
    import gdp_compare
    gdp_compare.environment()
    # The Process archive carries verified exact upstream files; no git clone/install needed.
    if package['package'] == 'process':
        os.environ['RBFOPT_GDP_SOURCES'] = str(ROOT / 'external')
    config = make_config(package, args)
    if args.mode == 'plan':
        print(json.dumps({'config': config, 'instances': specs(config),
                          'planned_jobs': len(specs(config)) * len(config['methods'])}, indent=2))
        return 0
    from grid_gdp_benchmark import locked, runtime, ensure_stopped
    if args.mode in {'resume', 'status', 'pack'}:
        if args.run_dir is None:
            raise ValueError('--run-dir is required')
        directory = args.run_dir.resolve()
        run = read(directory / 'run.json')
        if run['kind'] != KIND or run['config']['package'] != package['package'] or inventory != run['source_sha256']:
            raise ValueError('Run identity or frozen sources differ from this package')
        if args.mode == 'status':
            print(json.dumps(read(directory / 'summary.json') if (directory / 'summary.json').exists()
                             else {'preflight_status': run.get('preflight_status', 'pending')}, indent=2))
            return 0
        with locked(directory):
            ensure_stopped(directory)
            if args.mode == 'resume':
                current = runtime(run['config'])
                if any(current[k] != run['runtime'][k] for k in current):
                    raise ValueError('Runtime/CPU changed; do not combine timing environments')
                try:
                    execute(directory, run, {})
                finally:
                    pack(directory)
            else:
                pack(directory)
        return 0
    repository = Path(os.environ.get('GDP_SCIP_REPOSITORY', '/local/scratch/a/lee4382/repository/RBFopt_Test'))
    if sys.platform == 'linux':
        from cpu_affinity import check_cpu_pair
        print('CPU_PAIR=' + json.dumps(check_cpu_pair(config['cpu'], config['peer_cpu'])), flush=True)
    output = args.output_root or repository / ('results/' + package['package'] + '_gdpopt_scip')
    output.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
    directory = Path(tempfile.mkdtemp(prefix=f"{package['package']}_gdpopt_scip_{stamp}_", dir=output)).resolve()
    run = {'kind': KIND, 'config': config, 'source_sha256': inventory, 'mode': args.mode,
           'created_utc': datetime.now(timezone.utc).isoformat(),
           'correction_policy': 'Existing pyomo610-grid-v1 only; no new FBBT or GLOA patches',
           'time_policy': 'Per-method worker budget; model preparation and preflight separate'}
    save(directory / 'run.json', run)
    print('RUN_DIR=' + str(directory), flush=True)
    for name in inventory:
        target = directory / 'source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / name, target)
    with locked(directory):
        try:
            run['runtime'], templates = preflight(config, directory / 'preflight')
            run['preflight_status'] = 'passed'
            save(directory / 'run.json', run)
            print('PREFLIGHT=passed', flush=True)
            if args.mode == 'run':
                execute(directory, run, templates)
        except BaseException as error:
            run['error'] = f'{type(error).__name__}: {error}'
            save(directory / 'run.json', run)
            raise
        finally:
            summary = pack(directory)
    return int(any(r.get('status') in {'error', 'worker_error', 'subproblem_incomplete'} for r in summary['results']))


if __name__ == '__main__':
    raise SystemExit(main())
