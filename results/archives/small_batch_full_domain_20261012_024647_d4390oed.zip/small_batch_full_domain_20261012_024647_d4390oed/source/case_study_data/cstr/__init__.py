"""CSTR completed enumeration data."""
