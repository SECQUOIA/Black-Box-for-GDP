"""Accounting tests independent of measured runs."""

import math
import unittest
from process_dsda_fairness_analysis import join_costs, outcome_summary


class CostTests(unittest.TestCase):
    def test_exact_size_repeats_and_missing_costs(self):
        spec = {
            "case_name": "cstr",
            "grid_size": 10,
            "max_evaluations": 15,
            "seed": 0,
            "job_id": "sample",
        }
        events = [{"point": [1, 2], "objective_wall_s": 0.1}] * 2
        costs = {
            ("cstr", "10", (1, 2)): {
                "point_evaluation_s": 2.0,
                "point_outcome": "preprocessing_infeasible",
                "point_source": "x",
                "point_source_sha256": "hash",
            }
        }
        row, ledger, missing = join_costs(spec, events, costs, 1.0, 0.0)
        self.assertEqual(row["estimated_total_s"], 4.8)
        self.assertEqual(row["unaccepted_nlp_s"], 4.0)
        self.assertEqual(len(ledger), 2)
        self.assertEqual(missing, [])
        spec["grid_size"] = 5
        row, _, missing = join_costs(spec, events, costs, 1.0, 0.0)
        self.assertIsNone(row["estimated_total_s"])
        self.assertIsNone(row["accepted_nlp_s"])
        self.assertEqual(len(missing), 2)

    def test_incomplete_group_has_no_subset_median(self):
        template = {
            "case": "column",
            "cstr_size": "",
            "budget": 16,
            "method": "dsda",
            "lookup_target_hit": True,
            "search_overhead_s": 1.0,
            "accepted_nlp_s": 1.0,
            "unaccepted_nlp_s": 0.0,
            "dynamic_preparation_s": 0.0,
        }
        rows = [
            dict(template, estimated_total_s=2.0),
            dict(template, estimated_total_s=None),
        ]
        s = outcome_summary(rows)[0]
        self.assertEqual(s["target_hits"], 2)
        self.assertEqual(s["timed_runs"], 1)
        self.assertIsNone(s["median_completion_s"])
        self.assertIsNone(s["tts99_s"])
        self.assertIsNone(s["accepted_nlp_pct"])

    def test_all_failures_stay_in_denominator_and_time_median(self):
        rows = [
            {
                "case": "dynamic",
                "cstr_size": "",
                "budget": 12,
                "method": "dsda",
                "lookup_target_hit": False,
                "estimated_total_s": t,
                "search_overhead_s": t - 1.0,
                "accepted_nlp_s": 0.0,
                "unaccepted_nlp_s": 0.5,
                "dynamic_preparation_s": 0.5,
            }
            for t in (2.0, 4.0)
        ]
        s = outcome_summary(rows)[0]
        self.assertEqual(s["runs"], 2)
        self.assertEqual(s["median_completion_s"], 3.0)
        self.assertEqual(s["tts99_s"], math.inf)
        self.assertAlmostEqual(sum(s[k] for k in s if k.endswith("_pct")), 100.0)


if __name__ == "__main__":
    unittest.main()
