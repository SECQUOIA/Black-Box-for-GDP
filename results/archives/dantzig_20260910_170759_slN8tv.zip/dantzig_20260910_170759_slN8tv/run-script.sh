#!/usr/bin/env bash
set -Eeuo pipefail

# Save this file at the root of the cloned repository.
# Usage: bash run_dantzig.sh setup
#        BAM_LICENSE_FILE=/absolute/path/bamlice.txt bash run_dantzig.sh run
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ENV_DIR="$ROOT/.venv-dantzig"
MODE="${1:-run}"
fail() { echo "ERROR: $*" >&2; exit 1; }
case "$MODE" in
  setup|run) ;;
  *) fail "Usage: bash run_dantzig.sh {setup|run}" ;;
esac
[[ "$(uname -s)" == Linux ]] || fail "Run this script on the Linux server."
[[ -f "$ROOT/case_study_benchmark.py" ]] || fail "Save this script in the repository root."

# Set thread limits before importing any numerical library.
export OMP_NUM_THREADS=1 OMP_THREAD_LIMIT=1 OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1 BLIS_NUM_THREADS=1 GOTO_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 NUMEXPR_MAX_THREADS=1
export OMP_DYNAMIC=FALSE MKL_DYNAMIC=FALSE MPLBACKEND=Agg
export PYTHONUNBUFFERED=1 PYTHONNOUSERSITE=1

CONDA_CMD="${CONDA_EXE:-}"
if [[ ! -x "$CONDA_CMD" ]]; then
  CONDA_CMD="$(command -v conda || true)"
fi
if [[ ! -x "$CONDA_CMD" ]]; then
  CONDA_CMD="$ROOT/.venv-miniforge/bin/conda"
fi
if [[ ! -x "$CONDA_CMD" ]]; then
  [[ "$MODE" == setup ]] || fail "First run: bash run_dantzig.sh setup"
  command -v curl >/dev/null || fail "curl is required to download Miniforge."
  command -v sha256sum >/dev/null || fail "sha256sum is required."
  INSTALL_DIR="$(mktemp -d)"
  INSTALLER="Miniforge3-Linux-$(uname -m).sh"
  URL="https://github.com/conda-forge/miniforge/releases/latest/download/$INSTALLER"
  (
    cd "$INSTALL_DIR"
    curl -fL --retry 3 "$URL" -o "$INSTALLER"
    curl -fL --retry 3 "$URL.sha256" -o "$INSTALLER.sha256"
    sha256sum -c "$INSTALLER.sha256"
    bash "$INSTALLER" -b -p "$ROOT/.venv-miniforge"
  )
fi

if [[ "$MODE" == setup && ! -d "$ENV_DIR/conda-meta" ]]; then
  "$CONDA_CMD" create -y -p "$ENV_DIR" --override-channels -c conda-forge \
    python=3.11 pip coin-or-bonmin ipopt
fi
[[ -x "$ENV_DIR/bin/python" ]] || fail "First run: bash run_dantzig.sh setup"
CONDA_BASE="$("$CONDA_CMD" info --base)"
set +u
source "$CONDA_BASE/etc/profile.d/conda.sh"
conda activate "$ENV_DIR"
set -u

if [[ "$MODE" == setup ]]; then
  python -m pip install -e "$ROOT[bam]"
  python -m pip check
  echo "Setup complete. Set BAM_LICENSE_FILE, then run: bash run_dantzig.sh run"
  exit 0
fi

export COIN_BIN="$ENV_DIR/bin"
[[ -x "$COIN_BIN/bonmin" && -x "$COIN_BIN/ipopt" ]] || fail "BONMIN/IPOPT missing."
[[ -n "${BAM_LICENSE_FILE:-}" && -r "$BAM_LICENSE_FILE" && -f "$BAM_LICENSE_FILE" ]] ||
  fail "Set BAM_LICENSE_FILE to a readable license file; small_batch is 3D."
export BAM_LICENSE_FILE="$(python -c 'import os; print(os.path.abspath(os.environ["BAM_LICENSE_FILE"]))')"

# All Python runs and their solver children share one allowed logical CPU.
# BENCH_CPU can select another CPU from this process's permitted CPU set.
export BENCH_CPU="${BENCH_CPU:-$(python -c 'import os; print(min(os.sched_getaffinity(0)))')}"
py() {
  python -c 'import os, sys
cpu = int(os.environ["BENCH_CPU"])
if cpu not in os.sched_getaffinity(0):
    raise SystemExit("BENCH_CPU is outside the permitted CPU set")
os.sched_setaffinity(0, {cpu})
os.execv(sys.executable, [sys.executable, "-u", *sys.argv[1:]])' "$@"
}

# Keep supervision outside native solver output redirection and signal handlers.
# Benchmark modules are called unchanged, with their existing --verbose option.
run_stage() {
  local stage_label="$1"
  shift
  py - "$RUN_DIR/run.log" "$stage_label" "$@" <<'SUPERVISOR'
import math
import os
import selectors
import signal
import subprocess
import sys
import time

log_path, label, *arguments = sys.argv[1:]
heartbeat = float(os.environ.get("DANTZIG_HEARTBEAT_SECONDS", "30"))
if not math.isfinite(heartbeat) or heartbeat <= 0:
    raise SystemExit("DANTZIG_HEARTBEAT_SECONDS must be a positive number")

with open(log_path, "ab", buffering=0) as logfile:
    def emit(data):
        logfile.write(data)
        try:
            sys.stdout.buffer.write(data)
            sys.stdout.buffer.flush()
        except OSError:
            pass

    def message(text):
        emit(("\n" + time.strftime("%Y-%m-%d %H:%M:%S") + " " + text + "\n").encode())

    def interrupted(*_):
        raise KeyboardInterrupt

    message(f"[START] {label}")
    child = subprocess.Popen(
        [sys.executable, "-u", *arguments], stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True,
    )
    started = last_output = last_heartbeat = time.monotonic()
    selector = selectors.DefaultSelector()
    selector.register(child.stdout, selectors.EVENT_READ)
    old_term = signal.signal(signal.SIGTERM, interrupted)
    exit_code = 1
    try:
        while True:
            events = selector.select(timeout=0.2)
            for key, _ in events:
                data = os.read(key.fd, 65536)
                if data:
                    emit(data)
                    last_output = time.monotonic()
                else:
                    selector.unregister(key.fileobj)
            if child.poll() is not None and not events:
                break
            now = time.monotonic()
            if child.poll() is None and now - last_heartbeat >= heartbeat:
                message(f"[HEARTBEAT] {label}: process alive; elapsed={now-started:.0f}s; "
                        f"last solver output={now-last_output:.0f}s ago; pid={child.pid}")
                last_heartbeat = now
        result = child.wait()
        exit_code = result if result >= 0 else 128 - result
        message(f"[EXIT] {label}: status={exit_code}; elapsed={time.monotonic()-started:.0f}s")
    except KeyboardInterrupt:
        message(f"[STOP] {label}: terminating this benchmark and its solver children")
        exit_code = 130
    finally:
        # Terminate only this stage's isolated process group.
        for sig in (signal.SIGTERM, signal.SIGKILL):
            try:
                os.killpg(child.pid, sig)
            except ProcessLookupError:
                break
            if sig == signal.SIGTERM:
                time.sleep(0.5)
        child.wait()
        child.stdout.close()
        selector.close()
        signal.signal(signal.SIGTERM, old_term)
    sys.exit(exit_code)
SUPERVISOR
}

mkdir -p "$ROOT/results"
RUN_DIR="$(mktemp -d "$ROOT/results/dantzig_$(date +%Y%m%d_%H%M%S)_XXXXXX")"
mkdir -p "$RUN_DIR/work"
export MPLCONFIGDIR="$RUN_DIR/matplotlib-cache"
log() { printf '%s\n' "$*"; printf '%s\n' "$*" >> "$RUN_DIR/run.log"; }
trap 'log "Stopped at line $LINENO. Results/log: $RUN_DIR"' ERR
log "Results: $RUN_DIR"
log "CPU: $BENCH_CPU; numerical-library threads: 1; methods run sequentially."
log "Verbose solver output and a heartbeat every ${DANTZIG_HEARTBEAT_SECONDS:-30}s are enabled."
git -C "$ROOT" rev-parse HEAD > "$RUN_DIR/git-commit.txt"
git -C "$ROOT" status --short > "$RUN_DIR/git-status.txt"
python -m pip freeze > "$RUN_DIR/python-packages.txt"
uname -a > "$RUN_DIR/platform.txt"
cp "$ROOT/$(basename -- "${BASH_SOURCE[0]}")" "$RUN_DIR/run-script.sh"
cd "$RUN_DIR/work"

log "Checking dependencies, solvers, and a tiny 3D BAM solve..."
PREFLIGHT_CODE="$(cat <<'PY'
import os
import numpy as np
import bam
import rbfopt
from pyomo.environ import SolverFactory

if rbfopt.RbfoptSettings().num_cpus != 1:
    raise SystemExit("Unexpected RBFOpt default: num_cpus must be 1")
for name in ("bonmin", "ipopt"):
    solver = SolverFactory(name, executable=os.path.join(os.environ["COIN_BIN"], name))
    if not solver.available(exception_flag=False):
        raise SystemExit(f"Solver unavailable: {name}")
bam.set_license_file(os.environ["BAM_LICENSE_FILE"])
result = bam.minimize(
    lambda x: float(np.sum((np.asarray(x) - 1.0) ** 2)),
    x0=None, bounds=[(0.0, 2.0)] * 3, integrality=[1, 1, 1],
    options={"max_evals": 5, "print_to_screen": 0},
)
if result.nfev < 1 or not np.isfinite(result.fun):
    raise SystemExit("3D BAM check failed; verify the license and installation")
print("Preflight passed.")
PY
)"
run_stage "Preflight" -c "$PREFLIGHT_CODE"

log "[1/4] All packaged 31 x 31 grids: DSDA, RBFOpt, BAM"
run_stage "[1/4] grids" "$ROOT/benchmark.py" \
  --methods dsda,rbfopt,bam --seeds 0-9 --n-starts 3 \
  --max-evals 10,30,50,70,100 --solver-dir "$COIN_BIN" \
  --grids-dir "$ROOT/benchmark_grids" --output "$RUN_DIR/benchmark.csv" --verbose

log "[2/4] All process cases: DSDA, RBFOpt, BAM"
run_stage "[2/4] process cases" "$ROOT/case_study_benchmark.py" \
  --cases column,cstr,small_batch,dynamic --methods dsda,rbfopt,bam \
  --seeds 0-9 --column-seeds 1-9 --n-starts 3 \
  --column-budgets 16 --cstr-grid-sizes 5,10,15,20,25,30 \
  --small-batch-budgets 10 --dynamic-budgets 12,15,20,30,37,50 \
  --solver-dir "$COIN_BIN" --max-run-seconds 1800 \
  --output "$RUN_DIR/process_case_studies.csv" --verbose

log "[3/4] Grid comparison figures and statistics"
run_stage "[3/4] grid analysis" "$ROOT/benchmark_analysis.py" \
  --results-csv "$RUN_DIR/benchmark.csv" \
  --grids-dir "$ROOT/benchmark_grids" --figure-dir "$RUN_DIR/grid_analysis"

log "[4/4] Process-case comparison figures and statistics"
run_stage "[4/4] case analysis" "$ROOT/case_study_analysis.py" \
  --results-csv "$RUN_DIR/process_case_studies.csv" \
  --output-dir "$RUN_DIR/case_analysis"
log "Finished. Results, figures, environment record, and log: $RUN_DIR"

