"""Report the initialization effect without altering reference targets or manuscripts."""
import argparse
from collections import Counter
from pathlib import Path
import statistics

from common import METHODS, csvwrite, events, measure, read, require, rows, sha, table, validate_plan, validate_points, write


def delta(new, old):
    return float(new)-float(old) if new is not None and new != '' and old is not None and old != '' else None


def analyze(directory):
    root = directory / 'reproduction'
    plan = read(root / 'plan.json')
    validate_plan(plan)
    expected = read(root / 'expected_environment.json')
    old = table(root / 'baseline/cost_table_cstr_30.csv')
    records = [read(p) for p in sorted((directory / 'points').glob('*/first_attempt.json'))]
    validate_points(records)
    new = {tuple(r['point']): r for r in records}
    csvrows = [{**r, 'record_sha256': sha(directory / 'points' / f'{r["point"][0]:02d}_{r["point"][1]:02d}' / 'first_attempt.json')}
               for r in records]
    csvwrite(directory / 'evaluations.csv', csvrows)
    costs = table(directory / 'evaluations.csv')
    comparisons = []
    for point in sorted(new):
        a, b = old[point], new[point]
        row = dict(point=list(point), logical_allowed=point[1] <= point[0],
            old_accepted=a['accepted'] == 'True', new_accepted=b['accepted'],
            acceptance_change=int(b['accepted'])-int(a['accepted'] == 'True'),
            old_status=a['status'], new_status=b['status'], old_termination=a['termination'], new_termination=b['termination'],
            new_failure_type=b.get('rejection_phase') or b.get('status'),
            old_failure_type=a.get('rejection_phase') or a.get('status'),
            new_record_sha256=costs[point]['record_sha256'])
        for field in ('objective', 'candidate_objective', 'max_primal_violation',
                      'max_constraint_violation', 'max_bound_violation', 'total_wall_s', 'solve_wall_s'):
            row.update({f'old_{field}': a.get(field), f'new_{field}': b.get(field),
                        f'delta_{field}': delta(b.get(field), a.get(field))})
        comparisons.append(row)
    csvwrite(directory / 'coordinate_comparison.csv', comparisons)
    old_runs = rows(root / 'baseline/runs.csv')
    index = {(r['method'], int(r['budget']), int(r['seed'])): r for r in old_runs if r['case'] == 'cstr_30'}
    paired, callbacks = [], []
    require(len(list((directory / 'searches').glob('*/effective_result.json'))) == 50, 'Expected all 50 attempts, including failures')
    for job in plan:
        spec = job['spec']
        dest = directory / 'searches' / spec['job_id']
        result = read(dest / 'effective_result.json')
        if result.get('evaluation_table_sha256'):
            require(result['evaluation_table_sha256'] == sha(directory / 'evaluations.csv'),
                    'Search did not use the exported new evaluation table')
        metric, ledger = measure(spec, events(dest / 'callbacks.jsonl'), result, costs, job['target'])
        require(result.get('process_nlp_calls', 0) == 0, 'Process NLP called during search')
        previous = index[spec['method'], spec['budget'], spec['seed']]
        pair = {k: spec[k] for k in ('case', 'method', 'budget', 'seed', 'job_id')}
        pair.update({'old_' + k: v for k, v in previous.items() if k not in pair})
        pair.update({'new_' + k: v for k, v in metric.items()})
        old_hit, new_hit = previous['target_hit'] == 'True', metric['target_hit']
        pair.update(both_success=old_hit and new_hit, new_only_success=new_hit and not old_hit,
                    old_only_success=old_hit and not new_hit, neither_success=not old_hit and not new_hit)
        paired.append(pair)
        callbacks.extend(dict(job_id=spec['job_id'], method=spec['method'], seed=spec['seed'], **e) for e in ledger)
    csvwrite(directory / 'paired_runs.csv', paired)
    csvwrite(directory / 'callbacks.csv', callbacks)
    csvwrite(directory / 'rbfopt_coordinates.csv', [r for r in callbacks if r['method'] == 'rbfopt'])
    groups, aggregates = [], []
    for method in METHODS:
        rr = [r for r in paired if r['method'] == method]
        require(len(rr) == 10 and {r['seed'] for r in rr} == set(range(10)), 'Pairing incomplete')
        g = dict(method=method, runs=len(rr), old_hits=sum(r['old_target_hit'] == 'True' for r in rr),
                 new_hits=sum(r['new_target_hit'] for r in rr))
        g.update(old_rate=g['old_hits']/len(rr), new_rate=g['new_hits']/len(rr),
            **{key: sum(r[key] for r in rr) for key in ('both_success', 'new_only_success', 'old_only_success', 'neither_success')},
            new_execution_failures=sum(r['new_category'] == 'execution_failed' for r in rr),
            new_any_hit=sum(r['new_any_target_hit'] for r in rr),
            new_better_than_reference_final_misses=sum(r['new_better_than_reference_but_final_miss'] for r in rr))
        groups.append(g)
        retained = [r for r in old_runs if r['method'] == method and r['case'] != 'cstr_30']
        allold = [r for r in old_runs if r['method'] == method]
        require(len(retained) == 50 and len(allold) == 60, 'Other five CSTR sizes incomplete')
        aggregates.append(dict(method=method, runs=len(allold),
            old_hits=sum(r['target_hit'] == 'True' for r in allold),
            new_hits=sum(r['target_hit'] == 'True' for r in retained) + g['new_hits'],
            retained_other_size_runs=len(retained)))
    csvwrite(directory / 'method_summary.csv', groups)
    csvwrite(directory / 'all_cstr_summary.csv', aggregates)
    preserved = [r for r in old_runs if r['case'] != 'cstr_30']
    csvwrite(directory / 'retained_other_cstr_runs.csv', preserved)
    reference = new[tuple(expected['reference_point'])]
    best = min((r for r in records if r['accepted']), key=lambda r: r['objective'], default=None)
    totalcost = sum(r['total_wall_s'] for r in records)
    unknown_old = [p for p, r in old.items() if not r.get('total_wall_s')]
    summary = dict(status='complete', actual_coordinate_nlp_calls=sum(r['nlp_calls'] for r in records),
        logged_ipopt_coordinate_invocations=sum(r.get('ipopt_invocations_in_solver_log', 0) for r in records),
        preflight_nlp_calls=len(list(directory.glob('preflight*/nlp/smoke_call_started.json'))),
        search_process_nlp_calls=0, coordinates=len(records), logical_coordinates=465, structural_coordinates=435,
        old_accepted=sum(r['accepted'] == 'True' for r in old.values()), new_accepted=sum(r['accepted'] for r in records),
        newly_accepted=sum(r['acceptance_change'] == 1 for r in comparisons),
        newly_rejected=sum(r['acceptance_change'] == -1 for r in comparisons),
        new_status_counts=dict(Counter(r['status'] for r in records)),
        reference_point=expected['reference_point'], old_reference_objective=expected['reference_objective'],
        new_reference_objective=reference.get('objective'), reference_accepted=reference['accepted'],
        reference_objective_change=delta(reference.get('objective'), expected['reference_objective']),
        fixed_target=expected['reference_objective'], target_rule='final_best_absolute',
        new_table_minimum=best['objective'] if best else None, new_table_best_point=best['point'] if best else None,
        new_minimum_minus_fixed_reference=delta(best['objective'] if best else None, expected['reference_objective']),
        old_point_cost_sum_s=sum(float(r['total_wall_s']) for r in old.values()) if not unknown_old else None,
        new_point_cost_sum_s=totalcost, old_point_cost_median_s=statistics.median(float(r['total_wall_s']) for r in old.values()),
        new_point_cost_median_s=statistics.median(r['total_wall_s'] for r in records),
        measured_search_sum_s=sum(r['new_search_s'] or 0 for r in paired),
        estimated_search_completion_sum_s=sum(r['new_completion_s'] or 0 for r in paired),
        actual_search_attempts=len(paired), groups=groups, all_cstr=aggregates,
        overall_cstr=dict(old_hits=sum(r['old_hits'] for r in aggregates),
            new_hits=sum(r['new_hits'] for r in aggregates), runs=sum(r['runs'] for r in aggregates)),
        manuscript_original_hits=sum(r['category'] == 'target_reached'
            for r in rows(root / 'baseline/manuscript_runs.csv')),
        missing_old_separate_constraint_bound_residuals=True,
        retained_other_sizes_sha256=sha(directory / 'retained_other_cstr_runs.csv'))
    write(directory / 'summary.json', summary)
    failures = [r for r in paired if not r['new_shared_starts_complete'] or r['new_protocol_error']]
    write(directory / 'validation.json', dict(unique_900_coordinates=True, full_50_search_slots=True,
        exact_shared_starts_in_plan=True, observed_shared_starts_complete=not failures,
        incomplete_or_invalid_search_jobs=[r['job_id'] for r in failures],
        failed_attempts_retained=True, fixed_reference_and_tolerance=True,
        baseline_other_sizes_retained=len(preserved), retry_count=0,
        note='An early failed search can have fewer than three callbacks; it stays in the denominator and is reported here'))
    lines = ['CSTR30 initialization follow-up', '',
        'This experiment changes only the initialization used for CSTR30.',
        'The primary comparison retains the manuscript final-best absolute target rule and the original reference.',
        'The finite-penalty D-SDA and genetic RBFOpt records replace their older manuscript search records in the explicitly identified baseline.',
        'Any-hit results are reported separately because the historical finite-penalty report used that definition.',
        f"Actual coordinate NLP calls: {summary['actual_coordinate_nlp_calls']}; separate preflight NLP calls: {summary['preflight_nlp_calls']}; process NLP calls during lookup search: 0.",
        f"Accepted coordinates: {summary['old_accepted']} -> {summary['new_accepted']} out of 900.",
        f"Reference coordinate {summary['reference_point']}: {summary['old_reference_objective']} -> {summary['new_reference_objective']}.",
        f"The new table minimum is {summary['new_table_minimum']} at {summary['new_table_best_point']}.",
        f"The difference from the fixed reference is {summary['new_minimum_minus_fixed_reference']}.", '',
        'Method | Old hits | New hits | Both | New only | Old only | Neither | New any-hit',
        '--- | --- | --- | --- | --- | --- | --- | ---']
    lines += [f"{g['method']} | {g['old_hits']}/10 | {g['new_hits']}/10 | {g['both_success']} | {g['new_only_success']} | {g['old_only_success']} | {g['neither_success']} | {g['new_any_hit']}/10" for g in groups]
    lines += ['', 'All six CSTR sizes retain every old record for N=5, 10, 15, 20 and 25.']
    lines += [f"{g['method']}: {g['old_hits']}/{g['runs']} -> {g['new_hits']}/{g['runs']}." for g in aggregates]
    lines += ['', f"The new measured point-evaluation cost sums to {totalcost:.6f} seconds.",
        f"Measured search time sums to {summary['measured_search_sum_s']:.6f} seconds.",
        'Completion estimates subtract lookup time from measured search time and add the new per-callback evaluation costs, including repeats.',
        'Timing also includes recorded initialization and artifact-retention overhead and is not a pure solver-time comparison.',
        'Baseline residual records contain only the combined maximum, so separate old constraint and bound residuals remain unavailable.',
        'Better-than-reference objectives that miss the absolute target rule are explicitly flagged in paired_runs.csv.',
        'No raw baseline record, historical manifest, manuscript, Overleaf file or figure was modified.',
        'Whether to adopt this experiment as a representative manuscript result remains a later decision.']
    (directory / 'README.txt').write_text('\n'.join(lines) + '\n')
    return summary


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('directory', type=Path)
    analyze(p.parse_args().directory.resolve())
