CSTR30 initialization follow-up

This bundle is prepared for Dantzig and contains no new experimental NLP or search results.
The existing user workspace, raw archives, manuscript, Overleaf sources and figures are preserved.
The baseline uses the manuscript BAM v2, FMQA-SA and uniform records, with the explicitly requested 20261022 finite-1e6 D-SDA and genetic RBFOpt records.
The manuscript manifest predates that finite-penalty comparison and is retained separately without modification.
The CSTR30 NLP baseline is the original 465-coordinate constructor-default table, including its seven rejected points.
Later seven-point retry results are deliberately absent from that baseline.
The selected-input provenance explicitly documents the original-attempt selection.
The records show how the initialization differs but do not document why N=30 was omitted from the later full-box CSTR5–25 runs.

The archived CSTR5–25 initializer is reused with only its supported-size guard extended to N=30.
It computes mass-balance concentrations for the chosen reactor count and iterates over the actual N=30 model indices.
No smaller-model value arrays or previous solutions are copied.
The sequence remains constructor defaults, configuration fixing, original constraint snapshot, original preprocessing, then mass_balance_zero_recycle initialization.
Each point runs in a new process and builds a new model.
Objective, constraint and variable-bound fingerprints are compared immediately before and after initialization.
All 900 coordinates pass through the original model preparation, including the 435 structural rejections that must make no NLP call.
The first attempt at every point is retained, including failure, timeout or interruption.
Resume never retries a launched point or search.
An interrupted point with unknown timing blocks a complete comparison instead of receiving an invented cost.

GAMS 52.2.0, IPOPT 3.14.19 and MUMPS 5.8.1 are required.
The original GAMS binary hash, Python and dependency versions, model source hashes, IPOPT options and thread settings are checked before coordinate evaluation.
The GAMS solve limit is 60 seconds and the iteration limit is 3000.
IPOPT uses tol=1e-8, bound_relax_factor=0, warm_start_init_point=no and linear_solver=mumps.
The 180-second worker watchdog follows the archived CSTR5–25 runner.
Acceptance retains the original status rules and the absolute maximum primal-violation threshold of 1e-5.
The current OS kernel and CPU topology are recorded separately from solver identity.
A single quadratic NLP preflight checks actual IPOPT and MUMPS versions and is counted separately from the CSTR30 experiment.
No environment is installed or upgraded, and an unavailable historical environment blocks execution without a local solver fallback.

Exactly 50 new search attempts are planned: five methods, budget 43, seeds 0 through 9.
All initial triples and their order come from archived callbacks.
The archived optimizer implementations, settings, seeds, stops and failure-response policies are retained.
D-SDA and RBFOpt receive 1e6 for unaccepted responses, while BAM, FMQA-SA and uniform retain their own historical handling.
RBFOpt uses the MSRSM, auto-RBF and genetic candidate-search settings from the finite-penalty comparison.
Search workers can only query the new evaluation table and block process-model imports.
RBFOpt may invoke its historical auxiliary Bonmin/IPOPT surrogate solvers, which are not CSTR NLP evaluations.
Their calls remain logged separately.
No other CSTR size is rerun.

The primary target test is abs(best-reference) <= 1e-5*max(1,abs(reference)), with the original reference fixed.
The historical finite-penalty controller used any-hit, and the builder verifies that both definitions agree on every selected baseline run.
Any-hit and better-than-reference outcomes are exported separately for the new experiment.
A better objective can therefore be a primary absolute-target miss, and that case is explicitly flagged.
Neither the reference nor the acceptance tolerance is recomputed from the new minimum.
All failed searches remain in their original ten-run denominators.
Completion cost equals measured search time minus lookup time plus the new measured point costs for every charged callback, including repeats.
Evaluation timing includes initialization and durable GAMS-artifact overhead, as in the small-CSTR runner.
The original CSTR30 run used different process/artifact recording, so this is not a pure solver-time comparison.
Separate baseline constraint and bound residuals were not recorded and remain unavailable rather than reconstructed from another run.
Other-size records are retained exactly when calculating the six-size CSTR aggregate.
The old and new success counts are calculated from records rather than hardcoded.

Run from the extracted bundle on Dantzig:
  sha256sum -c SHA256SUMS > verify.log
  bash run_dantzig.sh dry-run
  nohup bash run_dantzig.sh run --cpu 10 > launch.log 2>&1 < /dev/null &
  echo $! > launcher.pid
  tail -f launch.log

CPU 10 is checked against physical cores used by the previous Grid and Process launch commands on CPUs 6 and 8.
Affinity is not an exclusive reservation.
START and DONE lines identify every coordinate and search, and every worker has its own run.log.
RUN_DIR is printed immediately, while RESULT_ZIP is printed on completion or on a caught blocker.
The latest paths are also written under results/cstr30_initialization/latest_run.txt and result_zip.txt.
On a preflight failure, inspect the named log and return the blocked archive without changing solver versions or substituting a solver.

After the controller has stopped, resume or package its original directory:
  bash run_dantzig.sh resume --run-dir /absolute/RUN_DIR
  bash run_dantzig.sh pack --run-dir /absolute/RUN_DIR

Completed output includes evaluations.csv, raw point logs and values, coordinate_comparison.csv, paired_runs.csv, callbacks.csv and rbfopt_coordinates.csv.
It also includes method_summary.csv, all_cstr_summary.csv, retained_other_cstr_runs.csv, summary.json, README.txt, validation.json, manifest.json and SHA256SUMS.
The manifest records execution source revision, exact source and input hashes, actual environment and output hashes.
The entire sealed reproduction bundle is copied into each result directory.
Whether to adopt the new results as representative manuscript results is left for a later review.

Local preparation verification does not invoke any solver:
  python3 build.py --output /new/empty/package/path
  RBFOPT_GDP_SOURCES=/path/to/repository/external python /new/empty/package/path/nlp.py validate --directory /new/validation/path
  RBFOPT_GDP_SOURCES=/path/to/repository/external python /new/empty/package/path/test_protocol.py
The build command is run from this source directory in the repository, while the other commands use the generated package.
