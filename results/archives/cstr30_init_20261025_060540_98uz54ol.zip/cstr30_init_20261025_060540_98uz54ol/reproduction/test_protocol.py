"""Solver-free protocol tests; synthetic fixtures are never experimental results."""
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

from common import events, measure, read, rows, table, validate_plan, write

ROOT = Path(__file__).resolve().parent


class ProtocolTests(unittest.TestCase):
    def test_exact_slots_and_initial_order(self):
        plan = read(ROOT / 'plan.json')
        validate_plan(plan)
        for job in plan:
            recorded = events(ROOT / job['baseline_directory'] / 'callbacks.jsonl')
            self.assertEqual([e['point'] for e in recorded[:3]], job['spec']['starts'])
        plan[0]['spec']['starts'] = list(reversed(plan[0]['spec']['starts']))
        with self.assertRaises(ValueError):
            validate_plan(plan)

    def test_uniform_stream_is_exact_archived_stream(self):
        sys.path.insert(0, str(ROOT / 'frozen/sampling'))
        from review_comparison.worker import sampling_points
        for job in read(ROOT / 'plan.json'):
            if job['spec']['method'] == 'uniform_without_replacement':
                points, _ = sampling_points(job['sampling_job'])
                original = events(ROOT / job['baseline_directory'] / 'callbacks.jsonl')
                self.assertEqual(points, [e['point'] for e in original])

    def test_better_minimum_does_not_silently_redefine_success(self):
        spec = dict(budget=4, starts=[[1, 1], [2, 1], [3, 1]])
        values = [2.0, 3.0, 4.0, 1.5]
        ev = [dict(index=i+1, point=[i+1, 1], raw_objective=value, accepted=True, lookup_wall_s=0.01)
              for i, value in enumerate(values)]
        costs = {(i+1, 1): dict(accepted='True', objective=str(v), total_wall_s='2') for i, v in enumerate(values)}
        result, _ = measure(spec, ev, dict(status='budget_completed', dfo_wall_s=1), costs, 2.0)
        self.assertFalse(result['target_hit'])
        self.assertTrue(result['any_target_hit'])
        self.assertTrue(result['better_than_reference_but_final_miss'])
        self.assertAlmostEqual(result['completion_s'], 8.96)
        failed, _ = measure(spec, ev, dict(status='execution_failed', dfo_wall_s=1), costs, 2.0)
        self.assertFalse(failed['target_hit'])
        self.assertEqual(failed['category'], 'execution_failed')
        costs[1, 1]['objective'] = '9'
        with self.assertRaisesRegex(ValueError, 'attempt mismatch'):
            measure(spec, ev, dict(status='completed', dfo_wall_s=1), costs, 2.0)

    def test_repeat_costs_and_terminal_observation_are_counted(self):
        spec = dict(budget=3, starts=[[1, 1], [1, 1], [2, 1]])
        ev = [dict(index=i+1, point=p, accepted=True, raw_objective=1 if i==2 else 2,
                   lookup_wall_s=0.01, value_returned_to_optimizer=i != 2) for i,p in enumerate(spec['starts'])]
        costs = {(1, 1): dict(accepted='True', objective='2', total_wall_s='4'),
                 (2, 1): dict(accepted='True', objective='1', total_wall_s='1')}
        metric, ledger = measure(spec, ev, dict(status='budget_completed', dfo_wall_s=0.5), costs, 1)
        self.assertEqual(metric['point_cost_s'], 9)
        self.assertTrue(ledger[1]['repeated_point'])
        self.assertTrue(metric['target_hit'])

    def test_structural_point_never_reaches_solver(self):
        import nlp
        from gdp_models import evaluation
        with tempfile.TemporaryDirectory() as tmp, patch.object(evaluation, 'optimizer_for', side_effect=AssertionError('NLP forbidden')):
            nlp.point_worker([1, 30], Path(tmp))
            r = read(Path(tmp) / 'record.json')
            self.assertEqual(r['status'], 'preprocessing_infeasible')
            self.assertEqual(r['nlp_calls'], 0)

    def test_fresh_models_and_initialization_does_not_change_algebra(self):
        import nlp
        from cstr_box_ipopt import formulation_fingerprint
        first = nlp.initialized_prepare('cstr', [30, 30], cstr_size=30, initialization='default')
        first.model.QR.set_value(9)
        second = nlp.initialized_prepare('cstr', [30, 30], cstr_size=30, initialization='default')
        self.assertIsNot(first.model, second.model)
        self.assertEqual(second.model.QR.value, 0)
        self.assertEqual(second.metadata['formulation_before'], formulation_fingerprint(second))
        second.model.V[1].setlb(second.model.V[1].lb + 0.125)
        self.assertNotEqual(second.metadata['formulation_before'], formulation_fingerprint(second))

    def test_identity_analysis_retains_all_other_sizes(self):
        """Replay baseline records as a synthetic identity fixture, without optimizers."""
        from analyze import analyze
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp)
            (d / 'reproduction').symlink_to(ROOT, target_is_directory=True)
            costs = table(ROOT / 'baseline/cost_table_cstr_30.csv')
            for point, old in costs.items():
                accepted = old['accepted'] == 'True'
                record = dict(point=list(point), case='cstr', cstr_size=30, attempt=1,
                    accepted=accepted, objective=float(old['objective']) if accepted else None,
                    status=old['status'], termination=old['termination'],
                    nlp_calls=int(point[1] <= point[0]), total_wall_s=float(old['total_wall_s']),
                    gams_solve_status=1 if accepted else None, gams_model_status=2 if accepted else None,
                    max_primal_violation=float(old['max_primal_violation']) if old.get('max_primal_violation') else None,
                    test_fixture=True)
                write(d / 'points' / f'{point[0]:02d}_{point[1]:02d}' / 'first_attempt.json', record)
            for job in read(ROOT / 'plan.json'):
                src = ROOT / job['baseline_directory']
                dest = d / 'searches' / job['spec']['job_id']
                dest.mkdir(parents=True)
                shutil.copyfile(src / 'callbacks.jsonl', dest / 'callbacks.jsonl')
                shutil.copyfile(src / 'result.json', dest / 'effective_result.json')
            summary = analyze(d)
            for g in summary['groups']:
                self.assertEqual(g['new_hits'], g['old_hits'])
                self.assertEqual(g['new_only_success'] + g['old_only_success'], 0)
            for g in summary['all_cstr']:
                self.assertEqual(g['new_hits'], g['old_hits'])
                self.assertEqual(g['retained_other_size_runs'], 50)
            self.assertEqual(len(rows(d / 'coordinate_comparison.csv')), 900)
            self.assertEqual(len(rows(d / 'paired_runs.csv')), 50)
            self.assertTrue(read(d / 'validation.json')['observed_shared_starts_complete'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
