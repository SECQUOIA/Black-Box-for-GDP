"""Execute one archived optimizer against the new table, without process NLPs."""
import argparse
import importlib
import importlib.metadata
import os
from pathlib import Path
import platform
import sys
import time
import traceback

from common import THREADS, read, require, sha, table, write

ROOT = Path(__file__).resolve().parent


def runtime(job, directory, core):
    expected = job['reference_runtime']
    actual = dict(python=platform.python_version(), host=platform.node(), platform=platform.platform(),
        versions={k: importlib.metadata.version(k) for k in expected['versions']},
        executable=sys.executable, threads={k: os.environ.get(k) for k in THREADS},
        effective_cpus=sorted(os.sched_getaffinity(0)))
    write(directory / 'runtime.json', actual)
    for key in ('python', 'host', 'versions'):
        require(actual[key] == expected[key], 'Search runtime mismatch: ' + key)
    require(actual['threads'] == THREADS and len(actual['effective_cpus']) == 1, 'Search threading mismatch')
    spec, config = job['spec'], job['config']
    if spec['method'] != 'uniform_without_replacement':
        checked = core.preflight(spec['method'], config)
        actual.update(checked)
    if spec['method'] == 'rbfopt':
        for name in ('bonmin', 'ipopt'):
            require(actual[name + '_sha256'] == expected[name + '_sha256'], 'Surrogate binary changed')
        modules = {name: importlib.import_module(name) for name in expected['rbfopt_sources_sha256']}
        actual['rbfopt_sources_sha256'] = {n: sha(m.__file__) for n, m in modules.items()}
        require(actual['rbfopt_sources_sha256'] == expected['rbfopt_sources_sha256'], 'RBFOpt implementation changed')
    if spec['method'] == 'fmqa_sa':
        require(actual['qhd_source'] == expected['qhd_source'], 'FMQA source changed')
    actual['historical_platform_equal'] = actual['platform'] == expected['platform']
    write(directory / 'runtime.json', actual)


def settings_check(job, directory):
    method = job['spec']['method']
    if method == 'uniform_without_replacement':
        return
    actual = read(directory / 'actual_settings.json')
    expected = job['reference_settings']
    if method == 'bam':
        # Responses must come from the new NLP attempt; all optimizer settings stay fixed.
        actual = {**actual, 'options': {k: v for k, v in actual['options'].items() if k != 'f_evaluated'}}
        expected = {**expected, 'options': {k: v for k, v in expected['options'].items() if k != 'f_evaluated'}}
    require(actual == expected, 'Actual optimizer settings differ from baseline')
    write(directory / 'settings_check.json', dict(identical=True,
        new_initial_responses_excluded_only_for_bam=method == 'bam'))


def run(job, directory, evaluation_csv, preflight=False):
    sys.path.insert(0, str(ROOT / 'frozen' / job['frozen']))
    core = importlib.import_module('ipopt_dfo_cstr')
    runtime(job, directory, core)
    if preflight:
        write(directory / 'passed.json', dict(passed=True))
        return
    sys.meta_path.insert(0, core.ProcessModelImportBlocker())
    spec = job['spec']
    oracle = core.Oracle(spec, table(evaluation_csv), directory)
    status, error, returned = 'completed', None, None
    started = time.perf_counter()
    write(directory / 'started.json', dict(pid=os.getpid(), method=spec['method'],
                                          evaluation_table_sha256=sha(evaluation_csv)))
    try:
        if spec['method'] == 'uniform_without_replacement':
            sys.path.insert(0, str(ROOT / 'frozen/sampling'))
            from review_comparison.worker import sampling_points
            points, settings = sampling_points(job['sampling_job'])
            write(directory / 'sampling_settings.json', settings)
            for point in points:
                oracle(point)
        else:
            returned = core.optimize(spec, oracle, job['config'], directory)
            if isinstance(returned, dict) and returned.get('status') == 'time_limit':
                status, error = 'execution_failed', 'FMQA soft time limit'
            if spec['method'] == 'bam' and returned.get('success') is False:
                status, error = 'execution_failed', returned.get('message')
            elif spec['method'] == 'bam' and oracle.call_count == spec['budget']:
                status = 'budget_completed'
    except core.BudgetStop:
        status = 'budget_completed'
    except Exception as exc:
        if oracle.events and oracle.events[-1]['callback_exit'] == 'budget_stop':
            status = 'budget_completed'
            returned = dict(terminal_budget_exception=f'{type(exc).__name__}: {exc}')
        else:
            status, error = 'execution_failed', f'{type(exc).__name__}: {exc}'
            traceback.print_exc()
    elapsed = time.perf_counter() - started
    if len(oracle.events) > spec['budget'] or any(e.get('budget_overrun') for e in oracle.events):
        status, error = 'execution_failed', 'Callback budget overrun'
    settings_error = None
    if (directory / 'actual_settings.json').exists():
        try:
            settings_check(job, directory)
        except Exception as exc:
            settings_error = str(exc)
            status, error = 'execution_failed', settings_error
    write(directory / 'result.json', dict(status=status, error=error,
        algorithm_result=core.clean(returned), recorded_search_wall_s=elapsed,
        settings_error=settings_error, process_nlp_calls=0,
        evaluation_table_sha256=sha(evaluation_csv)))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--job', type=Path, required=True)
    p.add_argument('--directory', type=Path, required=True)
    p.add_argument('--table', type=Path)
    p.add_argument('--preflight', action='store_true')
    a = p.parse_args()
    a.directory.mkdir(parents=True, exist_ok=True)
    run(read(a.job), a.directory, a.table, a.preflight)
