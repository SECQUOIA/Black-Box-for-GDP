"""One fresh CSTR30 model and one original GAMS/IPOPT attempt per coordinate."""
import argparse
import importlib.metadata
import math
import os
from pathlib import Path
import platform
import sys
import time
import traceback
from unittest.mock import patch

from common import THREADS, read, require, sha, write

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'frozen/nlp'))


def residuals(prepared):
    import pyomo.environ as pyo
    worst = dict(constraint=0.0, bound=0.0)
    undefined = []
    for c in prepared.constraints:
        v = pyo.value(c.body, exception=False)
        if v is None or not math.isfinite(v):
            undefined.append(c.name)
            continue
        for bound, sign in ((c.lower, -1), (c.upper, 1)):
            if bound is not None:
                b = pyo.value(bound, exception=False)
                if b is None or not math.isfinite(b):
                    undefined.append(c.name)
                else:
                    worst['constraint'] = max(worst['constraint'], sign * (v-b))
    for v in prepared.model.component_data_objects(pyo.Var, active=True, descend_into=True):
        if v.value is None:
            continue
        if not math.isfinite(v.value):
            undefined.append(v.name)
            continue
        if v.has_lb():
            worst['bound'] = max(worst['bound'], pyo.value(v.lb) - v.value)
        if v.has_ub():
            worst['bound'] = max(worst['bound'], v.value - pyo.value(v.ub))
    return dict(max_constraint_violation=worst['constraint'] if not undefined else None,
                max_bound_violation=worst['bound'] if not undefined else None,
                undefined_residual_expressions=undefined)


def initialized_prepare(case, point, **kw):
    from gdp_models.models import prepare_nlp
    from cstr_box_ipopt import initialize_feasible, formulation_fingerprint
    require(case == 'cstr' and kw.get('cstr_size') == 30, 'Only CSTR30 may be evaluated')
    prepared = prepare_nlp(case, point, **kw)
    before = formulation_fingerprint(prepared)
    initialize_feasible(prepared)
    after = formulation_fingerprint(prepared)
    require(before == after, 'Initialization changed objective, constraints or bounds')
    prepared.metadata.update(formulation_before=before, formulation_after=after)
    return prepared


def point_worker(point, directory):
    from gdp_models import evaluation
    import pyomo.environ as pyo
    expected = read(ROOT / 'expected_environment.json')
    captured = {}
    solver_calls = []
    original_solve = evaluation.solve_gams

    def prepare(*a, **kw):
        obj = initialized_prepare(*a, **kw)
        require(obj.metadata['source'] == expected['manifest']['runtime']['source'],
                'Point model sources differ from the historical model')
        captured['prepared'] = obj
        initial = {v.name: v.value for v in obj.model.component_data_objects(pyo.Var)
                   if v.value is not None and math.isfinite(v.value)}
        write(directory / 'initial_values.json', initial)
        return obj

    def solve(*a, **kw):
        require(not solver_calls, 'Second NLP call prohibited')
        solver_calls.append(dict(point=point, solver='gams_ipopt', attempt=1))
        write(directory / 'nlp_call_started.json', solver_calls[0])
        return original_solve(*a, **kw)

    started = time.perf_counter()
    try:
        with patch.object(evaluation, 'prepare_nlp', prepare), patch.object(evaluation, 'solve_gams', solve):
            result = evaluation.evaluate_point('cstr', point, cstr_size=30,
                initialization='default', solver='gams_ipopt',
                executable=expected['manifest']['runtime']['solver_executable'],
                time_limit=expected['time_limit'], feasibility_tolerance=expected['feasibility_tolerance'],
                tee=True, artifact_dir=directory / 'artifacts')
    except Exception as exc:
        traceback.print_exc()
        result = dict(accepted=False, objective=None, candidate_objective=None,
            status='worker_error', termination='error', message=f'{type(exc).__name__}: {exc}',
            total_wall_s=time.perf_counter() - started)
    result.update(case='cstr', cstr_size=30, point=point, logical_allowed=point[1] <= point[0],
        attempt=1, nlp_calls=len(solver_calls), initializer_id='mass_balance_zero_recycle_N30_v1',
        initializer_source_sha256=sha(ROOT / 'frozen/nlp/cstr_box_ipopt.py'),
        initialization_applied='prepared' in captured,
        worker_pid=os.getpid(), post_evaluation_audit_excluded_from_point_cost=True)
    if 'prepared' in captured:
        prepared = captured['prepared']
        result.update(residuals(prepared))
        result['residual_state'] = 'returned_candidate' if result.get('candidate_objective') is not None else 'last_model_state_no_loaded_candidate'
        result.update({k: prepared.metadata[k] for k in
            ('formulation_before', 'formulation_after', 'initial_primal_violation', 'initial_objective')})
        if result.get('max_primal_violation') is not None:
            require(abs(max(result['max_constraint_violation'], result['max_bound_violation'])
                        - result['max_primal_violation']) <= 1e-12, 'Residual decomposition differs')
        values = {v.name: v.value for v in prepared.model.component_data_objects(pyo.Var)
                  if v.value is not None and math.isfinite(v.value)}
        write(directory / 'final_values.json', dict(accepted=result['accepted'],
            objective=result.get('candidate_objective'), values=values, residual_state=result['residual_state']))
    else:
        result.update(max_constraint_violation=None, max_bound_violation=None,
                      residual_state='unavailable_no_prepared_nlp')
    log = directory / 'artifacts/solver.log'
    result['ipopt_invocations_in_solver_log'] = log.read_text(errors='replace').count('This is Ipopt version ') if log.exists() else 0
    if result['ipopt_invocations_in_solver_log']:
        require(expected['ipopt_version_line'] in log.read_text(errors='replace'), 'Point solver version mismatch')
    write(directory / 'record.json', result)


def environment(directory):
    from gdp_models import solvers
    from gdp_models._sources import provenance
    import pyomo.environ as pyo
    expected = read(ROOT / 'expected_environment.json')
    old = expected['manifest']['runtime']
    actual = dict(host=platform.node(), python_version=platform.python_version(), platform=platform.platform(),
        dependency_versions={k: importlib.metadata.version(k) for k in old['dependency_versions']},
        thread_environment={k: os.environ.get(k) for k in THREADS},
        solver_executable=old['solver_executable'],
        solver_executable_sha256=sha(old['solver_executable']),
        effective_cpus=sorted(os.sched_getaffinity(0)), python_executable=sys.executable,
        solver_options=solvers.solve_options('gams_ipopt', expected['time_limit']),
        solver_option_file=solvers.option_file_lines('gams_ipopt'))
    write(directory / 'actual_environment.json', actual)
    for key in ('host', 'python_version', 'dependency_versions', 'solver_executable_sha256'):
        require(actual[key] == old[key], f'NLP environment mismatch: {key}: {actual[key]} != {old[key]}')
    require(actual['thread_environment'] == THREADS and len(actual['effective_cpus']) == 1, 'Single-thread environment changed')
    require(actual['solver_options'] == expected['solver_options']
            and actual['solver_option_file'] == expected['solver_option_file'], 'Solver options changed')
    source = provenance('dsda-gdp', list(old['source']['files_sha256']))
    require(source == old['source'], 'Upstream model sources changed')
    actual['source'] = source
    optimizer = solvers.optimizer_for('gams_ipopt', old['solver_executable'])
    actual['solver_version'] = list(optimizer.version())
    require(actual['solver_version'] == old['solver_version'], 'GAMS version changed')
    # One separately counted, non-CSTR quadratic availability/version check.
    m = pyo.ConcreteModel()
    m.x = pyo.Var(bounds=(0, 3), initialize=0.5)
    m.obj = pyo.Objective(expr=(m.x-1)**2)
    write(directory / 'smoke_call_started.json', dict(model='quadratic', cstr_calls=0, nlp_calls=1))
    result, stats = solvers.solve_gams(optimizer, m, 'gams_ipopt', expected['time_limit'],
                                     tee=True, artifact_dir=directory / 'solver')
    require(stats['SOLVESTAT'] == 1 and stats['MODELSTAT'] in (1, 2), 'NLP preflight failed')
    m.solutions.load_from(result)
    require(abs(m.x.value-1) <= 1e-4, 'NLP preflight solution incorrect')
    actual_log = (directory / 'solver/solver.log').read_text(errors='replace')
    require(expected['ipopt_version_line'] in actual_log, 'IPOPT or linear solver version mismatch')
    actual.update(ipopt_version_line=expected['ipopt_version_line'], smoke_nlp_calls=1,
        platform_equal=actual['platform'] == old['platform'],
        platform_note='Kernel version is recorded separately from the solver/runtime identity checks')
    write(directory / 'actual_environment.json', actual)
    write(directory / 'passed.json', dict(passed=True, actual_environment_sha256=sha(directory / 'actual_environment.json')))


def validate_no_solver(directory):
    """Exercise all 900 original preprocessing paths without invoking any solver."""
    from cstr_box_ipopt import formulation_fingerprint
    from pyomo.common.errors import InfeasibleConstraintException
    records = []
    for x in range(1, 31):
        for y in range(1, 31):
            try:
                prepared = initialized_prepare('cstr', [x, y], cstr_size=30, initialization='default')
            except InfeasibleConstraintException:
                require(y > x, 'Unexpected logical rejection')
                records.append(dict(point=[x, y], logical_allowed=False, solver_called=False))
                continue
            require(y <= x, 'Disallowed coordinate reached prepared NLP')
            require(prepared.metadata['formulation_before'] == formulation_fingerprint(prepared), 'Model altered')
            r = residuals(prepared)
            require(not r['undefined_residual_expressions'] and max(r['max_constraint_violation'], r['max_bound_violation']) <= 1e-8,
                    'Initial feasibility check failed')
            records.append(dict(point=[x, y], logical_allowed=True, solver_called=False,
                initial_objective=prepared.metadata['initial_objective'],
                fingerprint=prepared.metadata['formulation_before'], **r))
        print(f'VALIDATED row {x}/30', flush=True)
    require(len(records) == 900 and sum(r['logical_allowed'] for r in records) == 465, 'Coordinate audit failed')
    write(directory / 'model_validation.json', dict(coordinates=records, actual_nlp_calls=0,
        model_algebra_and_bounds_unchanged=True, allowed=465, structural=435,
        fresh_model_per_coordinate=True))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('mode', choices=['point', 'preflight', 'validate'])
    p.add_argument('--directory', type=Path, required=True)
    p.add_argument('--point', type=int, nargs=2)
    a = p.parse_args()
    a.directory.mkdir(parents=True, exist_ok=True)
    if a.mode == 'point':
        point_worker(a.point, a.directory)
    elif a.mode == 'preflight':
        environment(a.directory)
    else:
        validate_no_solver(a.directory)
