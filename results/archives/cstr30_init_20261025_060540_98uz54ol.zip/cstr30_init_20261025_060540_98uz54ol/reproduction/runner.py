"""Sequential Dantzig controller, with immutable attempts and explicit blockers."""
import argparse
from datetime import datetime, timezone
import fcntl
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
import zipfile

from common import csvwrite, read, require, sha, validate_plan, validate_points, write

ROOT = Path(__file__).resolve().parent
SERVER = '/local/scratch/a/lee4382/repository/RBFopt_Test'


def verify(root):
    inventory = read(root / 'inventory.json')
    for name, digest in inventory.items():
        require(sha(root / name) == digest, 'Frozen input changed: ' + name)
    validate_plan(read(root / 'plan.json'))


def python_command(executable, config):
    executable = Path(executable)
    if (executable.parent.parent / 'conda-meta').is_dir():
        return [config['conda'], 'run', '--no-capture-output', '--prefix', str(executable.parent.parent), 'python']
    return [str(executable)]


def launch(command, dest, seconds, lock_fd, root):
    sys.path.insert(0, str(root / 'frozen/penalty'))
    from watchdog import _stop_process_group
    started = time.perf_counter()
    timed_out = False
    env = {**os.environ, 'PYTHONPATH': str(root)}
    with (dest / 'run.log').open('x') as log:
        process = subprocess.Popen(command, cwd=dest, env=env, stdout=log,
            stderr=subprocess.STDOUT, start_new_session=True, pass_fds=(lock_fd,))
        write(dest / 'process_started.json', dict(command=command, pid=process.pid, timeout_s=seconds))
        try:
            process.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            timed_out = True
            _stop_process_group(process)
        except BaseException:
            _stop_process_group(process)
            raise
    result = dict(returncode=process.returncode, worker_wall_s=time.perf_counter()-started,
                  watchdog_timeout=timed_out, command=command)
    write(dest / 'process.json', result)
    return result


def package(directory):
    manifest = read(directory / 'manifest.json')
    points = list((directory / 'points').glob('*/first_attempt.json'))
    manifest.update(actual_coordinate_nlp_calls=sum(read(p)['nlp_calls'] for p in points),
        actual_search_runs=len(list((directory / 'searches').glob('*/effective_result.json'))),
        input_inventory_sha256=sha(directory / 'reproduction/inventory.json'),
        output_hashes={p.relative_to(directory).as_posix(): sha(p)
            for p in sorted(directory.rglob('*')) if p.is_file() and
            p.name not in ('manifest.json', 'SHA256SUMS', '.controller.lock')
            and '__pycache__' not in p.parts and not p.name.endswith('.tmp')
            and 'reproduction' not in p.relative_to(directory).parts})
    env = directory / 'preflight/nlp/actual_environment.json'
    if env.exists():
        manifest['actual_environment'] = read(env)
    write(directory / 'manifest.json', manifest)
    files = [p for p in sorted(directory.rglob('*')) if p.is_file()
             and p.name not in ('SHA256SUMS', '.controller.lock') and '__pycache__' not in p.parts
             and not p.name.endswith('.tmp')]
    (directory / 'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(directory).as_posix()}\n' for p in files))
    archive = Path(str(directory) + '.zip')
    with zipfile.ZipFile(str(archive) + '.tmp', 'w', zipfile.ZIP_DEFLATED) as z:
        for p in files + [directory / 'SHA256SUMS']:
            z.write(p, directory.name + '/' + p.relative_to(directory).as_posix())
    Path(str(archive) + '.tmp').replace(archive)
    Path(str(archive) + '.sha256').write_text(f'{sha(archive)}  {archive.name}\n')
    (directory.parent / 'result_zip.txt').write_text(str(archive) + '\n')
    print('RESULT_ZIP=' + str(archive), flush=True)


def controller(args):
    verify(ROOT)
    if args.mode == 'dry-run':
        print('PREPARED: 900 coordinates, 465 logical, 435 structural, 50 searches; no NLP/search executed.')
        print((ROOT / 'baseline/summary.json').read_text())
        return
    require(platform.system() == 'Linux' and platform.node() == 'dantzig.ecn.purdue.edu',
            'Formal execution requires the original Dantzig host; no local solver substitution')
    if args.mode == 'run':
        args.output_root.mkdir(parents=True, exist_ok=True)
        directory = Path(tempfile.mkdtemp(prefix='cstr30_init_' + datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S') + '_',
                                          dir=args.output_root)).resolve()
        for name in [*read(ROOT / 'inventory.json'), 'inventory.json', 'SHA256SUMS']:
            dest = directory / 'reproduction' / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(ROOT / name, dest)
        write(directory / 'manifest.json', read(ROOT / 'manifest.json'))
        write(directory / 'run.json', dict(command=sys.argv, cpu=args.cpu,
            nlp_python=args.nlp_python, started_utc=datetime.now(timezone.utc).isoformat(),
            bundle_inventory_sha256=sha(ROOT / 'inventory.json')))
        (args.output_root / 'latest_run.txt').write_text(str(directory) + '\n')
    else:
        require(args.run_dir is not None, '--run-dir is required')
        directory = args.run_dir.resolve()
        require(read(directory / 'run.json')['bundle_inventory_sha256'] == sha(ROOT / 'inventory.json'), 'Resume bundle changed')
    print('RUN_DIR=' + str(directory), flush=True)
    root = directory / 'reproduction'
    verify(root)
    saved = read(directory / 'run.json')
    with (directory / '.controller.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.mode == 'pack':
            package(directory)
            return
        try:
            from cpu_affinity import check_cpu_pair, pin_cpu, affinity_record
            # Existing independently launched Grid/Process jobs use CPUs 6 and 8.
            checks = [check_cpu_pair(saved['cpu'], other) for other in (6, 8)]
            pin_cpu(saved['cpu'])
            write(directory / 'cpu_selection.json', dict(affinity=affinity_record(saved['cpu']), other_job_core_checks=checks))
            plan = read(root / 'plan.json')
            expected_environment = read(root / 'expected_environment.json')
            check_root = directory / ('preflight' if args.mode == 'run' else
                'preflight_resume_' + str(time.time_ns()))
            watchdog = check_root / 'watchdog'
            watchdog.mkdir(parents=True)
            print('PREFLIGHT owned-worker cleanup', flush=True)
            proc = launch([saved['nlp_python'], str(root / 'watchdog_check.py'), str(watchdog)],
                          watchdog, 30, lock.fileno(), root)
            require(proc['returncode'] == 0 and (watchdog / 'passed.json').exists(),
                    'Worker cleanup unavailable: ' + str(watchdog / 'run.log'))
            # All five search environments must be reproducible before evaluating a CSTR.
            for method in dict.fromkeys(j['spec']['method'] for j in plan):
                dest = check_root / method
                if (dest / 'passed.json').exists():
                    continue
                require(not dest.exists(), 'A failed preflight is retained; inspect it before starting a new experiment')
                dest.mkdir(parents=True)
                job = next(j for j in plan if j['spec']['method'] == method)
                write(dest / 'job.json', job)
                print('PREFLIGHT search ' + method, flush=True)
                command = python_command(job['python'], job['config']) + [str(root / 'search.py'),
                    '--job', str(dest / 'job.json'), '--directory', str(dest), '--preflight']
                proc = launch(command, dest, 120, lock.fileno(), root)
                require(proc['returncode'] == 0 and (dest / 'passed.json').exists(), 'Search environment unavailable: ' + str(dest / 'run.log'))
            nlp_check = check_root / 'nlp'
            if not (nlp_check / 'passed.json').exists():
                require(not nlp_check.exists(), 'A failed NLP preflight is retained')
                nlp_check.mkdir(parents=True)
                print('PREFLIGHT GAMS/IPOPT', flush=True)
                proc = launch([saved['nlp_python'], str(root / 'nlp.py'), 'preflight', '--directory', str(nlp_check)],
                              nlp_check, 180, lock.fileno(), root)
                require(proc['returncode'] == 0 and (nlp_check / 'passed.json').exists(), 'NLP environment unavailable: ' + str(nlp_check / 'run.log'))
            for x in range(1, 31):
                for y in range(1, 31):
                    dest = directory / 'points' / f'{x:02d}_{y:02d}'
                    if (dest / 'first_attempt.json').exists():
                        continue
                    if dest.exists():
                        # Never retry a launched coordinate, even if the controller was interrupted.
                        proc = read(dest / 'process.json') if (dest / 'process.json').exists() else dict(returncode=None, worker_wall_s=None, watchdog_timeout=False)
                        proc['interrupted_previous_attempt'] = True
                    else:
                        dest.mkdir(parents=True)
                        print(f'START NLP [{x},{y}]; {(x-1)*30+y}/900', flush=True)
                        proc = launch([saved['nlp_python'], str(root / 'nlp.py'), 'point', '--directory', str(dest), '--point', str(x), str(y)],
                                      dest, expected_environment['worker_timeout'], lock.fileno(), root)
                    raw = read(dest / 'record.json') if (dest / 'record.json').exists() else {}
                    outcome = dict(raw)
                    if proc['returncode'] != 0 or not raw or proc.get('interrupted_previous_attempt'):
                        outcome.update(accepted=False, objective=None, status='worker_timeout' if proc['watchdog_timeout'] else 'worker_error',
                            termination='error', total_wall_s=raw.get('total_wall_s', proc['worker_wall_s']),
                            missing_worker_result=not bool(raw), timing_scope='original_worker_report' if raw.get('total_wall_s') is not None else 'worker_process_including_startup_and_watchdog')
                    outcome.update(case='cstr', cstr_size=30, point=[x, y], attempt=1,
                        nlp_calls=int((dest / 'nlp_call_started.json').exists()), process=proc,
                        initializer_id='mass_balance_zero_recycle_N30_v1')
                    write(dest / 'first_attempt.json', outcome)
                    print(f'DONE NLP [{x},{y}]: {outcome["status"]}, objective={outcome.get("objective")}; {(x-1)*30+y}/900', flush=True)
            point_records = [read(p) for p in sorted((directory / 'points').glob('*/first_attempt.json'))]
            validate_points(point_records)
            evaluation_rows = [{**r, 'record_sha256': sha(directory / 'points' / f'{r["point"][0]:02d}_{r["point"][1]:02d}' / 'first_attempt.json')} for r in point_records]
            csvwrite(directory / 'evaluations.csv', evaluation_rows)
            for number, job in enumerate(plan, 1):
                dest = directory / 'searches' / job['spec']['job_id']
                if (dest / 'effective_result.json').exists():
                    continue
                if dest.exists():
                    result = dict(status='execution_failed', error='Interrupted previous attempt; not retried', process_nlp_calls=0)
                else:
                    dest.mkdir(parents=True)
                    write(dest / 'job.json', job)
                    print(f'START SEARCH {job["spec"]["job_id"]}; {number}/50', flush=True)
                    cmd = python_command(job['python'], job['config']) + [str(root / 'search.py'),
                        '--job', str(dest / 'job.json'), '--directory', str(dest), '--table', str(directory / 'evaluations.csv')]
                    proc = launch(cmd, dest, job['hard_seconds'], lock.fileno(), root)
                    result = read(dest / 'result.json') if (dest / 'result.json').exists() else dict(status='execution_failed', error='No worker result')
                    if proc['returncode'] != 0 or proc['watchdog_timeout']:
                        result = {**result, 'status': 'execution_failed', 'error': 'Worker failed or exceeded historical 2100-second watchdog'}
                    result['process'] = proc
                write(dest / 'effective_result.json', result)
                print(f'DONE SEARCH {job["spec"]["job_id"]}: {result["status"]}; {number}/50', flush=True)
            verify(root)
            from analyze import analyze
            summary = analyze(directory)
            manifest = read(directory / 'manifest.json')
            manifest.update(status='complete', actual_search_runs=50, actual_coordinate_nlp_calls=summary['actual_coordinate_nlp_calls'])
            write(directory / 'manifest.json', manifest)
        except BaseException as exc:
            traceback.print_exc()
            manifest = read(directory / 'manifest.json')
            manifest.update(status='blocked_or_interrupted', blocker=f'{type(exc).__name__}: {exc}')
            write(directory / 'manifest.json', manifest)
            (directory / 'BLOCKED.txt').write_text('The requested experiment is incomplete.\n' + str(exc) + '\nNo failed coordinate or search is automatically retried.\n')
            raise
        finally:
            package(directory)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('mode', choices=['dry-run', 'run', 'resume', 'pack'])
    p.add_argument('--cpu', type=int, default=10)
    p.add_argument('--nlp-python', default=SERVER + '/.venv-dantzig-gdp/bin/python')
    p.add_argument('--output-root', type=Path, default=Path(SERVER) / 'results/cstr30_initialization')
    p.add_argument('--run-dir', type=Path)
    controller(p.parse_args())
