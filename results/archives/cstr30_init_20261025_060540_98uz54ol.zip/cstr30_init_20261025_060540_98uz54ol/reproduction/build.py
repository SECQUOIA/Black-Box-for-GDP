"""Build a CSTR30-only experiment from archived, first-attempt evidence."""
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

from common import METHODS, csvwrite, events, measure, read, require, rows, sha, table, validate_plan, write

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
NAMES = dict(
    penalty='cstr_penalty_1e6_20261022_045249_vn111_rf.zip',
    original='ipopt_dfo_cstr_20261015_174637_r1dzn5tk.zip',
    bam='ipopt_dfo_cstr_20261015_223017_ncd_12gx.zip',
    review='review_comparison_20261020_124949_return_1792527395393579314.zip',
    nlp='dantzig_gdp_gams_20260922_050038_p4q8hy54.zip',
    small='dantzig_cstr_box_ipopt_20261015_162507_3bnp0xm3.zip')


def put(root, name, data):
    path = root / name
    require(path.resolve().is_relative_to(root.resolve()), 'Unsafe package path')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def archive(name):
    path = REPO / 'results/archives' / name
    digest = sha(path)
    sidecar = Path(str(path) + '.sha256')
    if sidecar.exists():
        require(digest == sidecar.read_text().split()[0], 'Archive hash mismatch: ' + name)
    else:
        evidence = '\n'.join(p.read_text() for p in [
            REPO / 'results/process_ipopt_bam_v2_20261015/integration/manifest.json',
            REPO / 'results/process_ipopt_bam_v2_20261015/source_manifest.json',
            REPO / 'cstr30_retry.py',
            REPO / 'results/ipopt_dfo_cstr_20261015_174637_r1dzn5tk/inputs/cstr_30/provenance.json'])
        require(digest in evidence, 'Archive not pinned by an existing record: ' + name)
    z = zipfile.ZipFile(path)
    names = [n for n in z.namelist() if not n.endswith('/')]
    prefix = names[0].split('/')[0] + '/'
    require(len(names) == len(set(names)) and all(n.startswith(prefix) for n in names), 'Archive ambiguity')
    data = {n[len(prefix):]: z.read(n) for n in names}
    z.close()
    if 'SHA256SUMS' in data:
        for line in data['SHA256SUMS'].decode().splitlines():
            expected, rel = line.split(maxsplit=1)
            require(hashlib.sha256(data[rel.lstrip('*')]).hexdigest() == expected, 'Member hash: ' + rel)
    return data, dict(path=str(path.relative_to(REPO)), sha256=digest, root=prefix)


def job_members(dest, data, prefix):
    for name, content in data.items():
        if name.startswith(prefix) and '/' not in name[len(prefix):]:
            put(dest, name[len(prefix):], content)


def build(output):
    require(not output.exists(), 'Output already exists; never overwrite an experiment')
    output.mkdir(parents=True)
    archives, provenance = {}, {}
    for key, name in NAMES.items():
        archives[key], provenance[key] = archive(name)
    original, small = archives['nlp'], archives['small']
    # The actual small-CSTR model preparation is byte-identical to original CSTR30.
    require(original['source/gdp_models/models.py'] == small['source/gdp_models/models.py'],
            'Baseline and small-CSTR model algebra/preprocessing differ')
    require(original['source/gdp_models/domains.py'] == small['source/gdp_models/domains.py'],
            'External mapping changed')
    for name, data in small.items():
        if name.startswith('source/') and name.endswith('.py'):
            put(output, 'frozen/nlp/' + name[7:], data)
    init = output / 'frozen/nlp/cstr_box_ipopt.py'
    previous = init.read_text()
    needle = 'SUPPORTED_SIZES = (5, 10, 15, 20, 25)'
    require(previous.count(needle) == 1, 'Initializer guard changed')
    current = previous.replace(needle, 'SUPPORTED_SIZES = (5, 10, 15, 20, 25, 30)')
    init.write_text(current)
    put(output, 'provenance/initialization.patch', ''.join(difflib.unified_diff(
        previous.splitlines(True), current.splitlines(True),
        fromfile='archived/cstr_box_ipopt.py', tofile='followup/cstr_box_ipopt.py')).encode())
    for filename in ('evaluation.py', 'solvers.py', 'models.py'):
        before = original['source/gdp_models/' + filename]
        after = small['source/gdp_models/' + filename]
        put(output, 'provenance/original_nlp/' + filename, before)
        put(output, 'provenance/nlp_instrumentation_' + filename + '.patch', ''.join(difflib.unified_diff(
            before.decode().splitlines(True), after.decode().splitlines(True))).encode())
    # No current working-tree optimizer is substituted for an archived implementation.
    for group, source in [('penalty', 'penalty'), ('bam', 'bam'), ('fmqa', 'original')]:
        for name, data in archives[source].items():
            if name.startswith('reproduction/'):
                rel = name[len('reproduction/'):]
                if rel.endswith('.py') or rel.startswith('fmqa_benchmark/vendor/'):
                    if not rel.startswith(('baseline/', 'inputs/', 'evidence/', 'provenance/')):
                        put(output, 'frozen/' + group + '/' + rel, data)
    for name in ('review_comparison/worker.py', 'review_comparison/common.py', 'review_comparison/__init__.py'):
        put(output, 'frozen/sampling/' + name, archives['review']['reproduction/' + name])
    baseline, plan = [], []
    for n, budget in zip((5, 10, 15, 20, 25, 30), (8, 15, 22, 29, 36, 43)):
        cost = REPO / f'results/process_ipopt_bam_v2_20261015/tables/cost_table_cstr_{n}.csv'
        put(output, f'baseline/cost_table_cstr_{n}.csv', cost.read_bytes())
        costs = table(cost)
        target = min(float(r['objective']) for r in costs.values() if r['accepted'] == 'True')
        require(len(costs) == n*n, 'Baseline full cost table incomplete')
        for seed in range(10):
            starts = None
            for method in METHODS:
                jobid = f'cstr_{n}_B{budget}_seed{seed}_{method}'
                source = 'penalty' if method in ('dsda', 'rbfopt') else 'bam' if method == 'bam' else 'original' if method == 'fmqa_sa' else 'review'
                data = archives[source]
                prefix = 'jobs/' + jobid + '/'
                if source == 'review':
                    candidates = [k[:-len('job.json')] for k in data if k.startswith(prefix) and k.endswith('/job.json')]
                    require(len(candidates) == 1, 'Ambiguous uniform attempt')
                    prefix = candidates[0]
                dest = output / 'baseline/jobs' / jobid
                job_members(dest, data, prefix)
                if source == 'penalty':
                    archived_job = read(dest / 'job.json')
                    spec = archived_job['spec']
                elif source == 'review':
                    archived_job = read(dest / 'job.json')
                    spec = {**archived_job['original_spec'], 'method': method, 'job_id': jobid}
                    spec['settings'] = {'sampling': 'archived review_comparison.worker.sampling_points'}
                else:
                    archived_job = None
                    spec = read(dest / 'spec.json')
                require(spec['seed'] == seed and spec['budget'] == budget and spec['case'] == f'cstr_{n}', 'Manifest condition mismatch')
                ev = events(dest / 'callbacks.jsonl')
                require([e['point'] for e in ev[:3]] == spec['starts'], 'Historical initial order differs')
                require(starts is None or starts == spec['starts'], 'Historical methods do not share starts')
                starts = spec['starts']
                metric, _ = measure(spec, ev, read(dest / 'result.json'), costs, target)
                require(metric['target_hit'] == metric['any_target_hit'], 'Baseline target definitions disagree')
                baseline.append(dict(case=spec['case'], method=method, budget=budget, seed=seed,
                    job_id=jobid, source_archive=provenance[source]['path'], source_member=prefix,
                    **metric))
                if n == 30:
                    run = json.loads(data['run.json'])
                    config = run['config']
                    runtime = read(dest / 'runtime.json')
                    interpreter = runtime['executable']
                    hard_seconds = archived_job['hard_seconds'] if archived_job and 'hard_seconds' in archived_job else config['hard_seconds']
                    require(hard_seconds == 2100, 'Historical search watchdog differs from the inspected protocol')
                    job = dict(spec=spec, frozen='penalty' if source == 'penalty' else 'bam' if source == 'bam' else 'fmqa',
                        reference_runtime=runtime, reference_settings=read(dest / 'actual_settings.json')
                            if (dest / 'actual_settings.json').exists() else None,
                        config=config, python=interpreter, hard_seconds=hard_seconds,
                        baseline_directory='baseline/jobs/' + jobid, target=target)
                    if source == 'review':
                        job['sampling_job'] = archived_job
                    plan.append(job)
    validate_plan(plan)
    csvwrite(output / 'baseline/runs.csv', baseline)
    write(output / 'plan.json', plan)
    published = rows(REPO / 'results/review_comparison_20261020/tables/completed_runs.csv')
    published = [r for r in published if r['case'].startswith('cstr_') and r['method'] in
                 ('dsda', 'rbfopt_msrsm_genetic', 'bam', 'fmqa_sa', 'uniform_without_replacement')]
    require(len(published) == 300, 'Manuscript CSTR selection incomplete')
    csvwrite(output / 'baseline/manuscript_runs.csv', published)
    pub_index = {(r['case'], r['method'], int(r['seed'])): r for r in published}
    penalty_rows = {r['job_id']: r for r in __import__('csv').DictReader(
        archives['penalty']['runs.csv'].decode().splitlines())}
    for r in baseline:
        if r['method'] in ('dsda', 'rbfopt'):
            require(r['target_hit'] == (penalty_rows[r['job_id']]['target_hit'] == 'True'), 'Finite-penalty result discrepancy')
        else:
            require(r['category'] == pub_index[r['case'], r['method'], r['seed']]['category'], 'Manuscript baseline discrepancy')
    for name in ('analysis_manifest_current.json', 'supplementary.tex'):
        put(output, 'provenance/manuscript/' + name, (REPO / 'manuscript' / name).read_bytes())
    for name in ('manifest.json', 'provenance.json', 'evaluations.csv', 'summary.json'):
        put(output, 'provenance/selected_cstr30/' + name,
            (REPO / 'results/ipopt_dfo_cstr_20261015_174637_r1dzn5tk/inputs/cstr_30' / name).read_bytes())
    for name, data in original.items():
        prefix = 'gams_ipopt/cstr_30/'
        if name.startswith(prefix):
            put(output, 'baseline/nlp/' + name[len(prefix):], data)
    nlp_manifest = read(output / 'baseline/nlp/manifest.json')
    reference = read(output / 'baseline/nlp/records/point_000465.json')
    small_config = json.loads(small['run.json'])['config']
    require(small_config['time_limit'] == reference['time_limit_s']
        and small_config['feasibility_tolerance'] == reference['feasibility_tolerance'],
        'Small-CSTR solver/acceptance limits differ from CSTR30')
    version_line = sorted(set(line for line in (output / 'baseline/nlp/run.log').read_text().splitlines()
                              if line.startswith('This is Ipopt version ')))
    require(len(version_line) == 1, 'Ambiguous baseline IPOPT build')
    costs30 = table(output / 'baseline/cost_table_cstr_30.csv')
    logical = table(output / 'baseline/nlp/evaluations.csv')
    require(len(logical) == 465, 'Original logical table incomplete')
    for point, r in logical.items():
        for key in ('accepted', 'objective', 'candidate_objective', 'status', 'termination', 'total_wall_s'):
            require(r[key] == costs30[point][key], 'Baseline cost is from another attempt')
    write(output / 'expected_environment.json', dict(manifest=nlp_manifest,
        solver_options=reference['solver_options'], solver_option_file=reference['solver_option_file'],
        ipopt_version_line=version_line[0], initialization_sequence='constructor defaults; external fixing; constraint snapshot; preprocessing; mass_balance_zero_recycle',
        time_limit=reference['time_limit_s'], feasibility_tolerance=reference['feasibility_tolerance'],
        worker_timeout=small_config['worker_timeout'], reference_point=reference['point'], reference_objective=reference['objective']))
    for p in HERE.glob('*'):
        if p.is_file() and p.suffix in ('.py', '.sh', '.txt'):
            put(output, p.name, p.read_bytes())
    for p in sorted((HERE / 'validation').glob('*')):
        if p.is_file():
            put(output, 'validation/' + p.name, p.read_bytes())
    put(output, 'cpu_affinity.py', (REPO / 'cpu_affinity.py').read_bytes())
    revision = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip()
    dirty = subprocess.check_output(['git', '-C', str(REPO), 'status', '--porcelain', '--', str(HERE)], text=True).strip()
    write(output / 'manifest.json', dict(repository='SECQUOIA/Black-Box-for-GDP',
        baseline_revision='44ed72156a03017d7021f3fac6744bae4366dbfb', execution_source_base_revision=revision,
        execution_source_revision=revision, execution_source_uncommitted=bool(dirty),
        execution_source_note='Exact archived sources and follow-up code are additionally identified by SHA256SUMS',
        manuscript_manifest=read(output / 'provenance/manuscript/analysis_manifest_current.json'),
        archives=provenance, factor='CSTR30 initialization only',
        initializer='archived cstr_box_ipopt.initialize_feasible; supported-size guard extended to 30',
        initializers_historical_reason='CSTR30 selected original constructor-default table; no documented reason found for excluding N=30 from later full-box initialization runs',
        baseline_selection='Manuscript BAM v2, FMQA-SA and uniform; finite-1e6 D-SDA/RBFOpt from 20261022; RBFOpt genetic',
        manuscript_difference='The manuscript manifest predates the finite-penalty experiment; this follow-up explicitly uses the finite-penalty overlay and retains the manuscript inventory separately',
        primary_target_rule='final_best_absolute', target_formula='abs(best-reference) <= 1e-5*max(1,abs(reference))',
        target_note='Historical finite-penalty report used any-hit; baseline results agree, and both definitions are exported for the follow-up',
        actual_environment=None, actual_nlp_calls=0, actual_search_runs=0,
        status='prepared_not_executed', historical_manifests_modified=False))
    summary = []
    for method in METHODS:
        allrows = [r for r in baseline if r['method'] == method]
        c30 = [r for r in allrows if r['case'] == 'cstr_30']
        summary.append(dict(method=method, cstr30_hits=sum(r['target_hit'] for r in c30),
            cstr30_runs=len(c30), all_cstr_hits=sum(r['target_hit'] for r in allrows), all_cstr_runs=len(allrows)))
    write(output / 'baseline/summary.json', dict(groups=summary,
        finite_penalty_baseline_total_hits=sum(r['target_hit'] for r in baseline),
        manuscript_total_hits=sum(r['category'] == 'target_reached' for r in published),
        total_runs=len(baseline),
        accepted_coordinates=sum(r['accepted'] == 'True' for r in costs30.values()),
        logical_coordinates=len(logical), structural_coordinates=len(costs30)-len(logical),
        reference_point=reference['point'], reference_objective=reference['objective']))
    inventory = {p.relative_to(output).as_posix(): sha(p) for p in sorted(output.rglob('*')) if p.is_file()}
    write(output / 'inventory.json', inventory)
    (output / 'SHA256SUMS').write_text(''.join(f'{digest}  {name}\n' for name, digest in
        sorted({**inventory, 'inventory.json': sha(output / 'inventory.json')}.items())))
    print(json.dumps(read(output / 'baseline/summary.json'), indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    build(p.parse_args().output.resolve())
