"""Verify owned-worker cleanup on Dantzig before any scientific evaluation."""
import os
from pathlib import Path
import subprocess
import sys

from common import require, write

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'frozen/penalty'))
from watchdog import _stop_process_group  # noqa: E402


if __name__ == '__main__':
    directory = Path(sys.argv[1])
    child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)'], start_new_session=True)
    write(directory / 'owned_child.json', dict(pid=child.pid))
    try:
        _stop_process_group(child)
        require(child.poll() is not None, 'Watchdog did not reap its child')
        try:
            os.killpg(child.pid, 0)
        except ProcessLookupError:
            pass
        else:
            raise RuntimeError('Owned process group is still alive')
    finally:
        if child.poll() is None:
            child.kill()
            child.wait()
    write(directory / 'passed.json', dict(passed=True, solver_calls=0, terminated_only_owned_child=True))
