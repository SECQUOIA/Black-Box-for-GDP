"""Record validation and fixed-reference accounting for the isolated follow-up."""
import csv
import hashlib
import json
import math
from pathlib import Path

METHODS = ('dsda', 'rbfopt', 'bam', 'fmqa_sa', 'uniform_without_replacement')
THREADS = dict.fromkeys(('OMP_NUM_THREADS', 'OMP_THREAD_LIMIT', 'OPENBLAS_NUM_THREADS',
    'MKL_NUM_THREADS', 'BLIS_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'), '1')
THREADS.update(OMP_DYNAMIC='FALSE', MKL_DYNAMIC='FALSE')


def require(test, message):
    if not test:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text())


def write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')
    temp.replace(path)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def rows(path):
    with Path(path).open(newline='') as stream:
        return list(csv.DictReader(stream))


def csvwrite(path, data, fields=None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = fields or list(dict.fromkeys(k for r in data for k in r))
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for r in data:
            writer.writerow({k: json.dumps(v, allow_nan=False) if isinstance(v, (list, dict)) else v
                             for k, v in r.items() if k in fields})


def events(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines()] if Path(path).exists() else []


def hit(value, target):
    return value is not None and math.isfinite(value) and abs(value - target) <= 1e-5 * max(1, abs(target))


def table(path):
    data = rows(path)
    result = {tuple(json.loads(r['point'])): r for r in data}
    require(len(data) == len(result), 'Duplicate evaluation coordinates')
    return result


def validate_points(records):
    expected = {(x, y) for x in range(1, 31) for y in range(1, 31)}
    points = [tuple(r['point']) for r in records]
    require(len(points) == 900 and set(points) == expected, 'Expected 900 distinct CSTR30 coordinates')
    require(sum(y <= x for x, y in points) == 465, 'Logical domain changed')
    for r in records:
        x, y = r['point']
        require(r['cstr_size'] == 30 and type(r['accepted']) is bool, 'Incorrect point identity')
        require(r['attempt'] == 1, 'Only the first attempt is permitted')
        if y > x:
            require(r['status'] == 'preprocessing_infeasible' and r['nlp_calls'] == 0,
                    'Structural exclusion must follow preprocessing without an NLP call')
        require(r['nlp_calls'] in (0, 1), 'Repeated NLP at one coordinate')
        if r['accepted']:
            require(r['nlp_calls'] == 1 and r['gams_solve_status'] == 1
                    and r['gams_model_status'] in (1, 2)
                    and r['termination'] in ('optimal', 'locallyOptimal', 'globallyOptimal')
                    and r.get('solver_status') not in ('error', 'aborted')
                    and math.isfinite(r['objective']) and r['max_primal_violation'] <= 1e-5,
                    'Acceptance criteria changed')
        require(r.get('total_wall_s') is not None and r['total_wall_s'] >= 0, 'Missing point cost')


def validate_plan(plan):
    require(len(plan) == 50, 'Exactly 50 CSTR30 search runs required')
    keys = {(j['spec']['method'], j['spec']['budget'], j['spec']['seed']) for j in plan}
    require(keys == {(m, 43, s) for m in METHODS for s in range(10)}, 'Search slots changed')
    for seed in range(10):
        selected = [j for j in plan if j['spec']['seed'] == seed]
        starts = selected[0]['spec']['starts']
        require(len(starts) == 3, 'Three initial coordinates required')
        require(all(j['spec']['starts'] == starts and j['spec']['case'] == 'cstr_30'
                    for j in selected), 'Shared initial sequence changed')
    for job in plan:
        s = job['spec']
        require(s['lower'] == [1, 1] and s['upper'] == [30, 30] and s['cstr_size'] == 30,
                'CSTR30 external-variable mapping changed')
        if s['method'] in ('dsda', 'rbfopt'):
            require(s['unaccepted_response'] == 1e6, 'Finite penalty baseline required')
        if s['method'] == 'rbfopt':
            require(s['settings']['global_search_method'] == 'genetic', 'Wrong RBFOpt primary')


def measure(spec, ev, result, costs, target, primary='final_best_absolute'):
    """Same measured-search-minus-lookup accounting, charging repeated callbacks."""
    charged = [e for e in ev if e['index'] <= spec['budget'] and not e.get('budget_overrun')]
    accepted = [e for e in charged if e['accepted']]
    best = min(accepted, key=lambda e: e['raw_objective']) if accepted else None
    any_hit = any(hit(e['raw_objective'], target) for e in accepted)
    final_hit = bool(best and hit(best['raw_objective'], target))
    status = result.get('status', 'not_run')
    protocol_error = (len(ev) > spec['budget'] or any(e.get('budget_overrun') for e in ev)
        or [e['point'] for e in ev[:3]] != spec['starts'][:min(3, len(ev))]
        or [e['index'] for e in ev] != list(range(1, len(ev) + 1)))
    failed = status not in ('completed', 'budget_completed') or best is None or protocol_error
    target_hit = (final_hit if primary == 'final_best_absolute' else any_hit) and not failed
    ledger, missing = [], []
    for e in charged:
        r = costs.get(tuple(e['point']))
        require(r is not None, 'Unmeasured coordinate in a full evaluation table')
        require(e['accepted'] == (r['accepted'] == 'True'), 'Acceptance/cost record mismatch')
        if e['accepted']:
            require(e['raw_objective'] == float(r['objective']), 'Objective/cost attempt mismatch')
        cost = float(r['total_wall_s']) if r.get('total_wall_s') else None
        if cost is None:
            missing.append(e['point'])
        else:
            require(math.isfinite(cost) and cost >= 0, 'Invalid evaluation cost')
        ledger.append({**e, 'point_cost_s': cost, 'evaluation_record_sha256': r.get('record_sha256'),
                       'repeated_point': any(p['point'] == e['point'] for p in ledger)})
    wall = result.get('recorded_search_wall_s', result.get('dfo_wall_s'))
    lookup = sum(e['lookup_wall_s'] for e in ev)
    retained = wall - lookup if wall is not None else None
    total = sum(e['point_cost_s'] for e in ledger) if not missing else None
    objective = best['raw_objective'] if best else None
    return dict(status=status, category='execution_failed' if failed else
        'target_reached' if target_hit else 'target_not_reached', target_hit=target_hit,
        target=target, target_rule=primary, any_target_hit=any_hit and not failed,
        final_best_target_hit=final_hit and not failed, best_objective=objective,
        best_point=best['point'] if best else None, callbacks=len(charged),
        shared_starts_complete=[e['point'] for e in ev[:3]] == spec['starts'],
        protocol_error=protocol_error, search_s=wall, lookup_s=lookup,
        retained_search_s=retained, point_cost_s=total,
        completion_s=retained + total if retained is not None and total is not None else None,
        missing_cost_points=missing, better_than_reference_but_final_miss=bool(objective is not None
            and objective < target and not final_hit)), ledger
