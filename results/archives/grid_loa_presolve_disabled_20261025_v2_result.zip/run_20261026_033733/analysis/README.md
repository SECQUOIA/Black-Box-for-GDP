# LOA subproblem presolve disabled: returned diagnostic

This is a selective three-problem diagnostic, not a new 21-grid benchmark.
Only subproblem_presolve=False changes the full LOA optimization configuration.
The option also bypasses fixed-variable and trivial-constraint preprocessing, so solver routing and measured time may differ.
Known feasible reference objectives and the 1e-5 acceptance/target tolerance remain unchanged.
The table uses independently evaluated original-GDP objectives from the same returned variable vectors as the residual checks.
An optimal termination string does not certify the original nonconvex GDP, and inconsistent lower bounds are retained in comparison.json.

| Grid | Prior objective | Prior termination | Prior max violation | Prior seconds | Prior reference evaluations | New objective | New termination/status | New max violation | New worker seconds | New reference evaluations | New target |
| --- | ---: | --- | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | --- |
| holder_table | 0.145167239953 | optimal | 0.0 | 1623.761 | 0 | None | not_run | None | None | 0 | None |
| michalewicz | 0.0864917048203 | optimal | 0.0 | 1490.761 | 0 | None | not_run | None | None | 0 | None |
| shubert | 0.0824278107512 | optimal | 0.0 | 1278.446 | 0 | None | not_run | None | None | 0 | None |

Fixed call attempts: 1; confirmed SCIP invocations: 0; full LOA solve entries: 0.
Fixed gates passed: 0/6; run status: stopped_fixed_gate.
The reference_paths.json file distinguishes discrete selection, bypassed presolve, evaluation entry, evaluation return and target incumbents for all six diagnostic coordinates.
Missing new values mean that the corresponding stage did not produce a result.
No solver is invoked by this analysis.
