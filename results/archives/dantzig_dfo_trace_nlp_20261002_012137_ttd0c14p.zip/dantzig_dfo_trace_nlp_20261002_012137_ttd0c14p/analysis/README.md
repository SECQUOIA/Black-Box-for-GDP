# Original DFO runtime and separate coordinate NLP timings

The original DSDA/RBFOpt/BAM lookup implementations and settings are unchanged. Existing Dantzig FMQA traces are reused. NLP results are never supplied back to the search.

- `dfo_runs.csv`: recorded DFO run time, result and trace identity.
- `evaluation_timings.csv`: actual ordered coordinates, DFO timestamps and linked separate NLP measurements.
- `point_timings.csv`: one recorded NLP evaluation time per visited coordinate, including unsuccessful/preprocessing-infeasible points.

`nlp_evaluation_wall_s` includes model preparation, preprocessing, solver invocation and validation. `nlp_solve_wall_s` is a subset, not an additional cost. Preprocessing rejection can have zero solver time but positive evaluation time. Missing measurements remain blank. Solver failures are not proofs of global infeasibility.

Repeated coordinates reference the same separate point measurement; this is not an NLP solve inside each DFO callback. DFO time and NLP costs are not relabelled as a measured combined runtime. Dynamic one-time preparation is saved separately in `dynamic_preparations.json`.

| Case | Size | Budget | Method | Recorded/planned | Mean DFO seconds |
|---|---:|---:|---|---:|---:|
| column |  | 16 | dsda | 9/9 | 0.000746 |
| column |  | 16 | rbfopt | 9/9 | 6.033094 |
| column |  | 16 | bam | 9/9 | 1.186924 |
| cstr | 5 | 8 | dsda | 10/10 | 0.000425 |
| cstr | 5 | 8 | rbfopt | 10/10 | 1.846477 |
| cstr | 5 | 8 | bam | 10/10 | 0.191965 |
| cstr | 10 | 15 | dsda | 10/10 | 0.000670 |
| cstr | 10 | 15 | rbfopt | 10/10 | 5.350902 |
| cstr | 10 | 15 | bam | 10/10 | 0.792922 |
| cstr | 15 | 22 | dsda | 10/10 | 0.000809 |
| cstr | 15 | 22 | rbfopt | 10/10 | 9.704174 |
| cstr | 15 | 22 | bam | 10/10 | 0.835596 |
| cstr | 20 | 29 | dsda | 10/10 | 0.000935 |
| cstr | 20 | 29 | rbfopt | 10/10 | 19.477836 |
| cstr | 20 | 29 | bam | 10/10 | 1.297918 |
| cstr | 25 | 36 | dsda | 10/10 | 0.001084 |
| cstr | 25 | 36 | rbfopt | 10/10 | 35.370289 |
| cstr | 25 | 36 | bam | 10/10 | 2.457107 |
| cstr | 30 | 43 | dsda | 10/10 | 0.001279 |
| cstr | 30 | 43 | rbfopt | 10/10 | 55.786598 |
| cstr | 30 | 43 | bam | 10/10 | 2.379396 |
| small_batch |  | 10 | dsda | 10/10 | 0.000551 |
| small_batch |  | 10 | rbfopt | 10/10 | 0.852352 |
| small_batch |  | 10 | bam | 10/10 | 0.116279 |
| dynamic |  | 12 | dsda | 10/10 | 0.000922 |
| dynamic |  | 12 | rbfopt | 10/10 | 3.480766 |
| dynamic |  | 12 | bam | 10/10 | 0.032211 |
| dynamic |  | 15 | dsda | 10/10 | 0.000698 |
| dynamic |  | 15 | rbfopt | 10/10 | 6.670305 |
| dynamic |  | 15 | bam | 10/10 | 0.799710 |
| dynamic |  | 20 | dsda | 10/10 | 0.000810 |
| dynamic |  | 20 | rbfopt | 10/10 | 15.818107 |
| dynamic |  | 20 | bam | 10/10 | 0.797441 |
| dynamic |  | 30 | dsda | 10/10 | 0.000979 |
| dynamic |  | 30 | rbfopt | 10/10 | 56.888799 |
| dynamic |  | 30 | bam | 10/10 | 1.696075 |
| dynamic |  | 37 | dsda | 10/10 | 0.000994 |
| dynamic |  | 37 | rbfopt | 10/10 | 108.991334 |
| dynamic |  | 37 | bam | 10/10 | 2.111301 |
| dynamic |  | 50 | dsda | 10/10 | 0.000989 |
| dynamic |  | 50 | rbfopt | 10/10 | 278.150546 |
| dynamic |  | 50 | bam | 10/10 | 4.340043 |
| column |  | 16 | fmqa_sa | 9/9 | 0.896710 |
| cstr | 5 | 8 | fmqa_sa | 10/10 | 0.327215 |
| cstr | 10 | 15 | fmqa_sa | 10/10 | 0.827857 |
| cstr | 15 | 22 | fmqa_sa | 10/10 | 1.310628 |
| cstr | 20 | 29 | fmqa_sa | 10/10 | 1.899914 |
| cstr | 25 | 36 | fmqa_sa | 10/10 | 2.401297 |
| cstr | 30 | 43 | fmqa_sa | 10/10 | 2.910601 |
| small_batch |  | 10 | fmqa_sa | 10/10 | 0.449839 |
| dynamic |  | 12 | fmqa_sa | 10/10 | 0.601819 |
| dynamic |  | 15 | fmqa_sa | 10/10 | 0.808699 |
| dynamic |  | 20 | fmqa_sa | 10/10 | 1.154902 |
| dynamic |  | 30 | fmqa_sa | 10/10 | 1.843989 |
| dynamic |  | 37 | fmqa_sa | 10/10 | 2.327349 |
| dynamic |  | 50 | fmqa_sa | 10/10 | 3.239480 |
