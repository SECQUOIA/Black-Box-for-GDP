$offlisting
$offdigit

EQUATIONS
	c1
	c2
	c3
	c4
	c5
	c6
	c7
	c8
	c9
	c10
	c11
	c12
	c13
	c14
	c15
	c16
	c17
	c18
	c19
	c20
	c21
	c22
	c23
	c24
	c25
	c26
	c27
	c28
	c29
	c30
	c31
	c32
	c33
	c34
	c35
	c36
	c37
	c38
	c39
	c40
	c41
	c42
	c43
	c44
	c45
	c46
	c47
	c48
	c49
	c50
	c51
	c52
	c53
	c54
	c55
	c56
	c57
	c58
	c59
	c60
	c61
	c62
	c63
	c64
	c65
	c66
	c67
	c68
	c69
	c70
	c71
	c72
	c73
	c74
	c75
	c76
	c77
	c78
	c79
	c80
	c81
	c82
	c83
	c84
	c85
	c86
	c87
	c88
	c89
	c90
	c91
	c92
	c93
	c94
	c95
	c96
	c97
	c98
	c99
	c100
	c101
	c102
	c103
	c104
	c105
	c106
	c107
	c108
	c109
	c110
	c111
	c112
	c113
	c114
	c115
	c116
	c117
	c118
	c119
	c120
	c121
	c122
	c123
	c124
	c125
	c126
	c127
	c128
	c129
	c130
	c131
	c132
	c133
	c134
	c135
	c136
	c137
	c138
	c139
	c140
	c141
	c142
	c143
	c144
	c145
	c146
	c147
	c148
	c149
	c150
	c151
	c152
	c153
	c154
	c155
	c156
	c157
	c158
	c159
	c160
	c161
	c162
	c163
	c164
	c165
	c166
	c167
	c168
	c169
	c170
	c171
	c172
	c173
	c174
	c175
	c176
	c177
	c178
	c179
	c180
	c181
	c182
	c183
	c184
	c185
	c186
	c187
	c188
	c189
	c190
	c191
	c192
	c193
	c194
	c195
	c196
	c197
	c198
	c199
	c200
	c201;

POSITIVE VARIABLES
	x1
	x2
	x4
	x5
	x7
	x8
	x10
	x11
	x13
	x14
	x16
	x17
	x19
	x20
	x22
	x23
	x25
	x26
	x28
	x29
	x31
	x32
	x34
	x35
	x37
	x38
	x40
	x41
	x43
	x44
	x46
	x47
	x49
	x50
	x52
	x53
	x54
	x56
	x57
	x59
	x60
	x62
	x63
	x65
	x66
	x68
	x69
	x71
	x72
	x74
	x75
	x77
	x78
	x79
	x80
	x81
	x82
	x84
	x86
	x88
	x90
	x92
	x94
	x96
	x98
	x100
	x102
	x104
	x106
	x108
	x110
	x112
	x114
	x116
	x117
	x119
	x121
	x123
	x125
	x127
	x129
	x131
	x133
	x134
	x135
	x155
	x166
	x167
	x168
	x169
	x170
	x171
	x172
	x173
	x174
	x175
	x176
	x177
	x178
	x179
	x180
	x181
	x182
	x183
	x184
	x185
	x186
	x187
	x188
	x189
	x190
	x191
	x192
	x193
	x194
	x195
	x196
	x197
	x198
	x199
	x200
	x201;

VARIABLES
	GAMS_OBJECTIVE
	x3
	x6
	x9
	x12
	x15
	x18
	x21
	x24
	x27
	x30
	x33
	x36
	x39
	x42
	x45
	x48
	x51
	x55
	x58
	x61
	x64
	x67
	x70
	x73
	x76
	x83
	x85
	x87
	x89
	x91
	x93
	x95
	x97
	x99
	x101
	x103
	x105
	x107
	x109
	x111
	x113
	x115
	x118
	x120
	x122
	x124
	x126
	x128
	x130
	x132
	x136
	x137
	x138
	x139
	x140
	x141
	x142
	x143
	x144
	x145
	x146
	x147
	x148
	x149
	x150
	x151
	x152
	x153
	x154
	x156
	x157
	x158
	x159
	x160
	x161
	x162
	x163
	x164
	x165;


c1.. x1 + 0 - x2 + x3*x4 =e= 0 ;
c2.. x5 + 0 - x1 + x6*x7 =e= 0 ;
c3.. x8 + 0 - x5 + x9*x10 =e= 0 ;
c4.. x11 + 0 - x8 + x12*x13 =e= 0 ;
c5.. x14 + 0 - x11 + x15*x16 =e= 0 ;
c6.. x17 + 0 - x14 + x18*x19 =e= 0 ;
c7.. x20 + 0 - x17 + x21*x22 =e= 0 ;
c8.. x23 + 0 - x20 + x24*x25 =e= 0 ;
c9.. x26 + 0 - x23 + x27*x28 =e= 0 ;
c10.. x29 + 0 - x26 + x30*x31 =e= 0 ;
c11.. x32 + 0 - x29 + x33*x34 =e= 0 ;
c12.. x35 + 0 - x32 + x36*x37 =e= 0 ;
c13.. x38 + 0 - x35 + x39*x40 =e= 0 ;
c14.. x41 + 0 - x38 + x42*x43 =e= 0 ;
c15.. x44 + 0 - x41 + x45*x46 =e= 0 ;
c16.. x47 + 0 - x44 + x48*x49 =e= 0 ;
c17.. x50 + 0 - x47 + x51*x52 =e= 0 ;
c18.. x53 + x54 - x50 + x55*x56 =e= 0 ;
c19.. x57 + 0 - x53 + x58*x59 =e= 0 ;
c20.. x60 + 0 - x57 + x61*x62 =e= 0 ;
c21.. x63 + 0 - x60 + x64*x65 =e= 0 ;
c22.. x66 + 0 - x63 + x67*x68 =e= 0 ;
c23.. x69 + 0 - x66 + x70*x71 =e= 0 ;
c24.. x72 + 0 - x69 + x73*x74 =e= 0 ;
c25.. x75 + 0 - x72 + x76*x77 =e= 0 ;
c26.. x78 - x75 =e= 0 ;
c27.. x79 - x78 =e= 0 ;
c28.. x80 - x79 =e= 0 ;
c29.. -x80 + 0.98999999999999999 =e= 0 ;
c30.. x81 + 0 - x82 + x83*x4 =e= 0 ;
c31.. x84 + 0 - x81 + x85*x7 =e= 0 ;
c32.. x86 + 0 - x84 + x87*x10 =e= 0 ;
c33.. x88 + 0 - x86 + x89*x13 =e= 0 ;
c34.. x90 + 0 - x88 + x91*x16 =e= 0 ;
c35.. x92 + 0 - x90 + x93*x19 =e= 0 ;
c36.. x94 + 0 - x92 + x95*x22 =e= 0 ;
c37.. x96 + 0 - x94 + x97*x25 =e= 0 ;
c38.. x98 + 0 - x96 + x99*x28 =e= 0 ;
c39.. x100 + 0 - x98 + x101*x31 =e= 0 ;
c40.. x102 + 0 - x100 + x103*x34 =e= 0 ;
c41.. x104 + 0 - x102 + x105*x37 =e= 0 ;
c42.. x106 + 0 - x104 + x107*x40 =e= 0 ;
c43.. x108 + 0 - x106 + x109*x43 =e= 0 ;
c44.. x110 + 0 - x108 + x111*x46 =e= 0 ;
c45.. x112 + 0 - x110 + x113*x49 =e= 0 ;
c46.. x114 + 0 - x112 + x115*x52 =e= 0 ;
c47.. x116 + x117 - x114 + x118*x56 =e= 0 ;
c48.. x119 + 0 - x116 + x120*x59 =e= 0 ;
c49.. x121 + 0 - x119 + x122*x62 =e= 0 ;
c50.. x123 + 0 - x121 + x124*x65 =e= 0 ;
c51.. x125 + 0 - x123 + x126*x68 =e= 0 ;
c52.. x127 + 0 - x125 + x128*x71 =e= 0 ;
c53.. x129 + 0 - x127 + x130*x74 =e= 0 ;
c54.. x131 + 0 - x129 + x132*x77 =e= 0 ;
c55.. x133 - x131 =e= 0 ;
c56.. x134 - x133 =e= 0 ;
c57.. x135 - x134 =e= 0 ;
c58.. -x135 + 0.01 =e= 0 ;
c59.. x136 - x137 =e= 0 ;
c60.. x138 - x136 =e= 0 ;
c61.. x139 - x138 =e= 0 ;
c62.. x140 - x139 =e= 0 ;
c63.. x141 - x140 =e= 0 ;
c64.. x142 - x141 =e= 0 ;
c65.. x143 - x142 =e= 0 ;
c66.. x144 - x143 =e= 0 ;
c67.. x145 - x144 =e= 0 ;
c68.. x146 - x145 =e= 0 ;
c69.. x147 - x146 =e= 0 ;
c70.. x148 - x147 =e= 0 ;
c71.. x149 - x148 =e= 0 ;
c72.. x150 - x149 =e= 0 ;
c73.. x151 - x150 =e= 0 ;
c74.. x152 - x151 =e= 0 ;
c75.. x153 - x152 =e= 0 ;
c76.. x154 + x155 - x153 =e= 0 ;
c77.. x156 - x154 =e= 0 ;
c78.. x157 - x156 =e= 0 ;
c79.. x158 - x157 =e= 0 ;
c80.. x159 - x158 =e= 0 ;
c81.. x160 - x159 =e= 0 ;
c82.. x161 - x160 =e= 0 ;
c83.. x162 - x161 =e= 0 ;
c84.. x163 - x162 =e= 0 ;
c85.. x164 - x163 =e= 0 ;
c86.. x165 - x164 =e= 0 ;
c87.. -x165 + 1 =e= 0 ;
c88.. x2 - x166 - x167 =e= 0 ;
c89.. x82 - x168 - x169 =e= 0 ;
c90.. x137 - x170 - x171 =e= 0 ;
c91.. x166*x137 - x2*x170 =e= 0 ;
c92.. x168*x137 - x82*x170 =e= 0 ;
c93.. 0.94999999999999996*x170 - x168 =e= 0 ;
c94.. x7 - x4 =e= 0 ;
c95.. x10 - x7 =e= 0 ;
c96.. x13 - x10 =e= 0 ;
c97.. x16 - x13 =e= 0 ;
c98.. x19 - x16 =e= 0 ;
c99.. x22 - x19 =e= 0 ;
c100.. x25 - x22 =e= 0 ;
c101.. x28 - x25 =e= 0 ;
c102.. x31 - x28 =e= 0 ;
c103.. x34 - x31 =e= 0 ;
c104.. x37 - x34 =e= 0 ;
c105.. x40 - x37 =e= 0 ;
c106.. x43 - x40 =e= 0 ;
c107.. x46 - x43 =e= 0 ;
c108.. x49 - x46 =e= 0 ;
c109.. x52 - x49 =e= 0 ;
c110.. x56 - x52 =e= 0 ;
c111.. x59 - x56 =e= 0 ;
c112.. x62 - x59 =e= 0 ;
c113.. x65 - x62 =e= 0 ;
c114.. x68 - x65 =e= 0 ;
c115.. x71 - x68 =e= 0 ;
c116.. x74 - x71 =e= 0 ;
c117.. x77 - x74 =e= 0 ;
c118.. x172 - x77 =e= 0 ;
c119.. x173 - x172 =e= 0 ;
c120.. x174 - x173 =e= 0 ;
c121.. x175 - x174 =e= 0 ;
c122.. x176 - x175 =e= 0 ;
c123.. x54 - x167 =e= 0 ;
c124.. x117 - x169 =e= 0 ;
c125.. x155 - x171 =e= 0 ;
c126.. x3*x137*x137 + 2*x2*x82 =e= 0 ;
c127.. x83 + x3 =e= 0 ;
c128.. x177 - x4 =e= 0 ;
c129.. x6*x136*x136 + 2*x1*x81 =e= 0 ;
c130.. x85 + x6 =e= 0 ;
c131.. x178 - x7 =e= 0 ;
c132.. x9*x138*x138 + 2*x5*x84 =e= 0 ;
c133.. x87 + x9 =e= 0 ;
c134.. x179 - x10 =e= 0 ;
c135.. x12*x139*x139 + 2*x8*x86 =e= 0 ;
c136.. x89 + x12 =e= 0 ;
c137.. x180 - x13 =e= 0 ;
c138.. x15*x140*x140 + 2*x11*x88 =e= 0 ;
c139.. x91 + x15 =e= 0 ;
c140.. x181 - x16 =e= 0 ;
c141.. x18*x141*x141 + 2*x14*x90 =e= 0 ;
c142.. x93 + x18 =e= 0 ;
c143.. x182 - x19 =e= 0 ;
c144.. x21*x142*x142 + 2*x17*x92 =e= 0 ;
c145.. x95 + x21 =e= 0 ;
c146.. x183 - x22 =e= 0 ;
c147.. x24*x143*x143 + 2*x20*x94 =e= 0 ;
c148.. x97 + x24 =e= 0 ;
c149.. x184 - x25 =e= 0 ;
c150.. x27*x144*x144 + 2*x23*x96 =e= 0 ;
c151.. x99 + x27 =e= 0 ;
c152.. x185 - x28 =e= 0 ;
c153.. x30*x145*x145 + 2*x26*x98 =e= 0 ;
c154.. x101 + x30 =e= 0 ;
c155.. x186 - x31 =e= 0 ;
c156.. x33*x146*x146 + 2*x29*x100 =e= 0 ;
c157.. x103 + x33 =e= 0 ;
c158.. x187 - x34 =e= 0 ;
c159.. x36*x147*x147 + 2*x32*x102 =e= 0 ;
c160.. x105 + x36 =e= 0 ;
c161.. x188 - x37 =e= 0 ;
c162.. x39*x148*x148 + 2*x35*x104 =e= 0 ;
c163.. x107 + x39 =e= 0 ;
c164.. x189 - x40 =e= 0 ;
c165.. x42*x149*x149 + 2*x38*x106 =e= 0 ;
c166.. x109 + x42 =e= 0 ;
c167.. x190 - x43 =e= 0 ;
c168.. x45*x150*x150 + 2*x41*x108 =e= 0 ;
c169.. x111 + x45 =e= 0 ;
c170.. x191 - x46 =e= 0 ;
c171.. x48*x151*x151 + 2*x44*x110 =e= 0 ;
c172.. x113 + x48 =e= 0 ;
c173.. x192 - x49 =e= 0 ;
c174.. x51*x152*x152 + 2*x47*x112 =e= 0 ;
c175.. x115 + x51 =e= 0 ;
c176.. x193 - x52 =e= 0 ;
c177.. x55*x153*x153 + 2*x50*x114 =e= 0 ;
c178.. x118 + x55 =e= 0 ;
c179.. x194 - x56 =e= 0 ;
c180.. x58*x154*x154 + 2*x53*x116 =e= 0 ;
c181.. x120 + x58 =e= 0 ;
c182.. x195 - x59 =e= 0 ;
c183.. x61*x156*x156 + 2*x57*x119 =e= 0 ;
c184.. x122 + x61 =e= 0 ;
c185.. x196 - x62 =e= 0 ;
c186.. x64*x157*x157 + 2*x60*x121 =e= 0 ;
c187.. x124 + x64 =e= 0 ;
c188.. x197 - x65 =e= 0 ;
c189.. x67*x158*x158 + 2*x63*x123 =e= 0 ;
c190.. x126 + x67 =e= 0 ;
c191.. x198 - x68 =e= 0 ;
c192.. x70*x159*x159 + 2*x66*x125 =e= 0 ;
c193.. x128 + x70 =e= 0 ;
c194.. x199 - x71 =e= 0 ;
c195.. x73*x160*x160 + 2*x69*x127 =e= 0 ;
c196.. x130 + x73 =e= 0 ;
c197.. x200 - x74 =e= 0 ;
c198.. x76*x161*x161 + 2*x72*x129 =e= 0 ;
c199.. x132 + x76 =e= 0 ;
c200.. x201 - x77 =e= 0 ;
c201.. GAMS_OBJECTIVE =e= x177 + x178 + x179 + x180 + x181 + x182 + x183 + x184 + x185 + x186 + x187 + x188 + x189 + x190 + x191 + x192 + x193 + x194 + x195 + x196 + x197 + x198 + x199 + x200 + x201 + 0 + 0 + 0 + 0 + 0 ;

x1.up = 10;
x2.up = 10;
x4.up = 10;
x5.up = 10;
x7.up = 10;
x8.up = 10;
x10.up = 10;
x11.up = 10;
x13.up = 10;
x14.up = 10;
x16.up = 10;
x17.up = 10;
x19.up = 10;
x20.up = 10;
x22.up = 10;
x23.up = 10;
x25.up = 10;
x26.up = 10;
x28.up = 10;
x29.up = 10;
x31.up = 10;
x32.up = 10;
x34.up = 10;
x35.up = 10;
x37.up = 10;
x38.up = 10;
x40.up = 10;
x41.up = 10;
x43.up = 10;
x44.up = 10;
x46.up = 10;
x47.up = 10;
x49.up = 10;
x50.up = 10;
x52.up = 10;
x53.up = 10;
x54.up = 10;
x56.up = 10;
x57.up = 10;
x59.up = 10;
x60.up = 10;
x62.up = 10;
x63.up = 10;
x65.up = 10;
x66.up = 10;
x68.up = 10;
x69.up = 10;
x71.up = 10;
x72.up = 10;
x74.up = 10;
x75.up = 10;
x77.up = 10;
x78.up = 10;
x79.up = 10;
x80.up = 10;
x81.up = 10;
x82.up = 10;
x84.up = 10;
x86.up = 10;
x88.up = 10;
x90.up = 10;
x92.up = 10;
x94.up = 10;
x96.up = 10;
x98.up = 10;
x100.up = 10;
x102.up = 10;
x104.up = 10;
x106.up = 10;
x108.up = 10;
x110.up = 10;
x112.up = 10;
x114.up = 10;
x116.up = 10;
x117.up = 10;
x119.up = 10;
x121.up = 10;
x123.up = 10;
x125.up = 10;
x127.up = 10;
x129.up = 10;
x131.up = 10;
x133.up = 10;
x134.up = 10;
x135.up = 10;
x155.up = 9;
x166.up = 10;
x167.up = 10;
x168.up = 9.5;
x169.up = 10;
x170.up = 10;
x171.up = 10;
x172.up = 10;
x173.up = 10;
x174.up = 10;
x175.up = 10;
x176.up = 10;
x177.up = 10;
x178.up = 10;
x179.up = 10;
x180.up = 10;
x181.up = 10;
x182.up = 10;
x183.up = 10;
x184.up = 10;
x185.up = 10;
x186.up = 10;
x187.up = 10;
x188.up = 10;
x189.up = 10;
x190.up = 10;
x191.up = 10;
x192.up = 10;
x193.up = 10;
x194.up = 10;
x195.up = 10;
x196.up = 10;
x197.up = 10;
x198.up = 10;
x199.up = 10;
x200.up = 10;
x201.up = 10;
x3.lo = -10;
x3.up = 10;
x6.lo = -10;
x6.up = 10;
x9.lo = -10;
x9.up = 10;
x12.lo = -10;
x12.up = 10;
x15.lo = -10;
x15.up = 10;
x18.lo = -10;
x18.up = 10;
x21.lo = -10;
x21.up = 10;
x24.lo = -10;
x24.up = 10;
x27.lo = -10;
x27.up = 10;
x30.lo = -10;
x30.up = 10;
x33.lo = -10;
x33.up = 10;
x36.lo = -10;
x36.up = 10;
x39.lo = -10;
x39.up = 10;
x42.lo = -10;
x42.up = 10;
x45.lo = -10;
x45.up = 10;
x48.lo = -10;
x48.up = 10;
x51.lo = -10;
x51.up = 10;
x55.lo = -10;
x55.up = 10;
x58.lo = -10;
x58.up = 10;
x61.lo = -10;
x61.up = 10;
x64.lo = -10;
x64.up = 10;
x67.lo = -10;
x67.up = 10;
x70.lo = -10;
x70.up = 10;
x73.lo = -10;
x73.up = 10;
x76.lo = -10;
x76.up = 10;
x83.lo = -10;
x83.up = 10;
x85.lo = -10;
x85.up = 10;
x87.lo = -10;
x87.up = 10;
x89.lo = -10;
x89.up = 10;
x91.lo = -10;
x91.up = 10;
x93.lo = -10;
x93.up = 10;
x95.lo = -10;
x95.up = 10;
x97.lo = -10;
x97.up = 10;
x99.lo = -10;
x99.up = 10;
x101.lo = -10;
x101.up = 10;
x103.lo = -10;
x103.up = 10;
x105.lo = -10;
x105.up = 10;
x107.lo = -10;
x107.up = 10;
x109.lo = -10;
x109.up = 10;
x111.lo = -10;
x111.up = 10;
x113.lo = -10;
x113.up = 10;
x115.lo = -10;
x115.up = 10;
x118.lo = -10;
x118.up = 10;
x120.lo = -10;
x120.up = 10;
x122.lo = -10;
x122.up = 10;
x124.lo = -10;
x124.up = 10;
x126.lo = -10;
x126.up = 10;
x128.lo = -10;
x128.up = 10;
x130.lo = -10;
x130.up = 10;
x132.lo = -10;
x132.up = 10;
x136.lo = 1;
x136.up = 10;
x137.lo = 1;
x137.up = 10;
x138.lo = 1;
x138.up = 10;
x139.lo = 1;
x139.up = 10;
x140.lo = 1;
x140.up = 10;
x141.lo = 1;
x141.up = 10;
x142.lo = 1;
x142.up = 10;
x143.lo = 1;
x143.up = 10;
x144.lo = 1;
x144.up = 10;
x145.lo = 1;
x145.up = 10;
x146.lo = 1;
x146.up = 10;
x147.lo = 1;
x147.up = 10;
x148.lo = 1;
x148.up = 10;
x149.lo = 1;
x149.up = 10;
x150.lo = 1;
x150.up = 10;
x151.lo = 1;
x151.up = 10;
x152.lo = 1;
x152.up = 10;
x153.lo = 1;
x153.up = 10;
x154.lo = 1;
x154.up = 10;
x156.lo = 1;
x156.up = 10;
x157.lo = 1;
x157.up = 10;
x158.lo = 1;
x158.up = 10;
x159.lo = 1;
x159.up = 10;
x160.lo = 1;
x160.up = 10;
x161.lo = 1;
x161.up = 10;
x162.lo = 1;
x162.up = 10;
x163.lo = 1;
x163.up = 10;
x164.lo = 1;
x164.up = 10;
x165.lo = 1;
x165.up = 10;

MODEL GAMS_MODEL /all/ ;
option nlp=scip;
option solprint=off;
option limrow=0;
option limcol=0;
option solvelink=5;

* START USER ADDITIONAL OPTIONS

option reslim=65.33229726555291;
option threads=1;
option optcr=1e-05;
option optca=0;
GAMS_MODEL.optfile=1;

* END USER ADDITIONAL OPTIONS

SOLVE GAMS_MODEL USING nlp minimizing GAMS_OBJECTIVE;

Scalars MODELSTAT 'model status', SOLVESTAT 'solve status';
MODELSTAT = GAMS_MODEL.modelstat;
SOLVESTAT = GAMS_MODEL.solvestat;

Scalar OBJEST 'best objective', OBJVAL 'objective value';
OBJEST = GAMS_MODEL.objest;
OBJVAL = GAMS_MODEL.objval;

Scalar NUMVAR 'number of variables';
NUMVAR = GAMS_MODEL.numvar

Scalar NUMEQU 'number of equations';
NUMEQU = GAMS_MODEL.numequ

Scalar NUMDVAR 'number of discrete variables';
NUMDVAR = GAMS_MODEL.numdvar

Scalar NUMNZ 'number of nonzeros';
NUMNZ = GAMS_MODEL.numnz

Scalar ETSOLVE 'time to execute solve statement';
ETSOLVE = GAMS_MODEL.etsolve


file results /'results.dat'/;
results.nd=15;
results.nw=21;
put results;
put 'SYMBOL  :  LEVEL  :  MARGINAL' /;
put x1 ' ' x1.l ' ' x1.m /;
put x2 ' ' x2.l ' ' x2.m /;
put x3 ' ' x3.l ' ' x3.m /;
put x4 ' ' x4.l ' ' x4.m /;
put x5 ' ' x5.l ' ' x5.m /;
put x6 ' ' x6.l ' ' x6.m /;
put x7 ' ' x7.l ' ' x7.m /;
put x8 ' ' x8.l ' ' x8.m /;
put x9 ' ' x9.l ' ' x9.m /;
put x10 ' ' x10.l ' ' x10.m /;
put x11 ' ' x11.l ' ' x11.m /;
put x12 ' ' x12.l ' ' x12.m /;
put x13 ' ' x13.l ' ' x13.m /;
put x14 ' ' x14.l ' ' x14.m /;
put x15 ' ' x15.l ' ' x15.m /;
put x16 ' ' x16.l ' ' x16.m /;
put x17 ' ' x17.l ' ' x17.m /;
put x18 ' ' x18.l ' ' x18.m /;
put x19 ' ' x19.l ' ' x19.m /;
put x20 ' ' x20.l ' ' x20.m /;
put x21 ' ' x21.l ' ' x21.m /;
put x22 ' ' x22.l ' ' x22.m /;
put x23 ' ' x23.l ' ' x23.m /;
put x24 ' ' x24.l ' ' x24.m /;
put x25 ' ' x25.l ' ' x25.m /;
put x26 ' ' x26.l ' ' x26.m /;
put x27 ' ' x27.l ' ' x27.m /;
put x28 ' ' x28.l ' ' x28.m /;
put x29 ' ' x29.l ' ' x29.m /;
put x30 ' ' x30.l ' ' x30.m /;
put x31 ' ' x31.l ' ' x31.m /;
put x32 ' ' x32.l ' ' x32.m /;
put x33 ' ' x33.l ' ' x33.m /;
put x34 ' ' x34.l ' ' x34.m /;
put x35 ' ' x35.l ' ' x35.m /;
put x36 ' ' x36.l ' ' x36.m /;
put x37 ' ' x37.l ' ' x37.m /;
put x38 ' ' x38.l ' ' x38.m /;
put x39 ' ' x39.l ' ' x39.m /;
put x40 ' ' x40.l ' ' x40.m /;
put x41 ' ' x41.l ' ' x41.m /;
put x42 ' ' x42.l ' ' x42.m /;
put x43 ' ' x43.l ' ' x43.m /;
put x44 ' ' x44.l ' ' x44.m /;
put x45 ' ' x45.l ' ' x45.m /;
put x46 ' ' x46.l ' ' x46.m /;
put x47 ' ' x47.l ' ' x47.m /;
put x48 ' ' x48.l ' ' x48.m /;
put x49 ' ' x49.l ' ' x49.m /;
put x50 ' ' x50.l ' ' x50.m /;
put x51 ' ' x51.l ' ' x51.m /;
put x52 ' ' x52.l ' ' x52.m /;
put x53 ' ' x53.l ' ' x53.m /;
put x54 ' ' x54.l ' ' x54.m /;
put x55 ' ' x55.l ' ' x55.m /;
put x56 ' ' x56.l ' ' x56.m /;
put x57 ' ' x57.l ' ' x57.m /;
put x58 ' ' x58.l ' ' x58.m /;
put x59 ' ' x59.l ' ' x59.m /;
put x60 ' ' x60.l ' ' x60.m /;
put x61 ' ' x61.l ' ' x61.m /;
put x62 ' ' x62.l ' ' x62.m /;
put x63 ' ' x63.l ' ' x63.m /;
put x64 ' ' x64.l ' ' x64.m /;
put x65 ' ' x65.l ' ' x65.m /;
put x66 ' ' x66.l ' ' x66.m /;
put x67 ' ' x67.l ' ' x67.m /;
put x68 ' ' x68.l ' ' x68.m /;
put x69 ' ' x69.l ' ' x69.m /;
put x70 ' ' x70.l ' ' x70.m /;
put x71 ' ' x71.l ' ' x71.m /;
put x72 ' ' x72.l ' ' x72.m /;
put x73 ' ' x73.l ' ' x73.m /;
put x74 ' ' x74.l ' ' x74.m /;
put x75 ' ' x75.l ' ' x75.m /;
put x76 ' ' x76.l ' ' x76.m /;
put x77 ' ' x77.l ' ' x77.m /;
put x78 ' ' x78.l ' ' x78.m /;
put x79 ' ' x79.l ' ' x79.m /;
put x80 ' ' x80.l ' ' x80.m /;
put x81 ' ' x81.l ' ' x81.m /;
put x82 ' ' x82.l ' ' x82.m /;
put x83 ' ' x83.l ' ' x83.m /;
put x84 ' ' x84.l ' ' x84.m /;
put x85 ' ' x85.l ' ' x85.m /;
put x86 ' ' x86.l ' ' x86.m /;
put x87 ' ' x87.l ' ' x87.m /;
put x88 ' ' x88.l ' ' x88.m /;
put x89 ' ' x89.l ' ' x89.m /;
put x90 ' ' x90.l ' ' x90.m /;
put x91 ' ' x91.l ' ' x91.m /;
put x92 ' ' x92.l ' ' x92.m /;
put x93 ' ' x93.l ' ' x93.m /;
put x94 ' ' x94.l ' ' x94.m /;
put x95 ' ' x95.l ' ' x95.m /;
put x96 ' ' x96.l ' ' x96.m /;
put x97 ' ' x97.l ' ' x97.m /;
put x98 ' ' x98.l ' ' x98.m /;
put x99 ' ' x99.l ' ' x99.m /;
put x100 ' ' x100.l ' ' x100.m /;
put x101 ' ' x101.l ' ' x101.m /;
put x102 ' ' x102.l ' ' x102.m /;
put x103 ' ' x103.l ' ' x103.m /;
put x104 ' ' x104.l ' ' x104.m /;
put x105 ' ' x105.l ' ' x105.m /;
put x106 ' ' x106.l ' ' x106.m /;
put x107 ' ' x107.l ' ' x107.m /;
put x108 ' ' x108.l ' ' x108.m /;
put x109 ' ' x109.l ' ' x109.m /;
put x110 ' ' x110.l ' ' x110.m /;
put x111 ' ' x111.l ' ' x111.m /;
put x112 ' ' x112.l ' ' x112.m /;
put x113 ' ' x113.l ' ' x113.m /;
put x114 ' ' x114.l ' ' x114.m /;
put x115 ' ' x115.l ' ' x115.m /;
put x116 ' ' x116.l ' ' x116.m /;
put x117 ' ' x117.l ' ' x117.m /;
put x118 ' ' x118.l ' ' x118.m /;
put x119 ' ' x119.l ' ' x119.m /;
put x120 ' ' x120.l ' ' x120.m /;
put x121 ' ' x121.l ' ' x121.m /;
put x122 ' ' x122.l ' ' x122.m /;
put x123 ' ' x123.l ' ' x123.m /;
put x124 ' ' x124.l ' ' x124.m /;
put x125 ' ' x125.l ' ' x125.m /;
put x126 ' ' x126.l ' ' x126.m /;
put x127 ' ' x127.l ' ' x127.m /;
put x128 ' ' x128.l ' ' x128.m /;
put x129 ' ' x129.l ' ' x129.m /;
put x130 ' ' x130.l ' ' x130.m /;
put x131 ' ' x131.l ' ' x131.m /;
put x132 ' ' x132.l ' ' x132.m /;
put x133 ' ' x133.l ' ' x133.m /;
put x134 ' ' x134.l ' ' x134.m /;
put x135 ' ' x135.l ' ' x135.m /;
put x136 ' ' x136.l ' ' x136.m /;
put x137 ' ' x137.l ' ' x137.m /;
put x138 ' ' x138.l ' ' x138.m /;
put x139 ' ' x139.l ' ' x139.m /;
put x140 ' ' x140.l ' ' x140.m /;
put x141 ' ' x141.l ' ' x141.m /;
put x142 ' ' x142.l ' ' x142.m /;
put x143 ' ' x143.l ' ' x143.m /;
put x144 ' ' x144.l ' ' x144.m /;
put x145 ' ' x145.l ' ' x145.m /;
put x146 ' ' x146.l ' ' x146.m /;
put x147 ' ' x147.l ' ' x147.m /;
put x148 ' ' x148.l ' ' x148.m /;
put x149 ' ' x149.l ' ' x149.m /;
put x150 ' ' x150.l ' ' x150.m /;
put x151 ' ' x151.l ' ' x151.m /;
put x152 ' ' x152.l ' ' x152.m /;
put x153 ' ' x153.l ' ' x153.m /;
put x154 ' ' x154.l ' ' x154.m /;
put x155 ' ' x155.l ' ' x155.m /;
put x156 ' ' x156.l ' ' x156.m /;
put x157 ' ' x157.l ' ' x157.m /;
put x158 ' ' x158.l ' ' x158.m /;
put x159 ' ' x159.l ' ' x159.m /;
put x160 ' ' x160.l ' ' x160.m /;
put x161 ' ' x161.l ' ' x161.m /;
put x162 ' ' x162.l ' ' x162.m /;
put x163 ' ' x163.l ' ' x163.m /;
put x164 ' ' x164.l ' ' x164.m /;
put x165 ' ' x165.l ' ' x165.m /;
put x166 ' ' x166.l ' ' x166.m /;
put x167 ' ' x167.l ' ' x167.m /;
put x168 ' ' x168.l ' ' x168.m /;
put x169 ' ' x169.l ' ' x169.m /;
put x170 ' ' x170.l ' ' x170.m /;
put x171 ' ' x171.l ' ' x171.m /;
put x172 ' ' x172.l ' ' x172.m /;
put x173 ' ' x173.l ' ' x173.m /;
put x174 ' ' x174.l ' ' x174.m /;
put x175 ' ' x175.l ' ' x175.m /;
put x176 ' ' x176.l ' ' x176.m /;
put x177 ' ' x177.l ' ' x177.m /;
put x178 ' ' x178.l ' ' x178.m /;
put x179 ' ' x179.l ' ' x179.m /;
put x180 ' ' x180.l ' ' x180.m /;
put x181 ' ' x181.l ' ' x181.m /;
put x182 ' ' x182.l ' ' x182.m /;
put x183 ' ' x183.l ' ' x183.m /;
put x184 ' ' x184.l ' ' x184.m /;
put x185 ' ' x185.l ' ' x185.m /;
put x186 ' ' x186.l ' ' x186.m /;
put x187 ' ' x187.l ' ' x187.m /;
put x188 ' ' x188.l ' ' x188.m /;
put x189 ' ' x189.l ' ' x189.m /;
put x190 ' ' x190.l ' ' x190.m /;
put x191 ' ' x191.l ' ' x191.m /;
put x192 ' ' x192.l ' ' x192.m /;
put x193 ' ' x193.l ' ' x193.m /;
put x194 ' ' x194.l ' ' x194.m /;
put x195 ' ' x195.l ' ' x195.m /;
put x196 ' ' x196.l ' ' x196.m /;
put x197 ' ' x197.l ' ' x197.m /;
put x198 ' ' x198.l ' ' x198.m /;
put x199 ' ' x199.l ' ' x199.m /;
put x200 ' ' x200.l ' ' x200.m /;
put x201 ' ' x201.l ' ' x201.m /;
put c1 ' ' c1.l ' ' c1.m /;
put c2 ' ' c2.l ' ' c2.m /;
put c3 ' ' c3.l ' ' c3.m /;
put c4 ' ' c4.l ' ' c4.m /;
put c5 ' ' c5.l ' ' c5.m /;
put c6 ' ' c6.l ' ' c6.m /;
put c7 ' ' c7.l ' ' c7.m /;
put c8 ' ' c8.l ' ' c8.m /;
put c9 ' ' c9.l ' ' c9.m /;
put c10 ' ' c10.l ' ' c10.m /;
put c11 ' ' c11.l ' ' c11.m /;
put c12 ' ' c12.l ' ' c12.m /;
put c13 ' ' c13.l ' ' c13.m /;
put c14 ' ' c14.l ' ' c14.m /;
put c15 ' ' c15.l ' ' c15.m /;
put c16 ' ' c16.l ' ' c16.m /;
put c17 ' ' c17.l ' ' c17.m /;
put c18 ' ' c18.l ' ' c18.m /;
put c19 ' ' c19.l ' ' c19.m /;
put c20 ' ' c20.l ' ' c20.m /;
put c21 ' ' c21.l ' ' c21.m /;
put c22 ' ' c22.l ' ' c22.m /;
put c23 ' ' c23.l ' ' c23.m /;
put c24 ' ' c24.l ' ' c24.m /;
put c25 ' ' c25.l ' ' c25.m /;
put c26 ' ' c26.l ' ' c26.m /;
put c27 ' ' c27.l ' ' c27.m /;
put c28 ' ' c28.l ' ' c28.m /;
put c29 ' ' c29.l ' ' c29.m /;
put c30 ' ' c30.l ' ' c30.m /;
put c31 ' ' c31.l ' ' c31.m /;
put c32 ' ' c32.l ' ' c32.m /;
put c33 ' ' c33.l ' ' c33.m /;
put c34 ' ' c34.l ' ' c34.m /;
put c35 ' ' c35.l ' ' c35.m /;
put c36 ' ' c36.l ' ' c36.m /;
put c37 ' ' c37.l ' ' c37.m /;
put c38 ' ' c38.l ' ' c38.m /;
put c39 ' ' c39.l ' ' c39.m /;
put c40 ' ' c40.l ' ' c40.m /;
put c41 ' ' c41.l ' ' c41.m /;
put c42 ' ' c42.l ' ' c42.m /;
put c43 ' ' c43.l ' ' c43.m /;
put c44 ' ' c44.l ' ' c44.m /;
put c45 ' ' c45.l ' ' c45.m /;
put c46 ' ' c46.l ' ' c46.m /;
put c47 ' ' c47.l ' ' c47.m /;
put c48 ' ' c48.l ' ' c48.m /;
put c49 ' ' c49.l ' ' c49.m /;
put c50 ' ' c50.l ' ' c50.m /;
put c51 ' ' c51.l ' ' c51.m /;
put c52 ' ' c52.l ' ' c52.m /;
put c53 ' ' c53.l ' ' c53.m /;
put c54 ' ' c54.l ' ' c54.m /;
put c55 ' ' c55.l ' ' c55.m /;
put c56 ' ' c56.l ' ' c56.m /;
put c57 ' ' c57.l ' ' c57.m /;
put c58 ' ' c58.l ' ' c58.m /;
put c59 ' ' c59.l ' ' c59.m /;
put c60 ' ' c60.l ' ' c60.m /;
put c61 ' ' c61.l ' ' c61.m /;
put c62 ' ' c62.l ' ' c62.m /;
put c63 ' ' c63.l ' ' c63.m /;
put c64 ' ' c64.l ' ' c64.m /;
put c65 ' ' c65.l ' ' c65.m /;
put c66 ' ' c66.l ' ' c66.m /;
put c67 ' ' c67.l ' ' c67.m /;
put c68 ' ' c68.l ' ' c68.m /;
put c69 ' ' c69.l ' ' c69.m /;
put c70 ' ' c70.l ' ' c70.m /;
put c71 ' ' c71.l ' ' c71.m /;
put c72 ' ' c72.l ' ' c72.m /;
put c73 ' ' c73.l ' ' c73.m /;
put c74 ' ' c74.l ' ' c74.m /;
put c75 ' ' c75.l ' ' c75.m /;
put c76 ' ' c76.l ' ' c76.m /;
put c77 ' ' c77.l ' ' c77.m /;
put c78 ' ' c78.l ' ' c78.m /;
put c79 ' ' c79.l ' ' c79.m /;
put c80 ' ' c80.l ' ' c80.m /;
put c81 ' ' c81.l ' ' c81.m /;
put c82 ' ' c82.l ' ' c82.m /;
put c83 ' ' c83.l ' ' c83.m /;
put c84 ' ' c84.l ' ' c84.m /;
put c85 ' ' c85.l ' ' c85.m /;
put c86 ' ' c86.l ' ' c86.m /;
put c87 ' ' c87.l ' ' c87.m /;
put c88 ' ' c88.l ' ' c88.m /;
put c89 ' ' c89.l ' ' c89.m /;
put c90 ' ' c90.l ' ' c90.m /;
put c91 ' ' c91.l ' ' c91.m /;
put c92 ' ' c92.l ' ' c92.m /;
put c93 ' ' c93.l ' ' c93.m /;
put c94 ' ' c94.l ' ' c94.m /;
put c95 ' ' c95.l ' ' c95.m /;
put c96 ' ' c96.l ' ' c96.m /;
put c97 ' ' c97.l ' ' c97.m /;
put c98 ' ' c98.l ' ' c98.m /;
put c99 ' ' c99.l ' ' c99.m /;
put c100 ' ' c100.l ' ' c100.m /;
put c101 ' ' c101.l ' ' c101.m /;
put c102 ' ' c102.l ' ' c102.m /;
put c103 ' ' c103.l ' ' c103.m /;
put c104 ' ' c104.l ' ' c104.m /;
put c105 ' ' c105.l ' ' c105.m /;
put c106 ' ' c106.l ' ' c106.m /;
put c107 ' ' c107.l ' ' c107.m /;
put c108 ' ' c108.l ' ' c108.m /;
put c109 ' ' c109.l ' ' c109.m /;
put c110 ' ' c110.l ' ' c110.m /;
put c111 ' ' c111.l ' ' c111.m /;
put c112 ' ' c112.l ' ' c112.m /;
put c113 ' ' c113.l ' ' c113.m /;
put c114 ' ' c114.l ' ' c114.m /;
put c115 ' ' c115.l ' ' c115.m /;
put c116 ' ' c116.l ' ' c116.m /;
put c117 ' ' c117.l ' ' c117.m /;
put c118 ' ' c118.l ' ' c118.m /;
put c119 ' ' c119.l ' ' c119.m /;
put c120 ' ' c120.l ' ' c120.m /;
put c121 ' ' c121.l ' ' c121.m /;
put c122 ' ' c122.l ' ' c122.m /;
put c123 ' ' c123.l ' ' c123.m /;
put c124 ' ' c124.l ' ' c124.m /;
put c125 ' ' c125.l ' ' c125.m /;
put c126 ' ' c126.l ' ' c126.m /;
put c127 ' ' c127.l ' ' c127.m /;
put c128 ' ' c128.l ' ' c128.m /;
put c129 ' ' c129.l ' ' c129.m /;
put c130 ' ' c130.l ' ' c130.m /;
put c131 ' ' c131.l ' ' c131.m /;
put c132 ' ' c132.l ' ' c132.m /;
put c133 ' ' c133.l ' ' c133.m /;
put c134 ' ' c134.l ' ' c134.m /;
put c135 ' ' c135.l ' ' c135.m /;
put c136 ' ' c136.l ' ' c136.m /;
put c137 ' ' c137.l ' ' c137.m /;
put c138 ' ' c138.l ' ' c138.m /;
put c139 ' ' c139.l ' ' c139.m /;
put c140 ' ' c140.l ' ' c140.m /;
put c141 ' ' c141.l ' ' c141.m /;
put c142 ' ' c142.l ' ' c142.m /;
put c143 ' ' c143.l ' ' c143.m /;
put c144 ' ' c144.l ' ' c144.m /;
put c145 ' ' c145.l ' ' c145.m /;
put c146 ' ' c146.l ' ' c146.m /;
put c147 ' ' c147.l ' ' c147.m /;
put c148 ' ' c148.l ' ' c148.m /;
put c149 ' ' c149.l ' ' c149.m /;
put c150 ' ' c150.l ' ' c150.m /;
put c151 ' ' c151.l ' ' c151.m /;
put c152 ' ' c152.l ' ' c152.m /;
put c153 ' ' c153.l ' ' c153.m /;
put c154 ' ' c154.l ' ' c154.m /;
put c155 ' ' c155.l ' ' c155.m /;
put c156 ' ' c156.l ' ' c156.m /;
put c157 ' ' c157.l ' ' c157.m /;
put c158 ' ' c158.l ' ' c158.m /;
put c159 ' ' c159.l ' ' c159.m /;
put c160 ' ' c160.l ' ' c160.m /;
put c161 ' ' c161.l ' ' c161.m /;
put c162 ' ' c162.l ' ' c162.m /;
put c163 ' ' c163.l ' ' c163.m /;
put c164 ' ' c164.l ' ' c164.m /;
put c165 ' ' c165.l ' ' c165.m /;
put c166 ' ' c166.l ' ' c166.m /;
put c167 ' ' c167.l ' ' c167.m /;
put c168 ' ' c168.l ' ' c168.m /;
put c169 ' ' c169.l ' ' c169.m /;
put c170 ' ' c170.l ' ' c170.m /;
put c171 ' ' c171.l ' ' c171.m /;
put c172 ' ' c172.l ' ' c172.m /;
put c173 ' ' c173.l ' ' c173.m /;
put c174 ' ' c174.l ' ' c174.m /;
put c175 ' ' c175.l ' ' c175.m /;
put c176 ' ' c176.l ' ' c176.m /;
put c177 ' ' c177.l ' ' c177.m /;
put c178 ' ' c178.l ' ' c178.m /;
put c179 ' ' c179.l ' ' c179.m /;
put c180 ' ' c180.l ' ' c180.m /;
put c181 ' ' c181.l ' ' c181.m /;
put c182 ' ' c182.l ' ' c182.m /;
put c183 ' ' c183.l ' ' c183.m /;
put c184 ' ' c184.l ' ' c184.m /;
put c185 ' ' c185.l ' ' c185.m /;
put c186 ' ' c186.l ' ' c186.m /;
put c187 ' ' c187.l ' ' c187.m /;
put c188 ' ' c188.l ' ' c188.m /;
put c189 ' ' c189.l ' ' c189.m /;
put c190 ' ' c190.l ' ' c190.m /;
put c191 ' ' c191.l ' ' c191.m /;
put c192 ' ' c192.l ' ' c192.m /;
put c193 ' ' c193.l ' ' c193.m /;
put c194 ' ' c194.l ' ' c194.m /;
put c195 ' ' c195.l ' ' c195.m /;
put c196 ' ' c196.l ' ' c196.m /;
put c197 ' ' c197.l ' ' c197.m /;
put c198 ' ' c198.l ' ' c198.m /;
put c199 ' ' c199.l ' ' c199.m /;
put c200 ' ' c200.l ' ' c200.m /;
put c201 ' ' c201.l ' ' c201.m /;
put GAMS_OBJECTIVE ' ' GAMS_OBJECTIVE.l ' ' GAMS_OBJECTIVE.m;

file statresults /'resultsstat.dat'/;
statresults.nd=15;
statresults.nw=21;
put statresults;
put 'SYMBOL   :   VALUE' /;
put 'MODELSTAT' ' ' MODELSTAT /;

put 'SOLVESTAT' ' ' SOLVESTAT /;

put 'OBJEST' ' ' OBJEST /;

put 'OBJVAL' ' ' OBJVAL /;

put 'NUMVAR' ' ' NUMVAR /;

put 'NUMEQU' ' ' NUMEQU /;

put 'NUMDVAR' ' ' NUMDVAR /;

put 'NUMNZ' ' ' NUMNZ /;

put 'ETSOLVE' ' ' ETSOLVE /;
