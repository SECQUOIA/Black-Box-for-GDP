# D-SDA 절대 개선 허용오차 변경 실험

이 디렉터리는 기존 실행자료를 보존하면서 Dantzig에서 D-SDA만 다시 탐색하기 위한 독립 실행 소스이다.
원래 LD-SDA 구현 전체를 재현했다고 주장하지 않는다.
원고, Overleaf, 기존 그림, 대표 결과와 기존 성공 판정은 수정하지 않는다.
이번 작업에서는 commit, push, PR 생성, 병합과 CI 실행을 하지 않는다.

채택 기준은 PR #52의 review/cstr15-dantzig-results 브랜치 revision 5e94df72b472a5039c35518b685de6080cf8d67f와 results/column_publication_20261025/tables/run_records.csv이다.
작업 시작 시 원래 체크아웃 revision은 2d1e2e49158d924f1fe589a55f7d7f210bf5f28b이다.
새 코드는 commit하지 않으므로 실제 실행 소스는 기준 revision과 파일별 SHA256으로 식별한다.
Grid 21개 함수 × 예산 5개 × seed 10개는 1050건이고 Process 14개 조건 × seed 10개는 140건이다.
Process는 최신 CSTR30 초기화 결과와 Column 논리 도메인 [8..15]×[1..8] 및 예산 13을 사용한다.
원본 Grid 실행 revision eeb560059c7001ad82c13b9249168531af073f95의 grid_dsda.py와 채택된 Process 보관 사본의 SHA256이 모두 같다.
원본 코드와 실험 코드 차이는 source_change.diff에 저장한다.

분리된 improvement_abs_tol을 지정한 경우 최소화 개선 조건은 old_value - new_value > improvement_abs_tol이며 이번 값은 1e-5이다.
이웃 탐색, 방향 탐색과 기존 better 함수에 연결된 best_seen 갱신 및 다중 시작점 best_run 갱신에 같은 개선 기준을 사용한다.
개선 설정을 지정하지 않으면 기존 비교 연산을 그대로 사용하며 기존 호출의 기본 동작을 바꾸지 않는다.
동률 판정과 tie-breaking 및 Grid 목표값 종료의 tol은 기존 1e-12를 유지한다.
관측 최솟값 incumbent는 허용오차로 필터링하지 않으며 모든 평가값을 반영한다.
기존 공통 분석의 hit 함수를 원본 그대로 가져오며 결과 성공 기준은 모든 방법에 동일하다.
상대 개선 조건은 추가하지 않는다.

초기 구성의 순서와 seed 및 예산을 보관된 spec에서 읽으며 새로 추출하지 않는다.
Grid는 목적값으로 순위를 매긴 초기점들을 차례로 사용하고 Process는 수용된 초기점 중 최선점 하나를 사용한다.
초기 세 점은 callback 예산에 포함하고 선택한 시작점은 캐시된 초기값을 재사용한다.
선택된 이웃을 방향 탐색의 첫 점으로 다시 평가하지 않는 기존 처리도 유지한다.
그 밖의 반복 평가에는 캐시로 예산을 할인하지 않는다.
Process의 미수용 응답은 유한 패널티 1e6이며 마지막 callback은 기록 후 BudgetStop으로 종료한다.
Process watchdog은 기존 2100초이고 Grid에는 원래 실행에 없던 watchdog을 새로 추가하지 않는다.
Dynamic에서 원래 입력표에 없던 논리 제외점은 후속 보관 표의 저장된 상태로 존재를 검증하고 원래 Oracle의 응답을 유지한다.
모든 후보 영역에 저장된 상태가 있는지 사전 검사하며 값이 빠지면 즉시 중단하고 NLP로 보충하지 않는다.

server 모드는 Dantzig 호스트, 지정 저장소 origin, 기존 Python 경로와 Python 및 NumPy·SciPy·pandas 버전을 확인한다.
사용자 요청에 따라 허용된 CPU 하나에 고정해 공유 실행하며 CPU 2를 우선 사용하고 가용성 대기는 하지 않는다.
CPU 공유로 인한 경합이 탐색 시간에 포함되므로 기존 대비 시간 차이를 허용오차 변경의 효과로 해석하지 않는다.
기존 작업을 종료하지 않으며 watchdog은 이번 작업이 만든 개별 worker 프로세스 그룹만 종료할 수 있다.
worker 내부는 solver와 모델 및 다른 최적화 방법의 import와 하위 프로세스 생성을 차단한다.
서버에서 단위 테스트 및 Grid·CSTR30·Column smoke를 통과한 다음 1190건을 실행한다.
실패 seed는 바꾸거나 분모에서 제외하지 않는다.

paired_comparison.csv에는 기존과 새 성공 범주, 목적값, callback 수, 최초 목표 도달 callback, 종료 사유와 경로 및 새 탐색 시간을 기록한다.
원래 Grid 종료 사유가 구조화되어 있지 않은 경우 원래 기록의 한계와 기본 설정 검증 재실행의 종료 사유를 구분한다.
Process의 BudgetStop으로 정상 반환 결과가 없을 때는 부분 이동 경로를 읽기 전용 Python 예외 추적으로 보관한다.
새 탐색 시간에는 기록 및 예외 추적 비용이 포함되므로 이를 곧바로 알고리즘의 속도 차이로 해석하지 않는다.
Grid 예산별 표, Process 조건별 표, Process 및 CSTR 전체 설명용 표와 기존 다른 방법을 고정한 비교표를 생성한다.
출력 디렉터리는 실제 서버 실행 UTC 날짜와 시각 및 PID로 새로 생성한다.
기존 실행자료를 덮어쓰지 않으며 비교 결과를 대표 결과로 자동 채택하지 않는다.

로컬 준비 재현 명령은 다음과 같다.

```bash
python experiments/dsda_abs1e5/build.py --output /absolute/new/input_directory
python /absolute/new/input_directory/test_experiment.py
python /absolute/new/input_directory/run.py verify
python /absolute/new/input_directory/run.py legacy --output /absolute/new/legacy_validation
python /absolute/new/input_directory/run.py smoke --output /absolute/new/smoke_validation
```

서버 실행 명령은 다음과 같으며 input_directory는 전송 후 압축을 푼 절대 경로이다.

```bash
/local/scratch/a/lee4382/repository/RBFopt_Test/.venv-dantzig/bin/python /absolute/input_directory/run.py server --repo /local/scratch/a/lee4382/repository/RBFopt_Test
```

완료되면 RETURN_ARCHIVE 줄의 ZIP을 SCP로 로컬에 가져와 OUTPUT_SHA256SUMS.json을 검증하고 결과를 검토한다.
