#!/usr/bin/env python3
"""Record the observed Dantzig kernel transition without changing solver code."""

import argparse
import copy
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform


OLD = "Linux-5.15.0-323.211.3.4.el9uek.x86_64-x86_64-with-glibc2.34"
NEW = "Linux-5.15.0-325.220.5.el9uek.x86_64-x86_64-with-glibc2.34"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def durable_write(path, data):
    with path.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()


def apply_transition(directory, apply=False, live_platform=None):
    directory = Path(directory).resolve()
    with (directory / ".lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        path = directory / "run.json"
        original = path.read_bytes()
        run = json.loads(original)
        if run.get("kind") != "fmqa_qhd_pytorch_sa_v1":
            raise ValueError("Unexpected experiment kind")
        old = run["runtime"]["fmqa"]
        new_bytes = (directory / "runtime_fmqa.json").read_bytes()
        new = json.loads(new_bytes)
        actual = platform.platform() if live_platform is None else live_platform
        if new.get("platform") != NEW or actual != NEW:
            raise ValueError("The current host must match the observed new Dantzig kernel")
        if old == new and run.get("runtime_transitions"):
            print("ALREADY_RECORDED: runtime matches; use the original resume command")
            return
        if old.get("platform") != OLD:
            raise ValueError("The saved platform differs from the observed original kernel")
        comparable = copy.deepcopy(old)
        comparable["platform"] = NEW
        if comparable != new:
            raise ValueError("More than the kernel changed; no modification was made")

        completed = []
        for spec in run["plan"]:
            job = directory / "jobs" / spec["job_id"]
            process_file = job / "process.json"
            if process_file.exists():
                pid = json.loads(process_file.read_bytes())["pid"]
                try:
                    command = Path(f"/proc/{pid}/cmdline").read_bytes()
                except FileNotFoundError:
                    command = b""
                if str(directory).encode() in command and job.name.encode() in command:
                    raise ValueError(f"Worker {pid} is still active; no modification was made")
            if (job / "terminal.json").exists() and (job / "result.json").exists():
                if json.loads((job / "result.json").read_bytes()).get("status") == "completed":
                    completed.append(spec["job_id"])

        print(f"CONFIRMED_KERNEL_ONLY: {OLD} -> {NEW}")
        print(f"COMPLETED_JOBS_RETAINED={len(completed)}")
        if not apply:
            print("CHECK_ONLY: add --apply to record this transition")
            return

        changes = directory / "runtime_changes"
        changes.mkdir(exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%fZ")
        audit_dir = changes / stamp
        audit_dir.mkdir()
        durable_write(audit_dir / "run.before.json", original)
        durable_write(audit_dir / "runtime.after.json", new_bytes)
        helper = Path(__file__).read_bytes()
        durable_write(audit_dir / "kernel_transition.py", helper)
        transition = {
            "utc": datetime.now(timezone.utc).isoformat(),
            "reason": "Observed Dantzig kernel update; all other recorded runtime fields match exactly",
            "old_platform": OLD,
            "new_platform": NEW,
            "previous_run_file": (audit_dir / "run.before.json").relative_to(directory).as_posix(),
            "previous_run_sha256": digest(original),
            "current_runtime_file": (audit_dir / "runtime.after.json").relative_to(directory).as_posix(),
            "current_runtime_sha256": digest(new_bytes),
            "helper_sha256": digest(helper),
            "completed_job_ids_before_transition": completed,
            "timing_note": "Retain the kernel transition when comparing runtimes; identical timings are not assumed",
        }
        durable_write(audit_dir / "transition.json", encoded(transition))
        run["runtime"]["fmqa"] = new
        run.setdefault("runtime_transitions", []).append(transition)
        replacement = audit_dir / "run.after.json.tmp"
        durable_write(replacement, encoded(run))
        os.chmod(replacement, path.stat().st_mode & 0o777)
        os.replace(replacement, path)
        print(f"RECORDED={audit_dir}")
        print("READY_TO_RESUME: original sources, settings, plan and job files are unchanged")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_dir", type=Path)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    try:
        apply_transition(args.run_dir, args.apply)
    except (ValueError, OSError, KeyError) as error:
        parser.exit(1, f"STOPPED: {error}\n")


if __name__ == "__main__":
    main()
