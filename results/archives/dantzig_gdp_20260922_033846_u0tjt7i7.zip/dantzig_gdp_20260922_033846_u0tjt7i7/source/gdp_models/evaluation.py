"""Solve and time one actual NLP, with conservative acceptance of its result."""

import math
from time import perf_counter

import pyomo.environ as pyo
from pyomo.common.errors import InfeasibleConstraintException
from pyomo.version import version as pyomo_version

from .models import dynamic_template, integer_point, prepare_nlp
from .preflight import SetupError


def primal_violation(prepared):
    """Maximum absolute bound/constraint violation, including presolved rows."""
    worst = 0.0
    m = prepared.model
    for constraint in prepared.constraints:
        body = pyo.value(constraint.body, exception=False)
        if body is None or not math.isfinite(body):
            return math.inf
        if constraint.has_lb():
            worst = max(worst, pyo.value(constraint.lower) - body)
        if constraint.has_ub():
            worst = max(worst, body - pyo.value(constraint.upper))
    for var in m.component_data_objects(pyo.Var, active=True, descend_into=True):
        # Unused variables can remain uninitialized; every constraint/objective
        # expression is checked separately for uninitialized/nonfinite values.
        if var.value is None:
            continue
        if not math.isfinite(var.value):
            return math.inf
        if var.has_lb():
            worst = max(worst, pyo.value(var.lb) - var.value)
        if var.has_ub():
            worst = max(worst, var.value - pyo.value(var.ub))
    return worst


def accepted_solution(termination, objective, violation, tolerance):
    return bool(
        termination in {"optimal", "locallyOptimal", "globallyOptimal"}
        and objective is not None and math.isfinite(objective)
        and math.isfinite(violation) and violation <= tolerance
    )


def evaluate_point(case, point, *, solver, cstr_size=5, initialization="auto",
                   time_limit=60.0, feasibility_tolerance=1e-5, executable=None,
                   tee=False):
    """Return a JSON-compatible result; solver choice is deliberately explicit.

    ``objective`` is populated only for accepted solutions. A time-limited or
    infeasible candidate is recorded separately and never returned as a valid
    black-box objective. Errors configuring sources/dependencies propagate.
    Each call builds a fresh NLP; there is no objective cache or warm start.
    Dynamic clones a single discretized template. Its one-time preparation
    is excluded from point timings and recorded separately by the batch.
    """
    if solver not in {"ipopt", "baron"}:
        raise ValueError("solver must be ipopt or baron (via GAMS)")
    if not math.isfinite(time_limit) or time_limit <= 0:
        raise ValueError("time_limit must be finite and positive")
    if not math.isfinite(feasibility_tolerance) or feasibility_tolerance <= 0:
        raise ValueError("feasibility_tolerance must be finite and positive")
    if case == "dynamic":
        dynamic_template()  # Outside per-point timing, even for the first point.
    started = perf_counter()
    point = integer_point(point)
    report = {
        "case": case, "point": list(point), "solver": solver,
        "cstr_size": cstr_size if case == "cstr" else None,
        "initialization_requested": initialization,
        "pyomo_version": pyomo_version, "time_limit_s": time_limit,
        "feasibility_tolerance": feasibility_tolerance,
        "accepted": False, "objective": None, "candidate_objective": None,
        "max_primal_violation": None, "solve_wall_s": 0.0,
    }
    try:
        prepared = prepare_nlp(case, point, cstr_size=cstr_size, initialization=initialization)
    except InfeasibleConstraintException as error:
        report.update(status="preprocessing_infeasible", termination="not_solved",
                      message=str(error), total_wall_s=perf_counter() - started)
        return report
    report.update(prepared.metadata)
    report.update(prepared.timings)
    m = prepared.model
    factory_kwargs = {"executable": executable} if executable else {}
    optimizer = pyo.SolverFactory("gams" if solver == "baron" else "ipopt", **factory_kwargs)
    if solver == "baron":
        options = {"solver": "baron", "add_options": [
            f"option reslim={time_limit};", "option optcr=0.00001;"
        ]}
    else:
        options = {"options": {"max_cpu_time": time_limit, "max_iter": 3000,
                               "bound_relax_factor": 0, "tol": 1e-8}}
    report["solver_options"] = options
    if executable:
        report["solver_executable"] = str(executable)
    solve_started = perf_counter()
    try:
        result = optimizer.solve(m, tee=tee, **options)
    except ImportError as error:
        raise SetupError(f"Missing/broken solver dependency: {error}") from error
    except Exception as error:
        report.update(status="solver_error", termination="error", message=str(error),
                      solve_wall_s=perf_counter() - solve_started,
                      total_wall_s=perf_counter() - started)
        return report
    report["solve_wall_s"] = perf_counter() - solve_started
    termination = str(result.solver.termination_condition)
    objective = pyo.value(m.obj, exception=False)
    violation = primal_violation(prepared)
    accepted = (str(result.solver.status) != "error" and
                accepted_solution(termination, objective, violation, feasibility_tolerance))
    report.update(
        status="accepted" if accepted else "rejected", accepted=accepted,
        objective=float(objective) if accepted else None,
        candidate_objective=float(objective) if objective is not None and math.isfinite(objective) else None,
        termination=termination, solver_status=str(result.solver.status),
        message=str(result.solver.message),
        max_primal_violation=violation if math.isfinite(violation) else None,
        total_wall_s=perf_counter() - started,
    )
    return report
