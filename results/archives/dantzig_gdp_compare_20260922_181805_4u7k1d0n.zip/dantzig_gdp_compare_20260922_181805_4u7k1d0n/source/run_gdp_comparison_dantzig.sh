#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPOSITORY="${GDP_REPOSITORY:-/local/scratch/a/lee4382/repository/RBFopt_Test}"
RUN_PYTHON="${GDP_PYTHON:-$REPOSITORY/.venv-dantzig-gdp/bin/python}"
MODE="${1:-run}"
if [[ $# -gt 0 ]]; then shift; fi
if [[ ! -x "$RUN_PYTHON" ]]; then
  printf 'GDP environment not found: %s. Set GDP_PYTHON to the existing GDP Python.\n' "$RUN_PYTHON" >&2
  exit 2
fi
export PYTHONPATH="$ROOT" PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1
export RBFOPT_GDP_SOURCES="${RBFOPT_GDP_SOURCES:-$REPOSITORY/external}"
export PYOMO_CONFIG_DIR="${PYOMO_CONFIG_DIR:-$REPOSITORY/.pyomo-gdp-comparison}"
export GAMS_BIN="${GAMS_BIN:-/package/gams/52.2/gams}"
cd "$ROOT"
if [[ "$MODE" == setup ]]; then
  "$RUN_PYTHON" -m pip install -r requirements-gdp-comparison.txt
fi
exec "$RUN_PYTHON" "$ROOT/gdp_compare.py" "$MODE" --output-root "$REPOSITORY/results" "$@"
