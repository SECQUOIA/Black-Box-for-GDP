#!/usr/bin/env bash
set -Eeuo pipefail

# One process, one CPU, three GAMS solvers; Dynamic discretization is shared.
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MODE="${1:-run}"
if [[ $# -gt 0 ]]; then shift; fi
case "$MODE" in
  check|run)
    exec bash "$ROOT/run_gdp_dantzig.sh" "$MODE" \
      --solvers gams_ipopt,ipopth,conopt \
      --expected-gams-version "${GDP_GAMS_VERSION:-52.2}" "$@" ;;
  setup|resume|pack)
    exec bash "$ROOT/run_gdp_dantzig.sh" "$MODE" "$@" ;;
  help|-h|--help)
    printf '%s\n' 'Usage: bash run_gdp_gams_dantzig.sh {setup|check|run|resume|pack} [options]' \
      'Default: GAMS 52.2; IPOPT (MUMPS), IPOPTH (MA27), CONOPT; all process cases.' \
      'GAMS executable: GAMS_BIN, GAMS_DIR/gams, or gams on PATH.' \
      'Use --cases cstr to compare CSTR only; --initialization default selects constructor starts.' \
      'All solver results are in one results/dantzig_gdp_gams_DATE_ID.zip.' ;;
  *) printf 'Unknown mode: %s\n' "$MODE" >&2; exit 2 ;;
esac
