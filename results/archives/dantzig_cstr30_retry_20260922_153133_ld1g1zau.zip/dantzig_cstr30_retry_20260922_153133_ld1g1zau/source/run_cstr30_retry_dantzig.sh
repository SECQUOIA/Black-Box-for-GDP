#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPOSITORY="${GDP_REPOSITORY:-/local/scratch/a/lee4382/repository/RBFopt_Test}"
RUN_PYTHON="${GDP_PYTHON:-$REPOSITORY/.venv-dantzig-gdp/bin/python}"
MODE="${1:-run}"
if [[ $# -gt 0 ]]; then shift; fi
case "$MODE" in
  run|check|pack) ;;
  help|-h|--help)
    printf '%s\n' 'Usage: bash run_cstr30_retry_dantzig.sh {run|check|pack} [options]' \
      'Runs only seven CSTR30 points using GAMS 52.2/IPOPT and feasible initialization.' \
      'Each point has a separate Python process. Optional single point: --point 5,3' \
      'Default repository: /local/scratch/a/lee4382/repository/RBFopt_Test' \
      'Overrides: GDP_REPOSITORY, GDP_PYTHON, GAMS_BIN, GDP_GAMS_VERSION.'
    exit 0 ;;
  *) printf 'Unknown mode: %s\n' "$MODE" >&2; exit 2 ;;
esac
if [[ ! -x "$RUN_PYTHON" ]]; then
  printf 'GDP Python not found: %s. Set GDP_PYTHON or use the existing GDP environment.\n' "$RUN_PYTHON" >&2
  exit 2
fi
if [[ -z "${GAMS_BIN:-}" && -x /package/gams/52.2/gams ]]; then
  export GAMS_BIN=/package/gams/52.2/gams
fi
export PYTHONPATH="$ROOT" PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1 MPLBACKEND=Agg
export RBFOPT_GDP_SOURCES="${RBFOPT_GDP_SOURCES:-$REPOSITORY/external}"
export OMP_NUM_THREADS=1 OMP_THREAD_LIMIT=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export BLIS_NUM_THREADS=1 GOTO_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
export NUMEXPR_NUM_THREADS=1 NUMEXPR_MAX_THREADS=1 OMP_DYNAMIC=FALSE MKL_DYNAMIC=FALSE
cd "$ROOT"
exec "$RUN_PYTHON" "$ROOT/cstr30_retry.py" "$MODE" --output-root "$REPOSITORY/results" "$@"
