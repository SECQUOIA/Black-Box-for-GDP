$offlisting
$offdigit

EQUATIONS
	c1
	c2
	c3
	c4
	c5
	c6
	c7
	c8
	c9
	c10
	c11
	c12
	c13
	c14
	c15
	c16
	c17
	c18
	c19
	c20
	c21
	c22
	c23
	c24
	c25
	c26
	c27
	c28
	c29
	c30
	c31
	c32
	c33
	c34
	c35
	c36
	c37
	c38
	c39
	c40
	c41
	c42
	c43
	c44
	c45
	c46
	c47
	c48
	c49
	c50
	c51
	c52
	c53
	c54
	c55
	c56
	c57
	c58
	c59
	c60
	c61
	c62
	c63
	c64
	c65
	c66
	c67
	c68
	c69
	c70
	c71
	c72
	c73
	c74
	c75
	c76
	c77
	c78
	c79
	c80
	c81
	c82
	c83
	c84
	c85
	c86
	c87
	c88
	c89
	c90
	c91
	c92
	c93
	c94
	c95
	c96
	c97
	c98
	c99
	c100
	c101
	c102
	c103
	c104
	c105
	c106
	c107
	c108
	c109
	c110
	c111
	c112
	c113
	c114
	c115
	c116
	c117
	c118
	c119
	c120
	c121
	c122
	c123
	c124
	c125
	c126_lo
	c127_lo
	c128_lo
	c129_lo
	c130_lo
	c131_lo
	c132_lo
	c133_lo
	c134_lo
	c135_lo
	c136_lo
	c137_lo
	c138_lo
	c139_lo
	c140_lo
	c141_lo
	c142_lo
	c143_lo
	c144_lo
	c145_lo
	c146_lo
	c147_lo
	c148_lo
	c149_lo
	c150_lo
	c151_lo
	c152_lo
	c153_lo
	c154_lo
	c155_lo
	c156
	c157
	c158
	c159_lo
	c160_lo
	c161_lo
	c162_lo
	c163_lo
	c164_lo
	c165_lo
	c166_lo
	c167_lo
	c168_lo
	c169_lo
	c170_lo
	c171_lo
	c172_lo
	c173_lo
	c174_lo
	c175_lo
	c176_lo
	c177_lo
	c178_lo
	c179_lo
	c180_lo
	c181_lo
	c182_lo
	c183_lo
	c184_lo
	c185_lo
	c186_lo
	c187_lo
	c188_lo
	c189_lo
	c190_lo
	c191_lo
	c192_lo
	c193_lo
	c194_lo
	c195_lo
	c196_lo
	c197_lo
	c198_lo
	c199_lo
	c200_lo
	c201_lo
	c202_lo
	c203_lo
	c204_lo
	c205_lo
	c206_lo
	c207_lo
	c208_lo
	c209_lo
	c210_lo
	c211_lo
	c212_lo
	c213_lo
	c214_lo
	c215_lo
	c216_lo
	c217_lo
	c218_lo
	c219_lo
	c220_lo
	c221_lo
	c222_lo
	c223_lo
	c224_lo
	c225_lo
	c226_lo
	c227_lo
	c228_lo
	c229_lo
	c230_lo
	c231_lo
	c232_lo
	c233_lo
	c234_lo
	c235_lo
	c236_lo
	c237_lo
	c238_lo
	c239_lo
	c240_lo
	c241_lo
	c242_lo
	c243_lo
	c244_lo
	c245_lo
	c246_lo
	c247_lo
	c248_lo
	c249_lo
	c250_lo
	c251_lo
	c252_lo
	c253_lo
	c254_lo
	c255_lo
	c256_lo
	c257_lo
	c258_lo
	c259_lo
	c260_lo
	c261_lo
	c262_lo
	c263_lo
	c264_lo
	c265_lo
	c266_lo
	c267_lo
	c268_lo
	c269_lo
	c270_lo
	c271_lo
	c272_lo
	c273_lo
	c274_lo
	c275_lo
	c276_lo
	c277_lo
	c278_lo
	c279_lo
	c280_lo
	c281_lo
	c282_lo
	c283_lo
	c284_lo
	c285_lo
	c286_lo
	c287_lo
	c288_lo
	c289_lo
	c290_lo
	c291_lo
	c292_lo
	c293_lo
	c294_lo
	c295_lo
	c296_lo
	c297_lo
	c298_lo
	c299_lo
	c300_lo
	c301_lo
	c302_lo
	c303_lo
	c304_lo
	c305_lo
	c306_lo
	c307_lo
	c308_lo
	c309_lo
	c310_lo
	c311_lo
	c312_lo
	c313_lo
	c314_lo
	c315_lo
	c316_lo
	c317_lo
	c318_lo
	c319_lo
	c320_lo
	c321_lo
	c322_lo
	c323_lo
	c324_lo
	c325_lo
	c326_lo
	c327_lo
	c328_lo
	c329_lo
	c330_lo
	c331_lo
	c332_lo
	c333_lo
	c334_lo
	c335_lo
	c336_lo
	c337_lo
	c338_lo
	c339_lo
	c340_lo
	c341_lo
	c342_lo
	c343_lo
	c344_lo
	c345_lo
	c346_lo
	c347_lo
	c348_lo
	c349_lo
	c350_lo
	c351_lo
	c352_lo
	c353_lo
	c354_lo
	c355_lo
	c356_lo
	c357_lo
	c358_lo
	c359_lo
	c360_lo
	c361_lo
	c362_lo
	c363_lo
	c364_lo
	c365_lo
	c366_lo
	c367_lo
	c368_lo
	c369_lo
	c370_lo
	c371_lo
	c372_lo
	c373_lo
	c374_lo
	c375_lo
	c376_lo
	c377_lo
	c378_lo
	c379_lo
	c380_lo
	c381_lo
	c382_lo
	c383_lo
	c384_lo
	c385_lo
	c386_lo
	c387_lo
	c388_lo
	c389_lo
	c390_lo
	c391_lo
	c392_lo
	c393_lo
	c394_lo
	c395_lo
	c396_lo
	c397_lo
	c398_lo
	c399_lo
	c400_lo
	c401_lo
	c402_lo
	c403_lo
	c404_lo
	c405_lo
	c406_lo
	c407_lo
	c408_lo
	c409_lo
	c410_lo
	c411_lo
	c412_lo
	c413_lo
	c414_lo
	c415_lo
	c416_lo
	c417_lo
	c418_lo
	c419_lo
	c420_lo
	c421_lo
	c422_lo
	c423_lo
	c424_lo
	c425_lo
	c426_lo
	c427_lo
	c428_lo
	c429_lo
	c430_lo
	c431_lo
	c432_lo
	c433_lo
	c434_lo
	c435_lo
	c436_lo
	c437_lo
	c438_lo
	c439_lo
	c440_lo
	c441_lo
	c442_lo
	c443_lo
	c444_lo
	c445_lo
	c446_lo
	c447_lo
	c448_lo
	c449_lo
	c450_lo
	c451_lo
	c452_lo
	c453_lo
	c454_lo
	c455_lo
	c456_lo
	c457_lo
	c458_lo
	c459_lo
	c460_lo
	c461_lo
	c462_lo
	c463_lo
	c464_lo
	c465_lo
	c466_lo
	c467_lo
	c468_lo
	c469_lo
	c470_lo
	c471_lo
	c472_lo
	c473_lo
	c474_lo
	c475_lo
	c476_lo
	c477_lo
	c478_lo
	c479_lo
	c480_lo
	c481_lo
	c482_lo
	c483_lo
	c484_lo
	c485_lo
	c486_lo
	c487_lo
	c488_lo
	c489_lo
	c490_lo
	c491_lo
	c492_lo
	c493_lo
	c494_lo
	c495_lo
	c496_lo
	c497_lo
	c498_lo
	c499_lo
	c500_lo
	c501_lo
	c502_lo
	c503_lo
	c504_lo
	c505_lo
	c506_lo
	c507_lo
	c508_lo
	c509_lo
	c510_lo
	c511_lo
	c512_lo
	c513_lo
	c514_lo
	c515_lo
	c516_lo
	c517_lo
	c518_lo
	c519_lo
	c520_lo
	c521_lo
	c522_lo
	c523_lo
	c524_lo
	c525_lo
	c526_lo
	c527_lo
	c528_lo
	c529_lo
	c530_lo
	c531_lo
	c532_lo
	c533_lo
	c534_lo
	c535_lo
	c536_lo
	c537_lo
	c538_lo
	c539_lo
	c540_lo
	c541_lo
	c542_lo
	c543_lo
	c544_lo
	c545_lo
	c546_lo
	c547_lo
	c548_lo
	c549_lo
	c550_lo
	c551_lo
	c552_lo
	c553_lo
	c554_lo
	c555_lo
	c556_lo
	c557_lo
	c558_lo
	c559_lo
	c560_lo
	c561_lo
	c562_lo
	c563_lo
	c564_lo
	c565_lo
	c566_lo
	c567_lo
	c568_lo
	c569_lo
	c570_lo
	c571_lo
	c572_lo
	c573_lo
	c574_lo
	c575_lo
	c576_lo
	c577_lo
	c578_lo
	c579_lo
	c580_lo
	c581_lo
	c582_lo
	c583_lo
	c584_lo
	c585_lo
	c586_lo
	c587_lo
	c588_lo
	c589_lo
	c590_lo
	c591_lo
	c592_lo
	c593_lo
	c594_lo
	c595_lo
	c596_lo
	c597_lo
	c598_lo
	c599_lo
	c600_lo
	c601_lo
	c602_lo
	c603_lo
	c604_lo
	c605_lo
	c606_lo
	c607_lo
	c608_lo
	c609_lo
	c610_lo
	c611_lo
	c612_lo
	c613_lo
	c614_lo
	c615_lo
	c616_lo
	c617_lo
	c618_lo
	c619_lo
	c620_lo
	c621_lo
	c622_lo
	c623_lo
	c624_lo
	c625_lo
	c626_lo
	c627_lo
	c628_lo
	c629_lo
	c630_lo
	c631_lo
	c632_lo
	c633_lo
	c634_lo
	c635_lo
	c636_lo
	c637_lo
	c638_lo
	c639_lo
	c640_lo
	c641_lo
	c642_lo
	c643_lo
	c644_lo
	c645_lo
	c646_lo
	c647_lo
	c648_lo
	c649_lo
	c650_lo
	c651_lo
	c652
	c653
	c654
	c655
	c656
	c657
	c658
	c659
	c660
	c661
	c662
	c663
	c664
	c665
	c666
	c667
	c668
	c669
	c670
	c671
	c672
	c673
	c674
	c675
	c676
	c677
	c678
	c679
	c680
	c681
	c682
	c683
	c684
	c685
	c686
	c687
	c688
	c689
	c690
	c691
	c692
	c693
	c694
	c695
	c696
	c697
	c698
	c699
	c700
	c701
	c702
	c703
	c704
	c705
	c706
	c707
	c708
	c709
	c710
	c711
	c712
	c713
	c714
	c715
	c716
	c717
	c718
	c719
	c720
	c721
	c722
	c723
	c724
	c725
	c726
	c727
	c728
	c729
	c730
	c731
	c732
	c733
	c734
	c735
	c736
	c737
	c738
	c739
	c740
	c741
	c742
	c743
	c744
	c745
	c746
	c747
	c748
	c749
	c750
	c751
	c752
	c753
	c754
	c755
	c756
	c757
	c758
	c759
	c760
	c761
	c762
	c763
	c764
	c765
	c766
	c767
	c768
	c769
	c770
	c771
	c772
	c773
	c774
	c775
	c776
	c777
	c778
	c779
	c780
	c781
	c782
	c783
	c784
	c785
	c786
	c787
	c788
	c789
	c790
	c791
	c792
	c793
	c794
	c795
	c796
	c797
	c798
	c799
	c800
	c801
	c802
	c803
	c804
	c805
	c806
	c807
	c808
	c809
	c810
	c811
	c812
	c813
	c814
	c815
	c816
	c817
	c818
	c819
	c820
	c821
	c822
	c823
	c824
	c825
	c826
	c827
	c828
	c829
	c830
	c831
	c832
	c833
	c834
	c835
	c836
	c837
	c838
	c839
	c840
	c841
	c842
	c843
	c844
	c845
	c846
	c847
	c848
	c849
	c850
	c851
	c852
	c853
	c854
	c855
	c856
	c857
	c858
	c859
	c860
	c861
	c862
	c863
	c864
	c865
	c866
	c867
	c868
	c869
	c870
	c871
	c872
	c873
	c874
	c875
	c876
	c877
	c878
	c879
	c880
	c881
	c882
	c883
	c884
	c885
	c886
	c887
	c888
	c889
	c890
	c891
	c892
	c893
	c894
	c895
	c896
	c897
	c898
	c899
	c900
	c901
	c902
	c903
	c904
	c905
	c906
	c907
	c908
	c909
	c910
	c911
	c912
	c913
	c914
	c915
	c916
	c917
	c918
	c919
	c920
	c921
	c922
	c923
	c924
	c925
	c926
	c927
	c928
	c929
	c930
	c931
	c932
	c933
	c934
	c935
	c936
	c937
	c938
	c939
	c940
	c941
	c942
	c943
	c944
	c945
	c946
	c947
	c948
	c949
	c950
	c951
	c952
	c953
	c954
	c955
	c956
	c957
	c958
	c959
	c960
	c961
	c962
	c963
	c964
	c965
	c966
	c967
	c968
	c969
	c970
	c971
	c972
	c973
	c974
	c975
	c976
	c977
	c978
	c979
	c980
	c981
	c982
	c983
	c984
	c985
	c986
	c987
	c988
	c989
	c990
	c991
	c992
	c993
	c994
	c995
	c996
	c997
	c998
	c999
	c1000
	c1001
	c1002
	c1003
	c1004
	c1005
	c1006
	c1007
	c1008
	c1009
	c1010
	c1011
	c1012
	c1013
	c1014
	c1015
	c1016
	c1017
	c1018
	c1019
	c1020
	c1021
	c1022
	c1023
	c1024
	c1025
	c1026
	c1027
	c1028
	c1029
	c1030
	c1031
	c1032
	c1033
	c1034
	c1035
	c1036
	c1037
	c1038
	c1039
	c1040
	c1041
	c1042
	c1043
	c1044
	c1045
	c1046
	c1047
	c1048
	c1049
	c1050
	c1051
	c1052
	c1053
	c1054
	c1055
	c1056
	c1057
	c1058
	c1059
	c1060
	c1061
	c1062
	c1063
	c1064
	c1065
	c1066
	c1067
	c1068
	c1069
	c1070
	c1071
	c1072
	c1073
	c1074
	c1075
	c1076
	c1077
	c1078
	c1079
	c1080
	c1081
	c1082
	c1083
	c1084
	c1085
	c1086
	c1087
	c1088
	c1089
	c1090
	c1091
	c1092
	c1093
	c1094
	c1095
	c1096
	c1097
	c1098
	c1099
	c1100
	c1101
	c1102
	c1103
	c1104
	c1105
	c1106
	c1107
	c1108
	c1109
	c1110
	c1111
	c1112
	c1113
	c1114
	c1115
	c1116
	c1117
	c1118
	c1119
	c1120
	c1121
	c1122
	c1123
	c1124
	c1125
	c1126
	c1127
	c1128
	c1129
	c1130
	c1131
	c1132_hi
	c1133_hi
	c1134_hi
	c1135_hi
	c1136_hi
	c1137_hi
	c1138_hi
	c1139_hi
	c1140_hi
	c1141_hi
	c1142_hi
	c1143_hi
	c1144_hi
	c1145_hi
	c1146_hi
	c1147_hi
	c1148_hi
	c1149_hi
	c1150_hi
	c1151_hi
	c1152_hi
	c1153_hi
	c1154_hi
	c1155_hi
	c1156_hi
	c1157_hi
	c1158_hi
	c1159_hi
	c1160_hi
	c1161_hi
	c1162_hi
	c1163_hi
	c1164_hi
	c1165_hi
	c1166_hi
	c1167_hi
	c1168_hi
	c1169_hi
	c1170_hi
	c1171_hi
	c1172_hi
	c1173_hi
	c1174_hi
	c1175_hi
	c1176_hi
	c1177_hi
	c1178_hi
	c1179_hi
	c1180_hi
	c1181_hi
	c1182_hi
	c1183_hi
	c1184_hi
	c1185_hi
	c1186_hi
	c1187_hi
	c1188_hi
	c1189_hi
	c1190_hi
	c1191_hi
	c1192_hi
	c1193_hi
	c1194_hi
	c1195_hi
	c1196_hi
	c1197_hi
	c1198_hi
	c1199_hi
	c1200_hi
	c1201_hi
	c1202_hi
	c1203_hi
	c1204_hi
	c1205_hi
	c1206_hi
	c1207_hi
	c1208_hi
	c1209_hi
	c1210_hi
	c1211_hi
	c1212_hi
	c1213_hi
	c1214_hi
	c1215_hi
	c1216_hi
	c1217_hi
	c1218_hi
	c1219_hi
	c1220_hi
	c1221_hi
	c1222_hi
	c1223_hi
	c1224_hi
	c1225_hi
	c1226_hi
	c1227_hi
	c1228_hi
	c1229_hi
	c1230_hi
	c1231_hi
	c1232_hi
	c1233_hi
	c1234_hi
	c1235_hi
	c1236_hi
	c1237_hi
	c1238_hi
	c1239_hi
	c1240_hi
	c1241_hi
	c1242_hi
	c1243_hi
	c1244_hi
	c1245_hi
	c1246_hi
	c1247_hi
	c1248_hi
	c1249_hi
	c1250_hi
	c1251_hi
	c1252_hi
	c1253_hi
	c1254_hi
	c1255_hi
	c1256_hi
	c1257_hi
	c1258_hi
	c1259_hi
	c1260_hi
	c1261_hi
	c1262_hi
	c1263_hi
	c1264_hi
	c1265_hi
	c1266_hi
	c1267_hi
	c1268_hi
	c1269_hi
	c1270_hi
	c1271_hi
	c1272_hi
	c1273_hi
	c1274_hi
	c1275_hi
	c1276_hi
	c1277_hi
	c1278_hi
	c1279_hi
	c1280_hi
	c1281_hi
	c1282_hi
	c1283_hi
	c1284_hi
	c1285_hi
	c1286_hi
	c1287_hi
	c1288_hi
	c1289_hi
	c1290_hi
	c1291_hi
	c1292_hi
	c1293_hi
	c1294_hi
	c1295_hi
	c1296_hi
	c1297_hi
	c1298_hi
	c1299_hi
	c1300_hi
	c1301_hi
	c1302_hi
	c1303_hi
	c1304_hi
	c1305_hi
	c1306_hi
	c1307_hi
	c1308_hi
	c1309_hi
	c1310_hi
	c1311_hi
	c1312_hi
	c1313_hi
	c1314_hi
	c1315_hi
	c1316_hi
	c1317_hi
	c1318_hi
	c1319_hi
	c1320_hi
	c1321_hi
	c1322_hi
	c1323_hi
	c1324_hi
	c1325_hi
	c1326_hi
	c1327_hi
	c1328_hi
	c1329_hi
	c1330_hi
	c1331_hi
	c1332_hi
	c1333_hi
	c1334_hi
	c1335_hi
	c1336_hi
	c1337_hi
	c1338_hi
	c1339_hi
	c1340_hi
	c1341_hi
	c1342_hi
	c1343_hi
	c1344_hi
	c1345_hi
	c1346_hi
	c1347_hi
	c1348_hi
	c1349_hi
	c1350_hi
	c1351_hi
	c1352_hi
	c1353_hi
	c1354_hi
	c1355_hi
	c1356_hi
	c1357_hi
	c1358_hi
	c1359_hi
	c1360_hi
	c1361_hi
	c1362_hi
	c1363_hi
	c1364_hi
	c1365_hi
	c1366_hi
	c1367_hi
	c1368_hi
	c1369_hi
	c1370_hi
	c1371_hi
	c1372_hi
	c1373_hi
	c1374_hi
	c1375_hi
	c1376_hi
	c1377_hi
	c1378_hi
	c1379_hi
	c1380_hi
	c1381_hi
	c1382_hi
	c1383_hi
	c1384_hi
	c1385_hi
	c1386_hi
	c1387_hi
	c1388_hi
	c1389_hi
	c1390_hi
	c1391_hi
	c1392_hi
	c1393_hi
	c1394_hi
	c1395_hi
	c1396_hi
	c1397_hi
	c1398_hi
	c1399_hi
	c1400_hi
	c1401_hi
	c1402_hi
	c1403_hi
	c1404_hi
	c1405_hi
	c1406_hi
	c1407_hi
	c1408_hi
	c1409_hi
	c1410_hi
	c1411_hi
	c1412_hi
	c1413_hi
	c1414_hi
	c1415_hi
	c1416_hi
	c1417_hi
	c1418_hi
	c1419_hi
	c1420_hi
	c1421_hi
	c1422_hi
	c1423_hi
	c1424_hi
	c1425_hi
	c1426_hi
	c1427_hi
	c1428_hi
	c1429_hi
	c1430_hi
	c1431_hi
	c1432_hi
	c1433_hi
	c1434_hi
	c1435_hi
	c1436_hi
	c1437_hi
	c1438_hi
	c1439_hi
	c1440_hi
	c1441_hi
	c1442_hi
	c1443_hi
	c1444_hi
	c1445_hi
	c1446_hi
	c1447_hi
	c1448_hi
	c1449_hi
	c1450_hi
	c1451_hi
	c1452_hi
	c1453_hi
	c1454_hi
	c1455_hi
	c1456_hi
	c1457_hi
	c1458_hi
	c1459_hi
	c1460_hi
	c1461_hi
	c1462
	c1463
	c1464
	c1465
	c1466
	c1467
	c1468
	c1469
	c1470
	c1471
	c1472
	c1473
	c1474
	c1475
	c1476
	c1477
	c1478
	c1479
	c1480
	c1481
	c1482
	c1483
	c1484
	c1485
	c1486
	c1487
	c1488
	c1489
	c1490
	c1491
	c1492
	c1493
	c1494
	c1495
	c1496
	c1497
	c1498
	c1499
	c1500
	c1501
	c1502
	c1503
	c1504
	c1505
	c1506
	c1507
	c1508
	c1509
	c1510
	c1511
	c1512
	c1513
	c1514
	c1515
	c1516
	c1517
	c1518
	c1519
	c1520
	c1521
	c1522
	c1523
	c1524
	c1525_hi
	c1526_hi
	c1527_hi
	c1528_hi
	c1529_hi
	c1530_hi
	c1531_hi
	c1532_hi
	c1533_hi
	c1534_hi
	c1535_hi
	c1536_hi
	c1537_hi
	c1538_hi
	c1539_hi
	c1540_hi
	c1541_hi
	c1542_hi
	c1543
	c1544
	c1545
	c1546_hi
	c1547_hi
	c1548_hi
	c1549_hi
	c1550_hi
	c1551_hi
	c1552_hi
	c1553_hi
	c1554_hi
	c1555_hi
	c1556_hi
	c1557_hi
	c1558_hi
	c1559_hi
	c1560_hi
	c1561_hi
	c1562_hi
	c1563_hi
	c1564
	c1565
	c1566
	c1567_hi
	c1568_hi
	c1569_hi
	c1570_hi
	c1571_hi
	c1572_hi
	c1573_hi
	c1574_hi
	c1575_hi
	c1576_hi
	c1577_hi
	c1578_hi
	c1579_hi
	c1580_hi
	c1581_hi
	c1582_hi
	c1583_hi
	c1584_hi
	c1585
	c1586
	c1587
	c1588_hi
	c1589_hi
	c1590_hi
	c1591_hi
	c1592_hi
	c1593_hi
	c1594_hi
	c1595_hi
	c1596_hi
	c1597_hi
	c1598_hi
	c1599_hi
	c1600_hi
	c1601_hi
	c1602_hi
	c1603_hi
	c1604_hi
	c1605_hi
	c1606
	c1607
	c1608
	c1609_hi
	c1610_hi
	c1611_hi
	c1612_hi
	c1613_hi
	c1614_hi
	c1615_hi
	c1616_hi
	c1617_hi
	c1618_hi
	c1619_hi
	c1620_hi
	c1621_hi
	c1622_hi
	c1623_hi
	c1624_hi
	c1625_hi
	c1626_hi
	c1627
	c1628
	c1629
	c1630_hi
	c1631_hi
	c1632_hi
	c1633_hi
	c1634_hi
	c1635_hi
	c1636_hi
	c1637_hi
	c1638_hi
	c1639_hi
	c1640_hi
	c1641_hi
	c1642_hi
	c1643_hi
	c1644_hi
	c1645_hi
	c1646_hi
	c1647_hi
	c1648
	c1649
	c1650
	c1651_hi
	c1652_hi
	c1653_hi
	c1654_hi
	c1655_hi
	c1656_hi
	c1657_hi
	c1658_hi
	c1659_hi
	c1660_hi
	c1661_hi
	c1662_hi
	c1663_hi
	c1664_hi
	c1665_hi
	c1666_hi
	c1667_hi
	c1668_hi
	c1669
	c1670
	c1671
	c1672_hi
	c1673_hi
	c1674_hi
	c1675_hi
	c1676_hi
	c1677_hi
	c1678_hi
	c1679_hi
	c1680_hi
	c1681_hi
	c1682_hi
	c1683_hi
	c1684_hi
	c1685_hi
	c1686_hi
	c1687_hi
	c1688_hi
	c1689_hi
	c1690
	c1691
	c1692
	c1693_hi
	c1694_hi
	c1695_hi
	c1696_hi
	c1697_hi
	c1698_hi
	c1699_hi
	c1700_hi
	c1701_hi
	c1702_hi
	c1703_hi
	c1704_hi
	c1705_hi
	c1706_hi
	c1707_hi
	c1708_hi
	c1709_hi
	c1710_hi
	c1711
	c1712
	c1713
	c1714_hi
	c1715_hi
	c1716_hi
	c1717_hi
	c1718_hi
	c1719_hi
	c1720_hi
	c1721_hi
	c1722_hi
	c1723_hi
	c1724_hi
	c1725_hi
	c1726_hi
	c1727_hi
	c1728_hi
	c1729_hi
	c1730_hi
	c1731_hi
	c1732
	c1733
	c1734
	c1735_hi
	c1736_hi
	c1737_hi
	c1738_hi
	c1739_hi
	c1740_hi
	c1741_hi
	c1742_hi
	c1743_hi
	c1744_hi
	c1745_hi
	c1746_hi
	c1747_hi
	c1748_hi
	c1749_hi
	c1750_hi
	c1751_hi
	c1752_hi
	c1753
	c1754
	c1755
	c1756_hi
	c1757_hi
	c1758_hi
	c1759_hi
	c1760_hi
	c1761_hi
	c1762_hi
	c1763_hi
	c1764_hi
	c1765_hi
	c1766_hi
	c1767_hi
	c1768_hi
	c1769_hi
	c1770_hi
	c1771_hi
	c1772_hi
	c1773_hi
	c1774
	c1775
	c1776
	c1777_hi
	c1778_hi
	c1779_hi
	c1780_hi
	c1781_hi
	c1782_hi
	c1783_hi
	c1784_hi
	c1785_hi
	c1786_hi
	c1787_hi
	c1788_hi
	c1789_hi
	c1790_hi
	c1791_hi
	c1792_hi
	c1793_hi
	c1794_hi
	c1795
	c1796
	c1797
	c1798_hi
	c1799_hi
	c1800_hi
	c1801_hi
	c1802_hi
	c1803_hi
	c1804_hi
	c1805_hi
	c1806_hi
	c1807_hi
	c1808_hi
	c1809_hi
	c1810_hi
	c1811_hi
	c1812_hi
	c1813_hi
	c1814_hi
	c1815_hi
	c1816
	c1817
	c1818
	c1819_hi
	c1820_hi
	c1821_hi
	c1822_hi
	c1823_hi
	c1824_hi
	c1825_hi
	c1826_hi
	c1827_hi
	c1828_hi
	c1829_hi
	c1830_hi
	c1831_hi
	c1832_hi
	c1833_hi
	c1834_hi
	c1835_hi
	c1836_hi
	c1837
	c1838
	c1839
	c1840_hi
	c1841_hi
	c1842_hi
	c1843_hi
	c1844_hi
	c1845_hi
	c1846_hi
	c1847_hi
	c1848_hi
	c1849_hi
	c1850_hi
	c1851_hi
	c1852_hi
	c1853_hi
	c1854_hi
	c1855_hi
	c1856_hi
	c1857_hi
	c1858
	c1859
	c1860
	c1861_hi
	c1862_hi
	c1863_hi
	c1864_hi
	c1865_hi
	c1866_hi
	c1867_hi
	c1868_hi
	c1869_hi
	c1870_hi
	c1871_hi
	c1872_hi
	c1873_hi
	c1874_hi
	c1875_hi
	c1876_hi
	c1877_hi
	c1878_hi
	c1879
	c1880
	c1881
	c1882_hi
	c1883_hi
	c1884_hi
	c1885_hi
	c1886_hi
	c1887_hi
	c1888_hi
	c1889_hi
	c1890_hi
	c1891_hi
	c1892_hi
	c1893_hi
	c1894_hi
	c1895_hi
	c1896_hi
	c1897_hi
	c1898_hi
	c1899_hi
	c1900
	c1901
	c1902
	c1903_hi
	c1904_hi
	c1905_hi
	c1906_hi
	c1907_hi
	c1908_hi
	c1909_hi
	c1910_hi
	c1911_hi
	c1912_hi
	c1913_hi
	c1914_hi
	c1915_hi
	c1916_hi
	c1917_hi
	c1918_hi
	c1919_hi
	c1920_hi
	c1921
	c1922
	c1923
	c1924_hi
	c1925_hi
	c1926_hi
	c1927_hi
	c1928_hi
	c1929_hi
	c1930_hi
	c1931_hi
	c1932_hi
	c1933_hi
	c1934_hi
	c1935_hi
	c1936_hi
	c1937_hi
	c1938_hi
	c1939_hi
	c1940_hi
	c1941_hi
	c1942
	c1943
	c1944
	c1945_hi
	c1946_hi
	c1947_hi
	c1948_hi
	c1949_hi
	c1950_hi
	c1951_hi
	c1952_hi
	c1953_hi
	c1954_hi
	c1955_hi
	c1956_hi
	c1957_hi
	c1958_hi
	c1959_hi
	c1960_hi
	c1961_hi
	c1962_hi
	c1963
	c1964
	c1965
	c1966_hi
	c1967_hi
	c1968_hi
	c1969_hi
	c1970_hi
	c1971_hi
	c1972_hi
	c1973_hi
	c1974_hi
	c1975_hi
	c1976_hi
	c1977_hi
	c1978_hi
	c1979_hi
	c1980_hi
	c1981_hi
	c1982_hi
	c1983_hi
	c1984
	c1985
	c1986
	c1987_hi
	c1988_hi
	c1989_hi
	c1990_hi
	c1991_hi
	c1992_hi
	c1993_hi
	c1994_hi
	c1995_hi
	c1996_hi
	c1997_hi
	c1998_hi
	c1999_hi
	c2000_hi
	c2001_hi
	c2002_hi
	c2003_hi
	c2004_hi
	c2005
	c2006
	c2007
	c2008_hi
	c2009_hi
	c2010_hi
	c2011_hi
	c2012_hi
	c2013_hi
	c2014_hi
	c2015_hi
	c2016_hi
	c2017_hi
	c2018_hi
	c2019_hi
	c2020_hi
	c2021_hi
	c2022_hi
	c2023_hi
	c2024_hi
	c2025_hi
	c2026
	c2027
	c2028
	c2029_hi
	c2030_hi
	c2031_hi
	c2032_hi
	c2033_hi
	c2034_hi
	c2035_hi
	c2036_hi
	c2037_hi
	c2038_hi
	c2039_hi
	c2040_hi
	c2041_hi
	c2042_hi
	c2043_hi
	c2044_hi
	c2045_hi
	c2046_hi
	c2047
	c2048
	c2049
	c2050_hi
	c2051_hi
	c2052_hi
	c2053_hi
	c2054_hi
	c2055_hi
	c2056_hi
	c2057_hi
	c2058_hi
	c2059_hi
	c2060_hi
	c2061_hi
	c2062_hi
	c2063_hi
	c2064_hi
	c2065_hi
	c2066_hi
	c2067_hi
	c2068
	c2069
	c2070
	c2071_hi
	c2072_hi
	c2073_hi
	c2074_hi
	c2075_hi
	c2076_hi
	c2077_hi
	c2078_hi
	c2079_hi
	c2080_hi
	c2081_hi
	c2082_hi
	c2083_hi
	c2084_hi
	c2085_hi
	c2086_hi
	c2087_hi
	c2088_hi
	c2089
	c2090
	c2091
	c2092_hi
	c2093_hi
	c2094_hi
	c2095_hi
	c2096_hi
	c2097_hi
	c2098_hi
	c2099_hi
	c2100_hi
	c2101_hi
	c2102_hi
	c2103_hi
	c2104_hi
	c2105_hi
	c2106_hi
	c2107_hi
	c2108_hi
	c2109_hi
	c2110
	c2111
	c2112
	c2113_hi
	c2114_hi
	c2115_hi
	c2116_hi
	c2117_hi
	c2118_hi
	c2119_hi
	c2120_hi
	c2121_hi
	c2122_hi
	c2123_hi
	c2124_hi
	c2125_hi
	c2126_hi
	c2127_hi
	c2128_hi
	c2129_hi
	c2130_hi
	c2131
	c2132
	c2133
	c2134_hi
	c2135_hi
	c2136_hi
	c2137_hi
	c2138_hi
	c2139_hi
	c2140_hi
	c2141_hi
	c2142_hi
	c2143_hi
	c2144_hi
	c2145_hi
	c2146_hi
	c2147_hi
	c2148_hi
	c2149_hi
	c2150_hi
	c2151_hi
	c2152
	c2153
	c2154
	c2155_hi
	c2156_hi
	c2157_hi
	c2158_hi
	c2159_hi
	c2160_hi
	c2161_hi
	c2162_hi
	c2163_hi
	c2164
	c2165
	c2166
	c2167_hi
	c2168_hi
	c2169_hi
	c2170_hi
	c2171_hi
	c2172_hi
	c2173_hi
	c2174_hi
	c2175_hi
	c2176
	c2177
	c2178
	c2179_hi
	c2180_hi
	c2181_hi
	c2182_hi
	c2183_hi
	c2184_hi
	c2185_hi
	c2186_hi
	c2187_hi
	c2188
	c2189
	c2190
	c2191_hi
	c2192_hi
	c2193_hi
	c2194_hi
	c2195_hi
	c2196_hi
	c2197_hi
	c2198_hi
	c2199_hi
	c2200
	c2201
	c2202
	c2203_hi
	c2204_hi
	c2205_hi
	c2206_hi
	c2207_hi
	c2208_hi
	c2209_hi
	c2210_hi
	c2211_hi
	c2212
	c2213
	c2214
	c2215_hi
	c2216_hi
	c2217_hi
	c2218_hi
	c2219_hi
	c2220_hi
	c2221_hi
	c2222_hi
	c2223_hi
	c2224
	c2225
	c2226
	c2227_hi
	c2228_hi
	c2229_hi
	c2230_hi
	c2231_hi
	c2232_hi
	c2233_hi
	c2234_hi
	c2235_hi
	c2236
	c2237
	c2238
	c2239_hi
	c2240_hi
	c2241_hi
	c2242_hi
	c2243_hi
	c2244_hi
	c2245_hi
	c2246_hi
	c2247_hi
	c2248
	c2249
	c2250
	c2251_hi
	c2252_hi
	c2253_hi
	c2254_hi
	c2255_hi
	c2256_hi
	c2257_hi
	c2258_hi
	c2259_hi
	c2260
	c2261
	c2262
	c2263_hi
	c2264_hi
	c2265_hi
	c2266_hi
	c2267_hi
	c2268_hi
	c2269_hi
	c2270_hi
	c2271_hi
	c2272
	c2273
	c2274
	c2275_hi
	c2276_hi
	c2277_hi
	c2278_hi
	c2279_hi
	c2280_hi
	c2281_hi
	c2282_hi
	c2283_hi
	c2284
	c2285
	c2286
	c2287_hi
	c2288_hi
	c2289_hi
	c2290_hi
	c2291_hi
	c2292_hi
	c2293_hi
	c2294_hi
	c2295_hi
	c2296
	c2297
	c2298
	c2299_hi
	c2300_hi
	c2301_hi
	c2302_hi
	c2303_hi
	c2304_hi
	c2305_hi
	c2306_hi
	c2307_hi
	c2308
	c2309
	c2310
	c2311_hi
	c2312_hi
	c2313_hi
	c2314_hi
	c2315_hi
	c2316_hi
	c2317_hi
	c2318_hi
	c2319_hi
	c2320
	c2321
	c2322
	c2323_hi
	c2324_hi
	c2325_hi
	c2326_hi
	c2327_hi
	c2328_hi
	c2329_hi
	c2330_hi
	c2331_hi
	c2332
	c2333
	c2334
	c2335_hi
	c2336_hi
	c2337_hi
	c2338_hi
	c2339_hi
	c2340_hi
	c2341_hi
	c2342_hi
	c2343_hi
	c2344
	c2345
	c2346
	c2347_hi
	c2348_hi
	c2349_hi
	c2350_hi
	c2351_hi
	c2352_hi
	c2353_hi
	c2354_hi
	c2355_hi
	c2356
	c2357
	c2358
	c2359_hi
	c2360_hi
	c2361_hi
	c2362_hi
	c2363_hi
	c2364_hi
	c2365_hi
	c2366_hi
	c2367_hi
	c2368
	c2369
	c2370
	c2371_hi
	c2372_hi
	c2373_hi
	c2374_hi
	c2375_hi
	c2376_hi
	c2377_hi
	c2378_hi
	c2379_hi
	c2380
	c2381
	c2382
	c2383_hi
	c2384_hi
	c2385_hi
	c2386_hi
	c2387_hi
	c2388_hi
	c2389_hi
	c2390_hi
	c2391_hi
	c2392
	c2393
	c2394
	c2395_hi
	c2396_hi
	c2397_hi
	c2398_hi
	c2399_hi
	c2400_hi
	c2401_hi
	c2402_hi
	c2403_hi
	c2404
	c2405
	c2406
	c2407_hi
	c2408_hi
	c2409_hi
	c2410_hi
	c2411_hi
	c2412_hi
	c2413_hi
	c2414_hi
	c2415_hi
	c2416
	c2417
	c2418
	c2419_hi
	c2420_hi
	c2421_hi
	c2422_hi
	c2423_hi
	c2424_hi
	c2425_hi
	c2426_hi
	c2427_hi
	c2428
	c2429
	c2430
	c2431_hi
	c2432_hi
	c2433_hi
	c2434_hi
	c2435_hi
	c2436_hi
	c2437_hi
	c2438_hi
	c2439_hi
	c2440
	c2441
	c2442
	c2443_hi
	c2444_hi
	c2445_hi
	c2446_hi
	c2447_hi
	c2448_hi
	c2449_hi
	c2450_hi
	c2451_hi
	c2452
	c2453
	c2454
	c2455_hi
	c2456_hi
	c2457_hi
	c2458_hi
	c2459_hi
	c2460_hi
	c2461_hi
	c2462_hi
	c2463_hi
	c2464
	c2465
	c2466
	c2467_hi
	c2468_hi
	c2469_hi
	c2470_hi
	c2471_hi
	c2472_hi
	c2473_hi
	c2474_hi
	c2475_hi
	c2476
	c2477
	c2478
	c2479_hi
	c2480_hi
	c2481_hi
	c2482_hi
	c2483_hi
	c2484_hi
	c2485_hi
	c2486_hi
	c2487_hi
	c2488
	c2489
	c2490
	c2491_hi
	c2492_hi
	c2493_hi
	c2494_hi
	c2495_hi
	c2496_hi
	c2497_hi
	c2498_hi
	c2499_hi
	c2500
	c2501
	c2502
	c2503_hi
	c2504_hi
	c2505_hi
	c2506_hi
	c2507_hi
	c2508_hi
	c2509_hi
	c2510_hi
	c2511_hi
	c2512;

BINARY VARIABLES
	x277
	x278
	x279
	x280
	x281
	x282
	x283
	x284
	x285
	x286
	x287
	x288
	x289
	x290
	x291
	x292
	x293
	x294
	x295
	x296
	x297
	x298
	x299
	x300
	x301
	x302
	x303
	x304
	x305
	x306
	x307
	x308
	x309
	x310
	x311
	x312
	x313
	x314
	x315
	x316
	x317
	x318
	x319
	x320
	x321
	x322
	x323
	x324
	x325
	x326
	x327
	x328
	x329
	x330
	x331
	x332
	x333
	x334
	x335
	x336
	x337
	x338
	x339
	x340
	x341
	x342
	x343
	x344
	x345
	x346
	x347
	x348
	x349
	x350
	x351
	x352
	x353
	x354
	x355
	x356
	x357
	x358
	x359
	x360
	x361
	x362
	x363
	x364
	x365
	x366
	x1087
	x1088
	x1089
	x1090
	x1091
	x1092
	x1093
	x1094
	x1095
	x1096
	x1097
	x1098
	x1099
	x1100
	x1101
	x1102
	x1103
	x1104
	x1105
	x1106
	x1107
	x1108
	x1109
	x1110
	x1111
	x1112
	x1113
	x1114
	x1115
	x1116
	x1117
	x1118
	x1119
	x1120
	x1121
	x1122
	x1123
	x1124
	x1125
	x1126
	x1127
	x1128
	x1129
	x1130
	x1131
	x1132
	x1133
	x1134
	x1135
	x1136
	x1137
	x1138
	x1139
	x1140
	x1141
	x1142
	x1143
	x1144
	x1145
	x1146;

POSITIVE VARIABLES
	x1
	x2
	x4
	x5
	x6
	x8
	x10
	x11
	x12
	x14
	x15
	x16
	x18
	x19
	x20
	x22
	x23
	x24
	x26
	x27
	x28
	x30
	x31
	x32
	x34
	x35
	x36
	x38
	x39
	x40
	x42
	x43
	x44
	x46
	x47
	x48
	x50
	x51
	x52
	x54
	x55
	x56
	x58
	x59
	x60
	x62
	x63
	x64
	x66
	x67
	x68
	x70
	x71
	x72
	x74
	x75
	x76
	x78
	x79
	x80
	x82
	x83
	x84
	x86
	x87
	x88
	x90
	x91
	x92
	x94
	x95
	x96
	x98
	x99
	x100
	x102
	x103
	x104
	x106
	x107
	x108
	x110
	x111
	x112
	x114
	x115
	x116
	x118
	x119
	x120
	x122
	x123
	x125
	x126
	x127
	x128
	x130
	x131
	x133
	x134
	x136
	x137
	x139
	x140
	x142
	x143
	x145
	x146
	x148
	x149
	x151
	x152
	x154
	x155
	x157
	x158
	x160
	x161
	x163
	x164
	x166
	x167
	x169
	x170
	x172
	x173
	x175
	x176
	x178
	x179
	x181
	x182
	x184
	x185
	x187
	x188
	x190
	x191
	x193
	x194
	x196
	x197
	x199
	x200
	x202
	x203
	x205
	x206
	x208
	x209
	x211
	x214
	x217
	x219
	x221
	x223
	x225
	x227
	x229
	x231
	x233
	x235
	x237
	x239
	x241
	x243
	x245
	x247
	x249
	x251
	x253
	x255
	x257
	x259
	x261
	x263
	x265
	x267
	x269
	x270
	x271
	x272
	x273
	x274
	x275
	x276
	x368
	x369
	x370
	x371
	x372
	x373
	x375
	x376
	x377
	x378
	x379
	x380
	x381
	x383
	x384
	x385
	x386
	x387
	x388
	x390
	x391
	x392
	x393
	x394
	x395
	x396
	x398
	x399
	x400
	x401
	x402
	x403
	x405
	x406
	x407
	x408
	x409
	x410
	x411
	x413
	x414
	x415
	x416
	x417
	x418
	x420
	x421
	x422
	x423
	x424
	x425
	x426
	x428
	x429
	x430
	x431
	x432
	x433
	x435
	x436
	x437
	x438
	x439
	x440
	x441
	x443
	x444
	x445
	x446
	x447
	x448
	x450
	x451
	x452
	x453
	x454
	x455
	x456
	x458
	x459
	x460
	x461
	x462
	x463
	x465
	x466
	x467
	x468
	x469
	x470
	x471
	x473
	x474
	x475
	x476
	x477
	x478
	x480
	x481
	x482
	x483
	x484
	x485
	x486
	x488
	x489
	x490
	x491
	x492
	x493
	x495
	x496
	x497
	x498
	x499
	x500
	x501
	x503
	x504
	x505
	x506
	x507
	x508
	x510
	x511
	x512
	x513
	x514
	x515
	x516
	x518
	x519
	x520
	x521
	x522
	x523
	x525
	x526
	x527
	x528
	x529
	x530
	x531
	x533
	x534
	x535
	x536
	x537
	x538
	x540
	x541
	x542
	x543
	x544
	x545
	x546
	x548
	x549
	x550
	x551
	x552
	x553
	x555
	x556
	x557
	x558
	x559
	x560
	x561
	x563
	x564
	x565
	x566
	x567
	x568
	x570
	x571
	x572
	x573
	x574
	x575
	x576
	x578
	x579
	x580
	x581
	x582
	x583
	x585
	x586
	x587
	x588
	x589
	x590
	x591
	x593
	x594
	x595
	x596
	x597
	x598
	x600
	x601
	x602
	x603
	x604
	x605
	x606
	x608
	x609
	x610
	x611
	x612
	x613
	x615
	x616
	x617
	x618
	x619
	x620
	x621
	x623
	x624
	x625
	x626
	x627
	x628
	x630
	x631
	x632
	x633
	x634
	x635
	x636
	x638
	x639
	x640
	x641
	x642
	x643
	x645
	x646
	x647
	x648
	x649
	x650
	x651
	x653
	x654
	x655
	x656
	x657
	x658
	x660
	x661
	x662
	x663
	x664
	x665
	x666
	x668
	x669
	x670
	x671
	x672
	x673
	x675
	x676
	x677
	x678
	x679
	x680
	x681
	x683
	x684
	x685
	x686
	x687
	x688
	x690
	x691
	x692
	x693
	x694
	x695
	x696
	x698
	x699
	x700
	x701
	x702
	x703
	x705
	x706
	x707
	x708
	x709
	x710
	x711
	x713
	x714
	x715
	x716
	x717
	x718
	x720
	x721
	x722
	x723
	x724
	x725
	x726
	x728
	x729
	x730
	x731
	x732
	x733
	x735
	x736
	x737
	x738
	x739
	x740
	x741
	x743
	x744
	x745
	x746
	x747
	x748
	x750
	x751
	x752
	x753
	x754
	x755
	x756
	x758
	x759
	x760
	x761
	x762
	x763
	x765
	x766
	x767
	x768
	x769
	x770
	x771
	x773
	x774
	x775
	x776
	x777
	x778
	x780
	x781
	x782
	x783
	x784
	x785
	x786
	x788
	x789
	x790
	x791
	x792
	x793
	x795
	x796
	x797
	x798
	x799
	x800
	x801
	x803
	x804
	x805
	x806
	x807
	x808
	x810
	x811
	x812
	x813
	x814
	x815
	x816
	x817
	x818
	x819
	x820
	x821
	x822
	x823
	x824
	x825
	x826
	x827
	x828
	x829
	x830
	x831
	x832
	x833
	x834
	x835
	x836
	x837
	x838
	x839
	x840
	x841
	x842
	x843
	x844
	x845
	x846
	x847
	x848
	x849
	x850
	x851
	x852
	x853
	x854
	x855
	x856
	x857
	x858
	x859
	x860
	x861
	x862
	x863
	x864
	x865
	x866
	x867
	x868
	x869
	x870
	x871
	x872
	x873
	x874
	x875
	x876
	x877
	x878
	x879
	x880
	x881
	x882
	x883
	x884
	x885
	x886
	x887
	x888
	x889
	x890
	x891
	x892
	x893
	x894
	x895
	x896
	x897
	x898
	x899
	x900
	x901
	x902
	x903
	x904
	x905
	x906
	x907
	x908
	x909
	x910
	x911
	x912
	x913
	x914
	x915
	x916
	x917
	x918
	x919
	x920
	x921
	x922
	x923
	x924
	x925
	x926
	x927
	x928
	x929
	x930
	x931
	x932
	x933
	x934
	x935
	x936
	x937
	x938
	x939
	x940
	x941
	x942
	x943
	x944
	x945
	x946
	x947
	x948
	x949
	x950
	x951
	x952
	x953
	x954
	x955
	x956
	x957
	x958
	x959
	x960
	x961
	x962
	x963
	x964
	x965
	x966
	x967
	x968
	x969
	x970
	x971
	x972
	x973
	x974
	x975
	x976
	x977
	x978
	x979
	x980
	x981
	x982
	x983
	x984
	x985
	x986
	x987
	x988
	x989
	x990
	x991
	x992
	x993
	x994
	x995
	x996
	x997
	x998
	x999
	x1000
	x1001
	x1002
	x1003
	x1004
	x1005
	x1006
	x1007
	x1008
	x1009
	x1010
	x1011
	x1012
	x1013
	x1014
	x1015
	x1016
	x1017
	x1018
	x1019
	x1020
	x1021
	x1022
	x1023
	x1024
	x1025
	x1026
	x1027
	x1028
	x1029
	x1030
	x1031
	x1032
	x1033
	x1034
	x1035
	x1036
	x1037
	x1038
	x1039
	x1040
	x1041
	x1042
	x1043
	x1044
	x1045
	x1046
	x1047
	x1048
	x1049
	x1050
	x1051
	x1052
	x1053
	x1054
	x1055
	x1056
	x1057
	x1058
	x1059
	x1060
	x1061
	x1062
	x1063
	x1064
	x1065
	x1066
	x1067
	x1068
	x1069
	x1070
	x1071
	x1072
	x1073
	x1074
	x1075
	x1076
	x1077
	x1078
	x1079
	x1080
	x1081
	x1082
	x1083
	x1084
	x1085
	x1086;

VARIABLES
	GAMS_OBJECTIVE
	x3
	x7
	x9
	x13
	x17
	x21
	x25
	x29
	x33
	x37
	x41
	x45
	x49
	x53
	x57
	x61
	x65
	x69
	x73
	x77
	x81
	x85
	x89
	x93
	x97
	x101
	x105
	x109
	x113
	x117
	x121
	x124
	x129
	x132
	x135
	x138
	x141
	x144
	x147
	x150
	x153
	x156
	x159
	x162
	x165
	x168
	x171
	x174
	x177
	x180
	x183
	x186
	x189
	x192
	x195
	x198
	x201
	x204
	x207
	x210
	x212
	x213
	x215
	x216
	x218
	x220
	x222
	x224
	x226
	x228
	x230
	x232
	x234
	x236
	x238
	x240
	x242
	x244
	x246
	x248
	x250
	x252
	x254
	x256
	x258
	x260
	x262
	x264
	x266
	x268
	x367
	x374
	x382
	x389
	x397
	x404
	x412
	x419
	x427
	x434
	x442
	x449
	x457
	x464
	x472
	x479
	x487
	x494
	x502
	x509
	x517
	x524
	x532
	x539
	x547
	x554
	x562
	x569
	x577
	x584
	x592
	x599
	x607
	x614
	x622
	x629
	x637
	x644
	x652
	x659
	x667
	x674
	x682
	x689
	x697
	x704
	x712
	x719
	x727
	x734
	x742
	x749
	x757
	x764
	x772
	x779
	x787
	x794
	x802
	x809;


c1.. 0.98999999999999999 + x1 - x2 + x3*x4 =e= 0 ;
c2.. 0.01 + x5 - x6 + x7*x4 =e= 0 ;
c3.. 1 + x8 - x9 =e= 0 ;
c4.. x10 + x11 - x12 + x13*x14 =e= 0 ;
c5.. x15 + x16 - x10 + x17*x18 =e= 0 ;
c6.. x19 + x20 - x15 + x21*x22 =e= 0 ;
c7.. x23 + x24 - x19 + x25*x26 =e= 0 ;
c8.. x27 + x28 - x23 + x29*x30 =e= 0 ;
c9.. x31 + x32 - x27 + x33*x34 =e= 0 ;
c10.. x35 + x36 - x31 + x37*x38 =e= 0 ;
c11.. x39 + x40 - x35 + x41*x42 =e= 0 ;
c12.. x43 + x44 - x39 + x45*x46 =e= 0 ;
c13.. x47 + x48 - x43 + x49*x50 =e= 0 ;
c14.. x51 + x52 - x47 + x53*x54 =e= 0 ;
c15.. x55 + x56 - x51 + x57*x58 =e= 0 ;
c16.. x59 + x60 - x55 + x61*x62 =e= 0 ;
c17.. x63 + x64 - x59 + x65*x66 =e= 0 ;
c18.. x67 + x68 - x63 + x69*x70 =e= 0 ;
c19.. x71 + x72 - x67 + x73*x74 =e= 0 ;
c20.. x75 + x76 - x71 + x77*x78 =e= 0 ;
c21.. x79 + x80 - x75 + x81*x82 =e= 0 ;
c22.. x83 + x84 - x79 + x85*x86 =e= 0 ;
c23.. x87 + x88 - x83 + x89*x90 =e= 0 ;
c24.. x91 + x92 - x87 + x93*x94 =e= 0 ;
c25.. x95 + x96 - x91 + x97*x98 =e= 0 ;
c26.. x99 + x100 - x95 + x101*x102 =e= 0 ;
c27.. x103 + x104 - x99 + x105*x106 =e= 0 ;
c28.. x107 + x108 - x103 + x109*x110 =e= 0 ;
c29.. x111 + x112 - x107 + x113*x114 =e= 0 ;
c30.. x115 + x116 - x111 + x117*x118 =e= 0 ;
c31.. x119 + x120 - x115 + x121*x122 =e= 0 ;
c32.. x2 + x123 - x119 + x124*x125 =e= 0 ;
c33.. x126 + x127 - x128 + x129*x14 =e= 0 ;
c34.. x130 + x131 - x126 + x132*x18 =e= 0 ;
c35.. x133 + x134 - x130 + x135*x22 =e= 0 ;
c36.. x136 + x137 - x133 + x138*x26 =e= 0 ;
c37.. x139 + x140 - x136 + x141*x30 =e= 0 ;
c38.. x142 + x143 - x139 + x144*x34 =e= 0 ;
c39.. x145 + x146 - x142 + x147*x38 =e= 0 ;
c40.. x148 + x149 - x145 + x150*x42 =e= 0 ;
c41.. x151 + x152 - x148 + x153*x46 =e= 0 ;
c42.. x154 + x155 - x151 + x156*x50 =e= 0 ;
c43.. x157 + x158 - x154 + x159*x54 =e= 0 ;
c44.. x160 + x161 - x157 + x162*x58 =e= 0 ;
c45.. x163 + x164 - x160 + x165*x62 =e= 0 ;
c46.. x166 + x167 - x163 + x168*x66 =e= 0 ;
c47.. x169 + x170 - x166 + x171*x70 =e= 0 ;
c48.. x172 + x173 - x169 + x174*x74 =e= 0 ;
c49.. x175 + x176 - x172 + x177*x78 =e= 0 ;
c50.. x178 + x179 - x175 + x180*x82 =e= 0 ;
c51.. x181 + x182 - x178 + x183*x86 =e= 0 ;
c52.. x184 + x185 - x181 + x186*x90 =e= 0 ;
c53.. x187 + x188 - x184 + x189*x94 =e= 0 ;
c54.. x190 + x191 - x187 + x192*x98 =e= 0 ;
c55.. x193 + x194 - x190 + x195*x102 =e= 0 ;
c56.. x196 + x197 - x193 + x198*x106 =e= 0 ;
c57.. x199 + x200 - x196 + x201*x110 =e= 0 ;
c58.. x202 + x203 - x199 + x204*x114 =e= 0 ;
c59.. x205 + x206 - x202 + x207*x118 =e= 0 ;
c60.. x208 + x209 - x205 + x210*x122 =e= 0 ;
c61.. x6 + x211 - x208 + x212*x125 =e= 0 ;
c62.. x213 + x214 - x215 =e= 0 ;
c63.. x216 + x217 - x213 =e= 0 ;
c64.. x218 + x219 - x216 =e= 0 ;
c65.. x220 + x221 - x218 =e= 0 ;
c66.. x222 + x223 - x220 =e= 0 ;
c67.. x224 + x225 - x222 =e= 0 ;
c68.. x226 + x227 - x224 =e= 0 ;
c69.. x228 + x229 - x226 =e= 0 ;
c70.. x230 + x231 - x228 =e= 0 ;
c71.. x232 + x233 - x230 =e= 0 ;
c72.. x234 + x235 - x232 =e= 0 ;
c73.. x236 + x237 - x234 =e= 0 ;
c74.. x238 + x239 - x236 =e= 0 ;
c75.. x240 + x241 - x238 =e= 0 ;
c76.. x242 + x243 - x240 =e= 0 ;
c77.. x244 + x245 - x242 =e= 0 ;
c78.. x246 + x247 - x244 =e= 0 ;
c79.. x248 + x249 - x246 =e= 0 ;
c80.. x250 + x251 - x248 =e= 0 ;
c81.. x252 + x253 - x250 =e= 0 ;
c82.. x254 + x255 - x252 =e= 0 ;
c83.. x256 + x257 - x254 =e= 0 ;
c84.. x258 + x259 - x256 =e= 0 ;
c85.. x260 + x261 - x258 =e= 0 ;
c86.. x262 + x263 - x260 =e= 0 ;
c87.. x264 + x265 - x262 =e= 0 ;
c88.. x266 + x267 - x264 =e= 0 ;
c89.. x268 + x269 - x266 =e= 0 ;
c90.. x9 + x270 - x268 =e= 0 ;
c91.. x12 - x271 - x272 =e= 0 ;
c92.. x128 - x273 - x274 =e= 0 ;
c93.. x215 - x275 - x276 =e= 0 ;
c94.. x271*x215 - x12*x275 =e= 0 ;
c95.. x273*x215 - x128*x275 =e= 0 ;
c96.. 0.94999999999999996*x275 - x273 =e= 0 ;
c97.. x18 - x14 =e= 0 ;
c98.. x22 - x18 =e= 0 ;
c99.. x26 - x22 =e= 0 ;
c100.. x30 - x26 =e= 0 ;
c101.. x34 - x30 =e= 0 ;
c102.. x38 - x34 =e= 0 ;
c103.. x42 - x38 =e= 0 ;
c104.. x46 - x42 =e= 0 ;
c105.. x50 - x46 =e= 0 ;
c106.. x54 - x50 =e= 0 ;
c107.. x58 - x54 =e= 0 ;
c108.. x62 - x58 =e= 0 ;
c109.. x66 - x62 =e= 0 ;
c110.. x70 - x66 =e= 0 ;
c111.. x74 - x70 =e= 0 ;
c112.. x78 - x74 =e= 0 ;
c113.. x82 - x78 =e= 0 ;
c114.. x86 - x82 =e= 0 ;
c115.. x90 - x86 =e= 0 ;
c116.. x94 - x90 =e= 0 ;
c117.. x98 - x94 =e= 0 ;
c118.. x102 - x98 =e= 0 ;
c119.. x106 - x102 =e= 0 ;
c120.. x110 - x106 =e= 0 ;
c121.. x114 - x110 =e= 0 ;
c122.. x118 - x114 =e= 0 ;
c123.. x122 - x118 =e= 0 ;
c124.. x125 - x122 =e= 0 ;
c125.. x4 - x125 =e= 0 ;
c126_lo.. 1 =l= 1 - x277 + x278 ;
c127_lo.. 1 =l= 1 - x279 + x280 ;
c128_lo.. 1 =l= 1 - x281 + x282 ;
c129_lo.. 1 =l= 1 - x283 + x284 ;
c130_lo.. 1 =l= 1 - x285 + x286 ;
c131_lo.. 1 =l= 1 - x287 + x288 ;
c132_lo.. 1 =l= 1 - x289 + x290 ;
c133_lo.. 1 =l= 1 - x291 + x292 ;
c134_lo.. 1 =l= 1 - x293 + x294 ;
c135_lo.. 1 =l= 1 - x295 + x296 ;
c136_lo.. 1 =l= 1 - x297 + x298 ;
c137_lo.. 1 =l= 1 - x299 + x300 ;
c138_lo.. 1 =l= 1 - x301 + x302 ;
c139_lo.. 1 =l= 1 - x303 + x304 ;
c140_lo.. 1 =l= 1 - x305 + x306 ;
c141_lo.. 1 =l= 1 - x307 + x308 ;
c142_lo.. 1 =l= 1 - x309 + x310 ;
c143_lo.. 1 =l= 1 - x311 + x312 ;
c144_lo.. 1 =l= 1 - x313 + x314 ;
c145_lo.. 1 =l= 1 - x315 + x316 ;
c146_lo.. 1 =l= 1 - x317 + x318 ;
c147_lo.. 1 =l= 1 - x319 + x320 ;
c148_lo.. 1 =l= 1 - x321 + x322 ;
c149_lo.. 1 =l= 1 - x323 + x324 ;
c150_lo.. 1 =l= 1 - x325 + x326 ;
c151_lo.. 1 =l= 1 - x327 + x328 ;
c152_lo.. 1 =l= 1 - x329 + x330 ;
c153_lo.. 1 =l= 1 - x331 + x332 ;
c154_lo.. 1 =l= 1 - x333 + x334 ;
c155_lo.. 1 =l= 1 - x335 + x336 ;
c156.. x337 + x338 + x339 + x340 + x341 + x342 + x343 + x344 + x345 + x346 + x347 + x348 + x349 + x350 + x351 + x352 + x353 + x354 + x355 + x356 + x357 + x358 + x359 + x360 + x361 + x362 + x363 + x364 + x365 + x366 =e= 1 ;
c157.. x277 + x279 + x281 + x283 + x285 + x287 + x289 + x291 + x293 + x295 + x297 + x299 + x301 + x303 + x305 + x307 + x309 + x311 + x313 + x315 + x317 + x319 + x321 + x323 + x325 + x327 + x329 + x331 + x333 + x335 =e= 1 ;
c158.. x278 =e= 1 ;
c159_lo.. 1 =l= x280 + x337 ;
c160_lo.. 1 =l= 1 - x338 + x280 ;
c161_lo.. 1 =l= 1 - x280 + x338 + 1 - x337 ;
c162_lo.. 1 =l= 1 - x339 + x282 ;
c163_lo.. 1 =l= x282 + x337 + x338 ;
c164_lo.. 1 =l= 1 - x282 + x339 + 1 - x337 ;
c165_lo.. 1 =l= 1 - x282 + x339 + 1 - x338 ;
c166_lo.. 1 =l= 1 - x340 + x284 ;
c167_lo.. 1 =l= x284 + x337 + x338 + x339 ;
c168_lo.. 1 =l= 1 - x284 + x340 + 1 - x337 ;
c169_lo.. 1 =l= 1 - x284 + x340 + 1 - x338 ;
c170_lo.. 1 =l= 1 - x284 + x340 + 1 - x339 ;
c171_lo.. 1 =l= 1 - x341 + x286 ;
c172_lo.. 1 =l= 1 - x286 + x341 + 1 - x337 ;
c173_lo.. 1 =l= 1 - x286 + x341 + 1 - x338 ;
c174_lo.. 1 =l= 1 - x286 + x341 + 1 - x339 ;
c175_lo.. 1 =l= 1 - x286 + x341 + 1 - x340 ;
c176_lo.. 1 =l= x286 + x337 + x338 + x339 + x340 ;
c177_lo.. 1 =l= 1 - x342 + x288 ;
c178_lo.. 1 =l= 1 - x288 + x342 + 1 - x337 ;
c179_lo.. 1 =l= 1 - x288 + x342 + 1 - x338 ;
c180_lo.. 1 =l= 1 - x288 + x342 + 1 - x339 ;
c181_lo.. 1 =l= 1 - x288 + x342 + 1 - x340 ;
c182_lo.. 1 =l= 1 - x288 + x342 + 1 - x341 ;
c183_lo.. 1 =l= x288 + x337 + x338 + x339 + x340 + x341 ;
c184_lo.. 1 =l= 1 - x343 + x290 ;
c185_lo.. 1 =l= 1 - x290 + x343 + 1 - x337 ;
c186_lo.. 1 =l= 1 - x290 + x343 + 1 - x338 ;
c187_lo.. 1 =l= 1 - x290 + x343 + 1 - x339 ;
c188_lo.. 1 =l= 1 - x290 + x343 + 1 - x340 ;
c189_lo.. 1 =l= 1 - x290 + x343 + 1 - x341 ;
c190_lo.. 1 =l= 1 - x290 + x343 + 1 - x342 ;
c191_lo.. 1 =l= x290 + x337 + x338 + x339 + x340 + x341 + x342 ;
c192_lo.. 1 =l= 1 - x344 + x292 ;
c193_lo.. 1 =l= 1 - x292 + x344 + 1 - x337 ;
c194_lo.. 1 =l= 1 - x292 + x344 + 1 - x338 ;
c195_lo.. 1 =l= 1 - x292 + x344 + 1 - x339 ;
c196_lo.. 1 =l= 1 - x292 + x344 + 1 - x340 ;
c197_lo.. 1 =l= 1 - x292 + x344 + 1 - x341 ;
c198_lo.. 1 =l= 1 - x292 + x344 + 1 - x342 ;
c199_lo.. 1 =l= 1 - x292 + x344 + 1 - x343 ;
c200_lo.. 1 =l= x292 + x337 + x338 + x339 + x340 + x341 + x342 + x343 ;
c201_lo.. 1 =l= 1 - x345 + x294 ;
c202_lo.. 1 =l= 1 - x294 + x345 + 1 - x337 ;
c203_lo.. 1 =l= 1 - x294 + x345 + 1 - x338 ;
c204_lo.. 1 =l= 1 - x294 + x345 + 1 - x339 ;
c205_lo.. 1 =l= 1 - x294 + x345 + 1 - x340 ;
c206_lo.. 1 =l= 1 - x294 + x345 + 1 - x341 ;
c207_lo.. 1 =l= 1 - x294 + x345 + 1 - x342 ;
c208_lo.. 1 =l= 1 - x294 + x345 + 1 - x343 ;
c209_lo.. 1 =l= 1 - x294 + x345 + 1 - x344 ;
c210_lo.. 1 =l= x294 + x337 + x338 + x339 + x340 + x341 + x342 + x343 + x344 ;
c211_lo.. 1 =l= 1 - x346 + x296 ;
c212_lo.. 1 =l= 1 - x296 + x346 + 1 - x337 ;
c213_lo.. 1 =l= 1 - x296 + x346 + 1 - x338 ;
c214_lo.. 1 =l= 1 - x296 + x346 + 1 - x339 ;
c215_lo.. 1 =l= 1 - x296 + x346 + 1 - x340 ;
c216_lo.. 1 =l= 1 - x296 + x346 + 1 - x341 ;
c217_lo.. 1 =l= 1 - x296 + x346 + 1 - x342 ;
c218_lo.. 1 =l= 1 - x296 + x346 + 1 - x343 ;
c219_lo.. 1 =l= 1 - x296 + x346 + 1 - x344 ;
c220_lo.. 1 =l= 1 - x296 + x346 + 1 - x345 ;
c221_lo.. 1 =l= x296 + x337 + x338 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c222_lo.. 1 =l= 1 - x347 + x298 ;
c223_lo.. 1 =l= 1 - x298 + x347 + 1 - x337 ;
c224_lo.. 1 =l= 1 - x298 + x347 + 1 - x346 ;
c225_lo.. 1 =l= 1 - x298 + x347 + 1 - x338 ;
c226_lo.. 1 =l= 1 - x298 + x347 + 1 - x339 ;
c227_lo.. 1 =l= 1 - x298 + x347 + 1 - x340 ;
c228_lo.. 1 =l= 1 - x298 + x347 + 1 - x341 ;
c229_lo.. 1 =l= 1 - x298 + x347 + 1 - x342 ;
c230_lo.. 1 =l= 1 - x298 + x347 + 1 - x343 ;
c231_lo.. 1 =l= 1 - x298 + x347 + 1 - x344 ;
c232_lo.. 1 =l= 1 - x298 + x347 + 1 - x345 ;
c233_lo.. 1 =l= x298 + x337 + x346 + x338 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c234_lo.. 1 =l= 1 - x348 + x300 ;
c235_lo.. 1 =l= 1 - x300 + x348 + 1 - x337 ;
c236_lo.. 1 =l= 1 - x300 + x348 + 1 - x346 ;
c237_lo.. 1 =l= 1 - x300 + x348 + 1 - x347 ;
c238_lo.. 1 =l= 1 - x300 + x348 + 1 - x338 ;
c239_lo.. 1 =l= 1 - x300 + x348 + 1 - x339 ;
c240_lo.. 1 =l= 1 - x300 + x348 + 1 - x340 ;
c241_lo.. 1 =l= 1 - x300 + x348 + 1 - x341 ;
c242_lo.. 1 =l= 1 - x300 + x348 + 1 - x342 ;
c243_lo.. 1 =l= 1 - x300 + x348 + 1 - x343 ;
c244_lo.. 1 =l= 1 - x300 + x348 + 1 - x344 ;
c245_lo.. 1 =l= 1 - x300 + x348 + 1 - x345 ;
c246_lo.. 1 =l= x300 + x337 + x346 + x347 + x338 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c247_lo.. 1 =l= 1 - x349 + x302 ;
c248_lo.. 1 =l= 1 - x302 + x349 + 1 - x337 ;
c249_lo.. 1 =l= 1 - x302 + x349 + 1 - x346 ;
c250_lo.. 1 =l= 1 - x302 + x349 + 1 - x347 ;
c251_lo.. 1 =l= 1 - x302 + x349 + 1 - x348 ;
c252_lo.. 1 =l= 1 - x302 + x349 + 1 - x338 ;
c253_lo.. 1 =l= 1 - x302 + x349 + 1 - x339 ;
c254_lo.. 1 =l= 1 - x302 + x349 + 1 - x340 ;
c255_lo.. 1 =l= 1 - x302 + x349 + 1 - x341 ;
c256_lo.. 1 =l= 1 - x302 + x349 + 1 - x342 ;
c257_lo.. 1 =l= 1 - x302 + x349 + 1 - x343 ;
c258_lo.. 1 =l= 1 - x302 + x349 + 1 - x344 ;
c259_lo.. 1 =l= 1 - x302 + x349 + 1 - x345 ;
c260_lo.. 1 =l= x302 + x337 + x346 + x347 + x348 + x338 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c261_lo.. 1 =l= 1 - x350 + x304 ;
c262_lo.. 1 =l= 1 - x304 + x350 + 1 - x337 ;
c263_lo.. 1 =l= 1 - x304 + x350 + 1 - x346 ;
c264_lo.. 1 =l= 1 - x304 + x350 + 1 - x347 ;
c265_lo.. 1 =l= 1 - x304 + x350 + 1 - x348 ;
c266_lo.. 1 =l= 1 - x304 + x350 + 1 - x349 ;
c267_lo.. 1 =l= 1 - x304 + x350 + 1 - x338 ;
c268_lo.. 1 =l= 1 - x304 + x350 + 1 - x339 ;
c269_lo.. 1 =l= 1 - x304 + x350 + 1 - x340 ;
c270_lo.. 1 =l= 1 - x304 + x350 + 1 - x341 ;
c271_lo.. 1 =l= 1 - x304 + x350 + 1 - x342 ;
c272_lo.. 1 =l= 1 - x304 + x350 + 1 - x343 ;
c273_lo.. 1 =l= 1 - x304 + x350 + 1 - x344 ;
c274_lo.. 1 =l= 1 - x304 + x350 + 1 - x345 ;
c275_lo.. 1 =l= x304 + x337 + x346 + x347 + x348 + x349 + x338 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c276_lo.. 1 =l= 1 - x351 + x306 ;
c277_lo.. 1 =l= 1 - x306 + x351 + 1 - x337 ;
c278_lo.. 1 =l= 1 - x306 + x351 + 1 - x346 ;
c279_lo.. 1 =l= 1 - x306 + x351 + 1 - x347 ;
c280_lo.. 1 =l= 1 - x306 + x351 + 1 - x348 ;
c281_lo.. 1 =l= 1 - x306 + x351 + 1 - x349 ;
c282_lo.. 1 =l= 1 - x306 + x351 + 1 - x350 ;
c283_lo.. 1 =l= 1 - x306 + x351 + 1 - x338 ;
c284_lo.. 1 =l= 1 - x306 + x351 + 1 - x339 ;
c285_lo.. 1 =l= 1 - x306 + x351 + 1 - x340 ;
c286_lo.. 1 =l= 1 - x306 + x351 + 1 - x341 ;
c287_lo.. 1 =l= 1 - x306 + x351 + 1 - x342 ;
c288_lo.. 1 =l= 1 - x306 + x351 + 1 - x343 ;
c289_lo.. 1 =l= 1 - x306 + x351 + 1 - x344 ;
c290_lo.. 1 =l= 1 - x306 + x351 + 1 - x345 ;
c291_lo.. 1 =l= x306 + x337 + x346 + x347 + x348 + x349 + x350 + x338 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c292_lo.. 1 =l= 1 - x352 + x308 ;
c293_lo.. 1 =l= 1 - x308 + x352 + 1 - x337 ;
c294_lo.. 1 =l= 1 - x308 + x352 + 1 - x346 ;
c295_lo.. 1 =l= 1 - x308 + x352 + 1 - x347 ;
c296_lo.. 1 =l= 1 - x308 + x352 + 1 - x348 ;
c297_lo.. 1 =l= 1 - x308 + x352 + 1 - x349 ;
c298_lo.. 1 =l= 1 - x308 + x352 + 1 - x350 ;
c299_lo.. 1 =l= 1 - x308 + x352 + 1 - x351 ;
c300_lo.. 1 =l= 1 - x308 + x352 + 1 - x338 ;
c301_lo.. 1 =l= 1 - x308 + x352 + 1 - x339 ;
c302_lo.. 1 =l= 1 - x308 + x352 + 1 - x340 ;
c303_lo.. 1 =l= 1 - x308 + x352 + 1 - x341 ;
c304_lo.. 1 =l= 1 - x308 + x352 + 1 - x342 ;
c305_lo.. 1 =l= 1 - x308 + x352 + 1 - x343 ;
c306_lo.. 1 =l= 1 - x308 + x352 + 1 - x344 ;
c307_lo.. 1 =l= 1 - x308 + x352 + 1 - x345 ;
c308_lo.. 1 =l= x308 + x337 + x346 + x347 + x348 + x349 + x350 + x351 + x338 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c309_lo.. 1 =l= 1 - x353 + x310 ;
c310_lo.. 1 =l= 1 - x310 + x353 + 1 - x337 ;
c311_lo.. 1 =l= 1 - x310 + x353 + 1 - x346 ;
c312_lo.. 1 =l= 1 - x310 + x353 + 1 - x347 ;
c313_lo.. 1 =l= 1 - x310 + x353 + 1 - x348 ;
c314_lo.. 1 =l= 1 - x310 + x353 + 1 - x349 ;
c315_lo.. 1 =l= 1 - x310 + x353 + 1 - x350 ;
c316_lo.. 1 =l= 1 - x310 + x353 + 1 - x351 ;
c317_lo.. 1 =l= 1 - x310 + x353 + 1 - x352 ;
c318_lo.. 1 =l= 1 - x310 + x353 + 1 - x338 ;
c319_lo.. 1 =l= 1 - x310 + x353 + 1 - x339 ;
c320_lo.. 1 =l= 1 - x310 + x353 + 1 - x340 ;
c321_lo.. 1 =l= 1 - x310 + x353 + 1 - x341 ;
c322_lo.. 1 =l= 1 - x310 + x353 + 1 - x342 ;
c323_lo.. 1 =l= 1 - x310 + x353 + 1 - x343 ;
c324_lo.. 1 =l= 1 - x310 + x353 + 1 - x344 ;
c325_lo.. 1 =l= 1 - x310 + x353 + 1 - x345 ;
c326_lo.. 1 =l= x310 + x337 + x346 + x347 + x348 + x349 + x350 + x351 + x352 + x338 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c327_lo.. 1 =l= 1 - x354 + x312 ;
c328_lo.. 1 =l= 1 - x312 + x354 + 1 - x337 ;
c329_lo.. 1 =l= 1 - x312 + x354 + 1 - x346 ;
c330_lo.. 1 =l= 1 - x312 + x354 + 1 - x347 ;
c331_lo.. 1 =l= 1 - x312 + x354 + 1 - x348 ;
c332_lo.. 1 =l= 1 - x312 + x354 + 1 - x349 ;
c333_lo.. 1 =l= 1 - x312 + x354 + 1 - x350 ;
c334_lo.. 1 =l= 1 - x312 + x354 + 1 - x351 ;
c335_lo.. 1 =l= 1 - x312 + x354 + 1 - x352 ;
c336_lo.. 1 =l= 1 - x312 + x354 + 1 - x353 ;
c337_lo.. 1 =l= 1 - x312 + x354 + 1 - x338 ;
c338_lo.. 1 =l= 1 - x312 + x354 + 1 - x339 ;
c339_lo.. 1 =l= 1 - x312 + x354 + 1 - x340 ;
c340_lo.. 1 =l= 1 - x312 + x354 + 1 - x341 ;
c341_lo.. 1 =l= 1 - x312 + x354 + 1 - x342 ;
c342_lo.. 1 =l= 1 - x312 + x354 + 1 - x343 ;
c343_lo.. 1 =l= 1 - x312 + x354 + 1 - x344 ;
c344_lo.. 1 =l= 1 - x312 + x354 + 1 - x345 ;
c345_lo.. 1 =l= x312 + x337 + x346 + x347 + x348 + x349 + x350 + x351 + x352 + x353 + x338 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c346_lo.. 1 =l= 1 - x355 + x314 ;
c347_lo.. 1 =l= 1 - x314 + x355 + 1 - x337 ;
c348_lo.. 1 =l= 1 - x314 + x355 + 1 - x346 ;
c349_lo.. 1 =l= 1 - x314 + x355 + 1 - x347 ;
c350_lo.. 1 =l= 1 - x314 + x355 + 1 - x348 ;
c351_lo.. 1 =l= 1 - x314 + x355 + 1 - x349 ;
c352_lo.. 1 =l= 1 - x314 + x355 + 1 - x350 ;
c353_lo.. 1 =l= 1 - x314 + x355 + 1 - x351 ;
c354_lo.. 1 =l= 1 - x314 + x355 + 1 - x352 ;
c355_lo.. 1 =l= 1 - x314 + x355 + 1 - x353 ;
c356_lo.. 1 =l= 1 - x314 + x355 + 1 - x354 ;
c357_lo.. 1 =l= 1 - x314 + x355 + 1 - x338 ;
c358_lo.. 1 =l= 1 - x314 + x355 + 1 - x339 ;
c359_lo.. 1 =l= 1 - x314 + x355 + 1 - x340 ;
c360_lo.. 1 =l= 1 - x314 + x355 + 1 - x341 ;
c361_lo.. 1 =l= 1 - x314 + x355 + 1 - x342 ;
c362_lo.. 1 =l= 1 - x314 + x355 + 1 - x343 ;
c363_lo.. 1 =l= 1 - x314 + x355 + 1 - x344 ;
c364_lo.. 1 =l= 1 - x314 + x355 + 1 - x345 ;
c365_lo.. 1 =l= x314 + x337 + x346 + x347 + x348 + x349 + x350 + x351 + x352 + x353 + x354 + x338 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c366_lo.. 1 =l= 1 - x356 + x316 ;
c367_lo.. 1 =l= 1 - x316 + x356 + 1 - x337 ;
c368_lo.. 1 =l= 1 - x316 + x356 + 1 - x346 ;
c369_lo.. 1 =l= 1 - x316 + x356 + 1 - x347 ;
c370_lo.. 1 =l= 1 - x316 + x356 + 1 - x348 ;
c371_lo.. 1 =l= 1 - x316 + x356 + 1 - x349 ;
c372_lo.. 1 =l= 1 - x316 + x356 + 1 - x350 ;
c373_lo.. 1 =l= 1 - x316 + x356 + 1 - x351 ;
c374_lo.. 1 =l= 1 - x316 + x356 + 1 - x352 ;
c375_lo.. 1 =l= 1 - x316 + x356 + 1 - x353 ;
c376_lo.. 1 =l= 1 - x316 + x356 + 1 - x354 ;
c377_lo.. 1 =l= 1 - x316 + x356 + 1 - x355 ;
c378_lo.. 1 =l= 1 - x316 + x356 + 1 - x338 ;
c379_lo.. 1 =l= 1 - x316 + x356 + 1 - x339 ;
c380_lo.. 1 =l= 1 - x316 + x356 + 1 - x340 ;
c381_lo.. 1 =l= 1 - x316 + x356 + 1 - x341 ;
c382_lo.. 1 =l= 1 - x316 + x356 + 1 - x342 ;
c383_lo.. 1 =l= 1 - x316 + x356 + 1 - x343 ;
c384_lo.. 1 =l= 1 - x316 + x356 + 1 - x344 ;
c385_lo.. 1 =l= 1 - x316 + x356 + 1 - x345 ;
c386_lo.. 1 =l= x316 + x337 + x346 + x347 + x348 + x349 + x350 + x351 + x352 + x353 + x354 + x355 + x338 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c387_lo.. 1 =l= 1 - x357 + x318 ;
c388_lo.. 1 =l= 1 - x318 + x357 + 1 - x337 ;
c389_lo.. 1 =l= 1 - x318 + x357 + 1 - x346 ;
c390_lo.. 1 =l= 1 - x318 + x357 + 1 - x347 ;
c391_lo.. 1 =l= 1 - x318 + x357 + 1 - x348 ;
c392_lo.. 1 =l= 1 - x318 + x357 + 1 - x349 ;
c393_lo.. 1 =l= 1 - x318 + x357 + 1 - x350 ;
c394_lo.. 1 =l= 1 - x318 + x357 + 1 - x351 ;
c395_lo.. 1 =l= 1 - x318 + x357 + 1 - x352 ;
c396_lo.. 1 =l= 1 - x318 + x357 + 1 - x353 ;
c397_lo.. 1 =l= 1 - x318 + x357 + 1 - x354 ;
c398_lo.. 1 =l= 1 - x318 + x357 + 1 - x355 ;
c399_lo.. 1 =l= 1 - x318 + x357 + 1 - x338 ;
c400_lo.. 1 =l= 1 - x318 + x357 + 1 - x356 ;
c401_lo.. 1 =l= 1 - x318 + x357 + 1 - x339 ;
c402_lo.. 1 =l= 1 - x318 + x357 + 1 - x340 ;
c403_lo.. 1 =l= 1 - x318 + x357 + 1 - x341 ;
c404_lo.. 1 =l= 1 - x318 + x357 + 1 - x342 ;
c405_lo.. 1 =l= 1 - x318 + x357 + 1 - x343 ;
c406_lo.. 1 =l= 1 - x318 + x357 + 1 - x344 ;
c407_lo.. 1 =l= 1 - x318 + x357 + 1 - x345 ;
c408_lo.. 1 =l= x318 + x337 + x346 + x347 + x348 + x349 + x350 + x351 + x352 + x353 + x354 + x355 + x338 + x356 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c409_lo.. 1 =l= 1 - x358 + x320 ;
c410_lo.. 1 =l= 1 - x320 + x358 + 1 - x337 ;
c411_lo.. 1 =l= 1 - x320 + x358 + 1 - x346 ;
c412_lo.. 1 =l= 1 - x320 + x358 + 1 - x347 ;
c413_lo.. 1 =l= 1 - x320 + x358 + 1 - x348 ;
c414_lo.. 1 =l= 1 - x320 + x358 + 1 - x349 ;
c415_lo.. 1 =l= 1 - x320 + x358 + 1 - x350 ;
c416_lo.. 1 =l= 1 - x320 + x358 + 1 - x351 ;
c417_lo.. 1 =l= 1 - x320 + x358 + 1 - x352 ;
c418_lo.. 1 =l= 1 - x320 + x358 + 1 - x353 ;
c419_lo.. 1 =l= 1 - x320 + x358 + 1 - x354 ;
c420_lo.. 1 =l= 1 - x320 + x358 + 1 - x355 ;
c421_lo.. 1 =l= 1 - x320 + x358 + 1 - x338 ;
c422_lo.. 1 =l= 1 - x320 + x358 + 1 - x356 ;
c423_lo.. 1 =l= 1 - x320 + x358 + 1 - x357 ;
c424_lo.. 1 =l= 1 - x320 + x358 + 1 - x339 ;
c425_lo.. 1 =l= 1 - x320 + x358 + 1 - x340 ;
c426_lo.. 1 =l= 1 - x320 + x358 + 1 - x341 ;
c427_lo.. 1 =l= 1 - x320 + x358 + 1 - x342 ;
c428_lo.. 1 =l= 1 - x320 + x358 + 1 - x343 ;
c429_lo.. 1 =l= 1 - x320 + x358 + 1 - x344 ;
c430_lo.. 1 =l= 1 - x320 + x358 + 1 - x345 ;
c431_lo.. 1 =l= x320 + x337 + x346 + x347 + x348 + x349 + x350 + x351 + x352 + x353 + x354 + x355 + x338 + x356 + x357 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c432_lo.. 1 =l= 1 - x359 + x322 ;
c433_lo.. 1 =l= 1 - x322 + x359 + 1 - x337 ;
c434_lo.. 1 =l= 1 - x322 + x359 + 1 - x346 ;
c435_lo.. 1 =l= 1 - x322 + x359 + 1 - x347 ;
c436_lo.. 1 =l= 1 - x322 + x359 + 1 - x348 ;
c437_lo.. 1 =l= 1 - x322 + x359 + 1 - x349 ;
c438_lo.. 1 =l= 1 - x322 + x359 + 1 - x350 ;
c439_lo.. 1 =l= 1 - x322 + x359 + 1 - x351 ;
c440_lo.. 1 =l= 1 - x322 + x359 + 1 - x352 ;
c441_lo.. 1 =l= 1 - x322 + x359 + 1 - x353 ;
c442_lo.. 1 =l= 1 - x322 + x359 + 1 - x354 ;
c443_lo.. 1 =l= 1 - x322 + x359 + 1 - x355 ;
c444_lo.. 1 =l= 1 - x322 + x359 + 1 - x338 ;
c445_lo.. 1 =l= 1 - x322 + x359 + 1 - x356 ;
c446_lo.. 1 =l= 1 - x322 + x359 + 1 - x357 ;
c447_lo.. 1 =l= 1 - x322 + x359 + 1 - x358 ;
c448_lo.. 1 =l= 1 - x322 + x359 + 1 - x339 ;
c449_lo.. 1 =l= 1 - x322 + x359 + 1 - x340 ;
c450_lo.. 1 =l= 1 - x322 + x359 + 1 - x341 ;
c451_lo.. 1 =l= 1 - x322 + x359 + 1 - x342 ;
c452_lo.. 1 =l= 1 - x322 + x359 + 1 - x343 ;
c453_lo.. 1 =l= 1 - x322 + x359 + 1 - x344 ;
c454_lo.. 1 =l= 1 - x322 + x359 + 1 - x345 ;
c455_lo.. 1 =l= x322 + x337 + x346 + x347 + x348 + x349 + x350 + x351 + x352 + x353 + x354 + x355 + x338 + x356 + x357 + x358 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c456_lo.. 1 =l= 1 - x360 + x324 ;
c457_lo.. 1 =l= 1 - x324 + x360 + 1 - x337 ;
c458_lo.. 1 =l= 1 - x324 + x360 + 1 - x346 ;
c459_lo.. 1 =l= 1 - x324 + x360 + 1 - x347 ;
c460_lo.. 1 =l= 1 - x324 + x360 + 1 - x348 ;
c461_lo.. 1 =l= 1 - x324 + x360 + 1 - x349 ;
c462_lo.. 1 =l= 1 - x324 + x360 + 1 - x350 ;
c463_lo.. 1 =l= 1 - x324 + x360 + 1 - x351 ;
c464_lo.. 1 =l= 1 - x324 + x360 + 1 - x352 ;
c465_lo.. 1 =l= 1 - x324 + x360 + 1 - x353 ;
c466_lo.. 1 =l= 1 - x324 + x360 + 1 - x354 ;
c467_lo.. 1 =l= 1 - x324 + x360 + 1 - x355 ;
c468_lo.. 1 =l= 1 - x324 + x360 + 1 - x338 ;
c469_lo.. 1 =l= 1 - x324 + x360 + 1 - x356 ;
c470_lo.. 1 =l= 1 - x324 + x360 + 1 - x357 ;
c471_lo.. 1 =l= 1 - x324 + x360 + 1 - x358 ;
c472_lo.. 1 =l= 1 - x324 + x360 + 1 - x359 ;
c473_lo.. 1 =l= 1 - x324 + x360 + 1 - x339 ;
c474_lo.. 1 =l= 1 - x324 + x360 + 1 - x340 ;
c475_lo.. 1 =l= 1 - x324 + x360 + 1 - x341 ;
c476_lo.. 1 =l= 1 - x324 + x360 + 1 - x342 ;
c477_lo.. 1 =l= 1 - x324 + x360 + 1 - x343 ;
c478_lo.. 1 =l= 1 - x324 + x360 + 1 - x344 ;
c479_lo.. 1 =l= 1 - x324 + x360 + 1 - x345 ;
c480_lo.. 1 =l= x324 + x337 + x346 + x347 + x348 + x349 + x350 + x351 + x352 + x353 + x354 + x355 + x338 + x356 + x357 + x358 + x359 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c481_lo.. 1 =l= 1 - x361 + x326 ;
c482_lo.. 1 =l= 1 - x326 + x361 + 1 - x337 ;
c483_lo.. 1 =l= 1 - x326 + x361 + 1 - x346 ;
c484_lo.. 1 =l= 1 - x326 + x361 + 1 - x347 ;
c485_lo.. 1 =l= 1 - x326 + x361 + 1 - x348 ;
c486_lo.. 1 =l= 1 - x326 + x361 + 1 - x349 ;
c487_lo.. 1 =l= 1 - x326 + x361 + 1 - x350 ;
c488_lo.. 1 =l= 1 - x326 + x361 + 1 - x351 ;
c489_lo.. 1 =l= 1 - x326 + x361 + 1 - x352 ;
c490_lo.. 1 =l= 1 - x326 + x361 + 1 - x353 ;
c491_lo.. 1 =l= 1 - x326 + x361 + 1 - x354 ;
c492_lo.. 1 =l= 1 - x326 + x361 + 1 - x355 ;
c493_lo.. 1 =l= 1 - x326 + x361 + 1 - x338 ;
c494_lo.. 1 =l= 1 - x326 + x361 + 1 - x356 ;
c495_lo.. 1 =l= 1 - x326 + x361 + 1 - x357 ;
c496_lo.. 1 =l= 1 - x326 + x361 + 1 - x358 ;
c497_lo.. 1 =l= 1 - x326 + x361 + 1 - x359 ;
c498_lo.. 1 =l= 1 - x326 + x361 + 1 - x360 ;
c499_lo.. 1 =l= 1 - x326 + x361 + 1 - x339 ;
c500_lo.. 1 =l= 1 - x326 + x361 + 1 - x340 ;
c501_lo.. 1 =l= 1 - x326 + x361 + 1 - x341 ;
c502_lo.. 1 =l= 1 - x326 + x361 + 1 - x342 ;
c503_lo.. 1 =l= 1 - x326 + x361 + 1 - x343 ;
c504_lo.. 1 =l= 1 - x326 + x361 + 1 - x344 ;
c505_lo.. 1 =l= 1 - x326 + x361 + 1 - x345 ;
c506_lo.. 1 =l= x326 + x337 + x346 + x347 + x348 + x349 + x350 + x351 + x352 + x353 + x354 + x355 + x338 + x356 + x357 + x358 + x359 + x360 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c507_lo.. 1 =l= 1 - x362 + x328 ;
c508_lo.. 1 =l= 1 - x328 + x362 + 1 - x337 ;
c509_lo.. 1 =l= 1 - x328 + x362 + 1 - x346 ;
c510_lo.. 1 =l= 1 - x328 + x362 + 1 - x347 ;
c511_lo.. 1 =l= 1 - x328 + x362 + 1 - x348 ;
c512_lo.. 1 =l= 1 - x328 + x362 + 1 - x349 ;
c513_lo.. 1 =l= 1 - x328 + x362 + 1 - x350 ;
c514_lo.. 1 =l= 1 - x328 + x362 + 1 - x351 ;
c515_lo.. 1 =l= 1 - x328 + x362 + 1 - x352 ;
c516_lo.. 1 =l= 1 - x328 + x362 + 1 - x353 ;
c517_lo.. 1 =l= 1 - x328 + x362 + 1 - x354 ;
c518_lo.. 1 =l= 1 - x328 + x362 + 1 - x355 ;
c519_lo.. 1 =l= 1 - x328 + x362 + 1 - x338 ;
c520_lo.. 1 =l= 1 - x328 + x362 + 1 - x356 ;
c521_lo.. 1 =l= 1 - x328 + x362 + 1 - x357 ;
c522_lo.. 1 =l= 1 - x328 + x362 + 1 - x358 ;
c523_lo.. 1 =l= 1 - x328 + x362 + 1 - x359 ;
c524_lo.. 1 =l= 1 - x328 + x362 + 1 - x360 ;
c525_lo.. 1 =l= 1 - x328 + x362 + 1 - x361 ;
c526_lo.. 1 =l= 1 - x328 + x362 + 1 - x339 ;
c527_lo.. 1 =l= 1 - x328 + x362 + 1 - x340 ;
c528_lo.. 1 =l= 1 - x328 + x362 + 1 - x341 ;
c529_lo.. 1 =l= 1 - x328 + x362 + 1 - x342 ;
c530_lo.. 1 =l= 1 - x328 + x362 + 1 - x343 ;
c531_lo.. 1 =l= 1 - x328 + x362 + 1 - x344 ;
c532_lo.. 1 =l= 1 - x328 + x362 + 1 - x345 ;
c533_lo.. 1 =l= x328 + x337 + x346 + x347 + x348 + x349 + x350 + x351 + x352 + x353 + x354 + x355 + x338 + x356 + x357 + x358 + x359 + x360 + x361 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c534_lo.. 1 =l= 1 - x363 + x330 ;
c535_lo.. 1 =l= 1 - x330 + x363 + 1 - x337 ;
c536_lo.. 1 =l= 1 - x330 + x363 + 1 - x346 ;
c537_lo.. 1 =l= 1 - x330 + x363 + 1 - x347 ;
c538_lo.. 1 =l= 1 - x330 + x363 + 1 - x348 ;
c539_lo.. 1 =l= 1 - x330 + x363 + 1 - x349 ;
c540_lo.. 1 =l= 1 - x330 + x363 + 1 - x350 ;
c541_lo.. 1 =l= 1 - x330 + x363 + 1 - x351 ;
c542_lo.. 1 =l= 1 - x330 + x363 + 1 - x352 ;
c543_lo.. 1 =l= 1 - x330 + x363 + 1 - x353 ;
c544_lo.. 1 =l= 1 - x330 + x363 + 1 - x354 ;
c545_lo.. 1 =l= 1 - x330 + x363 + 1 - x355 ;
c546_lo.. 1 =l= 1 - x330 + x363 + 1 - x338 ;
c547_lo.. 1 =l= 1 - x330 + x363 + 1 - x356 ;
c548_lo.. 1 =l= 1 - x330 + x363 + 1 - x357 ;
c549_lo.. 1 =l= 1 - x330 + x363 + 1 - x358 ;
c550_lo.. 1 =l= 1 - x330 + x363 + 1 - x359 ;
c551_lo.. 1 =l= 1 - x330 + x363 + 1 - x360 ;
c552_lo.. 1 =l= 1 - x330 + x363 + 1 - x361 ;
c553_lo.. 1 =l= 1 - x330 + x363 + 1 - x362 ;
c554_lo.. 1 =l= 1 - x330 + x363 + 1 - x339 ;
c555_lo.. 1 =l= 1 - x330 + x363 + 1 - x340 ;
c556_lo.. 1 =l= 1 - x330 + x363 + 1 - x341 ;
c557_lo.. 1 =l= 1 - x330 + x363 + 1 - x342 ;
c558_lo.. 1 =l= 1 - x330 + x363 + 1 - x343 ;
c559_lo.. 1 =l= 1 - x330 + x363 + 1 - x344 ;
c560_lo.. 1 =l= 1 - x330 + x363 + 1 - x345 ;
c561_lo.. 1 =l= x330 + x337 + x346 + x347 + x348 + x349 + x350 + x351 + x352 + x353 + x354 + x355 + x338 + x356 + x357 + x358 + x359 + x360 + x361 + x362 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c562_lo.. 1 =l= 1 - x364 + x332 ;
c563_lo.. 1 =l= 1 - x332 + x364 + 1 - x337 ;
c564_lo.. 1 =l= 1 - x332 + x364 + 1 - x346 ;
c565_lo.. 1 =l= 1 - x332 + x364 + 1 - x347 ;
c566_lo.. 1 =l= 1 - x332 + x364 + 1 - x348 ;
c567_lo.. 1 =l= 1 - x332 + x364 + 1 - x349 ;
c568_lo.. 1 =l= 1 - x332 + x364 + 1 - x350 ;
c569_lo.. 1 =l= 1 - x332 + x364 + 1 - x351 ;
c570_lo.. 1 =l= 1 - x332 + x364 + 1 - x352 ;
c571_lo.. 1 =l= 1 - x332 + x364 + 1 - x353 ;
c572_lo.. 1 =l= 1 - x332 + x364 + 1 - x354 ;
c573_lo.. 1 =l= 1 - x332 + x364 + 1 - x355 ;
c574_lo.. 1 =l= 1 - x332 + x364 + 1 - x338 ;
c575_lo.. 1 =l= 1 - x332 + x364 + 1 - x356 ;
c576_lo.. 1 =l= 1 - x332 + x364 + 1 - x357 ;
c577_lo.. 1 =l= 1 - x332 + x364 + 1 - x358 ;
c578_lo.. 1 =l= 1 - x332 + x364 + 1 - x359 ;
c579_lo.. 1 =l= 1 - x332 + x364 + 1 - x360 ;
c580_lo.. 1 =l= 1 - x332 + x364 + 1 - x361 ;
c581_lo.. 1 =l= 1 - x332 + x364 + 1 - x362 ;
c582_lo.. 1 =l= 1 - x332 + x364 + 1 - x363 ;
c583_lo.. 1 =l= 1 - x332 + x364 + 1 - x339 ;
c584_lo.. 1 =l= 1 - x332 + x364 + 1 - x340 ;
c585_lo.. 1 =l= 1 - x332 + x364 + 1 - x341 ;
c586_lo.. 1 =l= 1 - x332 + x364 + 1 - x342 ;
c587_lo.. 1 =l= 1 - x332 + x364 + 1 - x343 ;
c588_lo.. 1 =l= 1 - x332 + x364 + 1 - x344 ;
c589_lo.. 1 =l= 1 - x332 + x364 + 1 - x345 ;
c590_lo.. 1 =l= x332 + x337 + x346 + x347 + x348 + x349 + x350 + x351 + x352 + x353 + x354 + x355 + x338 + x356 + x357 + x358 + x359 + x360 + x361 + x362 + x363 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c591_lo.. 1 =l= 1 - x365 + x334 ;
c592_lo.. 1 =l= 1 - x334 + x365 + 1 - x337 ;
c593_lo.. 1 =l= 1 - x334 + x365 + 1 - x346 ;
c594_lo.. 1 =l= 1 - x334 + x365 + 1 - x347 ;
c595_lo.. 1 =l= 1 - x334 + x365 + 1 - x348 ;
c596_lo.. 1 =l= 1 - x334 + x365 + 1 - x349 ;
c597_lo.. 1 =l= 1 - x334 + x365 + 1 - x350 ;
c598_lo.. 1 =l= 1 - x334 + x365 + 1 - x351 ;
c599_lo.. 1 =l= 1 - x334 + x365 + 1 - x352 ;
c600_lo.. 1 =l= 1 - x334 + x365 + 1 - x353 ;
c601_lo.. 1 =l= 1 - x334 + x365 + 1 - x354 ;
c602_lo.. 1 =l= 1 - x334 + x365 + 1 - x355 ;
c603_lo.. 1 =l= 1 - x334 + x365 + 1 - x338 ;
c604_lo.. 1 =l= 1 - x334 + x365 + 1 - x356 ;
c605_lo.. 1 =l= 1 - x334 + x365 + 1 - x357 ;
c606_lo.. 1 =l= 1 - x334 + x365 + 1 - x358 ;
c607_lo.. 1 =l= 1 - x334 + x365 + 1 - x359 ;
c608_lo.. 1 =l= 1 - x334 + x365 + 1 - x360 ;
c609_lo.. 1 =l= 1 - x334 + x365 + 1 - x361 ;
c610_lo.. 1 =l= 1 - x334 + x365 + 1 - x362 ;
c611_lo.. 1 =l= 1 - x334 + x365 + 1 - x363 ;
c612_lo.. 1 =l= 1 - x334 + x365 + 1 - x364 ;
c613_lo.. 1 =l= 1 - x334 + x365 + 1 - x339 ;
c614_lo.. 1 =l= 1 - x334 + x365 + 1 - x340 ;
c615_lo.. 1 =l= 1 - x334 + x365 + 1 - x341 ;
c616_lo.. 1 =l= 1 - x334 + x365 + 1 - x342 ;
c617_lo.. 1 =l= 1 - x334 + x365 + 1 - x343 ;
c618_lo.. 1 =l= 1 - x334 + x365 + 1 - x344 ;
c619_lo.. 1 =l= 1 - x334 + x365 + 1 - x345 ;
c620_lo.. 1 =l= x334 + x337 + x346 + x347 + x348 + x349 + x350 + x351 + x352 + x353 + x354 + x355 + x338 + x356 + x357 + x358 + x359 + x360 + x361 + x362 + x363 + x364 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c621_lo.. 1 =l= 1 - x366 + x336 ;
c622_lo.. 1 =l= 1 - x336 + x366 + 1 - x337 ;
c623_lo.. 1 =l= 1 - x336 + x366 + 1 - x346 ;
c624_lo.. 1 =l= 1 - x336 + x366 + 1 - x347 ;
c625_lo.. 1 =l= 1 - x336 + x366 + 1 - x348 ;
c626_lo.. 1 =l= 1 - x336 + x366 + 1 - x349 ;
c627_lo.. 1 =l= 1 - x336 + x366 + 1 - x350 ;
c628_lo.. 1 =l= 1 - x336 + x366 + 1 - x351 ;
c629_lo.. 1 =l= 1 - x336 + x366 + 1 - x352 ;
c630_lo.. 1 =l= 1 - x336 + x366 + 1 - x353 ;
c631_lo.. 1 =l= 1 - x336 + x366 + 1 - x354 ;
c632_lo.. 1 =l= 1 - x336 + x366 + 1 - x355 ;
c633_lo.. 1 =l= 1 - x336 + x366 + 1 - x338 ;
c634_lo.. 1 =l= 1 - x336 + x366 + 1 - x356 ;
c635_lo.. 1 =l= 1 - x336 + x366 + 1 - x357 ;
c636_lo.. 1 =l= 1 - x336 + x366 + 1 - x358 ;
c637_lo.. 1 =l= 1 - x336 + x366 + 1 - x359 ;
c638_lo.. 1 =l= 1 - x336 + x366 + 1 - x360 ;
c639_lo.. 1 =l= 1 - x336 + x366 + 1 - x361 ;
c640_lo.. 1 =l= 1 - x336 + x366 + 1 - x362 ;
c641_lo.. 1 =l= 1 - x336 + x366 + 1 - x363 ;
c642_lo.. 1 =l= 1 - x336 + x366 + 1 - x364 ;
c643_lo.. 1 =l= 1 - x336 + x366 + 1 - x365 ;
c644_lo.. 1 =l= 1 - x336 + x366 + 1 - x339 ;
c645_lo.. 1 =l= 1 - x336 + x366 + 1 - x340 ;
c646_lo.. 1 =l= 1 - x336 + x366 + 1 - x341 ;
c647_lo.. 1 =l= 1 - x336 + x366 + 1 - x342 ;
c648_lo.. 1 =l= 1 - x336 + x366 + 1 - x343 ;
c649_lo.. 1 =l= 1 - x336 + x366 + 1 - x344 ;
c650_lo.. 1 =l= 1 - x336 + x366 + 1 - x345 ;
c651_lo.. 1 =l= x336 + x337 + x346 + x347 + x348 + x349 + x350 + x351 + x352 + x353 + x354 + x355 + x338 + x356 + x357 + x358 + x359 + x360 + x361 + x362 + x363 + x364 + x365 + x339 + x340 + x341 + x342 + x343 + x344 + x345 ;
c652.. x13 - (x367 + 0) =e= 0 ;
c653.. x215 - (x368 + x369) =e= 0 ;
c654.. x12 - (x370 + x371) =e= 0 ;
c655.. x128 - (x372 + x373) =e= 0 ;
c656.. x129 - (x374 + 0) =e= 0 ;
c657.. x375 - (x376 + 0) =e= 0 ;
c658.. x14 - (x377 + x378) =e= 0 ;
c659.. x11 - (x379 + 0) =e= 0 ;
c660.. x127 - (x380 + 0) =e= 0 ;
c661.. x214 - (x381 + 0) =e= 0 ;
c662.. x17 - (x382 + 0) =e= 0 ;
c663.. x213 - (x383 + x384) =e= 0 ;
c664.. x10 - (x385 + x386) =e= 0 ;
c665.. x126 - (x387 + x388) =e= 0 ;
c666.. x132 - (x389 + 0) =e= 0 ;
c667.. x390 - (x391 + 0) =e= 0 ;
c668.. x18 - (x392 + x393) =e= 0 ;
c669.. x16 - (x394 + 0) =e= 0 ;
c670.. x131 - (x395 + 0) =e= 0 ;
c671.. x217 - (x396 + 0) =e= 0 ;
c672.. x21 - (x397 + 0) =e= 0 ;
c673.. x216 - (x398 + x399) =e= 0 ;
c674.. x15 - (x400 + x401) =e= 0 ;
c675.. x130 - (x402 + x403) =e= 0 ;
c676.. x135 - (x404 + 0) =e= 0 ;
c677.. x405 - (x406 + 0) =e= 0 ;
c678.. x22 - (x407 + x408) =e= 0 ;
c679.. x20 - (x409 + 0) =e= 0 ;
c680.. x134 - (x410 + 0) =e= 0 ;
c681.. x219 - (x411 + 0) =e= 0 ;
c682.. x25 - (x412 + 0) =e= 0 ;
c683.. x218 - (x413 + x414) =e= 0 ;
c684.. x19 - (x415 + x416) =e= 0 ;
c685.. x133 - (x417 + x418) =e= 0 ;
c686.. x138 - (x419 + 0) =e= 0 ;
c687.. x420 - (x421 + 0) =e= 0 ;
c688.. x26 - (x422 + x423) =e= 0 ;
c689.. x24 - (x424 + 0) =e= 0 ;
c690.. x137 - (x425 + 0) =e= 0 ;
c691.. x221 - (x426 + 0) =e= 0 ;
c692.. x29 - (x427 + 0) =e= 0 ;
c693.. x220 - (x428 + x429) =e= 0 ;
c694.. x23 - (x430 + x431) =e= 0 ;
c695.. x136 - (x432 + x433) =e= 0 ;
c696.. x141 - (x434 + 0) =e= 0 ;
c697.. x435 - (x436 + 0) =e= 0 ;
c698.. x30 - (x437 + x438) =e= 0 ;
c699.. x28 - (x439 + 0) =e= 0 ;
c700.. x140 - (x440 + 0) =e= 0 ;
c701.. x223 - (x441 + 0) =e= 0 ;
c702.. x33 - (x442 + 0) =e= 0 ;
c703.. x222 - (x443 + x444) =e= 0 ;
c704.. x27 - (x445 + x446) =e= 0 ;
c705.. x139 - (x447 + x448) =e= 0 ;
c706.. x144 - (x449 + 0) =e= 0 ;
c707.. x450 - (x451 + 0) =e= 0 ;
c708.. x34 - (x452 + x453) =e= 0 ;
c709.. x32 - (x454 + 0) =e= 0 ;
c710.. x143 - (x455 + 0) =e= 0 ;
c711.. x225 - (x456 + 0) =e= 0 ;
c712.. x37 - (x457 + 0) =e= 0 ;
c713.. x224 - (x458 + x459) =e= 0 ;
c714.. x31 - (x460 + x461) =e= 0 ;
c715.. x142 - (x462 + x463) =e= 0 ;
c716.. x147 - (x464 + 0) =e= 0 ;
c717.. x465 - (x466 + 0) =e= 0 ;
c718.. x38 - (x467 + x468) =e= 0 ;
c719.. x36 - (x469 + 0) =e= 0 ;
c720.. x146 - (x470 + 0) =e= 0 ;
c721.. x227 - (x471 + 0) =e= 0 ;
c722.. x41 - (x472 + 0) =e= 0 ;
c723.. x226 - (x473 + x474) =e= 0 ;
c724.. x35 - (x475 + x476) =e= 0 ;
c725.. x145 - (x477 + x478) =e= 0 ;
c726.. x150 - (x479 + 0) =e= 0 ;
c727.. x480 - (x481 + 0) =e= 0 ;
c728.. x42 - (x482 + x483) =e= 0 ;
c729.. x40 - (x484 + 0) =e= 0 ;
c730.. x149 - (x485 + 0) =e= 0 ;
c731.. x229 - (x486 + 0) =e= 0 ;
c732.. x45 - (x487 + 0) =e= 0 ;
c733.. x228 - (x488 + x489) =e= 0 ;
c734.. x39 - (x490 + x491) =e= 0 ;
c735.. x148 - (x492 + x493) =e= 0 ;
c736.. x153 - (x494 + 0) =e= 0 ;
c737.. x495 - (x496 + 0) =e= 0 ;
c738.. x46 - (x497 + x498) =e= 0 ;
c739.. x44 - (x499 + 0) =e= 0 ;
c740.. x152 - (x500 + 0) =e= 0 ;
c741.. x231 - (x501 + 0) =e= 0 ;
c742.. x49 - (x502 + 0) =e= 0 ;
c743.. x230 - (x503 + x504) =e= 0 ;
c744.. x43 - (x505 + x506) =e= 0 ;
c745.. x151 - (x507 + x508) =e= 0 ;
c746.. x156 - (x509 + 0) =e= 0 ;
c747.. x510 - (x511 + 0) =e= 0 ;
c748.. x50 - (x512 + x513) =e= 0 ;
c749.. x48 - (x514 + 0) =e= 0 ;
c750.. x155 - (x515 + 0) =e= 0 ;
c751.. x233 - (x516 + 0) =e= 0 ;
c752.. x53 - (x517 + 0) =e= 0 ;
c753.. x232 - (x518 + x519) =e= 0 ;
c754.. x47 - (x520 + x521) =e= 0 ;
c755.. x154 - (x522 + x523) =e= 0 ;
c756.. x159 - (x524 + 0) =e= 0 ;
c757.. x525 - (x526 + 0) =e= 0 ;
c758.. x54 - (x527 + x528) =e= 0 ;
c759.. x52 - (x529 + 0) =e= 0 ;
c760.. x158 - (x530 + 0) =e= 0 ;
c761.. x235 - (x531 + 0) =e= 0 ;
c762.. x57 - (x532 + 0) =e= 0 ;
c763.. x234 - (x533 + x534) =e= 0 ;
c764.. x51 - (x535 + x536) =e= 0 ;
c765.. x157 - (x537 + x538) =e= 0 ;
c766.. x162 - (x539 + 0) =e= 0 ;
c767.. x540 - (x541 + 0) =e= 0 ;
c768.. x58 - (x542 + x543) =e= 0 ;
c769.. x56 - (x544 + 0) =e= 0 ;
c770.. x161 - (x545 + 0) =e= 0 ;
c771.. x237 - (x546 + 0) =e= 0 ;
c772.. x61 - (x547 + 0) =e= 0 ;
c773.. x236 - (x548 + x549) =e= 0 ;
c774.. x55 - (x550 + x551) =e= 0 ;
c775.. x160 - (x552 + x553) =e= 0 ;
c776.. x165 - (x554 + 0) =e= 0 ;
c777.. x555 - (x556 + 0) =e= 0 ;
c778.. x62 - (x557 + x558) =e= 0 ;
c779.. x60 - (x559 + 0) =e= 0 ;
c780.. x164 - (x560 + 0) =e= 0 ;
c781.. x239 - (x561 + 0) =e= 0 ;
c782.. x65 - (x562 + 0) =e= 0 ;
c783.. x238 - (x563 + x564) =e= 0 ;
c784.. x59 - (x565 + x566) =e= 0 ;
c785.. x163 - (x567 + x568) =e= 0 ;
c786.. x168 - (x569 + 0) =e= 0 ;
c787.. x570 - (x571 + 0) =e= 0 ;
c788.. x66 - (x572 + x573) =e= 0 ;
c789.. x64 - (x574 + 0) =e= 0 ;
c790.. x167 - (x575 + 0) =e= 0 ;
c791.. x241 - (x576 + 0) =e= 0 ;
c792.. x69 - (x577 + 0) =e= 0 ;
c793.. x240 - (x578 + x579) =e= 0 ;
c794.. x63 - (x580 + x581) =e= 0 ;
c795.. x166 - (x582 + x583) =e= 0 ;
c796.. x171 - (x584 + 0) =e= 0 ;
c797.. x585 - (x586 + 0) =e= 0 ;
c798.. x70 - (x587 + x588) =e= 0 ;
c799.. x68 - (x589 + 0) =e= 0 ;
c800.. x170 - (x590 + 0) =e= 0 ;
c801.. x243 - (x591 + 0) =e= 0 ;
c802.. x73 - (x592 + 0) =e= 0 ;
c803.. x242 - (x593 + x594) =e= 0 ;
c804.. x67 - (x595 + x596) =e= 0 ;
c805.. x169 - (x597 + x598) =e= 0 ;
c806.. x174 - (x599 + 0) =e= 0 ;
c807.. x600 - (x601 + 0) =e= 0 ;
c808.. x74 - (x602 + x603) =e= 0 ;
c809.. x72 - (x604 + 0) =e= 0 ;
c810.. x173 - (x605 + 0) =e= 0 ;
c811.. x245 - (x606 + 0) =e= 0 ;
c812.. x77 - (x607 + 0) =e= 0 ;
c813.. x244 - (x608 + x609) =e= 0 ;
c814.. x71 - (x610 + x611) =e= 0 ;
c815.. x172 - (x612 + x613) =e= 0 ;
c816.. x177 - (x614 + 0) =e= 0 ;
c817.. x615 - (x616 + 0) =e= 0 ;
c818.. x78 - (x617 + x618) =e= 0 ;
c819.. x76 - (x619 + 0) =e= 0 ;
c820.. x176 - (x620 + 0) =e= 0 ;
c821.. x247 - (x621 + 0) =e= 0 ;
c822.. x81 - (x622 + 0) =e= 0 ;
c823.. x246 - (x623 + x624) =e= 0 ;
c824.. x75 - (x625 + x626) =e= 0 ;
c825.. x175 - (x627 + x628) =e= 0 ;
c826.. x180 - (x629 + 0) =e= 0 ;
c827.. x630 - (x631 + 0) =e= 0 ;
c828.. x82 - (x632 + x633) =e= 0 ;
c829.. x80 - (x634 + 0) =e= 0 ;
c830.. x179 - (x635 + 0) =e= 0 ;
c831.. x249 - (x636 + 0) =e= 0 ;
c832.. x85 - (x637 + 0) =e= 0 ;
c833.. x248 - (x638 + x639) =e= 0 ;
c834.. x79 - (x640 + x641) =e= 0 ;
c835.. x178 - (x642 + x643) =e= 0 ;
c836.. x183 - (x644 + 0) =e= 0 ;
c837.. x645 - (x646 + 0) =e= 0 ;
c838.. x86 - (x647 + x648) =e= 0 ;
c839.. x84 - (x649 + 0) =e= 0 ;
c840.. x182 - (x650 + 0) =e= 0 ;
c841.. x251 - (x651 + 0) =e= 0 ;
c842.. x89 - (x652 + 0) =e= 0 ;
c843.. x250 - (x653 + x654) =e= 0 ;
c844.. x83 - (x655 + x656) =e= 0 ;
c845.. x181 - (x657 + x658) =e= 0 ;
c846.. x186 - (x659 + 0) =e= 0 ;
c847.. x660 - (x661 + 0) =e= 0 ;
c848.. x90 - (x662 + x663) =e= 0 ;
c849.. x88 - (x664 + 0) =e= 0 ;
c850.. x185 - (x665 + 0) =e= 0 ;
c851.. x253 - (x666 + 0) =e= 0 ;
c852.. x93 - (x667 + 0) =e= 0 ;
c853.. x252 - (x668 + x669) =e= 0 ;
c854.. x87 - (x670 + x671) =e= 0 ;
c855.. x184 - (x672 + x673) =e= 0 ;
c856.. x189 - (x674 + 0) =e= 0 ;
c857.. x675 - (x676 + 0) =e= 0 ;
c858.. x94 - (x677 + x678) =e= 0 ;
c859.. x92 - (x679 + 0) =e= 0 ;
c860.. x188 - (x680 + 0) =e= 0 ;
c861.. x255 - (x681 + 0) =e= 0 ;
c862.. x97 - (x682 + 0) =e= 0 ;
c863.. x254 - (x683 + x684) =e= 0 ;
c864.. x91 - (x685 + x686) =e= 0 ;
c865.. x187 - (x687 + x688) =e= 0 ;
c866.. x192 - (x689 + 0) =e= 0 ;
c867.. x690 - (x691 + 0) =e= 0 ;
c868.. x98 - (x692 + x693) =e= 0 ;
c869.. x96 - (x694 + 0) =e= 0 ;
c870.. x191 - (x695 + 0) =e= 0 ;
c871.. x257 - (x696 + 0) =e= 0 ;
c872.. x101 - (x697 + 0) =e= 0 ;
c873.. x256 - (x698 + x699) =e= 0 ;
c874.. x95 - (x700 + x701) =e= 0 ;
c875.. x190 - (x702 + x703) =e= 0 ;
c876.. x195 - (x704 + 0) =e= 0 ;
c877.. x705 - (x706 + 0) =e= 0 ;
c878.. x102 - (x707 + x708) =e= 0 ;
c879.. x100 - (x709 + 0) =e= 0 ;
c880.. x194 - (x710 + 0) =e= 0 ;
c881.. x259 - (x711 + 0) =e= 0 ;
c882.. x105 - (x712 + 0) =e= 0 ;
c883.. x258 - (x713 + x714) =e= 0 ;
c884.. x99 - (x715 + x716) =e= 0 ;
c885.. x193 - (x717 + x718) =e= 0 ;
c886.. x198 - (x719 + 0) =e= 0 ;
c887.. x720 - (x721 + 0) =e= 0 ;
c888.. x106 - (x722 + x723) =e= 0 ;
c889.. x104 - (x724 + 0) =e= 0 ;
c890.. x197 - (x725 + 0) =e= 0 ;
c891.. x261 - (x726 + 0) =e= 0 ;
c892.. x109 - (x727 + 0) =e= 0 ;
c893.. x260 - (x728 + x729) =e= 0 ;
c894.. x103 - (x730 + x731) =e= 0 ;
c895.. x196 - (x732 + x733) =e= 0 ;
c896.. x201 - (x734 + 0) =e= 0 ;
c897.. x735 - (x736 + 0) =e= 0 ;
c898.. x110 - (x737 + x738) =e= 0 ;
c899.. x108 - (x739 + 0) =e= 0 ;
c900.. x200 - (x740 + 0) =e= 0 ;
c901.. x263 - (x741 + 0) =e= 0 ;
c902.. x113 - (x742 + 0) =e= 0 ;
c903.. x262 - (x743 + x744) =e= 0 ;
c904.. x107 - (x745 + x746) =e= 0 ;
c905.. x199 - (x747 + x748) =e= 0 ;
c906.. x204 - (x749 + 0) =e= 0 ;
c907.. x750 - (x751 + 0) =e= 0 ;
c908.. x114 - (x752 + x753) =e= 0 ;
c909.. x112 - (x754 + 0) =e= 0 ;
c910.. x203 - (x755 + 0) =e= 0 ;
c911.. x265 - (x756 + 0) =e= 0 ;
c912.. x117 - (x757 + 0) =e= 0 ;
c913.. x264 - (x758 + x759) =e= 0 ;
c914.. x111 - (x760 + x761) =e= 0 ;
c915.. x202 - (x762 + x763) =e= 0 ;
c916.. x207 - (x764 + 0) =e= 0 ;
c917.. x765 - (x766 + 0) =e= 0 ;
c918.. x118 - (x767 + x768) =e= 0 ;
c919.. x116 - (x769 + 0) =e= 0 ;
c920.. x206 - (x770 + 0) =e= 0 ;
c921.. x267 - (x771 + 0) =e= 0 ;
c922.. x121 - (x772 + 0) =e= 0 ;
c923.. x266 - (x773 + x774) =e= 0 ;
c924.. x115 - (x775 + x776) =e= 0 ;
c925.. x205 - (x777 + x778) =e= 0 ;
c926.. x210 - (x779 + 0) =e= 0 ;
c927.. x780 - (x781 + 0) =e= 0 ;
c928.. x122 - (x782 + x783) =e= 0 ;
c929.. x120 - (x784 + 0) =e= 0 ;
c930.. x209 - (x785 + 0) =e= 0 ;
c931.. x269 - (x786 + 0) =e= 0 ;
c932.. x124 - (x787 + 0) =e= 0 ;
c933.. x268 - (x788 + x789) =e= 0 ;
c934.. x119 - (x790 + x791) =e= 0 ;
c935.. x208 - (x792 + x793) =e= 0 ;
c936.. x212 - (x794 + 0) =e= 0 ;
c937.. x795 - (x796 + 0) =e= 0 ;
c938.. x125 - (x797 + x798) =e= 0 ;
c939.. x123 - (x799 + 0) =e= 0 ;
c940.. x211 - (x800 + 0) =e= 0 ;
c941.. x270 - (x801 + 0) =e= 0 ;
c942.. x3 - (x802 + 0) =e= 0 ;
c943.. x9 - (x803 + x804) =e= 0 ;
c944.. x2 - (x805 + x806) =e= 0 ;
c945.. x6 - (x807 + x808) =e= 0 ;
c946.. x7 - (x809 + 0) =e= 0 ;
c947.. x810 - (x811 + 0) =e= 0 ;
c948.. x4 - (x812 + x813) =e= 0 ;
c949.. x1 - (x814 + 0) =e= 0 ;
c950.. x5 - (x815 + 0) =e= 0 ;
c951.. x8 - (x816 + 0) =e= 0 ;
c952.. x11 - (x817 + 0) =e= 0 ;
c953.. x272 - (x818 + x819) =e= 0 ;
c954.. x127 - (x820 + 0) =e= 0 ;
c955.. x274 - (x821 + x822) =e= 0 ;
c956.. x214 - (x823 + 0) =e= 0 ;
c957.. x276 - (x824 + x825) =e= 0 ;
c958.. x16 - (x826 + 0) =e= 0 ;
c959.. x272 - (x827 + x828) =e= 0 ;
c960.. x131 - (x829 + 0) =e= 0 ;
c961.. x274 - (x830 + x831) =e= 0 ;
c962.. x217 - (x832 + 0) =e= 0 ;
c963.. x276 - (x833 + x834) =e= 0 ;
c964.. x20 - (x835 + 0) =e= 0 ;
c965.. x272 - (x836 + x837) =e= 0 ;
c966.. x134 - (x838 + 0) =e= 0 ;
c967.. x274 - (x839 + x840) =e= 0 ;
c968.. x219 - (x841 + 0) =e= 0 ;
c969.. x276 - (x842 + x843) =e= 0 ;
c970.. x24 - (x844 + 0) =e= 0 ;
c971.. x272 - (x845 + x846) =e= 0 ;
c972.. x137 - (x847 + 0) =e= 0 ;
c973.. x274 - (x848 + x849) =e= 0 ;
c974.. x221 - (x850 + 0) =e= 0 ;
c975.. x276 - (x851 + x852) =e= 0 ;
c976.. x28 - (x853 + 0) =e= 0 ;
c977.. x272 - (x854 + x855) =e= 0 ;
c978.. x140 - (x856 + 0) =e= 0 ;
c979.. x274 - (x857 + x858) =e= 0 ;
c980.. x223 - (x859 + 0) =e= 0 ;
c981.. x276 - (x860 + x861) =e= 0 ;
c982.. x32 - (x862 + 0) =e= 0 ;
c983.. x272 - (x863 + x864) =e= 0 ;
c984.. x143 - (x865 + 0) =e= 0 ;
c985.. x274 - (x866 + x867) =e= 0 ;
c986.. x225 - (x868 + 0) =e= 0 ;
c987.. x276 - (x869 + x870) =e= 0 ;
c988.. x36 - (x871 + 0) =e= 0 ;
c989.. x272 - (x872 + x873) =e= 0 ;
c990.. x146 - (x874 + 0) =e= 0 ;
c991.. x274 - (x875 + x876) =e= 0 ;
c992.. x227 - (x877 + 0) =e= 0 ;
c993.. x276 - (x878 + x879) =e= 0 ;
c994.. x40 - (x880 + 0) =e= 0 ;
c995.. x272 - (x881 + x882) =e= 0 ;
c996.. x149 - (x883 + 0) =e= 0 ;
c997.. x274 - (x884 + x885) =e= 0 ;
c998.. x229 - (x886 + 0) =e= 0 ;
c999.. x276 - (x887 + x888) =e= 0 ;
c1000.. x44 - (x889 + 0) =e= 0 ;
c1001.. x272 - (x890 + x891) =e= 0 ;
c1002.. x152 - (x892 + 0) =e= 0 ;
c1003.. x274 - (x893 + x894) =e= 0 ;
c1004.. x231 - (x895 + 0) =e= 0 ;
c1005.. x276 - (x896 + x897) =e= 0 ;
c1006.. x48 - (x898 + 0) =e= 0 ;
c1007.. x272 - (x899 + x900) =e= 0 ;
c1008.. x155 - (x901 + 0) =e= 0 ;
c1009.. x274 - (x902 + x903) =e= 0 ;
c1010.. x233 - (x904 + 0) =e= 0 ;
c1011.. x276 - (x905 + x906) =e= 0 ;
c1012.. x52 - (x907 + 0) =e= 0 ;
c1013.. x272 - (x908 + x909) =e= 0 ;
c1014.. x158 - (x910 + 0) =e= 0 ;
c1015.. x274 - (x911 + x912) =e= 0 ;
c1016.. x235 - (x913 + 0) =e= 0 ;
c1017.. x276 - (x914 + x915) =e= 0 ;
c1018.. x56 - (x916 + 0) =e= 0 ;
c1019.. x272 - (x917 + x918) =e= 0 ;
c1020.. x161 - (x919 + 0) =e= 0 ;
c1021.. x274 - (x920 + x921) =e= 0 ;
c1022.. x237 - (x922 + 0) =e= 0 ;
c1023.. x276 - (x923 + x924) =e= 0 ;
c1024.. x60 - (x925 + 0) =e= 0 ;
c1025.. x272 - (x926 + x927) =e= 0 ;
c1026.. x164 - (x928 + 0) =e= 0 ;
c1027.. x274 - (x929 + x930) =e= 0 ;
c1028.. x239 - (x931 + 0) =e= 0 ;
c1029.. x276 - (x932 + x933) =e= 0 ;
c1030.. x64 - (x934 + 0) =e= 0 ;
c1031.. x272 - (x935 + x936) =e= 0 ;
c1032.. x167 - (x937 + 0) =e= 0 ;
c1033.. x274 - (x938 + x939) =e= 0 ;
c1034.. x241 - (x940 + 0) =e= 0 ;
c1035.. x276 - (x941 + x942) =e= 0 ;
c1036.. x68 - (x943 + 0) =e= 0 ;
c1037.. x272 - (x944 + x945) =e= 0 ;
c1038.. x170 - (x946 + 0) =e= 0 ;
c1039.. x274 - (x947 + x948) =e= 0 ;
c1040.. x243 - (x949 + 0) =e= 0 ;
c1041.. x276 - (x950 + x951) =e= 0 ;
c1042.. x72 - (x952 + 0) =e= 0 ;
c1043.. x272 - (x953 + x954) =e= 0 ;
c1044.. x173 - (x955 + 0) =e= 0 ;
c1045.. x274 - (x956 + x957) =e= 0 ;
c1046.. x245 - (x958 + 0) =e= 0 ;
c1047.. x276 - (x959 + x960) =e= 0 ;
c1048.. x76 - (x961 + 0) =e= 0 ;
c1049.. x272 - (x962 + x963) =e= 0 ;
c1050.. x176 - (x964 + 0) =e= 0 ;
c1051.. x274 - (x965 + x966) =e= 0 ;
c1052.. x247 - (x967 + 0) =e= 0 ;
c1053.. x276 - (x968 + x969) =e= 0 ;
c1054.. x80 - (x970 + 0) =e= 0 ;
c1055.. x272 - (x971 + x972) =e= 0 ;
c1056.. x179 - (x973 + 0) =e= 0 ;
c1057.. x274 - (x974 + x975) =e= 0 ;
c1058.. x249 - (x976 + 0) =e= 0 ;
c1059.. x276 - (x977 + x978) =e= 0 ;
c1060.. x84 - (x979 + 0) =e= 0 ;
c1061.. x272 - (x980 + x981) =e= 0 ;
c1062.. x182 - (x982 + 0) =e= 0 ;
c1063.. x274 - (x983 + x984) =e= 0 ;
c1064.. x251 - (x985 + 0) =e= 0 ;
c1065.. x276 - (x986 + x987) =e= 0 ;
c1066.. x88 - (x988 + 0) =e= 0 ;
c1067.. x272 - (x989 + x990) =e= 0 ;
c1068.. x185 - (x991 + 0) =e= 0 ;
c1069.. x274 - (x992 + x993) =e= 0 ;
c1070.. x253 - (x994 + 0) =e= 0 ;
c1071.. x276 - (x995 + x996) =e= 0 ;
c1072.. x92 - (x997 + 0) =e= 0 ;
c1073.. x272 - (x998 + x999) =e= 0 ;
c1074.. x188 - (x1000 + 0) =e= 0 ;
c1075.. x274 - (x1001 + x1002) =e= 0 ;
c1076.. x255 - (x1003 + 0) =e= 0 ;
c1077.. x276 - (x1004 + x1005) =e= 0 ;
c1078.. x96 - (x1006 + 0) =e= 0 ;
c1079.. x272 - (x1007 + x1008) =e= 0 ;
c1080.. x191 - (x1009 + 0) =e= 0 ;
c1081.. x274 - (x1010 + x1011) =e= 0 ;
c1082.. x257 - (x1012 + 0) =e= 0 ;
c1083.. x276 - (x1013 + x1014) =e= 0 ;
c1084.. x100 - (x1015 + 0) =e= 0 ;
c1085.. x272 - (x1016 + x1017) =e= 0 ;
c1086.. x194 - (x1018 + 0) =e= 0 ;
c1087.. x274 - (x1019 + x1020) =e= 0 ;
c1088.. x259 - (x1021 + 0) =e= 0 ;
c1089.. x276 - (x1022 + x1023) =e= 0 ;
c1090.. x104 - (x1024 + 0) =e= 0 ;
c1091.. x272 - (x1025 + x1026) =e= 0 ;
c1092.. x197 - (x1027 + 0) =e= 0 ;
c1093.. x274 - (x1028 + x1029) =e= 0 ;
c1094.. x261 - (x1030 + 0) =e= 0 ;
c1095.. x276 - (x1031 + x1032) =e= 0 ;
c1096.. x108 - (x1033 + 0) =e= 0 ;
c1097.. x272 - (x1034 + x1035) =e= 0 ;
c1098.. x200 - (x1036 + 0) =e= 0 ;
c1099.. x274 - (x1037 + x1038) =e= 0 ;
c1100.. x263 - (x1039 + 0) =e= 0 ;
c1101.. x276 - (x1040 + x1041) =e= 0 ;
c1102.. x112 - (x1042 + 0) =e= 0 ;
c1103.. x272 - (x1043 + x1044) =e= 0 ;
c1104.. x203 - (x1045 + 0) =e= 0 ;
c1105.. x274 - (x1046 + x1047) =e= 0 ;
c1106.. x265 - (x1048 + 0) =e= 0 ;
c1107.. x276 - (x1049 + x1050) =e= 0 ;
c1108.. x116 - (x1051 + 0) =e= 0 ;
c1109.. x272 - (x1052 + x1053) =e= 0 ;
c1110.. x206 - (x1054 + 0) =e= 0 ;
c1111.. x274 - (x1055 + x1056) =e= 0 ;
c1112.. x267 - (x1057 + 0) =e= 0 ;
c1113.. x276 - (x1058 + x1059) =e= 0 ;
c1114.. x120 - (x1060 + 0) =e= 0 ;
c1115.. x272 - (x1061 + x1062) =e= 0 ;
c1116.. x209 - (x1063 + 0) =e= 0 ;
c1117.. x274 - (x1064 + x1065) =e= 0 ;
c1118.. x269 - (x1066 + 0) =e= 0 ;
c1119.. x276 - (x1067 + x1068) =e= 0 ;
c1120.. x123 - (x1069 + 0) =e= 0 ;
c1121.. x272 - (x1070 + x1071) =e= 0 ;
c1122.. x211 - (x1072 + 0) =e= 0 ;
c1123.. x274 - (x1073 + x1074) =e= 0 ;
c1124.. x270 - (x1075 + 0) =e= 0 ;
c1125.. x276 - (x1076 + x1077) =e= 0 ;
c1126.. x1 - (x1078 + 0) =e= 0 ;
c1127.. x272 - (x1079 + x1080) =e= 0 ;
c1128.. x5 - (x1081 + 0) =e= 0 ;
c1129.. x274 - (x1082 + x1083) =e= 0 ;
c1130.. x8 - (x1084 + 0) =e= 0 ;
c1131.. x276 - (x1085 + x1086) =e= 0 ;
c1132_hi.. 1 - x278 - x368 =l= 0 ;
c1133_hi.. x368 - 10*(1 - x278) =l= 0 ;
c1134_hi.. x370 - 10*(1 - x278) =l= 0 ;
c1135_hi.. x372 - 10*(1 - x278) =l= 0 ;
c1136_hi.. x377 - 10*(1 - x278) =l= 0 ;
c1137_hi.. x379 - 10*(1 - x1087) =l= 0 ;
c1138_hi.. x380 - 10*(1 - x1087) =l= 0 ;
c1139_hi.. x381 - 9*(1 - x1087) =l= 0 ;
c1140_hi.. 1 - x280 - x383 =l= 0 ;
c1141_hi.. x383 - 10*(1 - x280) =l= 0 ;
c1142_hi.. x385 - 10*(1 - x280) =l= 0 ;
c1143_hi.. x387 - 10*(1 - x280) =l= 0 ;
c1144_hi.. x392 - 10*(1 - x280) =l= 0 ;
c1145_hi.. x394 - 10*(1 - x1088) =l= 0 ;
c1146_hi.. x395 - 10*(1 - x1088) =l= 0 ;
c1147_hi.. x396 - 9*(1 - x1088) =l= 0 ;
c1148_hi.. 1 - x282 - x398 =l= 0 ;
c1149_hi.. x398 - 10*(1 - x282) =l= 0 ;
c1150_hi.. x400 - 10*(1 - x282) =l= 0 ;
c1151_hi.. x402 - 10*(1 - x282) =l= 0 ;
c1152_hi.. x407 - 10*(1 - x282) =l= 0 ;
c1153_hi.. x409 - 10*(1 - x1089) =l= 0 ;
c1154_hi.. x410 - 10*(1 - x1089) =l= 0 ;
c1155_hi.. x411 - 9*(1 - x1089) =l= 0 ;
c1156_hi.. 1 - x284 - x413 =l= 0 ;
c1157_hi.. x413 - 10*(1 - x284) =l= 0 ;
c1158_hi.. x415 - 10*(1 - x284) =l= 0 ;
c1159_hi.. x417 - 10*(1 - x284) =l= 0 ;
c1160_hi.. x422 - 10*(1 - x284) =l= 0 ;
c1161_hi.. x424 - 10*(1 - x1090) =l= 0 ;
c1162_hi.. x425 - 10*(1 - x1090) =l= 0 ;
c1163_hi.. x426 - 9*(1 - x1090) =l= 0 ;
c1164_hi.. 1 - x286 - x428 =l= 0 ;
c1165_hi.. x428 - 10*(1 - x286) =l= 0 ;
c1166_hi.. x430 - 10*(1 - x286) =l= 0 ;
c1167_hi.. x432 - 10*(1 - x286) =l= 0 ;
c1168_hi.. x437 - 10*(1 - x286) =l= 0 ;
c1169_hi.. x439 - 10*(1 - x1091) =l= 0 ;
c1170_hi.. x440 - 10*(1 - x1091) =l= 0 ;
c1171_hi.. x441 - 9*(1 - x1091) =l= 0 ;
c1172_hi.. 1 - x288 - x443 =l= 0 ;
c1173_hi.. x443 - 10*(1 - x288) =l= 0 ;
c1174_hi.. x445 - 10*(1 - x288) =l= 0 ;
c1175_hi.. x447 - 10*(1 - x288) =l= 0 ;
c1176_hi.. x452 - 10*(1 - x288) =l= 0 ;
c1177_hi.. x454 - 10*(1 - x1092) =l= 0 ;
c1178_hi.. x455 - 10*(1 - x1092) =l= 0 ;
c1179_hi.. x456 - 9*(1 - x1092) =l= 0 ;
c1180_hi.. 1 - x290 - x458 =l= 0 ;
c1181_hi.. x458 - 10*(1 - x290) =l= 0 ;
c1182_hi.. x460 - 10*(1 - x290) =l= 0 ;
c1183_hi.. x462 - 10*(1 - x290) =l= 0 ;
c1184_hi.. x467 - 10*(1 - x290) =l= 0 ;
c1185_hi.. x469 - 10*(1 - x1093) =l= 0 ;
c1186_hi.. x470 - 10*(1 - x1093) =l= 0 ;
c1187_hi.. x471 - 9*(1 - x1093) =l= 0 ;
c1188_hi.. 1 - x292 - x473 =l= 0 ;
c1189_hi.. x473 - 10*(1 - x292) =l= 0 ;
c1190_hi.. x475 - 10*(1 - x292) =l= 0 ;
c1191_hi.. x477 - 10*(1 - x292) =l= 0 ;
c1192_hi.. x482 - 10*(1 - x292) =l= 0 ;
c1193_hi.. x484 - 10*(1 - x1094) =l= 0 ;
c1194_hi.. x485 - 10*(1 - x1094) =l= 0 ;
c1195_hi.. x486 - 9*(1 - x1094) =l= 0 ;
c1196_hi.. 1 - x294 - x488 =l= 0 ;
c1197_hi.. x488 - 10*(1 - x294) =l= 0 ;
c1198_hi.. x490 - 10*(1 - x294) =l= 0 ;
c1199_hi.. x492 - 10*(1 - x294) =l= 0 ;
c1200_hi.. x497 - 10*(1 - x294) =l= 0 ;
c1201_hi.. x499 - 10*(1 - x1095) =l= 0 ;
c1202_hi.. x500 - 10*(1 - x1095) =l= 0 ;
c1203_hi.. x501 - 9*(1 - x1095) =l= 0 ;
c1204_hi.. 1 - x296 - x503 =l= 0 ;
c1205_hi.. x503 - 10*(1 - x296) =l= 0 ;
c1206_hi.. x505 - 10*(1 - x296) =l= 0 ;
c1207_hi.. x507 - 10*(1 - x296) =l= 0 ;
c1208_hi.. x512 - 10*(1 - x296) =l= 0 ;
c1209_hi.. x514 - 10*(1 - x1096) =l= 0 ;
c1210_hi.. x515 - 10*(1 - x1096) =l= 0 ;
c1211_hi.. x516 - 9*(1 - x1096) =l= 0 ;
c1212_hi.. 1 - x298 - x518 =l= 0 ;
c1213_hi.. x518 - 10*(1 - x298) =l= 0 ;
c1214_hi.. x520 - 10*(1 - x298) =l= 0 ;
c1215_hi.. x522 - 10*(1 - x298) =l= 0 ;
c1216_hi.. x527 - 10*(1 - x298) =l= 0 ;
c1217_hi.. x529 - 10*(1 - x1097) =l= 0 ;
c1218_hi.. x530 - 10*(1 - x1097) =l= 0 ;
c1219_hi.. x531 - 9*(1 - x1097) =l= 0 ;
c1220_hi.. 1 - x300 - x533 =l= 0 ;
c1221_hi.. x533 - 10*(1 - x300) =l= 0 ;
c1222_hi.. x535 - 10*(1 - x300) =l= 0 ;
c1223_hi.. x537 - 10*(1 - x300) =l= 0 ;
c1224_hi.. x542 - 10*(1 - x300) =l= 0 ;
c1225_hi.. x544 - 10*(1 - x1098) =l= 0 ;
c1226_hi.. x545 - 10*(1 - x1098) =l= 0 ;
c1227_hi.. x546 - 9*(1 - x1098) =l= 0 ;
c1228_hi.. 1 - x302 - x548 =l= 0 ;
c1229_hi.. x548 - 10*(1 - x302) =l= 0 ;
c1230_hi.. x550 - 10*(1 - x302) =l= 0 ;
c1231_hi.. x552 - 10*(1 - x302) =l= 0 ;
c1232_hi.. x557 - 10*(1 - x302) =l= 0 ;
c1233_hi.. x559 - 10*(1 - x1099) =l= 0 ;
c1234_hi.. x560 - 10*(1 - x1099) =l= 0 ;
c1235_hi.. x561 - 9*(1 - x1099) =l= 0 ;
c1236_hi.. 1 - x304 - x563 =l= 0 ;
c1237_hi.. x563 - 10*(1 - x304) =l= 0 ;
c1238_hi.. x565 - 10*(1 - x304) =l= 0 ;
c1239_hi.. x567 - 10*(1 - x304) =l= 0 ;
c1240_hi.. x572 - 10*(1 - x304) =l= 0 ;
c1241_hi.. x574 - 10*(1 - x1100) =l= 0 ;
c1242_hi.. x575 - 10*(1 - x1100) =l= 0 ;
c1243_hi.. x576 - 9*(1 - x1100) =l= 0 ;
c1244_hi.. 1 - x306 - x578 =l= 0 ;
c1245_hi.. x578 - 10*(1 - x306) =l= 0 ;
c1246_hi.. x580 - 10*(1 - x306) =l= 0 ;
c1247_hi.. x582 - 10*(1 - x306) =l= 0 ;
c1248_hi.. x587 - 10*(1 - x306) =l= 0 ;
c1249_hi.. x589 - 10*(1 - x1101) =l= 0 ;
c1250_hi.. x590 - 10*(1 - x1101) =l= 0 ;
c1251_hi.. x591 - 9*(1 - x1101) =l= 0 ;
c1252_hi.. 1 - x308 - x593 =l= 0 ;
c1253_hi.. x593 - 10*(1 - x308) =l= 0 ;
c1254_hi.. x595 - 10*(1 - x308) =l= 0 ;
c1255_hi.. x597 - 10*(1 - x308) =l= 0 ;
c1256_hi.. x602 - 10*(1 - x308) =l= 0 ;
c1257_hi.. x604 - 10*(1 - x1102) =l= 0 ;
c1258_hi.. x605 - 10*(1 - x1102) =l= 0 ;
c1259_hi.. x606 - 9*(1 - x1102) =l= 0 ;
c1260_hi.. 1 - x310 - x608 =l= 0 ;
c1261_hi.. x608 - 10*(1 - x310) =l= 0 ;
c1262_hi.. x610 - 10*(1 - x310) =l= 0 ;
c1263_hi.. x612 - 10*(1 - x310) =l= 0 ;
c1264_hi.. x617 - 10*(1 - x310) =l= 0 ;
c1265_hi.. x619 - 10*(1 - x1103) =l= 0 ;
c1266_hi.. x620 - 10*(1 - x1103) =l= 0 ;
c1267_hi.. x621 - 9*(1 - x1103) =l= 0 ;
c1268_hi.. 1 - x312 - x623 =l= 0 ;
c1269_hi.. x623 - 10*(1 - x312) =l= 0 ;
c1270_hi.. x625 - 10*(1 - x312) =l= 0 ;
c1271_hi.. x627 - 10*(1 - x312) =l= 0 ;
c1272_hi.. x632 - 10*(1 - x312) =l= 0 ;
c1273_hi.. x634 - 10*(1 - x1104) =l= 0 ;
c1274_hi.. x635 - 10*(1 - x1104) =l= 0 ;
c1275_hi.. x636 - 9*(1 - x1104) =l= 0 ;
c1276_hi.. 1 - x314 - x638 =l= 0 ;
c1277_hi.. x638 - 10*(1 - x314) =l= 0 ;
c1278_hi.. x640 - 10*(1 - x314) =l= 0 ;
c1279_hi.. x642 - 10*(1 - x314) =l= 0 ;
c1280_hi.. x647 - 10*(1 - x314) =l= 0 ;
c1281_hi.. x649 - 10*(1 - x1105) =l= 0 ;
c1282_hi.. x650 - 10*(1 - x1105) =l= 0 ;
c1283_hi.. x651 - 9*(1 - x1105) =l= 0 ;
c1284_hi.. 1 - x316 - x653 =l= 0 ;
c1285_hi.. x653 - 10*(1 - x316) =l= 0 ;
c1286_hi.. x655 - 10*(1 - x316) =l= 0 ;
c1287_hi.. x657 - 10*(1 - x316) =l= 0 ;
c1288_hi.. x662 - 10*(1 - x316) =l= 0 ;
c1289_hi.. x664 - 10*(1 - x1106) =l= 0 ;
c1290_hi.. x665 - 10*(1 - x1106) =l= 0 ;
c1291_hi.. x666 - 9*(1 - x1106) =l= 0 ;
c1292_hi.. 1 - x318 - x668 =l= 0 ;
c1293_hi.. x668 - 10*(1 - x318) =l= 0 ;
c1294_hi.. x670 - 10*(1 - x318) =l= 0 ;
c1295_hi.. x672 - 10*(1 - x318) =l= 0 ;
c1296_hi.. x677 - 10*(1 - x318) =l= 0 ;
c1297_hi.. x679 - 10*(1 - x1107) =l= 0 ;
c1298_hi.. x680 - 10*(1 - x1107) =l= 0 ;
c1299_hi.. x681 - 9*(1 - x1107) =l= 0 ;
c1300_hi.. 1 - x320 - x683 =l= 0 ;
c1301_hi.. x683 - 10*(1 - x320) =l= 0 ;
c1302_hi.. x685 - 10*(1 - x320) =l= 0 ;
c1303_hi.. x687 - 10*(1 - x320) =l= 0 ;
c1304_hi.. x692 - 10*(1 - x320) =l= 0 ;
c1305_hi.. x694 - 10*(1 - x1108) =l= 0 ;
c1306_hi.. x695 - 10*(1 - x1108) =l= 0 ;
c1307_hi.. x696 - 9*(1 - x1108) =l= 0 ;
c1308_hi.. 1 - x322 - x698 =l= 0 ;
c1309_hi.. x698 - 10*(1 - x322) =l= 0 ;
c1310_hi.. x700 - 10*(1 - x322) =l= 0 ;
c1311_hi.. x702 - 10*(1 - x322) =l= 0 ;
c1312_hi.. x707 - 10*(1 - x322) =l= 0 ;
c1313_hi.. x709 - 10*(1 - x1109) =l= 0 ;
c1314_hi.. x710 - 10*(1 - x1109) =l= 0 ;
c1315_hi.. x711 - 9*(1 - x1109) =l= 0 ;
c1316_hi.. 1 - x324 - x713 =l= 0 ;
c1317_hi.. x713 - 10*(1 - x324) =l= 0 ;
c1318_hi.. x715 - 10*(1 - x324) =l= 0 ;
c1319_hi.. x717 - 10*(1 - x324) =l= 0 ;
c1320_hi.. x722 - 10*(1 - x324) =l= 0 ;
c1321_hi.. x724 - 10*(1 - x1110) =l= 0 ;
c1322_hi.. x725 - 10*(1 - x1110) =l= 0 ;
c1323_hi.. x726 - 9*(1 - x1110) =l= 0 ;
c1324_hi.. 1 - x326 - x728 =l= 0 ;
c1325_hi.. x728 - 10*(1 - x326) =l= 0 ;
c1326_hi.. x730 - 10*(1 - x326) =l= 0 ;
c1327_hi.. x732 - 10*(1 - x326) =l= 0 ;
c1328_hi.. x737 - 10*(1 - x326) =l= 0 ;
c1329_hi.. x739 - 10*(1 - x1111) =l= 0 ;
c1330_hi.. x740 - 10*(1 - x1111) =l= 0 ;
c1331_hi.. x741 - 9*(1 - x1111) =l= 0 ;
c1332_hi.. 1 - x328 - x743 =l= 0 ;
c1333_hi.. x743 - 10*(1 - x328) =l= 0 ;
c1334_hi.. x745 - 10*(1 - x328) =l= 0 ;
c1335_hi.. x747 - 10*(1 - x328) =l= 0 ;
c1336_hi.. x752 - 10*(1 - x328) =l= 0 ;
c1337_hi.. x754 - 10*(1 - x1112) =l= 0 ;
c1338_hi.. x755 - 10*(1 - x1112) =l= 0 ;
c1339_hi.. x756 - 9*(1 - x1112) =l= 0 ;
c1340_hi.. 1 - x330 - x758 =l= 0 ;
c1341_hi.. x758 - 10*(1 - x330) =l= 0 ;
c1342_hi.. x760 - 10*(1 - x330) =l= 0 ;
c1343_hi.. x762 - 10*(1 - x330) =l= 0 ;
c1344_hi.. x767 - 10*(1 - x330) =l= 0 ;
c1345_hi.. x769 - 10*(1 - x1113) =l= 0 ;
c1346_hi.. x770 - 10*(1 - x1113) =l= 0 ;
c1347_hi.. x771 - 9*(1 - x1113) =l= 0 ;
c1348_hi.. 1 - x332 - x773 =l= 0 ;
c1349_hi.. x773 - 10*(1 - x332) =l= 0 ;
c1350_hi.. x775 - 10*(1 - x332) =l= 0 ;
c1351_hi.. x777 - 10*(1 - x332) =l= 0 ;
c1352_hi.. x782 - 10*(1 - x332) =l= 0 ;
c1353_hi.. x784 - 10*(1 - x1114) =l= 0 ;
c1354_hi.. x785 - 10*(1 - x1114) =l= 0 ;
c1355_hi.. x786 - 9*(1 - x1114) =l= 0 ;
c1356_hi.. 1 - x334 - x788 =l= 0 ;
c1357_hi.. x788 - 10*(1 - x334) =l= 0 ;
c1358_hi.. x790 - 10*(1 - x334) =l= 0 ;
c1359_hi.. x792 - 10*(1 - x334) =l= 0 ;
c1360_hi.. x797 - 10*(1 - x334) =l= 0 ;
c1361_hi.. x799 - 10*(1 - x1115) =l= 0 ;
c1362_hi.. x800 - 10*(1 - x1115) =l= 0 ;
c1363_hi.. x801 - 9*(1 - x1115) =l= 0 ;
c1364_hi.. 1 - x336 - x803 =l= 0 ;
c1365_hi.. x803 - 10*(1 - x336) =l= 0 ;
c1366_hi.. x805 - 10*(1 - x336) =l= 0 ;
c1367_hi.. x807 - 10*(1 - x336) =l= 0 ;
c1368_hi.. x812 - 10*(1 - x336) =l= 0 ;
c1369_hi.. x814 - 10*(1 - x1116) =l= 0 ;
c1370_hi.. x815 - 10*(1 - x1116) =l= 0 ;
c1371_hi.. x816 - 9*(1 - x1116) =l= 0 ;
c1372_hi.. x818 - 10*(1 - x277) =l= 0 ;
c1373_hi.. x821 - 10*(1 - x277) =l= 0 ;
c1374_hi.. x824 - 10*(1 - x277) =l= 0 ;
c1375_hi.. x827 - 10*(1 - x279) =l= 0 ;
c1376_hi.. x830 - 10*(1 - x279) =l= 0 ;
c1377_hi.. x833 - 10*(1 - x279) =l= 0 ;
c1378_hi.. x836 - 10*(1 - x281) =l= 0 ;
c1379_hi.. x839 - 10*(1 - x281) =l= 0 ;
c1380_hi.. x842 - 10*(1 - x281) =l= 0 ;
c1381_hi.. x845 - 10*(1 - x283) =l= 0 ;
c1382_hi.. x848 - 10*(1 - x283) =l= 0 ;
c1383_hi.. x851 - 10*(1 - x283) =l= 0 ;
c1384_hi.. x854 - 10*(1 - x285) =l= 0 ;
c1385_hi.. x857 - 10*(1 - x285) =l= 0 ;
c1386_hi.. x860 - 10*(1 - x285) =l= 0 ;
c1387_hi.. x863 - 10*(1 - x287) =l= 0 ;
c1388_hi.. x866 - 10*(1 - x287) =l= 0 ;
c1389_hi.. x869 - 10*(1 - x287) =l= 0 ;
c1390_hi.. x872 - 10*(1 - x289) =l= 0 ;
c1391_hi.. x875 - 10*(1 - x289) =l= 0 ;
c1392_hi.. x878 - 10*(1 - x289) =l= 0 ;
c1393_hi.. x881 - 10*(1 - x291) =l= 0 ;
c1394_hi.. x884 - 10*(1 - x291) =l= 0 ;
c1395_hi.. x887 - 10*(1 - x291) =l= 0 ;
c1396_hi.. x890 - 10*(1 - x293) =l= 0 ;
c1397_hi.. x893 - 10*(1 - x293) =l= 0 ;
c1398_hi.. x896 - 10*(1 - x293) =l= 0 ;
c1399_hi.. x899 - 10*(1 - x295) =l= 0 ;
c1400_hi.. x902 - 10*(1 - x295) =l= 0 ;
c1401_hi.. x905 - 10*(1 - x295) =l= 0 ;
c1402_hi.. x908 - 10*(1 - x297) =l= 0 ;
c1403_hi.. x911 - 10*(1 - x297) =l= 0 ;
c1404_hi.. x914 - 10*(1 - x297) =l= 0 ;
c1405_hi.. x917 - 10*(1 - x299) =l= 0 ;
c1406_hi.. x920 - 10*(1 - x299) =l= 0 ;
c1407_hi.. x923 - 10*(1 - x299) =l= 0 ;
c1408_hi.. x926 - 10*(1 - x301) =l= 0 ;
c1409_hi.. x929 - 10*(1 - x301) =l= 0 ;
c1410_hi.. x932 - 10*(1 - x301) =l= 0 ;
c1411_hi.. x935 - 10*(1 - x303) =l= 0 ;
c1412_hi.. x938 - 10*(1 - x303) =l= 0 ;
c1413_hi.. x941 - 10*(1 - x303) =l= 0 ;
c1414_hi.. x944 - 10*(1 - x305) =l= 0 ;
c1415_hi.. x947 - 10*(1 - x305) =l= 0 ;
c1416_hi.. x950 - 10*(1 - x305) =l= 0 ;
c1417_hi.. x953 - 10*(1 - x307) =l= 0 ;
c1418_hi.. x956 - 10*(1 - x307) =l= 0 ;
c1419_hi.. x959 - 10*(1 - x307) =l= 0 ;
c1420_hi.. x962 - 10*(1 - x309) =l= 0 ;
c1421_hi.. x965 - 10*(1 - x309) =l= 0 ;
c1422_hi.. x968 - 10*(1 - x309) =l= 0 ;
c1423_hi.. x971 - 10*(1 - x311) =l= 0 ;
c1424_hi.. x974 - 10*(1 - x311) =l= 0 ;
c1425_hi.. x977 - 10*(1 - x311) =l= 0 ;
c1426_hi.. x980 - 10*(1 - x313) =l= 0 ;
c1427_hi.. x983 - 10*(1 - x313) =l= 0 ;
c1428_hi.. x986 - 10*(1 - x313) =l= 0 ;
c1429_hi.. x989 - 10*(1 - x315) =l= 0 ;
c1430_hi.. x992 - 10*(1 - x315) =l= 0 ;
c1431_hi.. x995 - 10*(1 - x315) =l= 0 ;
c1432_hi.. x998 - 10*(1 - x317) =l= 0 ;
c1433_hi.. x1001 - 10*(1 - x317) =l= 0 ;
c1434_hi.. x1004 - 10*(1 - x317) =l= 0 ;
c1435_hi.. x1007 - 10*(1 - x319) =l= 0 ;
c1436_hi.. x1010 - 10*(1 - x319) =l= 0 ;
c1437_hi.. x1013 - 10*(1 - x319) =l= 0 ;
c1438_hi.. x1016 - 10*(1 - x321) =l= 0 ;
c1439_hi.. x1019 - 10*(1 - x321) =l= 0 ;
c1440_hi.. x1022 - 10*(1 - x321) =l= 0 ;
c1441_hi.. x1025 - 10*(1 - x323) =l= 0 ;
c1442_hi.. x1028 - 10*(1 - x323) =l= 0 ;
c1443_hi.. x1031 - 10*(1 - x323) =l= 0 ;
c1444_hi.. x1034 - 10*(1 - x325) =l= 0 ;
c1445_hi.. x1037 - 10*(1 - x325) =l= 0 ;
c1446_hi.. x1040 - 10*(1 - x325) =l= 0 ;
c1447_hi.. x1043 - 10*(1 - x327) =l= 0 ;
c1448_hi.. x1046 - 10*(1 - x327) =l= 0 ;
c1449_hi.. x1049 - 10*(1 - x327) =l= 0 ;
c1450_hi.. x1052 - 10*(1 - x329) =l= 0 ;
c1451_hi.. x1055 - 10*(1 - x329) =l= 0 ;
c1452_hi.. x1058 - 10*(1 - x329) =l= 0 ;
c1453_hi.. x1061 - 10*(1 - x331) =l= 0 ;
c1454_hi.. x1064 - 10*(1 - x331) =l= 0 ;
c1455_hi.. x1067 - 10*(1 - x331) =l= 0 ;
c1456_hi.. x1070 - 10*(1 - x333) =l= 0 ;
c1457_hi.. x1073 - 10*(1 - x333) =l= 0 ;
c1458_hi.. x1076 - 10*(1 - x333) =l= 0 ;
c1459_hi.. x1079 - 10*(1 - x335) =l= 0 ;
c1460_hi.. x1082 - 10*(1 - x335) =l= 0 ;
c1461_hi.. x1085 - 10*(1 - x335) =l= 0 ;
c1462.. x278 + x1087 =e= 1 ;
c1463.. x280 + x1088 =e= 1 ;
c1464.. x282 + x1089 =e= 1 ;
c1465.. x284 + x1090 =e= 1 ;
c1466.. x286 + x1091 =e= 1 ;
c1467.. x288 + x1092 =e= 1 ;
c1468.. x290 + x1093 =e= 1 ;
c1469.. x292 + x1094 =e= 1 ;
c1470.. x294 + x1095 =e= 1 ;
c1471.. x296 + x1096 =e= 1 ;
c1472.. x298 + x1097 =e= 1 ;
c1473.. x300 + x1098 =e= 1 ;
c1474.. x302 + x1099 =e= 1 ;
c1475.. x304 + x1100 =e= 1 ;
c1476.. x306 + x1101 =e= 1 ;
c1477.. x308 + x1102 =e= 1 ;
c1478.. x310 + x1103 =e= 1 ;
c1479.. x312 + x1104 =e= 1 ;
c1480.. x314 + x1105 =e= 1 ;
c1481.. x316 + x1106 =e= 1 ;
c1482.. x318 + x1107 =e= 1 ;
c1483.. x320 + x1108 =e= 1 ;
c1484.. x322 + x1109 =e= 1 ;
c1485.. x324 + x1110 =e= 1 ;
c1486.. x326 + x1111 =e= 1 ;
c1487.. x328 + x1112 =e= 1 ;
c1488.. x330 + x1113 =e= 1 ;
c1489.. x332 + x1114 =e= 1 ;
c1490.. x334 + x1115 =e= 1 ;
c1491.. x336 + x1116 =e= 1 ;
c1492.. x277 + x1117 =e= 1 ;
c1493.. x279 + x1118 =e= 1 ;
c1494.. x281 + x1119 =e= 1 ;
c1495.. x283 + x1120 =e= 1 ;
c1496.. x285 + x1121 =e= 1 ;
c1497.. x287 + x1122 =e= 1 ;
c1498.. x289 + x1123 =e= 1 ;
c1499.. x291 + x1124 =e= 1 ;
c1500.. x293 + x1125 =e= 1 ;
c1501.. x295 + x1126 =e= 1 ;
c1502.. x297 + x1127 =e= 1 ;
c1503.. x299 + x1128 =e= 1 ;
c1504.. x301 + x1129 =e= 1 ;
c1505.. x303 + x1130 =e= 1 ;
c1506.. x305 + x1131 =e= 1 ;
c1507.. x307 + x1132 =e= 1 ;
c1508.. x309 + x1133 =e= 1 ;
c1509.. x311 + x1134 =e= 1 ;
c1510.. x313 + x1135 =e= 1 ;
c1511.. x315 + x1136 =e= 1 ;
c1512.. x317 + x1137 =e= 1 ;
c1513.. x319 + x1138 =e= 1 ;
c1514.. x321 + x1139 =e= 1 ;
c1515.. x323 + x1140 =e= 1 ;
c1516.. x325 + x1141 =e= 1 ;
c1517.. x327 + x1142 =e= 1 ;
c1518.. x329 + x1143 =e= 1 ;
c1519.. x331 + x1144 =e= 1 ;
c1520.. x333 + x1145 =e= 1 ;
c1521.. x335 + x1146 =e= 1 ;
c1522.. (0.9999*x278 + 0.0001)*(x367/(0.9999*x278 + 0.0001)*(x369/(0.9999*x278 + 0.0001))*(x369/(0.9999*x278 + 0.0001)) + 2*(x371/(0.9999*x278 + 0.0001))*(x373/(0.9999*x278 + 0.0001))) - 0*(1 - x278) + 0 =e= 0 ;
c1523.. x374 + x367 - (1 - x278)*0 + 0 =e= 0 ;
c1524.. x376 - x378 - (1 - x278)*0 + 0 =e= 0 ;
c1525_hi.. (-10)*x278 - x367 =l= 0 ;
c1526_hi.. x367 + (-10)*x278 =l= 0 ;
c1527_hi.. x278 - x369 =l= 0 ;
c1528_hi.. x369 + (-10)*x278 =l= 0 ;
c1529_hi.. x371 + (-10)*x278 =l= 0 ;
c1530_hi.. x373 + (-10)*x278 =l= 0 ;
c1531_hi.. (-10)*x278 - x374 =l= 0 ;
c1532_hi.. x374 + (-10)*x278 =l= 0 ;
c1533_hi.. x376 + (-10)*x278 =l= 0 ;
c1534_hi.. x378 + (-10)*x278 =l= 0 ;
c1535_hi.. (-10)*x1087 + 0 =l= 0 ;
c1536_hi.. 0 + (-10)*x1087 =l= 0 ;
c1537_hi.. (-10)*x1087 + 0 =l= 0 ;
c1538_hi.. 0 + (-10)*x1087 =l= 0 ;
c1539_hi.. 0 + (-10)*x1087 =l= 0 ;
c1540_hi.. 0 + (-10)*x1087 =l= 0 ;
c1541_hi.. 0 + (-10)*x1087 =l= 0 ;
c1542_hi.. 0 + (-9)*x1087 =l= 0 ;
c1543.. (0.9999*x280 + 0.0001)*(x382/(0.9999*x280 + 0.0001)*(x384/(0.9999*x280 + 0.0001))*(x384/(0.9999*x280 + 0.0001)) + 2*(x386/(0.9999*x280 + 0.0001))*(x388/(0.9999*x280 + 0.0001))) - 0*(1 - x280) + 0 =e= 0 ;
c1544.. x389 + x382 - (1 - x280)*0 + 0 =e= 0 ;
c1545.. x391 - x393 - (1 - x280)*0 + 0 =e= 0 ;
c1546_hi.. (-10)*x280 - x382 =l= 0 ;
c1547_hi.. x382 + (-10)*x280 =l= 0 ;
c1548_hi.. x280 - x384 =l= 0 ;
c1549_hi.. x384 + (-10)*x280 =l= 0 ;
c1550_hi.. x386 + (-10)*x280 =l= 0 ;
c1551_hi.. x388 + (-10)*x280 =l= 0 ;
c1552_hi.. (-10)*x280 - x389 =l= 0 ;
c1553_hi.. x389 + (-10)*x280 =l= 0 ;
c1554_hi.. x391 + (-10)*x280 =l= 0 ;
c1555_hi.. x393 + (-10)*x280 =l= 0 ;
c1556_hi.. (-10)*x1088 + 0 =l= 0 ;
c1557_hi.. 0 + (-10)*x1088 =l= 0 ;
c1558_hi.. (-10)*x1088 + 0 =l= 0 ;
c1559_hi.. 0 + (-10)*x1088 =l= 0 ;
c1560_hi.. 0 + (-10)*x1088 =l= 0 ;
c1561_hi.. 0 + (-10)*x1088 =l= 0 ;
c1562_hi.. 0 + (-10)*x1088 =l= 0 ;
c1563_hi.. 0 + (-9)*x1088 =l= 0 ;
c1564.. (0.9999*x282 + 0.0001)*(x397/(0.9999*x282 + 0.0001)*(x399/(0.9999*x282 + 0.0001))*(x399/(0.9999*x282 + 0.0001)) + 2*(x401/(0.9999*x282 + 0.0001))*(x403/(0.9999*x282 + 0.0001))) - 0*(1 - x282) + 0 =e= 0 ;
c1565.. x404 + x397 - (1 - x282)*0 + 0 =e= 0 ;
c1566.. x406 - x408 - (1 - x282)*0 + 0 =e= 0 ;
c1567_hi.. (-10)*x282 - x397 =l= 0 ;
c1568_hi.. x397 + (-10)*x282 =l= 0 ;
c1569_hi.. x282 - x399 =l= 0 ;
c1570_hi.. x399 + (-10)*x282 =l= 0 ;
c1571_hi.. x401 + (-10)*x282 =l= 0 ;
c1572_hi.. x403 + (-10)*x282 =l= 0 ;
c1573_hi.. (-10)*x282 - x404 =l= 0 ;
c1574_hi.. x404 + (-10)*x282 =l= 0 ;
c1575_hi.. x406 + (-10)*x282 =l= 0 ;
c1576_hi.. x408 + (-10)*x282 =l= 0 ;
c1577_hi.. (-10)*x1089 + 0 =l= 0 ;
c1578_hi.. 0 + (-10)*x1089 =l= 0 ;
c1579_hi.. (-10)*x1089 + 0 =l= 0 ;
c1580_hi.. 0 + (-10)*x1089 =l= 0 ;
c1581_hi.. 0 + (-10)*x1089 =l= 0 ;
c1582_hi.. 0 + (-10)*x1089 =l= 0 ;
c1583_hi.. 0 + (-10)*x1089 =l= 0 ;
c1584_hi.. 0 + (-9)*x1089 =l= 0 ;
c1585.. (0.9999*x284 + 0.0001)*(x412/(0.9999*x284 + 0.0001)*(x414/(0.9999*x284 + 0.0001))*(x414/(0.9999*x284 + 0.0001)) + 2*(x416/(0.9999*x284 + 0.0001))*(x418/(0.9999*x284 + 0.0001))) - 0*(1 - x284) + 0 =e= 0 ;
c1586.. x419 + x412 - (1 - x284)*0 + 0 =e= 0 ;
c1587.. x421 - x423 - (1 - x284)*0 + 0 =e= 0 ;
c1588_hi.. (-10)*x284 - x412 =l= 0 ;
c1589_hi.. x412 + (-10)*x284 =l= 0 ;
c1590_hi.. x284 - x414 =l= 0 ;
c1591_hi.. x414 + (-10)*x284 =l= 0 ;
c1592_hi.. x416 + (-10)*x284 =l= 0 ;
c1593_hi.. x418 + (-10)*x284 =l= 0 ;
c1594_hi.. (-10)*x284 - x419 =l= 0 ;
c1595_hi.. x419 + (-10)*x284 =l= 0 ;
c1596_hi.. x421 + (-10)*x284 =l= 0 ;
c1597_hi.. x423 + (-10)*x284 =l= 0 ;
c1598_hi.. (-10)*x1090 + 0 =l= 0 ;
c1599_hi.. 0 + (-10)*x1090 =l= 0 ;
c1600_hi.. (-10)*x1090 + 0 =l= 0 ;
c1601_hi.. 0 + (-10)*x1090 =l= 0 ;
c1602_hi.. 0 + (-10)*x1090 =l= 0 ;
c1603_hi.. 0 + (-10)*x1090 =l= 0 ;
c1604_hi.. 0 + (-10)*x1090 =l= 0 ;
c1605_hi.. 0 + (-9)*x1090 =l= 0 ;
c1606.. (0.9999*x286 + 0.0001)*(x427/(0.9999*x286 + 0.0001)*(x429/(0.9999*x286 + 0.0001))*(x429/(0.9999*x286 + 0.0001)) + 2*(x431/(0.9999*x286 + 0.0001))*(x433/(0.9999*x286 + 0.0001))) - 0*(1 - x286) + 0 =e= 0 ;
c1607.. x434 + x427 - (1 - x286)*0 + 0 =e= 0 ;
c1608.. x436 - x438 - (1 - x286)*0 + 0 =e= 0 ;
c1609_hi.. (-10)*x286 - x427 =l= 0 ;
c1610_hi.. x427 + (-10)*x286 =l= 0 ;
c1611_hi.. x286 - x429 =l= 0 ;
c1612_hi.. x429 + (-10)*x286 =l= 0 ;
c1613_hi.. x431 + (-10)*x286 =l= 0 ;
c1614_hi.. x433 + (-10)*x286 =l= 0 ;
c1615_hi.. (-10)*x286 - x434 =l= 0 ;
c1616_hi.. x434 + (-10)*x286 =l= 0 ;
c1617_hi.. x436 + (-10)*x286 =l= 0 ;
c1618_hi.. x438 + (-10)*x286 =l= 0 ;
c1619_hi.. (-10)*x1091 + 0 =l= 0 ;
c1620_hi.. 0 + (-10)*x1091 =l= 0 ;
c1621_hi.. (-10)*x1091 + 0 =l= 0 ;
c1622_hi.. 0 + (-10)*x1091 =l= 0 ;
c1623_hi.. 0 + (-10)*x1091 =l= 0 ;
c1624_hi.. 0 + (-10)*x1091 =l= 0 ;
c1625_hi.. 0 + (-10)*x1091 =l= 0 ;
c1626_hi.. 0 + (-9)*x1091 =l= 0 ;
c1627.. (0.9999*x288 + 0.0001)*(x442/(0.9999*x288 + 0.0001)*(x444/(0.9999*x288 + 0.0001))*(x444/(0.9999*x288 + 0.0001)) + 2*(x446/(0.9999*x288 + 0.0001))*(x448/(0.9999*x288 + 0.0001))) - 0*(1 - x288) + 0 =e= 0 ;
c1628.. x449 + x442 - (1 - x288)*0 + 0 =e= 0 ;
c1629.. x451 - x453 - (1 - x288)*0 + 0 =e= 0 ;
c1630_hi.. (-10)*x288 - x442 =l= 0 ;
c1631_hi.. x442 + (-10)*x288 =l= 0 ;
c1632_hi.. x288 - x444 =l= 0 ;
c1633_hi.. x444 + (-10)*x288 =l= 0 ;
c1634_hi.. x446 + (-10)*x288 =l= 0 ;
c1635_hi.. x448 + (-10)*x288 =l= 0 ;
c1636_hi.. (-10)*x288 - x449 =l= 0 ;
c1637_hi.. x449 + (-10)*x288 =l= 0 ;
c1638_hi.. x451 + (-10)*x288 =l= 0 ;
c1639_hi.. x453 + (-10)*x288 =l= 0 ;
c1640_hi.. (-10)*x1092 + 0 =l= 0 ;
c1641_hi.. 0 + (-10)*x1092 =l= 0 ;
c1642_hi.. (-10)*x1092 + 0 =l= 0 ;
c1643_hi.. 0 + (-10)*x1092 =l= 0 ;
c1644_hi.. 0 + (-10)*x1092 =l= 0 ;
c1645_hi.. 0 + (-10)*x1092 =l= 0 ;
c1646_hi.. 0 + (-10)*x1092 =l= 0 ;
c1647_hi.. 0 + (-9)*x1092 =l= 0 ;
c1648.. (0.9999*x290 + 0.0001)*(x457/(0.9999*x290 + 0.0001)*(x459/(0.9999*x290 + 0.0001))*(x459/(0.9999*x290 + 0.0001)) + 2*(x461/(0.9999*x290 + 0.0001))*(x463/(0.9999*x290 + 0.0001))) - 0*(1 - x290) + 0 =e= 0 ;
c1649.. x464 + x457 - (1 - x290)*0 + 0 =e= 0 ;
c1650.. x466 - x468 - (1 - x290)*0 + 0 =e= 0 ;
c1651_hi.. (-10)*x290 - x457 =l= 0 ;
c1652_hi.. x457 + (-10)*x290 =l= 0 ;
c1653_hi.. x290 - x459 =l= 0 ;
c1654_hi.. x459 + (-10)*x290 =l= 0 ;
c1655_hi.. x461 + (-10)*x290 =l= 0 ;
c1656_hi.. x463 + (-10)*x290 =l= 0 ;
c1657_hi.. (-10)*x290 - x464 =l= 0 ;
c1658_hi.. x464 + (-10)*x290 =l= 0 ;
c1659_hi.. x466 + (-10)*x290 =l= 0 ;
c1660_hi.. x468 + (-10)*x290 =l= 0 ;
c1661_hi.. (-10)*x1093 + 0 =l= 0 ;
c1662_hi.. 0 + (-10)*x1093 =l= 0 ;
c1663_hi.. (-10)*x1093 + 0 =l= 0 ;
c1664_hi.. 0 + (-10)*x1093 =l= 0 ;
c1665_hi.. 0 + (-10)*x1093 =l= 0 ;
c1666_hi.. 0 + (-10)*x1093 =l= 0 ;
c1667_hi.. 0 + (-10)*x1093 =l= 0 ;
c1668_hi.. 0 + (-9)*x1093 =l= 0 ;
c1669.. (0.9999*x292 + 0.0001)*(x472/(0.9999*x292 + 0.0001)*(x474/(0.9999*x292 + 0.0001))*(x474/(0.9999*x292 + 0.0001)) + 2*(x476/(0.9999*x292 + 0.0001))*(x478/(0.9999*x292 + 0.0001))) - 0*(1 - x292) + 0 =e= 0 ;
c1670.. x479 + x472 - (1 - x292)*0 + 0 =e= 0 ;
c1671.. x481 - x483 - (1 - x292)*0 + 0 =e= 0 ;
c1672_hi.. (-10)*x292 - x472 =l= 0 ;
c1673_hi.. x472 + (-10)*x292 =l= 0 ;
c1674_hi.. x292 - x474 =l= 0 ;
c1675_hi.. x474 + (-10)*x292 =l= 0 ;
c1676_hi.. x476 + (-10)*x292 =l= 0 ;
c1677_hi.. x478 + (-10)*x292 =l= 0 ;
c1678_hi.. (-10)*x292 - x479 =l= 0 ;
c1679_hi.. x479 + (-10)*x292 =l= 0 ;
c1680_hi.. x481 + (-10)*x292 =l= 0 ;
c1681_hi.. x483 + (-10)*x292 =l= 0 ;
c1682_hi.. (-10)*x1094 + 0 =l= 0 ;
c1683_hi.. 0 + (-10)*x1094 =l= 0 ;
c1684_hi.. (-10)*x1094 + 0 =l= 0 ;
c1685_hi.. 0 + (-10)*x1094 =l= 0 ;
c1686_hi.. 0 + (-10)*x1094 =l= 0 ;
c1687_hi.. 0 + (-10)*x1094 =l= 0 ;
c1688_hi.. 0 + (-10)*x1094 =l= 0 ;
c1689_hi.. 0 + (-9)*x1094 =l= 0 ;
c1690.. (0.9999*x294 + 0.0001)*(x487/(0.9999*x294 + 0.0001)*(x489/(0.9999*x294 + 0.0001))*(x489/(0.9999*x294 + 0.0001)) + 2*(x491/(0.9999*x294 + 0.0001))*(x493/(0.9999*x294 + 0.0001))) - 0*(1 - x294) + 0 =e= 0 ;
c1691.. x494 + x487 - (1 - x294)*0 + 0 =e= 0 ;
c1692.. x496 - x498 - (1 - x294)*0 + 0 =e= 0 ;
c1693_hi.. (-10)*x294 - x487 =l= 0 ;
c1694_hi.. x487 + (-10)*x294 =l= 0 ;
c1695_hi.. x294 - x489 =l= 0 ;
c1696_hi.. x489 + (-10)*x294 =l= 0 ;
c1697_hi.. x491 + (-10)*x294 =l= 0 ;
c1698_hi.. x493 + (-10)*x294 =l= 0 ;
c1699_hi.. (-10)*x294 - x494 =l= 0 ;
c1700_hi.. x494 + (-10)*x294 =l= 0 ;
c1701_hi.. x496 + (-10)*x294 =l= 0 ;
c1702_hi.. x498 + (-10)*x294 =l= 0 ;
c1703_hi.. (-10)*x1095 + 0 =l= 0 ;
c1704_hi.. 0 + (-10)*x1095 =l= 0 ;
c1705_hi.. (-10)*x1095 + 0 =l= 0 ;
c1706_hi.. 0 + (-10)*x1095 =l= 0 ;
c1707_hi.. 0 + (-10)*x1095 =l= 0 ;
c1708_hi.. 0 + (-10)*x1095 =l= 0 ;
c1709_hi.. 0 + (-10)*x1095 =l= 0 ;
c1710_hi.. 0 + (-9)*x1095 =l= 0 ;
c1711.. (0.9999*x296 + 0.0001)*(x502/(0.9999*x296 + 0.0001)*(x504/(0.9999*x296 + 0.0001))*(x504/(0.9999*x296 + 0.0001)) + 2*(x506/(0.9999*x296 + 0.0001))*(x508/(0.9999*x296 + 0.0001))) - 0*(1 - x296) + 0 =e= 0 ;
c1712.. x509 + x502 - (1 - x296)*0 + 0 =e= 0 ;
c1713.. x511 - x513 - (1 - x296)*0 + 0 =e= 0 ;
c1714_hi.. (-10)*x296 - x502 =l= 0 ;
c1715_hi.. x502 + (-10)*x296 =l= 0 ;
c1716_hi.. x296 - x504 =l= 0 ;
c1717_hi.. x504 + (-10)*x296 =l= 0 ;
c1718_hi.. x506 + (-10)*x296 =l= 0 ;
c1719_hi.. x508 + (-10)*x296 =l= 0 ;
c1720_hi.. (-10)*x296 - x509 =l= 0 ;
c1721_hi.. x509 + (-10)*x296 =l= 0 ;
c1722_hi.. x511 + (-10)*x296 =l= 0 ;
c1723_hi.. x513 + (-10)*x296 =l= 0 ;
c1724_hi.. (-10)*x1096 + 0 =l= 0 ;
c1725_hi.. 0 + (-10)*x1096 =l= 0 ;
c1726_hi.. (-10)*x1096 + 0 =l= 0 ;
c1727_hi.. 0 + (-10)*x1096 =l= 0 ;
c1728_hi.. 0 + (-10)*x1096 =l= 0 ;
c1729_hi.. 0 + (-10)*x1096 =l= 0 ;
c1730_hi.. 0 + (-10)*x1096 =l= 0 ;
c1731_hi.. 0 + (-9)*x1096 =l= 0 ;
c1732.. (0.9999*x298 + 0.0001)*(x517/(0.9999*x298 + 0.0001)*(x519/(0.9999*x298 + 0.0001))*(x519/(0.9999*x298 + 0.0001)) + 2*(x521/(0.9999*x298 + 0.0001))*(x523/(0.9999*x298 + 0.0001))) - 0*(1 - x298) + 0 =e= 0 ;
c1733.. x524 + x517 - (1 - x298)*0 + 0 =e= 0 ;
c1734.. x526 - x528 - (1 - x298)*0 + 0 =e= 0 ;
c1735_hi.. (-10)*x298 - x517 =l= 0 ;
c1736_hi.. x517 + (-10)*x298 =l= 0 ;
c1737_hi.. x298 - x519 =l= 0 ;
c1738_hi.. x519 + (-10)*x298 =l= 0 ;
c1739_hi.. x521 + (-10)*x298 =l= 0 ;
c1740_hi.. x523 + (-10)*x298 =l= 0 ;
c1741_hi.. (-10)*x298 - x524 =l= 0 ;
c1742_hi.. x524 + (-10)*x298 =l= 0 ;
c1743_hi.. x526 + (-10)*x298 =l= 0 ;
c1744_hi.. x528 + (-10)*x298 =l= 0 ;
c1745_hi.. (-10)*x1097 + 0 =l= 0 ;
c1746_hi.. 0 + (-10)*x1097 =l= 0 ;
c1747_hi.. (-10)*x1097 + 0 =l= 0 ;
c1748_hi.. 0 + (-10)*x1097 =l= 0 ;
c1749_hi.. 0 + (-10)*x1097 =l= 0 ;
c1750_hi.. 0 + (-10)*x1097 =l= 0 ;
c1751_hi.. 0 + (-10)*x1097 =l= 0 ;
c1752_hi.. 0 + (-9)*x1097 =l= 0 ;
c1753.. (0.9999*x300 + 0.0001)*(x532/(0.9999*x300 + 0.0001)*(x534/(0.9999*x300 + 0.0001))*(x534/(0.9999*x300 + 0.0001)) + 2*(x536/(0.9999*x300 + 0.0001))*(x538/(0.9999*x300 + 0.0001))) - 0*(1 - x300) + 0 =e= 0 ;
c1754.. x539 + x532 - (1 - x300)*0 + 0 =e= 0 ;
c1755.. x541 - x543 - (1 - x300)*0 + 0 =e= 0 ;
c1756_hi.. (-10)*x300 - x532 =l= 0 ;
c1757_hi.. x532 + (-10)*x300 =l= 0 ;
c1758_hi.. x300 - x534 =l= 0 ;
c1759_hi.. x534 + (-10)*x300 =l= 0 ;
c1760_hi.. x536 + (-10)*x300 =l= 0 ;
c1761_hi.. x538 + (-10)*x300 =l= 0 ;
c1762_hi.. (-10)*x300 - x539 =l= 0 ;
c1763_hi.. x539 + (-10)*x300 =l= 0 ;
c1764_hi.. x541 + (-10)*x300 =l= 0 ;
c1765_hi.. x543 + (-10)*x300 =l= 0 ;
c1766_hi.. (-10)*x1098 + 0 =l= 0 ;
c1767_hi.. 0 + (-10)*x1098 =l= 0 ;
c1768_hi.. (-10)*x1098 + 0 =l= 0 ;
c1769_hi.. 0 + (-10)*x1098 =l= 0 ;
c1770_hi.. 0 + (-10)*x1098 =l= 0 ;
c1771_hi.. 0 + (-10)*x1098 =l= 0 ;
c1772_hi.. 0 + (-10)*x1098 =l= 0 ;
c1773_hi.. 0 + (-9)*x1098 =l= 0 ;
c1774.. (0.9999*x302 + 0.0001)*(x547/(0.9999*x302 + 0.0001)*(x549/(0.9999*x302 + 0.0001))*(x549/(0.9999*x302 + 0.0001)) + 2*(x551/(0.9999*x302 + 0.0001))*(x553/(0.9999*x302 + 0.0001))) - 0*(1 - x302) + 0 =e= 0 ;
c1775.. x554 + x547 - (1 - x302)*0 + 0 =e= 0 ;
c1776.. x556 - x558 - (1 - x302)*0 + 0 =e= 0 ;
c1777_hi.. (-10)*x302 - x547 =l= 0 ;
c1778_hi.. x547 + (-10)*x302 =l= 0 ;
c1779_hi.. x302 - x549 =l= 0 ;
c1780_hi.. x549 + (-10)*x302 =l= 0 ;
c1781_hi.. x551 + (-10)*x302 =l= 0 ;
c1782_hi.. x553 + (-10)*x302 =l= 0 ;
c1783_hi.. (-10)*x302 - x554 =l= 0 ;
c1784_hi.. x554 + (-10)*x302 =l= 0 ;
c1785_hi.. x556 + (-10)*x302 =l= 0 ;
c1786_hi.. x558 + (-10)*x302 =l= 0 ;
c1787_hi.. (-10)*x1099 + 0 =l= 0 ;
c1788_hi.. 0 + (-10)*x1099 =l= 0 ;
c1789_hi.. (-10)*x1099 + 0 =l= 0 ;
c1790_hi.. 0 + (-10)*x1099 =l= 0 ;
c1791_hi.. 0 + (-10)*x1099 =l= 0 ;
c1792_hi.. 0 + (-10)*x1099 =l= 0 ;
c1793_hi.. 0 + (-10)*x1099 =l= 0 ;
c1794_hi.. 0 + (-9)*x1099 =l= 0 ;
c1795.. (0.9999*x304 + 0.0001)*(x562/(0.9999*x304 + 0.0001)*(x564/(0.9999*x304 + 0.0001))*(x564/(0.9999*x304 + 0.0001)) + 2*(x566/(0.9999*x304 + 0.0001))*(x568/(0.9999*x304 + 0.0001))) - 0*(1 - x304) + 0 =e= 0 ;
c1796.. x569 + x562 - (1 - x304)*0 + 0 =e= 0 ;
c1797.. x571 - x573 - (1 - x304)*0 + 0 =e= 0 ;
c1798_hi.. (-10)*x304 - x562 =l= 0 ;
c1799_hi.. x562 + (-10)*x304 =l= 0 ;
c1800_hi.. x304 - x564 =l= 0 ;
c1801_hi.. x564 + (-10)*x304 =l= 0 ;
c1802_hi.. x566 + (-10)*x304 =l= 0 ;
c1803_hi.. x568 + (-10)*x304 =l= 0 ;
c1804_hi.. (-10)*x304 - x569 =l= 0 ;
c1805_hi.. x569 + (-10)*x304 =l= 0 ;
c1806_hi.. x571 + (-10)*x304 =l= 0 ;
c1807_hi.. x573 + (-10)*x304 =l= 0 ;
c1808_hi.. (-10)*x1100 + 0 =l= 0 ;
c1809_hi.. 0 + (-10)*x1100 =l= 0 ;
c1810_hi.. (-10)*x1100 + 0 =l= 0 ;
c1811_hi.. 0 + (-10)*x1100 =l= 0 ;
c1812_hi.. 0 + (-10)*x1100 =l= 0 ;
c1813_hi.. 0 + (-10)*x1100 =l= 0 ;
c1814_hi.. 0 + (-10)*x1100 =l= 0 ;
c1815_hi.. 0 + (-9)*x1100 =l= 0 ;
c1816.. (0.9999*x306 + 0.0001)*(x577/(0.9999*x306 + 0.0001)*(x579/(0.9999*x306 + 0.0001))*(x579/(0.9999*x306 + 0.0001)) + 2*(x581/(0.9999*x306 + 0.0001))*(x583/(0.9999*x306 + 0.0001))) - 0*(1 - x306) + 0 =e= 0 ;
c1817.. x584 + x577 - (1 - x306)*0 + 0 =e= 0 ;
c1818.. x586 - x588 - (1 - x306)*0 + 0 =e= 0 ;
c1819_hi.. (-10)*x306 - x577 =l= 0 ;
c1820_hi.. x577 + (-10)*x306 =l= 0 ;
c1821_hi.. x306 - x579 =l= 0 ;
c1822_hi.. x579 + (-10)*x306 =l= 0 ;
c1823_hi.. x581 + (-10)*x306 =l= 0 ;
c1824_hi.. x583 + (-10)*x306 =l= 0 ;
c1825_hi.. (-10)*x306 - x584 =l= 0 ;
c1826_hi.. x584 + (-10)*x306 =l= 0 ;
c1827_hi.. x586 + (-10)*x306 =l= 0 ;
c1828_hi.. x588 + (-10)*x306 =l= 0 ;
c1829_hi.. (-10)*x1101 + 0 =l= 0 ;
c1830_hi.. 0 + (-10)*x1101 =l= 0 ;
c1831_hi.. (-10)*x1101 + 0 =l= 0 ;
c1832_hi.. 0 + (-10)*x1101 =l= 0 ;
c1833_hi.. 0 + (-10)*x1101 =l= 0 ;
c1834_hi.. 0 + (-10)*x1101 =l= 0 ;
c1835_hi.. 0 + (-10)*x1101 =l= 0 ;
c1836_hi.. 0 + (-9)*x1101 =l= 0 ;
c1837.. (0.9999*x308 + 0.0001)*(x592/(0.9999*x308 + 0.0001)*(x594/(0.9999*x308 + 0.0001))*(x594/(0.9999*x308 + 0.0001)) + 2*(x596/(0.9999*x308 + 0.0001))*(x598/(0.9999*x308 + 0.0001))) - 0*(1 - x308) + 0 =e= 0 ;
c1838.. x599 + x592 - (1 - x308)*0 + 0 =e= 0 ;
c1839.. x601 - x603 - (1 - x308)*0 + 0 =e= 0 ;
c1840_hi.. (-10)*x308 - x592 =l= 0 ;
c1841_hi.. x592 + (-10)*x308 =l= 0 ;
c1842_hi.. x308 - x594 =l= 0 ;
c1843_hi.. x594 + (-10)*x308 =l= 0 ;
c1844_hi.. x596 + (-10)*x308 =l= 0 ;
c1845_hi.. x598 + (-10)*x308 =l= 0 ;
c1846_hi.. (-10)*x308 - x599 =l= 0 ;
c1847_hi.. x599 + (-10)*x308 =l= 0 ;
c1848_hi.. x601 + (-10)*x308 =l= 0 ;
c1849_hi.. x603 + (-10)*x308 =l= 0 ;
c1850_hi.. (-10)*x1102 + 0 =l= 0 ;
c1851_hi.. 0 + (-10)*x1102 =l= 0 ;
c1852_hi.. (-10)*x1102 + 0 =l= 0 ;
c1853_hi.. 0 + (-10)*x1102 =l= 0 ;
c1854_hi.. 0 + (-10)*x1102 =l= 0 ;
c1855_hi.. 0 + (-10)*x1102 =l= 0 ;
c1856_hi.. 0 + (-10)*x1102 =l= 0 ;
c1857_hi.. 0 + (-9)*x1102 =l= 0 ;
c1858.. (0.9999*x310 + 0.0001)*(x607/(0.9999*x310 + 0.0001)*(x609/(0.9999*x310 + 0.0001))*(x609/(0.9999*x310 + 0.0001)) + 2*(x611/(0.9999*x310 + 0.0001))*(x613/(0.9999*x310 + 0.0001))) - 0*(1 - x310) + 0 =e= 0 ;
c1859.. x614 + x607 - (1 - x310)*0 + 0 =e= 0 ;
c1860.. x616 - x618 - (1 - x310)*0 + 0 =e= 0 ;
c1861_hi.. (-10)*x310 - x607 =l= 0 ;
c1862_hi.. x607 + (-10)*x310 =l= 0 ;
c1863_hi.. x310 - x609 =l= 0 ;
c1864_hi.. x609 + (-10)*x310 =l= 0 ;
c1865_hi.. x611 + (-10)*x310 =l= 0 ;
c1866_hi.. x613 + (-10)*x310 =l= 0 ;
c1867_hi.. (-10)*x310 - x614 =l= 0 ;
c1868_hi.. x614 + (-10)*x310 =l= 0 ;
c1869_hi.. x616 + (-10)*x310 =l= 0 ;
c1870_hi.. x618 + (-10)*x310 =l= 0 ;
c1871_hi.. (-10)*x1103 + 0 =l= 0 ;
c1872_hi.. 0 + (-10)*x1103 =l= 0 ;
c1873_hi.. (-10)*x1103 + 0 =l= 0 ;
c1874_hi.. 0 + (-10)*x1103 =l= 0 ;
c1875_hi.. 0 + (-10)*x1103 =l= 0 ;
c1876_hi.. 0 + (-10)*x1103 =l= 0 ;
c1877_hi.. 0 + (-10)*x1103 =l= 0 ;
c1878_hi.. 0 + (-9)*x1103 =l= 0 ;
c1879.. (0.9999*x312 + 0.0001)*(x622/(0.9999*x312 + 0.0001)*(x624/(0.9999*x312 + 0.0001))*(x624/(0.9999*x312 + 0.0001)) + 2*(x626/(0.9999*x312 + 0.0001))*(x628/(0.9999*x312 + 0.0001))) - 0*(1 - x312) + 0 =e= 0 ;
c1880.. x629 + x622 - (1 - x312)*0 + 0 =e= 0 ;
c1881.. x631 - x633 - (1 - x312)*0 + 0 =e= 0 ;
c1882_hi.. (-10)*x312 - x622 =l= 0 ;
c1883_hi.. x622 + (-10)*x312 =l= 0 ;
c1884_hi.. x312 - x624 =l= 0 ;
c1885_hi.. x624 + (-10)*x312 =l= 0 ;
c1886_hi.. x626 + (-10)*x312 =l= 0 ;
c1887_hi.. x628 + (-10)*x312 =l= 0 ;
c1888_hi.. (-10)*x312 - x629 =l= 0 ;
c1889_hi.. x629 + (-10)*x312 =l= 0 ;
c1890_hi.. x631 + (-10)*x312 =l= 0 ;
c1891_hi.. x633 + (-10)*x312 =l= 0 ;
c1892_hi.. (-10)*x1104 + 0 =l= 0 ;
c1893_hi.. 0 + (-10)*x1104 =l= 0 ;
c1894_hi.. (-10)*x1104 + 0 =l= 0 ;
c1895_hi.. 0 + (-10)*x1104 =l= 0 ;
c1896_hi.. 0 + (-10)*x1104 =l= 0 ;
c1897_hi.. 0 + (-10)*x1104 =l= 0 ;
c1898_hi.. 0 + (-10)*x1104 =l= 0 ;
c1899_hi.. 0 + (-9)*x1104 =l= 0 ;
c1900.. (0.9999*x314 + 0.0001)*(x637/(0.9999*x314 + 0.0001)*(x639/(0.9999*x314 + 0.0001))*(x639/(0.9999*x314 + 0.0001)) + 2*(x641/(0.9999*x314 + 0.0001))*(x643/(0.9999*x314 + 0.0001))) - 0*(1 - x314) + 0 =e= 0 ;
c1901.. x644 + x637 - (1 - x314)*0 + 0 =e= 0 ;
c1902.. x646 - x648 - (1 - x314)*0 + 0 =e= 0 ;
c1903_hi.. (-10)*x314 - x637 =l= 0 ;
c1904_hi.. x637 + (-10)*x314 =l= 0 ;
c1905_hi.. x314 - x639 =l= 0 ;
c1906_hi.. x639 + (-10)*x314 =l= 0 ;
c1907_hi.. x641 + (-10)*x314 =l= 0 ;
c1908_hi.. x643 + (-10)*x314 =l= 0 ;
c1909_hi.. (-10)*x314 - x644 =l= 0 ;
c1910_hi.. x644 + (-10)*x314 =l= 0 ;
c1911_hi.. x646 + (-10)*x314 =l= 0 ;
c1912_hi.. x648 + (-10)*x314 =l= 0 ;
c1913_hi.. (-10)*x1105 + 0 =l= 0 ;
c1914_hi.. 0 + (-10)*x1105 =l= 0 ;
c1915_hi.. (-10)*x1105 + 0 =l= 0 ;
c1916_hi.. 0 + (-10)*x1105 =l= 0 ;
c1917_hi.. 0 + (-10)*x1105 =l= 0 ;
c1918_hi.. 0 + (-10)*x1105 =l= 0 ;
c1919_hi.. 0 + (-10)*x1105 =l= 0 ;
c1920_hi.. 0 + (-9)*x1105 =l= 0 ;
c1921.. (0.9999*x316 + 0.0001)*(x652/(0.9999*x316 + 0.0001)*(x654/(0.9999*x316 + 0.0001))*(x654/(0.9999*x316 + 0.0001)) + 2*(x656/(0.9999*x316 + 0.0001))*(x658/(0.9999*x316 + 0.0001))) - 0*(1 - x316) + 0 =e= 0 ;
c1922.. x659 + x652 - (1 - x316)*0 + 0 =e= 0 ;
c1923.. x661 - x663 - (1 - x316)*0 + 0 =e= 0 ;
c1924_hi.. (-10)*x316 - x652 =l= 0 ;
c1925_hi.. x652 + (-10)*x316 =l= 0 ;
c1926_hi.. x316 - x654 =l= 0 ;
c1927_hi.. x654 + (-10)*x316 =l= 0 ;
c1928_hi.. x656 + (-10)*x316 =l= 0 ;
c1929_hi.. x658 + (-10)*x316 =l= 0 ;
c1930_hi.. (-10)*x316 - x659 =l= 0 ;
c1931_hi.. x659 + (-10)*x316 =l= 0 ;
c1932_hi.. x661 + (-10)*x316 =l= 0 ;
c1933_hi.. x663 + (-10)*x316 =l= 0 ;
c1934_hi.. (-10)*x1106 + 0 =l= 0 ;
c1935_hi.. 0 + (-10)*x1106 =l= 0 ;
c1936_hi.. (-10)*x1106 + 0 =l= 0 ;
c1937_hi.. 0 + (-10)*x1106 =l= 0 ;
c1938_hi.. 0 + (-10)*x1106 =l= 0 ;
c1939_hi.. 0 + (-10)*x1106 =l= 0 ;
c1940_hi.. 0 + (-10)*x1106 =l= 0 ;
c1941_hi.. 0 + (-9)*x1106 =l= 0 ;
c1942.. (0.9999*x318 + 0.0001)*(x667/(0.9999*x318 + 0.0001)*(x669/(0.9999*x318 + 0.0001))*(x669/(0.9999*x318 + 0.0001)) + 2*(x671/(0.9999*x318 + 0.0001))*(x673/(0.9999*x318 + 0.0001))) - 0*(1 - x318) + 0 =e= 0 ;
c1943.. x674 + x667 - (1 - x318)*0 + 0 =e= 0 ;
c1944.. x676 - x678 - (1 - x318)*0 + 0 =e= 0 ;
c1945_hi.. (-10)*x318 - x667 =l= 0 ;
c1946_hi.. x667 + (-10)*x318 =l= 0 ;
c1947_hi.. x318 - x669 =l= 0 ;
c1948_hi.. x669 + (-10)*x318 =l= 0 ;
c1949_hi.. x671 + (-10)*x318 =l= 0 ;
c1950_hi.. x673 + (-10)*x318 =l= 0 ;
c1951_hi.. (-10)*x318 - x674 =l= 0 ;
c1952_hi.. x674 + (-10)*x318 =l= 0 ;
c1953_hi.. x676 + (-10)*x318 =l= 0 ;
c1954_hi.. x678 + (-10)*x318 =l= 0 ;
c1955_hi.. (-10)*x1107 + 0 =l= 0 ;
c1956_hi.. 0 + (-10)*x1107 =l= 0 ;
c1957_hi.. (-10)*x1107 + 0 =l= 0 ;
c1958_hi.. 0 + (-10)*x1107 =l= 0 ;
c1959_hi.. 0 + (-10)*x1107 =l= 0 ;
c1960_hi.. 0 + (-10)*x1107 =l= 0 ;
c1961_hi.. 0 + (-10)*x1107 =l= 0 ;
c1962_hi.. 0 + (-9)*x1107 =l= 0 ;
c1963.. (0.9999*x320 + 0.0001)*(x682/(0.9999*x320 + 0.0001)*(x684/(0.9999*x320 + 0.0001))*(x684/(0.9999*x320 + 0.0001)) + 2*(x686/(0.9999*x320 + 0.0001))*(x688/(0.9999*x320 + 0.0001))) - 0*(1 - x320) + 0 =e= 0 ;
c1964.. x689 + x682 - (1 - x320)*0 + 0 =e= 0 ;
c1965.. x691 - x693 - (1 - x320)*0 + 0 =e= 0 ;
c1966_hi.. (-10)*x320 - x682 =l= 0 ;
c1967_hi.. x682 + (-10)*x320 =l= 0 ;
c1968_hi.. x320 - x684 =l= 0 ;
c1969_hi.. x684 + (-10)*x320 =l= 0 ;
c1970_hi.. x686 + (-10)*x320 =l= 0 ;
c1971_hi.. x688 + (-10)*x320 =l= 0 ;
c1972_hi.. (-10)*x320 - x689 =l= 0 ;
c1973_hi.. x689 + (-10)*x320 =l= 0 ;
c1974_hi.. x691 + (-10)*x320 =l= 0 ;
c1975_hi.. x693 + (-10)*x320 =l= 0 ;
c1976_hi.. (-10)*x1108 + 0 =l= 0 ;
c1977_hi.. 0 + (-10)*x1108 =l= 0 ;
c1978_hi.. (-10)*x1108 + 0 =l= 0 ;
c1979_hi.. 0 + (-10)*x1108 =l= 0 ;
c1980_hi.. 0 + (-10)*x1108 =l= 0 ;
c1981_hi.. 0 + (-10)*x1108 =l= 0 ;
c1982_hi.. 0 + (-10)*x1108 =l= 0 ;
c1983_hi.. 0 + (-9)*x1108 =l= 0 ;
c1984.. (0.9999*x322 + 0.0001)*(x697/(0.9999*x322 + 0.0001)*(x699/(0.9999*x322 + 0.0001))*(x699/(0.9999*x322 + 0.0001)) + 2*(x701/(0.9999*x322 + 0.0001))*(x703/(0.9999*x322 + 0.0001))) - 0*(1 - x322) + 0 =e= 0 ;
c1985.. x704 + x697 - (1 - x322)*0 + 0 =e= 0 ;
c1986.. x706 - x708 - (1 - x322)*0 + 0 =e= 0 ;
c1987_hi.. (-10)*x322 - x697 =l= 0 ;
c1988_hi.. x697 + (-10)*x322 =l= 0 ;
c1989_hi.. x322 - x699 =l= 0 ;
c1990_hi.. x699 + (-10)*x322 =l= 0 ;
c1991_hi.. x701 + (-10)*x322 =l= 0 ;
c1992_hi.. x703 + (-10)*x322 =l= 0 ;
c1993_hi.. (-10)*x322 - x704 =l= 0 ;
c1994_hi.. x704 + (-10)*x322 =l= 0 ;
c1995_hi.. x706 + (-10)*x322 =l= 0 ;
c1996_hi.. x708 + (-10)*x322 =l= 0 ;
c1997_hi.. (-10)*x1109 + 0 =l= 0 ;
c1998_hi.. 0 + (-10)*x1109 =l= 0 ;
c1999_hi.. (-10)*x1109 + 0 =l= 0 ;
c2000_hi.. 0 + (-10)*x1109 =l= 0 ;
c2001_hi.. 0 + (-10)*x1109 =l= 0 ;
c2002_hi.. 0 + (-10)*x1109 =l= 0 ;
c2003_hi.. 0 + (-10)*x1109 =l= 0 ;
c2004_hi.. 0 + (-9)*x1109 =l= 0 ;
c2005.. (0.9999*x324 + 0.0001)*(x712/(0.9999*x324 + 0.0001)*(x714/(0.9999*x324 + 0.0001))*(x714/(0.9999*x324 + 0.0001)) + 2*(x716/(0.9999*x324 + 0.0001))*(x718/(0.9999*x324 + 0.0001))) - 0*(1 - x324) + 0 =e= 0 ;
c2006.. x719 + x712 - (1 - x324)*0 + 0 =e= 0 ;
c2007.. x721 - x723 - (1 - x324)*0 + 0 =e= 0 ;
c2008_hi.. (-10)*x324 - x712 =l= 0 ;
c2009_hi.. x712 + (-10)*x324 =l= 0 ;
c2010_hi.. x324 - x714 =l= 0 ;
c2011_hi.. x714 + (-10)*x324 =l= 0 ;
c2012_hi.. x716 + (-10)*x324 =l= 0 ;
c2013_hi.. x718 + (-10)*x324 =l= 0 ;
c2014_hi.. (-10)*x324 - x719 =l= 0 ;
c2015_hi.. x719 + (-10)*x324 =l= 0 ;
c2016_hi.. x721 + (-10)*x324 =l= 0 ;
c2017_hi.. x723 + (-10)*x324 =l= 0 ;
c2018_hi.. (-10)*x1110 + 0 =l= 0 ;
c2019_hi.. 0 + (-10)*x1110 =l= 0 ;
c2020_hi.. (-10)*x1110 + 0 =l= 0 ;
c2021_hi.. 0 + (-10)*x1110 =l= 0 ;
c2022_hi.. 0 + (-10)*x1110 =l= 0 ;
c2023_hi.. 0 + (-10)*x1110 =l= 0 ;
c2024_hi.. 0 + (-10)*x1110 =l= 0 ;
c2025_hi.. 0 + (-9)*x1110 =l= 0 ;
c2026.. (0.9999*x326 + 0.0001)*(x727/(0.9999*x326 + 0.0001)*(x729/(0.9999*x326 + 0.0001))*(x729/(0.9999*x326 + 0.0001)) + 2*(x731/(0.9999*x326 + 0.0001))*(x733/(0.9999*x326 + 0.0001))) - 0*(1 - x326) + 0 =e= 0 ;
c2027.. x734 + x727 - (1 - x326)*0 + 0 =e= 0 ;
c2028.. x736 - x738 - (1 - x326)*0 + 0 =e= 0 ;
c2029_hi.. (-10)*x326 - x727 =l= 0 ;
c2030_hi.. x727 + (-10)*x326 =l= 0 ;
c2031_hi.. x326 - x729 =l= 0 ;
c2032_hi.. x729 + (-10)*x326 =l= 0 ;
c2033_hi.. x731 + (-10)*x326 =l= 0 ;
c2034_hi.. x733 + (-10)*x326 =l= 0 ;
c2035_hi.. (-10)*x326 - x734 =l= 0 ;
c2036_hi.. x734 + (-10)*x326 =l= 0 ;
c2037_hi.. x736 + (-10)*x326 =l= 0 ;
c2038_hi.. x738 + (-10)*x326 =l= 0 ;
c2039_hi.. (-10)*x1111 + 0 =l= 0 ;
c2040_hi.. 0 + (-10)*x1111 =l= 0 ;
c2041_hi.. (-10)*x1111 + 0 =l= 0 ;
c2042_hi.. 0 + (-10)*x1111 =l= 0 ;
c2043_hi.. 0 + (-10)*x1111 =l= 0 ;
c2044_hi.. 0 + (-10)*x1111 =l= 0 ;
c2045_hi.. 0 + (-10)*x1111 =l= 0 ;
c2046_hi.. 0 + (-9)*x1111 =l= 0 ;
c2047.. (0.9999*x328 + 0.0001)*(x742/(0.9999*x328 + 0.0001)*(x744/(0.9999*x328 + 0.0001))*(x744/(0.9999*x328 + 0.0001)) + 2*(x746/(0.9999*x328 + 0.0001))*(x748/(0.9999*x328 + 0.0001))) - 0*(1 - x328) + 0 =e= 0 ;
c2048.. x749 + x742 - (1 - x328)*0 + 0 =e= 0 ;
c2049.. x751 - x753 - (1 - x328)*0 + 0 =e= 0 ;
c2050_hi.. (-10)*x328 - x742 =l= 0 ;
c2051_hi.. x742 + (-10)*x328 =l= 0 ;
c2052_hi.. x328 - x744 =l= 0 ;
c2053_hi.. x744 + (-10)*x328 =l= 0 ;
c2054_hi.. x746 + (-10)*x328 =l= 0 ;
c2055_hi.. x748 + (-10)*x328 =l= 0 ;
c2056_hi.. (-10)*x328 - x749 =l= 0 ;
c2057_hi.. x749 + (-10)*x328 =l= 0 ;
c2058_hi.. x751 + (-10)*x328 =l= 0 ;
c2059_hi.. x753 + (-10)*x328 =l= 0 ;
c2060_hi.. (-10)*x1112 + 0 =l= 0 ;
c2061_hi.. 0 + (-10)*x1112 =l= 0 ;
c2062_hi.. (-10)*x1112 + 0 =l= 0 ;
c2063_hi.. 0 + (-10)*x1112 =l= 0 ;
c2064_hi.. 0 + (-10)*x1112 =l= 0 ;
c2065_hi.. 0 + (-10)*x1112 =l= 0 ;
c2066_hi.. 0 + (-10)*x1112 =l= 0 ;
c2067_hi.. 0 + (-9)*x1112 =l= 0 ;
c2068.. (0.9999*x330 + 0.0001)*(x757/(0.9999*x330 + 0.0001)*(x759/(0.9999*x330 + 0.0001))*(x759/(0.9999*x330 + 0.0001)) + 2*(x761/(0.9999*x330 + 0.0001))*(x763/(0.9999*x330 + 0.0001))) - 0*(1 - x330) + 0 =e= 0 ;
c2069.. x764 + x757 - (1 - x330)*0 + 0 =e= 0 ;
c2070.. x766 - x768 - (1 - x330)*0 + 0 =e= 0 ;
c2071_hi.. (-10)*x330 - x757 =l= 0 ;
c2072_hi.. x757 + (-10)*x330 =l= 0 ;
c2073_hi.. x330 - x759 =l= 0 ;
c2074_hi.. x759 + (-10)*x330 =l= 0 ;
c2075_hi.. x761 + (-10)*x330 =l= 0 ;
c2076_hi.. x763 + (-10)*x330 =l= 0 ;
c2077_hi.. (-10)*x330 - x764 =l= 0 ;
c2078_hi.. x764 + (-10)*x330 =l= 0 ;
c2079_hi.. x766 + (-10)*x330 =l= 0 ;
c2080_hi.. x768 + (-10)*x330 =l= 0 ;
c2081_hi.. (-10)*x1113 + 0 =l= 0 ;
c2082_hi.. 0 + (-10)*x1113 =l= 0 ;
c2083_hi.. (-10)*x1113 + 0 =l= 0 ;
c2084_hi.. 0 + (-10)*x1113 =l= 0 ;
c2085_hi.. 0 + (-10)*x1113 =l= 0 ;
c2086_hi.. 0 + (-10)*x1113 =l= 0 ;
c2087_hi.. 0 + (-10)*x1113 =l= 0 ;
c2088_hi.. 0 + (-9)*x1113 =l= 0 ;
c2089.. (0.9999*x332 + 0.0001)*(x772/(0.9999*x332 + 0.0001)*(x774/(0.9999*x332 + 0.0001))*(x774/(0.9999*x332 + 0.0001)) + 2*(x776/(0.9999*x332 + 0.0001))*(x778/(0.9999*x332 + 0.0001))) - 0*(1 - x332) + 0 =e= 0 ;
c2090.. x779 + x772 - (1 - x332)*0 + 0 =e= 0 ;
c2091.. x781 - x783 - (1 - x332)*0 + 0 =e= 0 ;
c2092_hi.. (-10)*x332 - x772 =l= 0 ;
c2093_hi.. x772 + (-10)*x332 =l= 0 ;
c2094_hi.. x332 - x774 =l= 0 ;
c2095_hi.. x774 + (-10)*x332 =l= 0 ;
c2096_hi.. x776 + (-10)*x332 =l= 0 ;
c2097_hi.. x778 + (-10)*x332 =l= 0 ;
c2098_hi.. (-10)*x332 - x779 =l= 0 ;
c2099_hi.. x779 + (-10)*x332 =l= 0 ;
c2100_hi.. x781 + (-10)*x332 =l= 0 ;
c2101_hi.. x783 + (-10)*x332 =l= 0 ;
c2102_hi.. (-10)*x1114 + 0 =l= 0 ;
c2103_hi.. 0 + (-10)*x1114 =l= 0 ;
c2104_hi.. (-10)*x1114 + 0 =l= 0 ;
c2105_hi.. 0 + (-10)*x1114 =l= 0 ;
c2106_hi.. 0 + (-10)*x1114 =l= 0 ;
c2107_hi.. 0 + (-10)*x1114 =l= 0 ;
c2108_hi.. 0 + (-10)*x1114 =l= 0 ;
c2109_hi.. 0 + (-9)*x1114 =l= 0 ;
c2110.. (0.9999*x334 + 0.0001)*(x787/(0.9999*x334 + 0.0001)*(x789/(0.9999*x334 + 0.0001))*(x789/(0.9999*x334 + 0.0001)) + 2*(x791/(0.9999*x334 + 0.0001))*(x793/(0.9999*x334 + 0.0001))) - 0*(1 - x334) + 0 =e= 0 ;
c2111.. x794 + x787 - (1 - x334)*0 + 0 =e= 0 ;
c2112.. x796 - x798 - (1 - x334)*0 + 0 =e= 0 ;
c2113_hi.. (-10)*x334 - x787 =l= 0 ;
c2114_hi.. x787 + (-10)*x334 =l= 0 ;
c2115_hi.. x334 - x789 =l= 0 ;
c2116_hi.. x789 + (-10)*x334 =l= 0 ;
c2117_hi.. x791 + (-10)*x334 =l= 0 ;
c2118_hi.. x793 + (-10)*x334 =l= 0 ;
c2119_hi.. (-10)*x334 - x794 =l= 0 ;
c2120_hi.. x794 + (-10)*x334 =l= 0 ;
c2121_hi.. x796 + (-10)*x334 =l= 0 ;
c2122_hi.. x798 + (-10)*x334 =l= 0 ;
c2123_hi.. (-10)*x1115 + 0 =l= 0 ;
c2124_hi.. 0 + (-10)*x1115 =l= 0 ;
c2125_hi.. (-10)*x1115 + 0 =l= 0 ;
c2126_hi.. 0 + (-10)*x1115 =l= 0 ;
c2127_hi.. 0 + (-10)*x1115 =l= 0 ;
c2128_hi.. 0 + (-10)*x1115 =l= 0 ;
c2129_hi.. 0 + (-10)*x1115 =l= 0 ;
c2130_hi.. 0 + (-9)*x1115 =l= 0 ;
c2131.. (0.9999*x336 + 0.0001)*(x802/(0.9999*x336 + 0.0001)*(x804/(0.9999*x336 + 0.0001))*(x804/(0.9999*x336 + 0.0001)) + 2*(x806/(0.9999*x336 + 0.0001))*(x808/(0.9999*x336 + 0.0001))) - 0*(1 - x336) + 0 =e= 0 ;
c2132.. x809 + x802 - (1 - x336)*0 + 0 =e= 0 ;
c2133.. x811 - x813 - (1 - x336)*0 + 0 =e= 0 ;
c2134_hi.. (-10)*x336 - x802 =l= 0 ;
c2135_hi.. x802 + (-10)*x336 =l= 0 ;
c2136_hi.. x336 - x804 =l= 0 ;
c2137_hi.. x804 + (-10)*x336 =l= 0 ;
c2138_hi.. x806 + (-10)*x336 =l= 0 ;
c2139_hi.. x808 + (-10)*x336 =l= 0 ;
c2140_hi.. (-10)*x336 - x809 =l= 0 ;
c2141_hi.. x809 + (-10)*x336 =l= 0 ;
c2142_hi.. x811 + (-10)*x336 =l= 0 ;
c2143_hi.. x813 + (-10)*x336 =l= 0 ;
c2144_hi.. (-10)*x1116 + 0 =l= 0 ;
c2145_hi.. 0 + (-10)*x1116 =l= 0 ;
c2146_hi.. (-10)*x1116 + 0 =l= 0 ;
c2147_hi.. 0 + (-10)*x1116 =l= 0 ;
c2148_hi.. 0 + (-10)*x1116 =l= 0 ;
c2149_hi.. 0 + (-10)*x1116 =l= 0 ;
c2150_hi.. 0 + (-10)*x1116 =l= 0 ;
c2151_hi.. 0 + (-9)*x1116 =l= 0 ;
c2152.. x817 - x819 - (1 - x277)*0 + 0 =e= 0 ;
c2153.. x820 - x822 - (1 - x277)*0 + 0 =e= 0 ;
c2154.. x823 - x825 - (1 - x277)*0 + 0 =e= 0 ;
c2155_hi.. x817 + (-10)*x277 =l= 0 ;
c2156_hi.. x819 + (-10)*x277 =l= 0 ;
c2157_hi.. x820 + (-10)*x277 =l= 0 ;
c2158_hi.. x822 + (-10)*x277 =l= 0 ;
c2159_hi.. x823 + (-9)*x277 =l= 0 ;
c2160_hi.. x825 + (-10)*x277 =l= 0 ;
c2161_hi.. 0 + (-10)*x1117 =l= 0 ;
c2162_hi.. 0 + (-10)*x1117 =l= 0 ;
c2163_hi.. 0 + (-9)*x1117 =l= 0 ;
c2164.. x826 - x828 - (1 - x279)*0 + 0 =e= 0 ;
c2165.. x829 - x831 - (1 - x279)*0 + 0 =e= 0 ;
c2166.. x832 - x834 - (1 - x279)*0 + 0 =e= 0 ;
c2167_hi.. x826 + (-10)*x279 =l= 0 ;
c2168_hi.. x828 + (-10)*x279 =l= 0 ;
c2169_hi.. x829 + (-10)*x279 =l= 0 ;
c2170_hi.. x831 + (-10)*x279 =l= 0 ;
c2171_hi.. x832 + (-9)*x279 =l= 0 ;
c2172_hi.. x834 + (-10)*x279 =l= 0 ;
c2173_hi.. 0 + (-10)*x1118 =l= 0 ;
c2174_hi.. 0 + (-10)*x1118 =l= 0 ;
c2175_hi.. 0 + (-9)*x1118 =l= 0 ;
c2176.. x835 - x837 - (1 - x281)*0 + 0 =e= 0 ;
c2177.. x838 - x840 - (1 - x281)*0 + 0 =e= 0 ;
c2178.. x841 - x843 - (1 - x281)*0 + 0 =e= 0 ;
c2179_hi.. x835 + (-10)*x281 =l= 0 ;
c2180_hi.. x837 + (-10)*x281 =l= 0 ;
c2181_hi.. x838 + (-10)*x281 =l= 0 ;
c2182_hi.. x840 + (-10)*x281 =l= 0 ;
c2183_hi.. x841 + (-9)*x281 =l= 0 ;
c2184_hi.. x843 + (-10)*x281 =l= 0 ;
c2185_hi.. 0 + (-10)*x1119 =l= 0 ;
c2186_hi.. 0 + (-10)*x1119 =l= 0 ;
c2187_hi.. 0 + (-9)*x1119 =l= 0 ;
c2188.. x844 - x846 - (1 - x283)*0 + 0 =e= 0 ;
c2189.. x847 - x849 - (1 - x283)*0 + 0 =e= 0 ;
c2190.. x850 - x852 - (1 - x283)*0 + 0 =e= 0 ;
c2191_hi.. x844 + (-10)*x283 =l= 0 ;
c2192_hi.. x846 + (-10)*x283 =l= 0 ;
c2193_hi.. x847 + (-10)*x283 =l= 0 ;
c2194_hi.. x849 + (-10)*x283 =l= 0 ;
c2195_hi.. x850 + (-9)*x283 =l= 0 ;
c2196_hi.. x852 + (-10)*x283 =l= 0 ;
c2197_hi.. 0 + (-10)*x1120 =l= 0 ;
c2198_hi.. 0 + (-10)*x1120 =l= 0 ;
c2199_hi.. 0 + (-9)*x1120 =l= 0 ;
c2200.. x853 - x855 - (1 - x285)*0 + 0 =e= 0 ;
c2201.. x856 - x858 - (1 - x285)*0 + 0 =e= 0 ;
c2202.. x859 - x861 - (1 - x285)*0 + 0 =e= 0 ;
c2203_hi.. x853 + (-10)*x285 =l= 0 ;
c2204_hi.. x855 + (-10)*x285 =l= 0 ;
c2205_hi.. x856 + (-10)*x285 =l= 0 ;
c2206_hi.. x858 + (-10)*x285 =l= 0 ;
c2207_hi.. x859 + (-9)*x285 =l= 0 ;
c2208_hi.. x861 + (-10)*x285 =l= 0 ;
c2209_hi.. 0 + (-10)*x1121 =l= 0 ;
c2210_hi.. 0 + (-10)*x1121 =l= 0 ;
c2211_hi.. 0 + (-9)*x1121 =l= 0 ;
c2212.. x862 - x864 - (1 - x287)*0 + 0 =e= 0 ;
c2213.. x865 - x867 - (1 - x287)*0 + 0 =e= 0 ;
c2214.. x868 - x870 - (1 - x287)*0 + 0 =e= 0 ;
c2215_hi.. x862 + (-10)*x287 =l= 0 ;
c2216_hi.. x864 + (-10)*x287 =l= 0 ;
c2217_hi.. x865 + (-10)*x287 =l= 0 ;
c2218_hi.. x867 + (-10)*x287 =l= 0 ;
c2219_hi.. x868 + (-9)*x287 =l= 0 ;
c2220_hi.. x870 + (-10)*x287 =l= 0 ;
c2221_hi.. 0 + (-10)*x1122 =l= 0 ;
c2222_hi.. 0 + (-10)*x1122 =l= 0 ;
c2223_hi.. 0 + (-9)*x1122 =l= 0 ;
c2224.. x871 - x873 - (1 - x289)*0 + 0 =e= 0 ;
c2225.. x874 - x876 - (1 - x289)*0 + 0 =e= 0 ;
c2226.. x877 - x879 - (1 - x289)*0 + 0 =e= 0 ;
c2227_hi.. x871 + (-10)*x289 =l= 0 ;
c2228_hi.. x873 + (-10)*x289 =l= 0 ;
c2229_hi.. x874 + (-10)*x289 =l= 0 ;
c2230_hi.. x876 + (-10)*x289 =l= 0 ;
c2231_hi.. x877 + (-9)*x289 =l= 0 ;
c2232_hi.. x879 + (-10)*x289 =l= 0 ;
c2233_hi.. 0 + (-10)*x1123 =l= 0 ;
c2234_hi.. 0 + (-10)*x1123 =l= 0 ;
c2235_hi.. 0 + (-9)*x1123 =l= 0 ;
c2236.. x880 - x882 - (1 - x291)*0 + 0 =e= 0 ;
c2237.. x883 - x885 - (1 - x291)*0 + 0 =e= 0 ;
c2238.. x886 - x888 - (1 - x291)*0 + 0 =e= 0 ;
c2239_hi.. x880 + (-10)*x291 =l= 0 ;
c2240_hi.. x882 + (-10)*x291 =l= 0 ;
c2241_hi.. x883 + (-10)*x291 =l= 0 ;
c2242_hi.. x885 + (-10)*x291 =l= 0 ;
c2243_hi.. x886 + (-9)*x291 =l= 0 ;
c2244_hi.. x888 + (-10)*x291 =l= 0 ;
c2245_hi.. 0 + (-10)*x1124 =l= 0 ;
c2246_hi.. 0 + (-10)*x1124 =l= 0 ;
c2247_hi.. 0 + (-9)*x1124 =l= 0 ;
c2248.. x889 - x891 - (1 - x293)*0 + 0 =e= 0 ;
c2249.. x892 - x894 - (1 - x293)*0 + 0 =e= 0 ;
c2250.. x895 - x897 - (1 - x293)*0 + 0 =e= 0 ;
c2251_hi.. x889 + (-10)*x293 =l= 0 ;
c2252_hi.. x891 + (-10)*x293 =l= 0 ;
c2253_hi.. x892 + (-10)*x293 =l= 0 ;
c2254_hi.. x894 + (-10)*x293 =l= 0 ;
c2255_hi.. x895 + (-9)*x293 =l= 0 ;
c2256_hi.. x897 + (-10)*x293 =l= 0 ;
c2257_hi.. 0 + (-10)*x1125 =l= 0 ;
c2258_hi.. 0 + (-10)*x1125 =l= 0 ;
c2259_hi.. 0 + (-9)*x1125 =l= 0 ;
c2260.. x898 - x900 - (1 - x295)*0 + 0 =e= 0 ;
c2261.. x901 - x903 - (1 - x295)*0 + 0 =e= 0 ;
c2262.. x904 - x906 - (1 - x295)*0 + 0 =e= 0 ;
c2263_hi.. x898 + (-10)*x295 =l= 0 ;
c2264_hi.. x900 + (-10)*x295 =l= 0 ;
c2265_hi.. x901 + (-10)*x295 =l= 0 ;
c2266_hi.. x903 + (-10)*x295 =l= 0 ;
c2267_hi.. x904 + (-9)*x295 =l= 0 ;
c2268_hi.. x906 + (-10)*x295 =l= 0 ;
c2269_hi.. 0 + (-10)*x1126 =l= 0 ;
c2270_hi.. 0 + (-10)*x1126 =l= 0 ;
c2271_hi.. 0 + (-9)*x1126 =l= 0 ;
c2272.. x907 - x909 - (1 - x297)*0 + 0 =e= 0 ;
c2273.. x910 - x912 - (1 - x297)*0 + 0 =e= 0 ;
c2274.. x913 - x915 - (1 - x297)*0 + 0 =e= 0 ;
c2275_hi.. x907 + (-10)*x297 =l= 0 ;
c2276_hi.. x909 + (-10)*x297 =l= 0 ;
c2277_hi.. x910 + (-10)*x297 =l= 0 ;
c2278_hi.. x912 + (-10)*x297 =l= 0 ;
c2279_hi.. x913 + (-9)*x297 =l= 0 ;
c2280_hi.. x915 + (-10)*x297 =l= 0 ;
c2281_hi.. 0 + (-10)*x1127 =l= 0 ;
c2282_hi.. 0 + (-10)*x1127 =l= 0 ;
c2283_hi.. 0 + (-9)*x1127 =l= 0 ;
c2284.. x916 - x918 - (1 - x299)*0 + 0 =e= 0 ;
c2285.. x919 - x921 - (1 - x299)*0 + 0 =e= 0 ;
c2286.. x922 - x924 - (1 - x299)*0 + 0 =e= 0 ;
c2287_hi.. x916 + (-10)*x299 =l= 0 ;
c2288_hi.. x918 + (-10)*x299 =l= 0 ;
c2289_hi.. x919 + (-10)*x299 =l= 0 ;
c2290_hi.. x921 + (-10)*x299 =l= 0 ;
c2291_hi.. x922 + (-9)*x299 =l= 0 ;
c2292_hi.. x924 + (-10)*x299 =l= 0 ;
c2293_hi.. 0 + (-10)*x1128 =l= 0 ;
c2294_hi.. 0 + (-10)*x1128 =l= 0 ;
c2295_hi.. 0 + (-9)*x1128 =l= 0 ;
c2296.. x925 - x927 - (1 - x301)*0 + 0 =e= 0 ;
c2297.. x928 - x930 - (1 - x301)*0 + 0 =e= 0 ;
c2298.. x931 - x933 - (1 - x301)*0 + 0 =e= 0 ;
c2299_hi.. x925 + (-10)*x301 =l= 0 ;
c2300_hi.. x927 + (-10)*x301 =l= 0 ;
c2301_hi.. x928 + (-10)*x301 =l= 0 ;
c2302_hi.. x930 + (-10)*x301 =l= 0 ;
c2303_hi.. x931 + (-9)*x301 =l= 0 ;
c2304_hi.. x933 + (-10)*x301 =l= 0 ;
c2305_hi.. 0 + (-10)*x1129 =l= 0 ;
c2306_hi.. 0 + (-10)*x1129 =l= 0 ;
c2307_hi.. 0 + (-9)*x1129 =l= 0 ;
c2308.. x934 - x936 - (1 - x303)*0 + 0 =e= 0 ;
c2309.. x937 - x939 - (1 - x303)*0 + 0 =e= 0 ;
c2310.. x940 - x942 - (1 - x303)*0 + 0 =e= 0 ;
c2311_hi.. x934 + (-10)*x303 =l= 0 ;
c2312_hi.. x936 + (-10)*x303 =l= 0 ;
c2313_hi.. x937 + (-10)*x303 =l= 0 ;
c2314_hi.. x939 + (-10)*x303 =l= 0 ;
c2315_hi.. x940 + (-9)*x303 =l= 0 ;
c2316_hi.. x942 + (-10)*x303 =l= 0 ;
c2317_hi.. 0 + (-10)*x1130 =l= 0 ;
c2318_hi.. 0 + (-10)*x1130 =l= 0 ;
c2319_hi.. 0 + (-9)*x1130 =l= 0 ;
c2320.. x943 - x945 - (1 - x305)*0 + 0 =e= 0 ;
c2321.. x946 - x948 - (1 - x305)*0 + 0 =e= 0 ;
c2322.. x949 - x951 - (1 - x305)*0 + 0 =e= 0 ;
c2323_hi.. x943 + (-10)*x305 =l= 0 ;
c2324_hi.. x945 + (-10)*x305 =l= 0 ;
c2325_hi.. x946 + (-10)*x305 =l= 0 ;
c2326_hi.. x948 + (-10)*x305 =l= 0 ;
c2327_hi.. x949 + (-9)*x305 =l= 0 ;
c2328_hi.. x951 + (-10)*x305 =l= 0 ;
c2329_hi.. 0 + (-10)*x1131 =l= 0 ;
c2330_hi.. 0 + (-10)*x1131 =l= 0 ;
c2331_hi.. 0 + (-9)*x1131 =l= 0 ;
c2332.. x952 - x954 - (1 - x307)*0 + 0 =e= 0 ;
c2333.. x955 - x957 - (1 - x307)*0 + 0 =e= 0 ;
c2334.. x958 - x960 - (1 - x307)*0 + 0 =e= 0 ;
c2335_hi.. x952 + (-10)*x307 =l= 0 ;
c2336_hi.. x954 + (-10)*x307 =l= 0 ;
c2337_hi.. x955 + (-10)*x307 =l= 0 ;
c2338_hi.. x957 + (-10)*x307 =l= 0 ;
c2339_hi.. x958 + (-9)*x307 =l= 0 ;
c2340_hi.. x960 + (-10)*x307 =l= 0 ;
c2341_hi.. 0 + (-10)*x1132 =l= 0 ;
c2342_hi.. 0 + (-10)*x1132 =l= 0 ;
c2343_hi.. 0 + (-9)*x1132 =l= 0 ;
c2344.. x961 - x963 - (1 - x309)*0 + 0 =e= 0 ;
c2345.. x964 - x966 - (1 - x309)*0 + 0 =e= 0 ;
c2346.. x967 - x969 - (1 - x309)*0 + 0 =e= 0 ;
c2347_hi.. x961 + (-10)*x309 =l= 0 ;
c2348_hi.. x963 + (-10)*x309 =l= 0 ;
c2349_hi.. x964 + (-10)*x309 =l= 0 ;
c2350_hi.. x966 + (-10)*x309 =l= 0 ;
c2351_hi.. x967 + (-9)*x309 =l= 0 ;
c2352_hi.. x969 + (-10)*x309 =l= 0 ;
c2353_hi.. 0 + (-10)*x1133 =l= 0 ;
c2354_hi.. 0 + (-10)*x1133 =l= 0 ;
c2355_hi.. 0 + (-9)*x1133 =l= 0 ;
c2356.. x970 - x972 - (1 - x311)*0 + 0 =e= 0 ;
c2357.. x973 - x975 - (1 - x311)*0 + 0 =e= 0 ;
c2358.. x976 - x978 - (1 - x311)*0 + 0 =e= 0 ;
c2359_hi.. x970 + (-10)*x311 =l= 0 ;
c2360_hi.. x972 + (-10)*x311 =l= 0 ;
c2361_hi.. x973 + (-10)*x311 =l= 0 ;
c2362_hi.. x975 + (-10)*x311 =l= 0 ;
c2363_hi.. x976 + (-9)*x311 =l= 0 ;
c2364_hi.. x978 + (-10)*x311 =l= 0 ;
c2365_hi.. 0 + (-10)*x1134 =l= 0 ;
c2366_hi.. 0 + (-10)*x1134 =l= 0 ;
c2367_hi.. 0 + (-9)*x1134 =l= 0 ;
c2368.. x979 - x981 - (1 - x313)*0 + 0 =e= 0 ;
c2369.. x982 - x984 - (1 - x313)*0 + 0 =e= 0 ;
c2370.. x985 - x987 - (1 - x313)*0 + 0 =e= 0 ;
c2371_hi.. x979 + (-10)*x313 =l= 0 ;
c2372_hi.. x981 + (-10)*x313 =l= 0 ;
c2373_hi.. x982 + (-10)*x313 =l= 0 ;
c2374_hi.. x984 + (-10)*x313 =l= 0 ;
c2375_hi.. x985 + (-9)*x313 =l= 0 ;
c2376_hi.. x987 + (-10)*x313 =l= 0 ;
c2377_hi.. 0 + (-10)*x1135 =l= 0 ;
c2378_hi.. 0 + (-10)*x1135 =l= 0 ;
c2379_hi.. 0 + (-9)*x1135 =l= 0 ;
c2380.. x988 - x990 - (1 - x315)*0 + 0 =e= 0 ;
c2381.. x991 - x993 - (1 - x315)*0 + 0 =e= 0 ;
c2382.. x994 - x996 - (1 - x315)*0 + 0 =e= 0 ;
c2383_hi.. x988 + (-10)*x315 =l= 0 ;
c2384_hi.. x990 + (-10)*x315 =l= 0 ;
c2385_hi.. x991 + (-10)*x315 =l= 0 ;
c2386_hi.. x993 + (-10)*x315 =l= 0 ;
c2387_hi.. x994 + (-9)*x315 =l= 0 ;
c2388_hi.. x996 + (-10)*x315 =l= 0 ;
c2389_hi.. 0 + (-10)*x1136 =l= 0 ;
c2390_hi.. 0 + (-10)*x1136 =l= 0 ;
c2391_hi.. 0 + (-9)*x1136 =l= 0 ;
c2392.. x997 - x999 - (1 - x317)*0 + 0 =e= 0 ;
c2393.. x1000 - x1002 - (1 - x317)*0 + 0 =e= 0 ;
c2394.. x1003 - x1005 - (1 - x317)*0 + 0 =e= 0 ;
c2395_hi.. x997 + (-10)*x317 =l= 0 ;
c2396_hi.. x999 + (-10)*x317 =l= 0 ;
c2397_hi.. x1000 + (-10)*x317 =l= 0 ;
c2398_hi.. x1002 + (-10)*x317 =l= 0 ;
c2399_hi.. x1003 + (-9)*x317 =l= 0 ;
c2400_hi.. x1005 + (-10)*x317 =l= 0 ;
c2401_hi.. 0 + (-10)*x1137 =l= 0 ;
c2402_hi.. 0 + (-10)*x1137 =l= 0 ;
c2403_hi.. 0 + (-9)*x1137 =l= 0 ;
c2404.. x1006 - x1008 - (1 - x319)*0 + 0 =e= 0 ;
c2405.. x1009 - x1011 - (1 - x319)*0 + 0 =e= 0 ;
c2406.. x1012 - x1014 - (1 - x319)*0 + 0 =e= 0 ;
c2407_hi.. x1006 + (-10)*x319 =l= 0 ;
c2408_hi.. x1008 + (-10)*x319 =l= 0 ;
c2409_hi.. x1009 + (-10)*x319 =l= 0 ;
c2410_hi.. x1011 + (-10)*x319 =l= 0 ;
c2411_hi.. x1012 + (-9)*x319 =l= 0 ;
c2412_hi.. x1014 + (-10)*x319 =l= 0 ;
c2413_hi.. 0 + (-10)*x1138 =l= 0 ;
c2414_hi.. 0 + (-10)*x1138 =l= 0 ;
c2415_hi.. 0 + (-9)*x1138 =l= 0 ;
c2416.. x1015 - x1017 - (1 - x321)*0 + 0 =e= 0 ;
c2417.. x1018 - x1020 - (1 - x321)*0 + 0 =e= 0 ;
c2418.. x1021 - x1023 - (1 - x321)*0 + 0 =e= 0 ;
c2419_hi.. x1015 + (-10)*x321 =l= 0 ;
c2420_hi.. x1017 + (-10)*x321 =l= 0 ;
c2421_hi.. x1018 + (-10)*x321 =l= 0 ;
c2422_hi.. x1020 + (-10)*x321 =l= 0 ;
c2423_hi.. x1021 + (-9)*x321 =l= 0 ;
c2424_hi.. x1023 + (-10)*x321 =l= 0 ;
c2425_hi.. 0 + (-10)*x1139 =l= 0 ;
c2426_hi.. 0 + (-10)*x1139 =l= 0 ;
c2427_hi.. 0 + (-9)*x1139 =l= 0 ;
c2428.. x1024 - x1026 - (1 - x323)*0 + 0 =e= 0 ;
c2429.. x1027 - x1029 - (1 - x323)*0 + 0 =e= 0 ;
c2430.. x1030 - x1032 - (1 - x323)*0 + 0 =e= 0 ;
c2431_hi.. x1024 + (-10)*x323 =l= 0 ;
c2432_hi.. x1026 + (-10)*x323 =l= 0 ;
c2433_hi.. x1027 + (-10)*x323 =l= 0 ;
c2434_hi.. x1029 + (-10)*x323 =l= 0 ;
c2435_hi.. x1030 + (-9)*x323 =l= 0 ;
c2436_hi.. x1032 + (-10)*x323 =l= 0 ;
c2437_hi.. 0 + (-10)*x1140 =l= 0 ;
c2438_hi.. 0 + (-10)*x1140 =l= 0 ;
c2439_hi.. 0 + (-9)*x1140 =l= 0 ;
c2440.. x1033 - x1035 - (1 - x325)*0 + 0 =e= 0 ;
c2441.. x1036 - x1038 - (1 - x325)*0 + 0 =e= 0 ;
c2442.. x1039 - x1041 - (1 - x325)*0 + 0 =e= 0 ;
c2443_hi.. x1033 + (-10)*x325 =l= 0 ;
c2444_hi.. x1035 + (-10)*x325 =l= 0 ;
c2445_hi.. x1036 + (-10)*x325 =l= 0 ;
c2446_hi.. x1038 + (-10)*x325 =l= 0 ;
c2447_hi.. x1039 + (-9)*x325 =l= 0 ;
c2448_hi.. x1041 + (-10)*x325 =l= 0 ;
c2449_hi.. 0 + (-10)*x1141 =l= 0 ;
c2450_hi.. 0 + (-10)*x1141 =l= 0 ;
c2451_hi.. 0 + (-9)*x1141 =l= 0 ;
c2452.. x1042 - x1044 - (1 - x327)*0 + 0 =e= 0 ;
c2453.. x1045 - x1047 - (1 - x327)*0 + 0 =e= 0 ;
c2454.. x1048 - x1050 - (1 - x327)*0 + 0 =e= 0 ;
c2455_hi.. x1042 + (-10)*x327 =l= 0 ;
c2456_hi.. x1044 + (-10)*x327 =l= 0 ;
c2457_hi.. x1045 + (-10)*x327 =l= 0 ;
c2458_hi.. x1047 + (-10)*x327 =l= 0 ;
c2459_hi.. x1048 + (-9)*x327 =l= 0 ;
c2460_hi.. x1050 + (-10)*x327 =l= 0 ;
c2461_hi.. 0 + (-10)*x1142 =l= 0 ;
c2462_hi.. 0 + (-10)*x1142 =l= 0 ;
c2463_hi.. 0 + (-9)*x1142 =l= 0 ;
c2464.. x1051 - x1053 - (1 - x329)*0 + 0 =e= 0 ;
c2465.. x1054 - x1056 - (1 - x329)*0 + 0 =e= 0 ;
c2466.. x1057 - x1059 - (1 - x329)*0 + 0 =e= 0 ;
c2467_hi.. x1051 + (-10)*x329 =l= 0 ;
c2468_hi.. x1053 + (-10)*x329 =l= 0 ;
c2469_hi.. x1054 + (-10)*x329 =l= 0 ;
c2470_hi.. x1056 + (-10)*x329 =l= 0 ;
c2471_hi.. x1057 + (-9)*x329 =l= 0 ;
c2472_hi.. x1059 + (-10)*x329 =l= 0 ;
c2473_hi.. 0 + (-10)*x1143 =l= 0 ;
c2474_hi.. 0 + (-10)*x1143 =l= 0 ;
c2475_hi.. 0 + (-9)*x1143 =l= 0 ;
c2476.. x1060 - x1062 - (1 - x331)*0 + 0 =e= 0 ;
c2477.. x1063 - x1065 - (1 - x331)*0 + 0 =e= 0 ;
c2478.. x1066 - x1068 - (1 - x331)*0 + 0 =e= 0 ;
c2479_hi.. x1060 + (-10)*x331 =l= 0 ;
c2480_hi.. x1062 + (-10)*x331 =l= 0 ;
c2481_hi.. x1063 + (-10)*x331 =l= 0 ;
c2482_hi.. x1065 + (-10)*x331 =l= 0 ;
c2483_hi.. x1066 + (-9)*x331 =l= 0 ;
c2484_hi.. x1068 + (-10)*x331 =l= 0 ;
c2485_hi.. 0 + (-10)*x1144 =l= 0 ;
c2486_hi.. 0 + (-10)*x1144 =l= 0 ;
c2487_hi.. 0 + (-9)*x1144 =l= 0 ;
c2488.. x1069 - x1071 - (1 - x333)*0 + 0 =e= 0 ;
c2489.. x1072 - x1074 - (1 - x333)*0 + 0 =e= 0 ;
c2490.. x1075 - x1077 - (1 - x333)*0 + 0 =e= 0 ;
c2491_hi.. x1069 + (-10)*x333 =l= 0 ;
c2492_hi.. x1071 + (-10)*x333 =l= 0 ;
c2493_hi.. x1072 + (-10)*x333 =l= 0 ;
c2494_hi.. x1074 + (-10)*x333 =l= 0 ;
c2495_hi.. x1075 + (-9)*x333 =l= 0 ;
c2496_hi.. x1077 + (-10)*x333 =l= 0 ;
c2497_hi.. 0 + (-10)*x1145 =l= 0 ;
c2498_hi.. 0 + (-10)*x1145 =l= 0 ;
c2499_hi.. 0 + (-9)*x1145 =l= 0 ;
c2500.. x1078 - x1080 - (1 - x335)*0 + 0 =e= 0 ;
c2501.. x1081 - x1083 - (1 - x335)*0 + 0 =e= 0 ;
c2502.. x1084 - x1086 - (1 - x335)*0 + 0 =e= 0 ;
c2503_hi.. x1078 + (-10)*x335 =l= 0 ;
c2504_hi.. x1080 + (-10)*x335 =l= 0 ;
c2505_hi.. x1081 + (-10)*x335 =l= 0 ;
c2506_hi.. x1083 + (-10)*x335 =l= 0 ;
c2507_hi.. x1084 + (-9)*x335 =l= 0 ;
c2508_hi.. x1086 + (-10)*x335 =l= 0 ;
c2509_hi.. 0 + (-10)*x1146 =l= 0 ;
c2510_hi.. 0 + (-10)*x1146 =l= 0 ;
c2511_hi.. 0 + (-9)*x1146 =l= 0 ;
c2512.. GAMS_OBJECTIVE =e= x375 + x390 + x405 + x420 + x435 + x450 + x465 + x480 + x495 + x510 + x525 + x540 + x555 + x570 + x585 + x600 + x615 + x630 + x645 + x660 + x675 + x690 + x705 + x720 + x735 + x750 + x765 + x780 + x795 + x810 ;

x1.up = 10;
x1.l = 0;
x2.up = 10;
x2.l = 0;
x4.up = 10;
x4.l = 0;
x5.up = 10;
x5.l = 0;
x6.up = 10;
x6.l = 0;
x8.up = 9;
x8.l = 0;
x10.up = 10;
x10.l = 0;
x11.up = 10;
x11.l = 0;
x12.up = 10;
x12.l = 0;
x14.up = 10;
x14.l = 0;
x15.up = 10;
x15.l = 0;
x16.up = 10;
x16.l = 0;
x18.up = 10;
x18.l = 0;
x19.up = 10;
x19.l = 0;
x20.up = 10;
x20.l = 0;
x22.up = 10;
x22.l = 0;
x23.up = 10;
x23.l = 0;
x24.up = 10;
x24.l = 0;
x26.up = 10;
x26.l = 0;
x27.up = 10;
x27.l = 0;
x28.up = 10;
x28.l = 0;
x30.up = 10;
x30.l = 0;
x31.up = 10;
x31.l = 0;
x32.up = 10;
x32.l = 0;
x34.up = 10;
x34.l = 0;
x35.up = 10;
x35.l = 0;
x36.up = 10;
x36.l = 0;
x38.up = 10;
x38.l = 0;
x39.up = 10;
x39.l = 0;
x40.up = 10;
x40.l = 0;
x42.up = 10;
x42.l = 0;
x43.up = 10;
x43.l = 0;
x44.up = 10;
x44.l = 0;
x46.up = 10;
x46.l = 0;
x47.up = 10;
x47.l = 0;
x48.up = 10;
x48.l = 0;
x50.up = 10;
x50.l = 0;
x51.up = 10;
x51.l = 0;
x52.up = 10;
x52.l = 0;
x54.up = 10;
x54.l = 0;
x55.up = 10;
x55.l = 0;
x56.up = 10;
x56.l = 0;
x58.up = 10;
x58.l = 0;
x59.up = 10;
x59.l = 0;
x60.up = 10;
x60.l = 0;
x62.up = 10;
x62.l = 0;
x63.up = 10;
x63.l = 0;
x64.up = 10;
x64.l = 0;
x66.up = 10;
x66.l = 0;
x67.up = 10;
x67.l = 0;
x68.up = 10;
x68.l = 0;
x70.up = 10;
x70.l = 0;
x71.up = 10;
x71.l = 0;
x72.up = 10;
x72.l = 0;
x74.up = 10;
x74.l = 0;
x75.up = 10;
x75.l = 0;
x76.up = 10;
x76.l = 0;
x78.up = 10;
x78.l = 0;
x79.up = 10;
x79.l = 0;
x80.up = 10;
x80.l = 0;
x82.up = 10;
x82.l = 0;
x83.up = 10;
x83.l = 0;
x84.up = 10;
x84.l = 0;
x86.up = 10;
x86.l = 0;
x87.up = 10;
x87.l = 0;
x88.up = 10;
x88.l = 0;
x90.up = 10;
x90.l = 0;
x91.up = 10;
x91.l = 0;
x92.up = 10;
x92.l = 0;
x94.up = 10;
x94.l = 0;
x95.up = 10;
x95.l = 0;
x96.up = 10;
x96.l = 0;
x98.up = 10;
x98.l = 0;
x99.up = 10;
x99.l = 0;
x100.up = 10;
x100.l = 0;
x102.up = 10;
x102.l = 0;
x103.up = 10;
x103.l = 0;
x104.up = 10;
x104.l = 0;
x106.up = 10;
x106.l = 0;
x107.up = 10;
x107.l = 0;
x108.up = 10;
x108.l = 0;
x110.up = 10;
x110.l = 0;
x111.up = 10;
x111.l = 0;
x112.up = 10;
x112.l = 0;
x114.up = 10;
x114.l = 0;
x115.up = 10;
x115.l = 0;
x116.up = 10;
x116.l = 0;
x118.up = 10;
x118.l = 0;
x119.up = 10;
x119.l = 0;
x120.up = 10;
x120.l = 0;
x122.up = 10;
x122.l = 0;
x123.up = 10;
x123.l = 0;
x125.up = 10;
x125.l = 0;
x126.up = 10;
x126.l = 0;
x127.up = 10;
x127.l = 0;
x128.up = 10;
x128.l = 0;
x130.up = 10;
x130.l = 0;
x131.up = 10;
x131.l = 0;
x133.up = 10;
x133.l = 0;
x134.up = 10;
x134.l = 0;
x136.up = 10;
x136.l = 0;
x137.up = 10;
x137.l = 0;
x139.up = 10;
x139.l = 0;
x140.up = 10;
x140.l = 0;
x142.up = 10;
x142.l = 0;
x143.up = 10;
x143.l = 0;
x145.up = 10;
x145.l = 0;
x146.up = 10;
x146.l = 0;
x148.up = 10;
x148.l = 0;
x149.up = 10;
x149.l = 0;
x151.up = 10;
x151.l = 0;
x152.up = 10;
x152.l = 0;
x154.up = 10;
x154.l = 0;
x155.up = 10;
x155.l = 0;
x157.up = 10;
x157.l = 0;
x158.up = 10;
x158.l = 0;
x160.up = 10;
x160.l = 0;
x161.up = 10;
x161.l = 0;
x163.up = 10;
x163.l = 0;
x164.up = 10;
x164.l = 0;
x166.up = 10;
x166.l = 0;
x167.up = 10;
x167.l = 0;
x169.up = 10;
x169.l = 0;
x170.up = 10;
x170.l = 0;
x172.up = 10;
x172.l = 0;
x173.up = 10;
x173.l = 0;
x175.up = 10;
x175.l = 0;
x176.up = 10;
x176.l = 0;
x178.up = 10;
x178.l = 0;
x179.up = 10;
x179.l = 0;
x181.up = 10;
x181.l = 0;
x182.up = 10;
x182.l = 0;
x184.up = 10;
x184.l = 0;
x185.up = 10;
x185.l = 0;
x187.up = 10;
x187.l = 0;
x188.up = 10;
x188.l = 0;
x190.up = 10;
x190.l = 0;
x191.up = 10;
x191.l = 0;
x193.up = 10;
x193.l = 0;
x194.up = 10;
x194.l = 0;
x196.up = 10;
x196.l = 0;
x197.up = 10;
x197.l = 0;
x199.up = 10;
x199.l = 0;
x200.up = 10;
x200.l = 0;
x202.up = 10;
x202.l = 0;
x203.up = 10;
x203.l = 0;
x205.up = 10;
x205.l = 0;
x206.up = 10;
x206.l = 0;
x208.up = 10;
x208.l = 0;
x209.up = 10;
x209.l = 0;
x211.up = 10;
x211.l = 0;
x214.up = 9;
x214.l = 0;
x217.up = 9;
x217.l = 0;
x219.up = 9;
x219.l = 0;
x221.up = 9;
x221.l = 0;
x223.up = 9;
x223.l = 0;
x225.up = 9;
x225.l = 0;
x227.up = 9;
x227.l = 0;
x229.up = 9;
x229.l = 0;
x231.up = 9;
x231.l = 0;
x233.up = 9;
x233.l = 0;
x235.up = 9;
x235.l = 0;
x237.up = 9;
x237.l = 0;
x239.up = 9;
x239.l = 0;
x241.up = 9;
x241.l = 0;
x243.up = 9;
x243.l = 0;
x245.up = 9;
x245.l = 0;
x247.up = 9;
x247.l = 0;
x249.up = 9;
x249.l = 0;
x251.up = 9;
x251.l = 0;
x253.up = 9;
x253.l = 0;
x255.up = 9;
x255.l = 0;
x257.up = 9;
x257.l = 0;
x259.up = 9;
x259.l = 0;
x261.up = 9;
x261.l = 0;
x263.up = 9;
x263.l = 0;
x265.up = 9;
x265.l = 0;
x267.up = 9;
x267.l = 0;
x269.up = 9;
x269.l = 0;
x270.up = 9;
x270.l = 0;
x271.up = 10;
x271.l = 0;
x272.up = 10;
x272.l = 0;
x273.up = 9.5;
x273.l = 0;
x274.up = 10;
x274.l = 0;
x275.up = 10;
x275.l = 0;
x276.up = 10;
x276.l = 0;
x368.up = 10;
x369.up = 10;
x369.l = 0;
x370.up = 10;
x371.up = 10;
x371.l = 0;
x372.up = 10;
x373.up = 10;
x373.l = 0;
x375.up = 10;
x375.l = 0;
x376.up = 10;
x376.l = 0;
x377.up = 10;
x378.up = 10;
x378.l = 0;
x379.up = 10;
x380.up = 10;
x381.up = 9;
x383.up = 10;
x384.up = 10;
x384.l = 0;
x385.up = 10;
x386.up = 10;
x386.l = 0;
x387.up = 10;
x388.up = 10;
x388.l = 0;
x390.up = 10;
x390.l = 0;
x391.up = 10;
x391.l = 0;
x392.up = 10;
x393.up = 10;
x393.l = 0;
x394.up = 10;
x395.up = 10;
x396.up = 9;
x398.up = 10;
x399.up = 10;
x399.l = 0;
x400.up = 10;
x401.up = 10;
x401.l = 0;
x402.up = 10;
x403.up = 10;
x403.l = 0;
x405.up = 10;
x405.l = 0;
x406.up = 10;
x406.l = 0;
x407.up = 10;
x408.up = 10;
x408.l = 0;
x409.up = 10;
x410.up = 10;
x411.up = 9;
x413.up = 10;
x414.up = 10;
x414.l = 0;
x415.up = 10;
x416.up = 10;
x416.l = 0;
x417.up = 10;
x418.up = 10;
x418.l = 0;
x420.up = 10;
x420.l = 0;
x421.up = 10;
x421.l = 0;
x422.up = 10;
x423.up = 10;
x423.l = 0;
x424.up = 10;
x425.up = 10;
x426.up = 9;
x428.up = 10;
x429.up = 10;
x429.l = 0;
x430.up = 10;
x431.up = 10;
x431.l = 0;
x432.up = 10;
x433.up = 10;
x433.l = 0;
x435.up = 10;
x435.l = 0;
x436.up = 10;
x436.l = 0;
x437.up = 10;
x438.up = 10;
x438.l = 0;
x439.up = 10;
x440.up = 10;
x441.up = 9;
x443.up = 10;
x444.up = 10;
x444.l = 0;
x445.up = 10;
x446.up = 10;
x446.l = 0;
x447.up = 10;
x448.up = 10;
x448.l = 0;
x450.up = 10;
x450.l = 0;
x451.up = 10;
x451.l = 0;
x452.up = 10;
x453.up = 10;
x453.l = 0;
x454.up = 10;
x455.up = 10;
x456.up = 9;
x458.up = 10;
x459.up = 10;
x459.l = 0;
x460.up = 10;
x461.up = 10;
x461.l = 0;
x462.up = 10;
x463.up = 10;
x463.l = 0;
x465.up = 10;
x465.l = 0;
x466.up = 10;
x466.l = 0;
x467.up = 10;
x468.up = 10;
x468.l = 0;
x469.up = 10;
x470.up = 10;
x471.up = 9;
x473.up = 10;
x474.up = 10;
x474.l = 0;
x475.up = 10;
x476.up = 10;
x476.l = 0;
x477.up = 10;
x478.up = 10;
x478.l = 0;
x480.up = 10;
x480.l = 0;
x481.up = 10;
x481.l = 0;
x482.up = 10;
x483.up = 10;
x483.l = 0;
x484.up = 10;
x485.up = 10;
x486.up = 9;
x488.up = 10;
x489.up = 10;
x489.l = 0;
x490.up = 10;
x491.up = 10;
x491.l = 0;
x492.up = 10;
x493.up = 10;
x493.l = 0;
x495.up = 10;
x495.l = 0;
x496.up = 10;
x496.l = 0;
x497.up = 10;
x498.up = 10;
x498.l = 0;
x499.up = 10;
x500.up = 10;
x501.up = 9;
x503.up = 10;
x504.up = 10;
x504.l = 0;
x505.up = 10;
x506.up = 10;
x506.l = 0;
x507.up = 10;
x508.up = 10;
x508.l = 0;
x510.up = 10;
x510.l = 0;
x511.up = 10;
x511.l = 0;
x512.up = 10;
x513.up = 10;
x513.l = 0;
x514.up = 10;
x515.up = 10;
x516.up = 9;
x518.up = 10;
x519.up = 10;
x519.l = 0;
x520.up = 10;
x521.up = 10;
x521.l = 0;
x522.up = 10;
x523.up = 10;
x523.l = 0;
x525.up = 10;
x525.l = 0;
x526.up = 10;
x526.l = 0;
x527.up = 10;
x528.up = 10;
x528.l = 0;
x529.up = 10;
x530.up = 10;
x531.up = 9;
x533.up = 10;
x534.up = 10;
x534.l = 0;
x535.up = 10;
x536.up = 10;
x536.l = 0;
x537.up = 10;
x538.up = 10;
x538.l = 0;
x540.up = 10;
x540.l = 0;
x541.up = 10;
x541.l = 0;
x542.up = 10;
x543.up = 10;
x543.l = 0;
x544.up = 10;
x545.up = 10;
x546.up = 9;
x548.up = 10;
x549.up = 10;
x549.l = 0;
x550.up = 10;
x551.up = 10;
x551.l = 0;
x552.up = 10;
x553.up = 10;
x553.l = 0;
x555.up = 10;
x555.l = 0;
x556.up = 10;
x556.l = 0;
x557.up = 10;
x558.up = 10;
x558.l = 0;
x559.up = 10;
x560.up = 10;
x561.up = 9;
x563.up = 10;
x564.up = 10;
x564.l = 0;
x565.up = 10;
x566.up = 10;
x566.l = 0;
x567.up = 10;
x568.up = 10;
x568.l = 0;
x570.up = 10;
x570.l = 0;
x571.up = 10;
x571.l = 0;
x572.up = 10;
x573.up = 10;
x573.l = 0;
x574.up = 10;
x575.up = 10;
x576.up = 9;
x578.up = 10;
x579.up = 10;
x579.l = 0;
x580.up = 10;
x581.up = 10;
x581.l = 0;
x582.up = 10;
x583.up = 10;
x583.l = 0;
x585.up = 10;
x585.l = 0;
x586.up = 10;
x586.l = 0;
x587.up = 10;
x588.up = 10;
x588.l = 0;
x589.up = 10;
x590.up = 10;
x591.up = 9;
x593.up = 10;
x594.up = 10;
x594.l = 0;
x595.up = 10;
x596.up = 10;
x596.l = 0;
x597.up = 10;
x598.up = 10;
x598.l = 0;
x600.up = 10;
x600.l = 0;
x601.up = 10;
x601.l = 0;
x602.up = 10;
x603.up = 10;
x603.l = 0;
x604.up = 10;
x605.up = 10;
x606.up = 9;
x608.up = 10;
x609.up = 10;
x609.l = 0;
x610.up = 10;
x611.up = 10;
x611.l = 0;
x612.up = 10;
x613.up = 10;
x613.l = 0;
x615.up = 10;
x615.l = 0;
x616.up = 10;
x616.l = 0;
x617.up = 10;
x618.up = 10;
x618.l = 0;
x619.up = 10;
x620.up = 10;
x621.up = 9;
x623.up = 10;
x624.up = 10;
x624.l = 0;
x625.up = 10;
x626.up = 10;
x626.l = 0;
x627.up = 10;
x628.up = 10;
x628.l = 0;
x630.up = 10;
x630.l = 0;
x631.up = 10;
x631.l = 0;
x632.up = 10;
x633.up = 10;
x633.l = 0;
x634.up = 10;
x635.up = 10;
x636.up = 9;
x638.up = 10;
x639.up = 10;
x639.l = 0;
x640.up = 10;
x641.up = 10;
x641.l = 0;
x642.up = 10;
x643.up = 10;
x643.l = 0;
x645.up = 10;
x645.l = 0;
x646.up = 10;
x646.l = 0;
x647.up = 10;
x648.up = 10;
x648.l = 0;
x649.up = 10;
x650.up = 10;
x651.up = 9;
x653.up = 10;
x654.up = 10;
x654.l = 0;
x655.up = 10;
x656.up = 10;
x656.l = 0;
x657.up = 10;
x658.up = 10;
x658.l = 0;
x660.up = 10;
x660.l = 0;
x661.up = 10;
x661.l = 0;
x662.up = 10;
x663.up = 10;
x663.l = 0;
x664.up = 10;
x665.up = 10;
x666.up = 9;
x668.up = 10;
x669.up = 10;
x669.l = 0;
x670.up = 10;
x671.up = 10;
x671.l = 0;
x672.up = 10;
x673.up = 10;
x673.l = 0;
x675.up = 10;
x675.l = 0;
x676.up = 10;
x676.l = 0;
x677.up = 10;
x678.up = 10;
x678.l = 0;
x679.up = 10;
x680.up = 10;
x681.up = 9;
x683.up = 10;
x684.up = 10;
x684.l = 0;
x685.up = 10;
x686.up = 10;
x686.l = 0;
x687.up = 10;
x688.up = 10;
x688.l = 0;
x690.up = 10;
x690.l = 0;
x691.up = 10;
x691.l = 0;
x692.up = 10;
x693.up = 10;
x693.l = 0;
x694.up = 10;
x695.up = 10;
x696.up = 9;
x698.up = 10;
x699.up = 10;
x699.l = 0;
x700.up = 10;
x701.up = 10;
x701.l = 0;
x702.up = 10;
x703.up = 10;
x703.l = 0;
x705.up = 10;
x705.l = 0;
x706.up = 10;
x706.l = 0;
x707.up = 10;
x708.up = 10;
x708.l = 0;
x709.up = 10;
x710.up = 10;
x711.up = 9;
x713.up = 10;
x714.up = 10;
x714.l = 0;
x715.up = 10;
x716.up = 10;
x716.l = 0;
x717.up = 10;
x718.up = 10;
x718.l = 0;
x720.up = 10;
x720.l = 0;
x721.up = 10;
x721.l = 0;
x722.up = 10;
x723.up = 10;
x723.l = 0;
x724.up = 10;
x725.up = 10;
x726.up = 9;
x728.up = 10;
x729.up = 10;
x729.l = 0;
x730.up = 10;
x731.up = 10;
x731.l = 0;
x732.up = 10;
x733.up = 10;
x733.l = 0;
x735.up = 10;
x735.l = 0;
x736.up = 10;
x736.l = 0;
x737.up = 10;
x738.up = 10;
x738.l = 0;
x739.up = 10;
x740.up = 10;
x741.up = 9;
x743.up = 10;
x744.up = 10;
x744.l = 0;
x745.up = 10;
x746.up = 10;
x746.l = 0;
x747.up = 10;
x748.up = 10;
x748.l = 0;
x750.up = 10;
x750.l = 0;
x751.up = 10;
x751.l = 0;
x752.up = 10;
x753.up = 10;
x753.l = 0;
x754.up = 10;
x755.up = 10;
x756.up = 9;
x758.up = 10;
x759.up = 10;
x759.l = 0;
x760.up = 10;
x761.up = 10;
x761.l = 0;
x762.up = 10;
x763.up = 10;
x763.l = 0;
x765.up = 10;
x765.l = 0;
x766.up = 10;
x766.l = 0;
x767.up = 10;
x768.up = 10;
x768.l = 0;
x769.up = 10;
x770.up = 10;
x771.up = 9;
x773.up = 10;
x774.up = 10;
x774.l = 0;
x775.up = 10;
x776.up = 10;
x776.l = 0;
x777.up = 10;
x778.up = 10;
x778.l = 0;
x780.up = 10;
x780.l = 0;
x781.up = 10;
x781.l = 0;
x782.up = 10;
x783.up = 10;
x783.l = 0;
x784.up = 10;
x785.up = 10;
x786.up = 9;
x788.up = 10;
x789.up = 10;
x789.l = 0;
x790.up = 10;
x791.up = 10;
x791.l = 0;
x792.up = 10;
x793.up = 10;
x793.l = 0;
x795.up = 10;
x795.l = 0;
x796.up = 10;
x796.l = 0;
x797.up = 10;
x798.up = 10;
x798.l = 0;
x799.up = 10;
x800.up = 10;
x801.up = 9;
x803.up = 10;
x804.up = 10;
x804.l = 0;
x805.up = 10;
x806.up = 10;
x806.l = 0;
x807.up = 10;
x808.up = 10;
x808.l = 0;
x810.up = 10;
x810.l = 0;
x811.up = 10;
x811.l = 0;
x812.up = 10;
x813.up = 10;
x813.l = 0;
x814.up = 10;
x815.up = 10;
x816.up = 9;
x817.up = 10;
x817.l = 0;
x818.up = 10;
x819.up = 10;
x819.l = 0;
x820.up = 10;
x820.l = 0;
x821.up = 10;
x822.up = 10;
x822.l = 0;
x823.up = 9;
x823.l = 0;
x824.up = 10;
x825.up = 10;
x825.l = 0;
x826.up = 10;
x826.l = 0;
x827.up = 10;
x828.up = 10;
x828.l = 0;
x829.up = 10;
x829.l = 0;
x830.up = 10;
x831.up = 10;
x831.l = 0;
x832.up = 9;
x832.l = 0;
x833.up = 10;
x834.up = 10;
x834.l = 0;
x835.up = 10;
x835.l = 0;
x836.up = 10;
x837.up = 10;
x837.l = 0;
x838.up = 10;
x838.l = 0;
x839.up = 10;
x840.up = 10;
x840.l = 0;
x841.up = 9;
x841.l = 0;
x842.up = 10;
x843.up = 10;
x843.l = 0;
x844.up = 10;
x844.l = 0;
x845.up = 10;
x846.up = 10;
x846.l = 0;
x847.up = 10;
x847.l = 0;
x848.up = 10;
x849.up = 10;
x849.l = 0;
x850.up = 9;
x850.l = 0;
x851.up = 10;
x852.up = 10;
x852.l = 0;
x853.up = 10;
x853.l = 0;
x854.up = 10;
x855.up = 10;
x855.l = 0;
x856.up = 10;
x856.l = 0;
x857.up = 10;
x858.up = 10;
x858.l = 0;
x859.up = 9;
x859.l = 0;
x860.up = 10;
x861.up = 10;
x861.l = 0;
x862.up = 10;
x862.l = 0;
x863.up = 10;
x864.up = 10;
x864.l = 0;
x865.up = 10;
x865.l = 0;
x866.up = 10;
x867.up = 10;
x867.l = 0;
x868.up = 9;
x868.l = 0;
x869.up = 10;
x870.up = 10;
x870.l = 0;
x871.up = 10;
x871.l = 0;
x872.up = 10;
x873.up = 10;
x873.l = 0;
x874.up = 10;
x874.l = 0;
x875.up = 10;
x876.up = 10;
x876.l = 0;
x877.up = 9;
x877.l = 0;
x878.up = 10;
x879.up = 10;
x879.l = 0;
x880.up = 10;
x880.l = 0;
x881.up = 10;
x882.up = 10;
x882.l = 0;
x883.up = 10;
x883.l = 0;
x884.up = 10;
x885.up = 10;
x885.l = 0;
x886.up = 9;
x886.l = 0;
x887.up = 10;
x888.up = 10;
x888.l = 0;
x889.up = 10;
x889.l = 0;
x890.up = 10;
x891.up = 10;
x891.l = 0;
x892.up = 10;
x892.l = 0;
x893.up = 10;
x894.up = 10;
x894.l = 0;
x895.up = 9;
x895.l = 0;
x896.up = 10;
x897.up = 10;
x897.l = 0;
x898.up = 10;
x898.l = 0;
x899.up = 10;
x900.up = 10;
x900.l = 0;
x901.up = 10;
x901.l = 0;
x902.up = 10;
x903.up = 10;
x903.l = 0;
x904.up = 9;
x904.l = 0;
x905.up = 10;
x906.up = 10;
x906.l = 0;
x907.up = 10;
x907.l = 0;
x908.up = 10;
x909.up = 10;
x909.l = 0;
x910.up = 10;
x910.l = 0;
x911.up = 10;
x912.up = 10;
x912.l = 0;
x913.up = 9;
x913.l = 0;
x914.up = 10;
x915.up = 10;
x915.l = 0;
x916.up = 10;
x916.l = 0;
x917.up = 10;
x918.up = 10;
x918.l = 0;
x919.up = 10;
x919.l = 0;
x920.up = 10;
x921.up = 10;
x921.l = 0;
x922.up = 9;
x922.l = 0;
x923.up = 10;
x924.up = 10;
x924.l = 0;
x925.up = 10;
x925.l = 0;
x926.up = 10;
x927.up = 10;
x927.l = 0;
x928.up = 10;
x928.l = 0;
x929.up = 10;
x930.up = 10;
x930.l = 0;
x931.up = 9;
x931.l = 0;
x932.up = 10;
x933.up = 10;
x933.l = 0;
x934.up = 10;
x934.l = 0;
x935.up = 10;
x936.up = 10;
x936.l = 0;
x937.up = 10;
x937.l = 0;
x938.up = 10;
x939.up = 10;
x939.l = 0;
x940.up = 9;
x940.l = 0;
x941.up = 10;
x942.up = 10;
x942.l = 0;
x943.up = 10;
x943.l = 0;
x944.up = 10;
x945.up = 10;
x945.l = 0;
x946.up = 10;
x946.l = 0;
x947.up = 10;
x948.up = 10;
x948.l = 0;
x949.up = 9;
x949.l = 0;
x950.up = 10;
x951.up = 10;
x951.l = 0;
x952.up = 10;
x952.l = 0;
x953.up = 10;
x954.up = 10;
x954.l = 0;
x955.up = 10;
x955.l = 0;
x956.up = 10;
x957.up = 10;
x957.l = 0;
x958.up = 9;
x958.l = 0;
x959.up = 10;
x960.up = 10;
x960.l = 0;
x961.up = 10;
x961.l = 0;
x962.up = 10;
x963.up = 10;
x963.l = 0;
x964.up = 10;
x964.l = 0;
x965.up = 10;
x966.up = 10;
x966.l = 0;
x967.up = 9;
x967.l = 0;
x968.up = 10;
x969.up = 10;
x969.l = 0;
x970.up = 10;
x970.l = 0;
x971.up = 10;
x972.up = 10;
x972.l = 0;
x973.up = 10;
x973.l = 0;
x974.up = 10;
x975.up = 10;
x975.l = 0;
x976.up = 9;
x976.l = 0;
x977.up = 10;
x978.up = 10;
x978.l = 0;
x979.up = 10;
x979.l = 0;
x980.up = 10;
x981.up = 10;
x981.l = 0;
x982.up = 10;
x982.l = 0;
x983.up = 10;
x984.up = 10;
x984.l = 0;
x985.up = 9;
x985.l = 0;
x986.up = 10;
x987.up = 10;
x987.l = 0;
x988.up = 10;
x988.l = 0;
x989.up = 10;
x990.up = 10;
x990.l = 0;
x991.up = 10;
x991.l = 0;
x992.up = 10;
x993.up = 10;
x993.l = 0;
x994.up = 9;
x994.l = 0;
x995.up = 10;
x996.up = 10;
x996.l = 0;
x997.up = 10;
x997.l = 0;
x998.up = 10;
x999.up = 10;
x999.l = 0;
x1000.up = 10;
x1000.l = 0;
x1001.up = 10;
x1002.up = 10;
x1002.l = 0;
x1003.up = 9;
x1003.l = 0;
x1004.up = 10;
x1005.up = 10;
x1005.l = 0;
x1006.up = 10;
x1006.l = 0;
x1007.up = 10;
x1008.up = 10;
x1008.l = 0;
x1009.up = 10;
x1009.l = 0;
x1010.up = 10;
x1011.up = 10;
x1011.l = 0;
x1012.up = 9;
x1012.l = 0;
x1013.up = 10;
x1014.up = 10;
x1014.l = 0;
x1015.up = 10;
x1015.l = 0;
x1016.up = 10;
x1017.up = 10;
x1017.l = 0;
x1018.up = 10;
x1018.l = 0;
x1019.up = 10;
x1020.up = 10;
x1020.l = 0;
x1021.up = 9;
x1021.l = 0;
x1022.up = 10;
x1023.up = 10;
x1023.l = 0;
x1024.up = 10;
x1024.l = 0;
x1025.up = 10;
x1026.up = 10;
x1026.l = 0;
x1027.up = 10;
x1027.l = 0;
x1028.up = 10;
x1029.up = 10;
x1029.l = 0;
x1030.up = 9;
x1030.l = 0;
x1031.up = 10;
x1032.up = 10;
x1032.l = 0;
x1033.up = 10;
x1033.l = 0;
x1034.up = 10;
x1035.up = 10;
x1035.l = 0;
x1036.up = 10;
x1036.l = 0;
x1037.up = 10;
x1038.up = 10;
x1038.l = 0;
x1039.up = 9;
x1039.l = 0;
x1040.up = 10;
x1041.up = 10;
x1041.l = 0;
x1042.up = 10;
x1042.l = 0;
x1043.up = 10;
x1044.up = 10;
x1044.l = 0;
x1045.up = 10;
x1045.l = 0;
x1046.up = 10;
x1047.up = 10;
x1047.l = 0;
x1048.up = 9;
x1048.l = 0;
x1049.up = 10;
x1050.up = 10;
x1050.l = 0;
x1051.up = 10;
x1051.l = 0;
x1052.up = 10;
x1053.up = 10;
x1053.l = 0;
x1054.up = 10;
x1054.l = 0;
x1055.up = 10;
x1056.up = 10;
x1056.l = 0;
x1057.up = 9;
x1057.l = 0;
x1058.up = 10;
x1059.up = 10;
x1059.l = 0;
x1060.up = 10;
x1060.l = 0;
x1061.up = 10;
x1062.up = 10;
x1062.l = 0;
x1063.up = 10;
x1063.l = 0;
x1064.up = 10;
x1065.up = 10;
x1065.l = 0;
x1066.up = 9;
x1066.l = 0;
x1067.up = 10;
x1068.up = 10;
x1068.l = 0;
x1069.up = 10;
x1069.l = 0;
x1070.up = 10;
x1071.up = 10;
x1071.l = 0;
x1072.up = 10;
x1072.l = 0;
x1073.up = 10;
x1074.up = 10;
x1074.l = 0;
x1075.up = 9;
x1075.l = 0;
x1076.up = 10;
x1077.up = 10;
x1077.l = 0;
x1078.up = 10;
x1078.l = 0;
x1079.up = 10;
x1080.up = 10;
x1080.l = 0;
x1081.up = 10;
x1081.l = 0;
x1082.up = 10;
x1083.up = 10;
x1083.l = 0;
x1084.up = 9;
x1084.l = 0;
x1085.up = 10;
x1086.up = 10;
x1086.l = 0;
x3.lo = -10;
x3.up = 10;
x3.l = 0;
x7.lo = -10;
x7.up = 10;
x7.l = 0;
x9.lo = 1;
x9.up = 10;
x9.l = 0;
x13.lo = -10;
x13.up = 10;
x13.l = 0;
x17.lo = -10;
x17.up = 10;
x17.l = 0;
x21.lo = -10;
x21.up = 10;
x21.l = 0;
x25.lo = -10;
x25.up = 10;
x25.l = 0;
x29.lo = -10;
x29.up = 10;
x29.l = 0;
x33.lo = -10;
x33.up = 10;
x33.l = 0;
x37.lo = -10;
x37.up = 10;
x37.l = 0;
x41.lo = -10;
x41.up = 10;
x41.l = 0;
x45.lo = -10;
x45.up = 10;
x45.l = 0;
x49.lo = -10;
x49.up = 10;
x49.l = 0;
x53.lo = -10;
x53.up = 10;
x53.l = 0;
x57.lo = -10;
x57.up = 10;
x57.l = 0;
x61.lo = -10;
x61.up = 10;
x61.l = 0;
x65.lo = -10;
x65.up = 10;
x65.l = 0;
x69.lo = -10;
x69.up = 10;
x69.l = 0;
x73.lo = -10;
x73.up = 10;
x73.l = 0;
x77.lo = -10;
x77.up = 10;
x77.l = 0;
x81.lo = -10;
x81.up = 10;
x81.l = 0;
x85.lo = -10;
x85.up = 10;
x85.l = 0;
x89.lo = -10;
x89.up = 10;
x89.l = 0;
x93.lo = -10;
x93.up = 10;
x93.l = 0;
x97.lo = -10;
x97.up = 10;
x97.l = 0;
x101.lo = -10;
x101.up = 10;
x101.l = 0;
x105.lo = -10;
x105.up = 10;
x105.l = 0;
x109.lo = -10;
x109.up = 10;
x109.l = 0;
x113.lo = -10;
x113.up = 10;
x113.l = 0;
x117.lo = -10;
x117.up = 10;
x117.l = 0;
x121.lo = -10;
x121.up = 10;
x121.l = 0;
x124.lo = -10;
x124.up = 10;
x124.l = 0;
x129.lo = -10;
x129.up = 10;
x129.l = 0;
x132.lo = -10;
x132.up = 10;
x132.l = 0;
x135.lo = -10;
x135.up = 10;
x135.l = 0;
x138.lo = -10;
x138.up = 10;
x138.l = 0;
x141.lo = -10;
x141.up = 10;
x141.l = 0;
x144.lo = -10;
x144.up = 10;
x144.l = 0;
x147.lo = -10;
x147.up = 10;
x147.l = 0;
x150.lo = -10;
x150.up = 10;
x150.l = 0;
x153.lo = -10;
x153.up = 10;
x153.l = 0;
x156.lo = -10;
x156.up = 10;
x156.l = 0;
x159.lo = -10;
x159.up = 10;
x159.l = 0;
x162.lo = -10;
x162.up = 10;
x162.l = 0;
x165.lo = -10;
x165.up = 10;
x165.l = 0;
x168.lo = -10;
x168.up = 10;
x168.l = 0;
x171.lo = -10;
x171.up = 10;
x171.l = 0;
x174.lo = -10;
x174.up = 10;
x174.l = 0;
x177.lo = -10;
x177.up = 10;
x177.l = 0;
x180.lo = -10;
x180.up = 10;
x180.l = 0;
x183.lo = -10;
x183.up = 10;
x183.l = 0;
x186.lo = -10;
x186.up = 10;
x186.l = 0;
x189.lo = -10;
x189.up = 10;
x189.l = 0;
x192.lo = -10;
x192.up = 10;
x192.l = 0;
x195.lo = -10;
x195.up = 10;
x195.l = 0;
x198.lo = -10;
x198.up = 10;
x198.l = 0;
x201.lo = -10;
x201.up = 10;
x201.l = 0;
x204.lo = -10;
x204.up = 10;
x204.l = 0;
x207.lo = -10;
x207.up = 10;
x207.l = 0;
x210.lo = -10;
x210.up = 10;
x210.l = 0;
x212.lo = -10;
x212.up = 10;
x212.l = 0;
x213.lo = 1;
x213.up = 10;
x213.l = 0;
x215.lo = 1;
x215.up = 10;
x215.l = 0;
x216.lo = 1;
x216.up = 10;
x216.l = 0;
x218.lo = 1;
x218.up = 10;
x218.l = 0;
x220.lo = 1;
x220.up = 10;
x220.l = 0;
x222.lo = 1;
x222.up = 10;
x222.l = 0;
x224.lo = 1;
x224.up = 10;
x224.l = 0;
x226.lo = 1;
x226.up = 10;
x226.l = 0;
x228.lo = 1;
x228.up = 10;
x228.l = 0;
x230.lo = 1;
x230.up = 10;
x230.l = 0;
x232.lo = 1;
x232.up = 10;
x232.l = 0;
x234.lo = 1;
x234.up = 10;
x234.l = 0;
x236.lo = 1;
x236.up = 10;
x236.l = 0;
x238.lo = 1;
x238.up = 10;
x238.l = 0;
x240.lo = 1;
x240.up = 10;
x240.l = 0;
x242.lo = 1;
x242.up = 10;
x242.l = 0;
x244.lo = 1;
x244.up = 10;
x244.l = 0;
x246.lo = 1;
x246.up = 10;
x246.l = 0;
x248.lo = 1;
x248.up = 10;
x248.l = 0;
x250.lo = 1;
x250.up = 10;
x250.l = 0;
x252.lo = 1;
x252.up = 10;
x252.l = 0;
x254.lo = 1;
x254.up = 10;
x254.l = 0;
x256.lo = 1;
x256.up = 10;
x256.l = 0;
x258.lo = 1;
x258.up = 10;
x258.l = 0;
x260.lo = 1;
x260.up = 10;
x260.l = 0;
x262.lo = 1;
x262.up = 10;
x262.l = 0;
x264.lo = 1;
x264.up = 10;
x264.l = 0;
x266.lo = 1;
x266.up = 10;
x266.l = 0;
x268.lo = 1;
x268.up = 10;
x268.l = 0;
x367.lo = -10;
x367.up = 10;
x367.l = 0;
x374.lo = -10;
x374.up = 10;
x374.l = 0;
x382.lo = -10;
x382.up = 10;
x382.l = 0;
x389.lo = -10;
x389.up = 10;
x389.l = 0;
x397.lo = -10;
x397.up = 10;
x397.l = 0;
x404.lo = -10;
x404.up = 10;
x404.l = 0;
x412.lo = -10;
x412.up = 10;
x412.l = 0;
x419.lo = -10;
x419.up = 10;
x419.l = 0;
x427.lo = -10;
x427.up = 10;
x427.l = 0;
x434.lo = -10;
x434.up = 10;
x434.l = 0;
x442.lo = -10;
x442.up = 10;
x442.l = 0;
x449.lo = -10;
x449.up = 10;
x449.l = 0;
x457.lo = -10;
x457.up = 10;
x457.l = 0;
x464.lo = -10;
x464.up = 10;
x464.l = 0;
x472.lo = -10;
x472.up = 10;
x472.l = 0;
x479.lo = -10;
x479.up = 10;
x479.l = 0;
x487.lo = -10;
x487.up = 10;
x487.l = 0;
x494.lo = -10;
x494.up = 10;
x494.l = 0;
x502.lo = -10;
x502.up = 10;
x502.l = 0;
x509.lo = -10;
x509.up = 10;
x509.l = 0;
x517.lo = -10;
x517.up = 10;
x517.l = 0;
x524.lo = -10;
x524.up = 10;
x524.l = 0;
x532.lo = -10;
x532.up = 10;
x532.l = 0;
x539.lo = -10;
x539.up = 10;
x539.l = 0;
x547.lo = -10;
x547.up = 10;
x547.l = 0;
x554.lo = -10;
x554.up = 10;
x554.l = 0;
x562.lo = -10;
x562.up = 10;
x562.l = 0;
x569.lo = -10;
x569.up = 10;
x569.l = 0;
x577.lo = -10;
x577.up = 10;
x577.l = 0;
x584.lo = -10;
x584.up = 10;
x584.l = 0;
x592.lo = -10;
x592.up = 10;
x592.l = 0;
x599.lo = -10;
x599.up = 10;
x599.l = 0;
x607.lo = -10;
x607.up = 10;
x607.l = 0;
x614.lo = -10;
x614.up = 10;
x614.l = 0;
x622.lo = -10;
x622.up = 10;
x622.l = 0;
x629.lo = -10;
x629.up = 10;
x629.l = 0;
x637.lo = -10;
x637.up = 10;
x637.l = 0;
x644.lo = -10;
x644.up = 10;
x644.l = 0;
x652.lo = -10;
x652.up = 10;
x652.l = 0;
x659.lo = -10;
x659.up = 10;
x659.l = 0;
x667.lo = -10;
x667.up = 10;
x667.l = 0;
x674.lo = -10;
x674.up = 10;
x674.l = 0;
x682.lo = -10;
x682.up = 10;
x682.l = 0;
x689.lo = -10;
x689.up = 10;
x689.l = 0;
x697.lo = -10;
x697.up = 10;
x697.l = 0;
x704.lo = -10;
x704.up = 10;
x704.l = 0;
x712.lo = -10;
x712.up = 10;
x712.l = 0;
x719.lo = -10;
x719.up = 10;
x719.l = 0;
x727.lo = -10;
x727.up = 10;
x727.l = 0;
x734.lo = -10;
x734.up = 10;
x734.l = 0;
x742.lo = -10;
x742.up = 10;
x742.l = 0;
x749.lo = -10;
x749.up = 10;
x749.l = 0;
x757.lo = -10;
x757.up = 10;
x757.l = 0;
x764.lo = -10;
x764.up = 10;
x764.l = 0;
x772.lo = -10;
x772.up = 10;
x772.l = 0;
x779.lo = -10;
x779.up = 10;
x779.l = 0;
x787.lo = -10;
x787.up = 10;
x787.l = 0;
x794.lo = -10;
x794.up = 10;
x794.l = 0;
x802.lo = -10;
x802.up = 10;
x802.l = 0;
x809.lo = -10;
x809.up = 10;
x809.l = 0;

MODEL GAMS_MODEL /all/ ;
option minlp=scip;
option solprint=off;
option limrow=0;
option limcol=0;
option solvelink=5;
SOLVE GAMS_MODEL USING minlp minimizing GAMS_OBJECTIVE;

Scalars MODELSTAT 'model status', SOLVESTAT 'solve status';
MODELSTAT = GAMS_MODEL.modelstat;
SOLVESTAT = GAMS_MODEL.solvestat;

Scalar OBJEST 'best objective', OBJVAL 'objective value';
OBJEST = GAMS_MODEL.objest;
OBJVAL = GAMS_MODEL.objval;

Scalar NUMVAR 'number of variables';
NUMVAR = GAMS_MODEL.numvar

Scalar NUMEQU 'number of equations';
NUMEQU = GAMS_MODEL.numequ

Scalar NUMDVAR 'number of discrete variables';
NUMDVAR = GAMS_MODEL.numdvar

Scalar NUMNZ 'number of nonzeros';
NUMNZ = GAMS_MODEL.numnz

Scalar ETSOLVE 'time to execute solve statement';
ETSOLVE = GAMS_MODEL.etsolve

