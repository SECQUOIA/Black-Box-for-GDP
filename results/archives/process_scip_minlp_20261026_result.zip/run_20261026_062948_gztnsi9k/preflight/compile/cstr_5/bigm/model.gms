$offlisting
$offdigit

EQUATIONS
	c1
	c2
	c3
	c4
	c5
	c6
	c7
	c8
	c9
	c10
	c11
	c12
	c13
	c14
	c15
	c16
	c17
	c18
	c19
	c20
	c21
	c22
	c23
	c24
	c25
	c26_lo
	c27_lo
	c28_lo
	c29_lo
	c30_lo
	c31
	c32
	c33
	c34_lo
	c35_lo
	c36_lo
	c37_lo
	c38_lo
	c39_lo
	c40_lo
	c41_lo
	c42_lo
	c43_lo
	c44_lo
	c45_lo
	c46_lo
	c47_lo
	c48_lo
	c49_lo
	c50_lo
	c51_lo
	c52
	c53
	c54
	c55
	c56
	c57
	c58
	c59
	c60
	c61
	c62_lo
	c63_hi
	c64_lo
	c65_hi
	c66_lo
	c67_hi
	c68_lo
	c69_hi
	c70_lo
	c71_hi
	c72_lo
	c73_hi
	c74_lo
	c75_hi
	c76_lo
	c77_hi
	c78_lo
	c79_hi
	c80_lo
	c81_hi
	c82_lo
	c83_hi
	c84_lo
	c85_hi
	c86_lo
	c87_hi
	c88_lo
	c89_hi
	c90_lo
	c91_hi
	c92_lo
	c93_hi
	c94_lo
	c95_hi
	c96_lo
	c97_hi
	c98_lo
	c99_hi
	c100_lo
	c101_hi
	c102_lo
	c103_hi
	c104_lo
	c105_hi
	c106_lo
	c107_hi
	c108_lo
	c109_hi
	c110_lo
	c111_hi
	c112_lo
	c113_hi
	c114_lo
	c115_hi
	c116_lo
	c117_hi
	c118_lo
	c119_hi
	c120_lo
	c121_hi
	c122_lo
	c123_hi
	c124_lo
	c125_hi
	c126_lo
	c127_hi
	c128_lo
	c129_hi
	c130_lo
	c131_hi
	c132_lo
	c133_hi
	c134_lo
	c135_hi
	c136_lo
	c137_hi
	c138_lo
	c139_hi
	c140_lo
	c141_hi
	c142_lo
	c143_hi
	c144_lo
	c145_hi
	c146_lo
	c147_hi
	c148_lo
	c149_hi
	c150_lo
	c151_hi
	c152_lo
	c153_hi
	c154_lo
	c155_hi
	c156_lo
	c157_hi
	c158_lo
	c159_hi
	c160_lo
	c161_hi
	c162_lo
	c163_hi
	c164_lo
	c165_hi
	c166_lo
	c167_hi
	c168_lo
	c169_hi
	c170_lo
	c171_hi
	c172_lo
	c173_hi
	c174_lo
	c175_hi
	c176_lo
	c177_hi
	c178_lo
	c179_hi
	c180_lo
	c181_hi
	c182_lo
	c183_hi
	c184_lo
	c185_hi
	c186_lo
	c187_hi
	c188_lo
	c189_hi
	c190_lo
	c191_hi
	c192_lo
	c193_hi
	c194_lo
	c195_hi
	c196_lo
	c197_hi
	c198_lo
	c199_hi
	c200_lo
	c201_hi
	c202_lo
	c203_hi
	c204_lo
	c205_hi
	c206_lo
	c207_hi
	c208_lo
	c209_hi
	c210_lo
	c211_hi
	c212;

BINARY VARIABLES
	x52
	x53
	x54
	x55
	x56
	x57
	x58
	x59
	x60
	x61
	x62
	x63
	x64
	x65
	x66
	x67
	x68
	x69
	x70
	x71
	x72
	x73
	x74
	x75
	x76;

POSITIVE VARIABLES
	x1
	x2
	x4
	x5
	x6
	x8
	x10
	x11
	x12
	x14
	x15
	x16
	x18
	x19
	x20
	x22
	x23
	x25
	x26
	x27
	x28
	x30
	x31
	x33
	x34
	x36
	x39
	x42
	x44
	x45
	x46
	x47
	x48
	x49
	x50
	x51
	x77
	x78
	x79
	x80
	x81;

VARIABLES
	GAMS_OBJECTIVE
	x3
	x7
	x9
	x13
	x17
	x21
	x24
	x29
	x32
	x35
	x37
	x38
	x40
	x41
	x43;


c1.. 0.98999999999999999 + x1 - x2 + x3*x4 =e= 0 ;
c2.. 0.01 + x5 - x6 + x7*x4 =e= 0 ;
c3.. 1 + x8 - x9 =e= 0 ;
c4.. x10 + x11 - x12 + x13*x14 =e= 0 ;
c5.. x15 + x16 - x10 + x17*x18 =e= 0 ;
c6.. x19 + x20 - x15 + x21*x22 =e= 0 ;
c7.. x2 + x23 - x19 + x24*x25 =e= 0 ;
c8.. x26 + x27 - x28 + x29*x14 =e= 0 ;
c9.. x30 + x31 - x26 + x32*x18 =e= 0 ;
c10.. x33 + x34 - x30 + x35*x22 =e= 0 ;
c11.. x6 + x36 - x33 + x37*x25 =e= 0 ;
c12.. x38 + x39 - x40 =e= 0 ;
c13.. x41 + x42 - x38 =e= 0 ;
c14.. x43 + x44 - x41 =e= 0 ;
c15.. x9 + x45 - x43 =e= 0 ;
c16.. x12 - x46 - x47 =e= 0 ;
c17.. x28 - x48 - x49 =e= 0 ;
c18.. x40 - x50 - x51 =e= 0 ;
c19.. x46*x40 - x12*x50 =e= 0 ;
c20.. x48*x40 - x28*x50 =e= 0 ;
c21.. 0.94999999999999996*x50 - x48 =e= 0 ;
c22.. x18 - x14 =e= 0 ;
c23.. x22 - x18 =e= 0 ;
c24.. x25 - x22 =e= 0 ;
c25.. x4 - x25 =e= 0 ;
c26_lo.. 1 =l= 1 - x52 + x53 ;
c27_lo.. 1 =l= 1 - x54 + x55 ;
c28_lo.. 1 =l= 1 - x56 + x57 ;
c29_lo.. 1 =l= 1 - x58 + x59 ;
c30_lo.. 1 =l= 1 - x60 + x61 ;
c31.. x62 + x63 + x64 + x65 + x66 =e= 1 ;
c32.. x52 + x54 + x56 + x58 + x60 =e= 1 ;
c33.. x53 =e= 1 ;
c34_lo.. 1 =l= x55 + x62 ;
c35_lo.. 1 =l= 1 - x63 + x55 ;
c36_lo.. 1 =l= 1 - x55 + x63 + 1 - x62 ;
c37_lo.. 1 =l= 1 - x64 + x57 ;
c38_lo.. 1 =l= x57 + x62 + x63 ;
c39_lo.. 1 =l= 1 - x57 + x64 + 1 - x62 ;
c40_lo.. 1 =l= 1 - x57 + x64 + 1 - x63 ;
c41_lo.. 1 =l= 1 - x65 + x59 ;
c42_lo.. 1 =l= x59 + x62 + x63 + x64 ;
c43_lo.. 1 =l= 1 - x59 + x65 + 1 - x62 ;
c44_lo.. 1 =l= 1 - x59 + x65 + 1 - x63 ;
c45_lo.. 1 =l= 1 - x59 + x65 + 1 - x64 ;
c46_lo.. 1 =l= 1 - x66 + x61 ;
c47_lo.. 1 =l= 1 - x61 + x66 + 1 - x62 ;
c48_lo.. 1 =l= 1 - x61 + x66 + 1 - x63 ;
c49_lo.. 1 =l= 1 - x61 + x66 + 1 - x64 ;
c50_lo.. 1 =l= 1 - x61 + x66 + 1 - x65 ;
c51_lo.. 1 =l= x61 + x62 + x63 + x64 + x65 ;
c52.. x53 + x67 =e= 1 ;
c53.. x55 + x68 =e= 1 ;
c54.. x57 + x69 =e= 1 ;
c55.. x59 + x70 =e= 1 ;
c56.. x61 + x71 =e= 1 ;
c57.. x52 + x72 =e= 1 ;
c58.. x54 + x73 =e= 1 ;
c59.. x56 + x74 =e= 1 ;
c60.. x58 + x75 =e= 1 ;
c61.. x60 + x76 =e= 1 ;
c62_lo.. 0 =l= x13*x40*x40 + 2*x12*x28 - (-1000)*(1 - x53) ;
c63_hi.. x13*x40*x40 + 2*x12*x28 - 1200*(1 - x53) =l= 0 ;
c64_lo.. 0 =l= x29 + x13 - (-20)*(1 - x53) ;
c65_hi.. x29 + x13 - 20*(1 - x53) =l= 0 ;
c66_lo.. 0 =l= x77 - x14 - (-10)*(1 - x53) ;
c67_hi.. x77 - x14 - 10*(1 - x53) =l= 0 ;
c68_lo.. 0 =l= x11 - 0*(1 - x67) ;
c69_hi.. x11 - 10*(1 - x67) =l= 0 ;
c70_lo.. 0 =l= x27 - 0*(1 - x67) ;
c71_hi.. x27 - 10*(1 - x67) =l= 0 ;
c72_lo.. 0 =l= x39 - 0*(1 - x67) ;
c73_hi.. x39 - 9*(1 - x67) =l= 0 ;
c74_lo.. 0 =l= x13 - (-10)*(1 - x67) ;
c75_hi.. x13 - 10*(1 - x67) =l= 0 ;
c76_lo.. 0 =l= x29 - (-10)*(1 - x67) ;
c77_hi.. x29 - 10*(1 - x67) =l= 0 ;
c78_lo.. 0 =l= x77 - 0*(1 - x67) ;
c79_hi.. x77 - 10*(1 - x67) =l= 0 ;
c80_lo.. 0 =l= x17*x38*x38 + 2*x10*x26 - (-1000)*(1 - x55) ;
c81_hi.. x17*x38*x38 + 2*x10*x26 - 1200*(1 - x55) =l= 0 ;
c82_lo.. 0 =l= x32 + x17 - (-20)*(1 - x55) ;
c83_hi.. x32 + x17 - 20*(1 - x55) =l= 0 ;
c84_lo.. 0 =l= x78 - x18 - (-10)*(1 - x55) ;
c85_hi.. x78 - x18 - 10*(1 - x55) =l= 0 ;
c86_lo.. 0 =l= x16 - 0*(1 - x68) ;
c87_hi.. x16 - 10*(1 - x68) =l= 0 ;
c88_lo.. 0 =l= x31 - 0*(1 - x68) ;
c89_hi.. x31 - 10*(1 - x68) =l= 0 ;
c90_lo.. 0 =l= x42 - 0*(1 - x68) ;
c91_hi.. x42 - 9*(1 - x68) =l= 0 ;
c92_lo.. 0 =l= x17 - (-10)*(1 - x68) ;
c93_hi.. x17 - 10*(1 - x68) =l= 0 ;
c94_lo.. 0 =l= x32 - (-10)*(1 - x68) ;
c95_hi.. x32 - 10*(1 - x68) =l= 0 ;
c96_lo.. 0 =l= x78 - 0*(1 - x68) ;
c97_hi.. x78 - 10*(1 - x68) =l= 0 ;
c98_lo.. 0 =l= x21*x41*x41 + 2*x15*x30 - (-1000)*(1 - x57) ;
c99_hi.. x21*x41*x41 + 2*x15*x30 - 1200*(1 - x57) =l= 0 ;
c100_lo.. 0 =l= x35 + x21 - (-20)*(1 - x57) ;
c101_hi.. x35 + x21 - 20*(1 - x57) =l= 0 ;
c102_lo.. 0 =l= x79 - x22 - (-10)*(1 - x57) ;
c103_hi.. x79 - x22 - 10*(1 - x57) =l= 0 ;
c104_lo.. 0 =l= x20 - 0*(1 - x69) ;
c105_hi.. x20 - 10*(1 - x69) =l= 0 ;
c106_lo.. 0 =l= x34 - 0*(1 - x69) ;
c107_hi.. x34 - 10*(1 - x69) =l= 0 ;
c108_lo.. 0 =l= x44 - 0*(1 - x69) ;
c109_hi.. x44 - 9*(1 - x69) =l= 0 ;
c110_lo.. 0 =l= x21 - (-10)*(1 - x69) ;
c111_hi.. x21 - 10*(1 - x69) =l= 0 ;
c112_lo.. 0 =l= x35 - (-10)*(1 - x69) ;
c113_hi.. x35 - 10*(1 - x69) =l= 0 ;
c114_lo.. 0 =l= x79 - 0*(1 - x69) ;
c115_hi.. x79 - 10*(1 - x69) =l= 0 ;
c116_lo.. 0 =l= x24*x43*x43 + 2*x19*x33 - (-1000)*(1 - x59) ;
c117_hi.. x24*x43*x43 + 2*x19*x33 - 1200*(1 - x59) =l= 0 ;
c118_lo.. 0 =l= x37 + x24 - (-20)*(1 - x59) ;
c119_hi.. x37 + x24 - 20*(1 - x59) =l= 0 ;
c120_lo.. 0 =l= x80 - x25 - (-10)*(1 - x59) ;
c121_hi.. x80 - x25 - 10*(1 - x59) =l= 0 ;
c122_lo.. 0 =l= x23 - 0*(1 - x70) ;
c123_hi.. x23 - 10*(1 - x70) =l= 0 ;
c124_lo.. 0 =l= x36 - 0*(1 - x70) ;
c125_hi.. x36 - 10*(1 - x70) =l= 0 ;
c126_lo.. 0 =l= x45 - 0*(1 - x70) ;
c127_hi.. x45 - 9*(1 - x70) =l= 0 ;
c128_lo.. 0 =l= x24 - (-10)*(1 - x70) ;
c129_hi.. x24 - 10*(1 - x70) =l= 0 ;
c130_lo.. 0 =l= x37 - (-10)*(1 - x70) ;
c131_hi.. x37 - 10*(1 - x70) =l= 0 ;
c132_lo.. 0 =l= x80 - 0*(1 - x70) ;
c133_hi.. x80 - 10*(1 - x70) =l= 0 ;
c134_lo.. 0 =l= x3*x9*x9 + 2*x2*x6 - (-1000)*(1 - x61) ;
c135_hi.. x3*x9*x9 + 2*x2*x6 - 1200*(1 - x61) =l= 0 ;
c136_lo.. 0 =l= x7 + x3 - (-20)*(1 - x61) ;
c137_hi.. x7 + x3 - 20*(1 - x61) =l= 0 ;
c138_lo.. 0 =l= x81 - x4 - (-10)*(1 - x61) ;
c139_hi.. x81 - x4 - 10*(1 - x61) =l= 0 ;
c140_lo.. 0 =l= x1 - 0*(1 - x71) ;
c141_hi.. x1 - 10*(1 - x71) =l= 0 ;
c142_lo.. 0 =l= x5 - 0*(1 - x71) ;
c143_hi.. x5 - 10*(1 - x71) =l= 0 ;
c144_lo.. 0 =l= x8 - 0*(1 - x71) ;
c145_hi.. x8 - 9*(1 - x71) =l= 0 ;
c146_lo.. 0 =l= x3 - (-10)*(1 - x71) ;
c147_hi.. x3 - 10*(1 - x71) =l= 0 ;
c148_lo.. 0 =l= x7 - (-10)*(1 - x71) ;
c149_hi.. x7 - 10*(1 - x71) =l= 0 ;
c150_lo.. 0 =l= x81 - 0*(1 - x71) ;
c151_hi.. x81 - 10*(1 - x71) =l= 0 ;
c152_lo.. 0 =l= x11 - x47 - (-10)*(1 - x52) ;
c153_hi.. x11 - x47 - 10*(1 - x52) =l= 0 ;
c154_lo.. 0 =l= x27 - x49 - (-10)*(1 - x52) ;
c155_hi.. x27 - x49 - 10*(1 - x52) =l= 0 ;
c156_lo.. 0 =l= x39 - x51 - (-10)*(1 - x52) ;
c157_hi.. x39 - x51 - 9*(1 - x52) =l= 0 ;
c158_lo.. 0 =l= x11 - 0*(1 - x72) ;
c159_hi.. x11 - 10*(1 - x72) =l= 0 ;
c160_lo.. 0 =l= x27 - 0*(1 - x72) ;
c161_hi.. x27 - 10*(1 - x72) =l= 0 ;
c162_lo.. 0 =l= x39 - 0*(1 - x72) ;
c163_hi.. x39 - 9*(1 - x72) =l= 0 ;
c164_lo.. 0 =l= x16 - x47 - (-10)*(1 - x54) ;
c165_hi.. x16 - x47 - 10*(1 - x54) =l= 0 ;
c166_lo.. 0 =l= x31 - x49 - (-10)*(1 - x54) ;
c167_hi.. x31 - x49 - 10*(1 - x54) =l= 0 ;
c168_lo.. 0 =l= x42 - x51 - (-10)*(1 - x54) ;
c169_hi.. x42 - x51 - 9*(1 - x54) =l= 0 ;
c170_lo.. 0 =l= x16 - 0*(1 - x73) ;
c171_hi.. x16 - 10*(1 - x73) =l= 0 ;
c172_lo.. 0 =l= x31 - 0*(1 - x73) ;
c173_hi.. x31 - 10*(1 - x73) =l= 0 ;
c174_lo.. 0 =l= x42 - 0*(1 - x73) ;
c175_hi.. x42 - 9*(1 - x73) =l= 0 ;
c176_lo.. 0 =l= x20 - x47 - (-10)*(1 - x56) ;
c177_hi.. x20 - x47 - 10*(1 - x56) =l= 0 ;
c178_lo.. 0 =l= x34 - x49 - (-10)*(1 - x56) ;
c179_hi.. x34 - x49 - 10*(1 - x56) =l= 0 ;
c180_lo.. 0 =l= x44 - x51 - (-10)*(1 - x56) ;
c181_hi.. x44 - x51 - 9*(1 - x56) =l= 0 ;
c182_lo.. 0 =l= x20 - 0*(1 - x74) ;
c183_hi.. x20 - 10*(1 - x74) =l= 0 ;
c184_lo.. 0 =l= x34 - 0*(1 - x74) ;
c185_hi.. x34 - 10*(1 - x74) =l= 0 ;
c186_lo.. 0 =l= x44 - 0*(1 - x74) ;
c187_hi.. x44 - 9*(1 - x74) =l= 0 ;
c188_lo.. 0 =l= x23 - x47 - (-10)*(1 - x58) ;
c189_hi.. x23 - x47 - 10*(1 - x58) =l= 0 ;
c190_lo.. 0 =l= x36 - x49 - (-10)*(1 - x58) ;
c191_hi.. x36 - x49 - 10*(1 - x58) =l= 0 ;
c192_lo.. 0 =l= x45 - x51 - (-10)*(1 - x58) ;
c193_hi.. x45 - x51 - 9*(1 - x58) =l= 0 ;
c194_lo.. 0 =l= x23 - 0*(1 - x75) ;
c195_hi.. x23 - 10*(1 - x75) =l= 0 ;
c196_lo.. 0 =l= x36 - 0*(1 - x75) ;
c197_hi.. x36 - 10*(1 - x75) =l= 0 ;
c198_lo.. 0 =l= x45 - 0*(1 - x75) ;
c199_hi.. x45 - 9*(1 - x75) =l= 0 ;
c200_lo.. 0 =l= x1 - x47 - (-10)*(1 - x60) ;
c201_hi.. x1 - x47 - 10*(1 - x60) =l= 0 ;
c202_lo.. 0 =l= x5 - x49 - (-10)*(1 - x60) ;
c203_hi.. x5 - x49 - 10*(1 - x60) =l= 0 ;
c204_lo.. 0 =l= x8 - x51 - (-10)*(1 - x60) ;
c205_hi.. x8 - x51 - 9*(1 - x60) =l= 0 ;
c206_lo.. 0 =l= x1 - 0*(1 - x76) ;
c207_hi.. x1 - 10*(1 - x76) =l= 0 ;
c208_lo.. 0 =l= x5 - 0*(1 - x76) ;
c209_hi.. x5 - 10*(1 - x76) =l= 0 ;
c210_lo.. 0 =l= x8 - 0*(1 - x76) ;
c211_hi.. x8 - 9*(1 - x76) =l= 0 ;
c212.. GAMS_OBJECTIVE =e= x77 + x78 + x79 + x80 + x81 ;

x1.up = 10;
x1.l = 0;
x2.up = 10;
x2.l = 0.98999999999999999;
x4.up = 10;
x4.l = 9.894736842105251;
x5.up = 10;
x5.l = 0;
x6.up = 10;
x6.l = 0.01;
x8.up = 9;
x8.l = 0;
x10.up = 10;
x10.l = 0.98999999999999999;
x11.up = 10;
x11.l = 0;
x12.up = 10;
x12.l = 0.050000000000000058;
x14.up = 10;
x14.l = 9.894736842105251;
x15.up = 10;
x15.l = 0.98999999999999999;
x16.up = 10;
x16.l = 0;
x18.up = 10;
x18.l = 9.894736842105251;
x19.up = 10;
x19.l = 0.98999999999999999;
x20.up = 10;
x20.l = 0;
x22.up = 10;
x22.l = 9.894736842105251;
x23.up = 10;
x23.l = 0;
x25.up = 10;
x25.l = 9.894736842105251;
x26.up = 10;
x26.l = 0.01;
x27.up = 10;
x27.l = 0;
x28.up = 10;
x28.l = 0.94999999999999996;
x30.up = 10;
x30.l = 0.01;
x31.up = 10;
x31.l = 0;
x33.up = 10;
x33.l = 0.01;
x34.up = 10;
x34.l = 0;
x36.up = 10;
x36.l = 0;
x39.up = 9;
x39.l = 0;
x42.up = 9;
x42.l = 0;
x44.up = 9;
x44.l = 0;
x45.up = 9;
x45.l = 0;
x46.up = 10;
x46.l = 0.050000000000000058;
x47.up = 10;
x47.l = 0;
x48.up = 9.5;
x48.l = 0.94999999999999996;
x49.up = 10;
x49.l = 0;
x50.up = 10;
x50.l = 1;
x51.up = 10;
x51.l = 0;
x77.up = 10;
x77.l = 9.894736842105251;
x78.up = 10;
x78.l = 0;
x79.up = 10;
x79.l = 0;
x80.up = 10;
x80.l = 0;
x81.up = 10;
x81.l = 0;
x3.lo = -10;
x3.up = 10;
x3.l = 0;
x7.lo = -10;
x7.up = 10;
x7.l = 0;
x9.lo = 1;
x9.up = 10;
x9.l = 1;
x13.lo = -10;
x13.up = 10;
x13.l = -0.09500000000000011;
x17.lo = -10;
x17.up = 10;
x17.l = 0;
x21.lo = -10;
x21.up = 10;
x21.l = 0;
x24.lo = -10;
x24.up = 10;
x24.l = 0;
x29.lo = -10;
x29.up = 10;
x29.l = 0.09500000000000011;
x32.lo = -10;
x32.up = 10;
x32.l = 0;
x35.lo = -10;
x35.up = 10;
x35.l = 0;
x37.lo = -10;
x37.up = 10;
x37.l = 0;
x38.lo = 1;
x38.up = 10;
x38.l = 1;
x40.lo = 1;
x40.up = 10;
x40.l = 1;
x41.lo = 1;
x41.up = 10;
x41.l = 1;
x43.lo = 1;
x43.up = 10;
x43.l = 1;

MODEL GAMS_MODEL /all/ ;
option minlp=scip;
option solprint=off;
option limrow=0;
option limcol=0;
option solvelink=5;
SOLVE GAMS_MODEL USING minlp minimizing GAMS_OBJECTIVE;

Scalars MODELSTAT 'model status', SOLVESTAT 'solve status';
MODELSTAT = GAMS_MODEL.modelstat;
SOLVESTAT = GAMS_MODEL.solvestat;

Scalar OBJEST 'best objective', OBJVAL 'objective value';
OBJEST = GAMS_MODEL.objest;
OBJVAL = GAMS_MODEL.objval;

Scalar NUMVAR 'number of variables';
NUMVAR = GAMS_MODEL.numvar

Scalar NUMEQU 'number of equations';
NUMEQU = GAMS_MODEL.numequ

Scalar NUMDVAR 'number of discrete variables';
NUMDVAR = GAMS_MODEL.numdvar

Scalar NUMNZ 'number of nonzeros';
NUMNZ = GAMS_MODEL.numnz

Scalar ETSOLVE 'time to execute solve statement';
ETSOLVE = GAMS_MODEL.etsolve

