$offlisting
$offdigit

EQUATIONS
	c1_hi
	c2_hi
	c3_hi
	c4_hi
	c5_hi
	c6_hi
	c7_lo
	c8_lo
	c9_lo
	c10_lo
	c11_lo
	c12_lo
	c13_hi
	c14
	c15
	c16
	c17
	c18
	c19
	c20
	c21
	c22
	c23
	c24
	c25
	c26
	c27
	c28
	c29_lo
	c30_hi
	c31_lo
	c32_hi
	c33_lo
	c34_hi
	c35_lo
	c36_hi
	c37_lo
	c38_hi
	c39_lo
	c40_hi
	c41_lo
	c42_hi
	c43_lo
	c44_hi
	c45_lo
	c46_hi
	c47_lo
	c48_hi
	c49_lo
	c50_hi
	c51_lo
	c52_hi
	c53_lo
	c54_hi
	c55_lo
	c56_hi
	c57_lo
	c58_hi
	c59_lo
	c60_hi
	c61_lo
	c62_hi
	c63_lo
	c64_hi
	c65;

BINARY VARIABLES
	x20
	x21
	x22
	x23
	x24
	x25
	x26
	x27
	x28
	x29
	x30
	x31
	x32
	x33
	x34
	x35
	x36
	x37;

POSITIVE VARIABLES
	x6
	x7
	x9
	x10
	x11
	x12
	x13
	x14
	x15
	x16
	x17
	x18
	x19;

VARIABLES
	GAMS_OBJECTIVE
	x1
	x2
	x3
	x4
	x5
	x8;


c1_hi.. 0.69314718055994529 + x1 - x2 =l= 0 ;
c2_hi.. 1.0986122886681098 + x1 - x3 =l= 0 ;
c3_hi.. 1.3862943611198906 + x1 - x4 =l= 0 ;
c4_hi.. 1.3862943611198906 + x5 - x2 =l= 0 ;
c5_hi.. 1.791759469228055 + x5 - x3 =l= 0 ;
c6_hi.. 1.0986122886681098 + x5 - x4 =l= 0 ;
c7_lo.. 2.0794415416798357 =l= x6 + x7 ;
c8_lo.. 2.9957322735539909 =l= x8 + x7 ;
c9_lo.. 1.3862943611198906 =l= x9 + x7 ;
c10_lo.. 2.3025850929940459 =l= x6 + x10 ;
c11_lo.. 2.4849066497880004 =l= x8 + x10 ;
c12_lo.. 1.0986122886681098 =l= x9 + x10 ;
c13_hi.. 200000*exp(x7 - x1) + 150000*exp(x10 - x5) =l= 6000 ;
c14.. x6 - (x11 + x12 + x13) =e= 0 ;
c15.. x8 - (x14 + x15 + x16) =e= 0 ;
c16.. x9 - (x17 + x18 + x19) =e= 0 ;
c17.. x20 + x21 + x22 =e= 1 ;
c18.. x23 + x24 + x25 =e= 1 ;
c19.. x26 + x27 + x28 =e= 1 ;
c20.. x26 + x29 =e= 1 ;
c21.. x20 + x30 =e= 1 ;
c22.. x23 + x31 =e= 1 ;
c23.. x27 + x32 =e= 1 ;
c24.. x21 + x33 =e= 1 ;
c25.. x24 + x34 =e= 1 ;
c26.. x28 + x35 =e= 1 ;
c27.. x22 + x36 =e= 1 ;
c28.. x25 + x37 =e= 1 ;
c29_lo.. 0 =l= x11 - 0*(1 - x20) ;
c30_hi.. x11 - 1.0986122886681098*(1 - x20) =l= 0 ;
c31_lo.. 0 =l= x11 - 0*(1 - x30) ;
c32_hi.. x11 - 1.0986122886681098*(1 - x30) =l= 0 ;
c33_lo.. 0 =l= x14 - 0*(1 - x23) ;
c34_hi.. x14 - 1.0986122886681098*(1 - x23) =l= 0 ;
c35_lo.. 0 =l= x14 - 0*(1 - x31) ;
c36_hi.. x14 - 1.0986122886681098*(1 - x31) =l= 0 ;
c37_lo.. 0 =l= x17 - 0*(1 - x26) ;
c38_hi.. x17 - 1.0986122886681098*(1 - x26) =l= 0 ;
c39_lo.. 0 =l= x17 - 0*(1 - x29) ;
c40_hi.. x17 - 1.0986122886681098*(1 - x29) =l= 0 ;
c41_lo.. 0.69314718055994529 =l= x12 - (-0.69314718055994529)*(1 - x21) ;
c42_hi.. x12 - 0.4054651081081645*(1 - x21) =l= 0.69314718055994529 ;
c43_lo.. 0 =l= x12 - 0*(1 - x33) ;
c44_hi.. x12 - 1.0986122886681098*(1 - x33) =l= 0 ;
c45_lo.. 0.69314718055994529 =l= x15 - (-0.69314718055994529)*(1 - x24) ;
c46_hi.. x15 - 0.4054651081081645*(1 - x24) =l= 0.69314718055994529 ;
c47_lo.. 0 =l= x15 - 0*(1 - x34) ;
c48_hi.. x15 - 1.0986122886681098*(1 - x34) =l= 0 ;
c49_lo.. 0.69314718055994529 =l= x18 - (-0.69314718055994529)*(1 - x27) ;
c50_hi.. x18 - 0.4054651081081645*(1 - x27) =l= 0.69314718055994529 ;
c51_lo.. 0 =l= x18 - 0*(1 - x32) ;
c52_hi.. x18 - 1.0986122886681098*(1 - x32) =l= 0 ;
c53_lo.. 1.0986122886681098 =l= x13 - (-1.0986122886681098)*(1 - x22) ;
c54_hi.. x13 - 0*(1 - x22) =l= 1.0986122886681098 ;
c55_lo.. 0 =l= x13 - 0*(1 - x36) ;
c56_hi.. x13 - 1.0986122886681098*(1 - x36) =l= 0 ;
c57_lo.. 1.0986122886681098 =l= x16 - (-1.0986122886681098)*(1 - x25) ;
c58_hi.. x16 - 0*(1 - x25) =l= 1.0986122886681098 ;
c59_lo.. 0 =l= x16 - 0*(1 - x37) ;
c60_hi.. x16 - 1.0986122886681098*(1 - x37) =l= 0 ;
c61_lo.. 1.0986122886681098 =l= x19 - (-1.0986122886681098)*(1 - x28) ;
c62_hi.. x19 - 0*(1 - x28) =l= 1.0986122886681098 ;
c63_lo.. 0 =l= x19 - 0*(1 - x35) ;
c64_hi.. x19 - 1.0986122886681098*(1 - x35) =l= 0 ;
c65.. GAMS_OBJECTIVE =e= 250*exp(x6 + 0.59999999999999998*x2) + 500*exp(x8 + 0.59999999999999998*x3) + 340*exp(x9 + 0.59999999999999998*x4) ;

x6.up = 3.295836866004329;
x6.l = 1.0986122886681098;
x7.up = 2.8693183486983322;
x7.l = 1.897119984885881;
x9.up = 3.295836866004329;
x9.l = 1.0986122886681098;
x10.up = 2.7586024802650408;
x10.l = 1.3862943611198906;
x11.up = 1.0986122886681098;
x11.l = 0;
x12.up = 1.0986122886681098;
x12.l = 0;
x13.up = 1.0986122886681098;
x13.l = 1.0986122886681098;
x14.up = 1.0986122886681098;
x14.l = 0;
x15.up = 1.0986122886681098;
x15.l = 0;
x16.up = 1.0986122886681098;
x16.l = 1.0986122886681098;
x17.up = 1.0986122886681098;
x17.l = 0;
x18.up = 1.0986122886681098;
x18.l = 0;
x19.up = 1.0986122886681098;
x19.l = 1.0986122886681098;
x1.lo = 3.5684333010380689;
x1.up = 6.437751649736401;
x1.l = 6.0455317683782308;
x2.lo = 5.521460917862246;
x2.up = 7.8240460108562919;
x2.l = 6.7386789489381806;
x3.lo = 5.521460917862246;
x3.up = 7.8240460108562919;
x3.l = 7.1441440570463408;
x4.lo = 5.521460917862246;
x4.up = 7.8240460108562919;
x4.l = 7.4318261294981207;
x5.lo = 3.273684061363196;
x5.up = 6.0322865416282365;
x5.l = 5.3523845878182907;
x8.lo = 0.1264139248556586;
x8.up = 3.295836866004329;
x8.l = 1.0986122886681098;

MODEL GAMS_MODEL /all/ ;
option minlp=scip;
option solprint=off;
option limrow=0;
option limcol=0;
option solvelink=5;
SOLVE GAMS_MODEL USING minlp minimizing GAMS_OBJECTIVE;

Scalars MODELSTAT 'model status', SOLVESTAT 'solve status';
MODELSTAT = GAMS_MODEL.modelstat;
SOLVESTAT = GAMS_MODEL.solvestat;

Scalar OBJEST 'best objective', OBJVAL 'objective value';
OBJEST = GAMS_MODEL.objest;
OBJVAL = GAMS_MODEL.objval;

Scalar NUMVAR 'number of variables';
NUMVAR = GAMS_MODEL.numvar

Scalar NUMEQU 'number of equations';
NUMEQU = GAMS_MODEL.numequ

Scalar NUMDVAR 'number of discrete variables';
NUMDVAR = GAMS_MODEL.numdvar

Scalar NUMNZ 'number of nonzeros';
NUMNZ = GAMS_MODEL.numnz

Scalar ETSOLVE 'time to execute solve statement';
ETSOLVE = GAMS_MODEL.etsolve

