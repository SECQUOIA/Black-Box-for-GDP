$offlisting
$offdigit

EQUATIONS
	c1
	c2
	c3_hi
	c4;

VARIABLES
	GAMS_OBJECTIVE
	x1
	x2
	x3;


c1.. x1 =e= 6.6666666666666679 ;
c2.. x2 =e= 1.3333333333333321 ;
c3_hi.. ((- abs(sin(x1)*cos(x2)*exp(abs(1 - sqrt(power(x1, 2) + power(x2, 2))/3.141592653589793)))) + 18.138024104635146)/18.138024104635146 - x3 =l= 0 ;
c4.. GAMS_OBJECTIVE =e= x3 ;

x1.lo = -10;
x1.up = 10;
x2.lo = -10;
x2.up = 10;
x3.lo = -0.8286373404940521;
x3.up = 1;

MODEL GAMS_MODEL /all/ ;
option dnlp=scip;
option solprint=off;
option limrow=0;
option limcol=0;
option solvelink=5;

* START USER ADDITIONAL OPTIONS

option reslim=17.68699444171507;
option threads=1;
option optcr=1e-05;
option optca=0;
GAMS_MODEL.optfile=1;

* END USER ADDITIONAL OPTIONS

SOLVE GAMS_MODEL USING dnlp minimizing GAMS_OBJECTIVE;

Scalars MODELSTAT 'model status', SOLVESTAT 'solve status';
MODELSTAT = GAMS_MODEL.modelstat;
SOLVESTAT = GAMS_MODEL.solvestat;

Scalar OBJEST 'best objective', OBJVAL 'objective value';
OBJEST = GAMS_MODEL.objest;
OBJVAL = GAMS_MODEL.objval;

Scalar NUMVAR 'number of variables';
NUMVAR = GAMS_MODEL.numvar

Scalar NUMEQU 'number of equations';
NUMEQU = GAMS_MODEL.numequ

Scalar NUMDVAR 'number of discrete variables';
NUMDVAR = GAMS_MODEL.numdvar

Scalar NUMNZ 'number of nonzeros';
NUMNZ = GAMS_MODEL.numnz

Scalar ETSOLVE 'time to execute solve statement';
ETSOLVE = GAMS_MODEL.etsolve


file results /'results.dat'/;
results.nd=15;
results.nw=21;
put results;
put 'SYMBOL  :  LEVEL  :  MARGINAL' /;
put x1 ' ' x1.l ' ' x1.m /;
put x2 ' ' x2.l ' ' x2.m /;
put x3 ' ' x3.l ' ' x3.m /;
put c1 ' ' c1.l ' ' c1.m /;
put c2 ' ' c2.l ' ' c2.m /;
put c3_hi ' ' c3_hi.l ' ' c3_hi.m /;
put c4 ' ' c4.l ' ' c4.m /;
put GAMS_OBJECTIVE ' ' GAMS_OBJECTIVE.l ' ' GAMS_OBJECTIVE.m;

file statresults /'resultsstat.dat'/;
statresults.nd=15;
statresults.nw=21;
put statresults;
put 'SYMBOL   :   VALUE' /;
put 'MODELSTAT' ' ' MODELSTAT /;

put 'SOLVESTAT' ' ' SOLVESTAT /;

put 'OBJEST' ' ' OBJEST /;

put 'OBJVAL' ' ' OBJVAL /;

put 'NUMVAR' ' ' NUMVAR /;

put 'NUMEQU' ' ' NUMEQU /;

put 'NUMDVAR' ' ' NUMDVAR /;

put 'NUMNZ' ' ' NUMNZ /;

put 'ETSOLVE' ' ' ETSOLVE /;
