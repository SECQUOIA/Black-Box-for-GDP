CSTR penalty experiment
{
  "target_reached": 60,
  "target_not_reached": 60
}
See runs.csv, paired_comparison.csv, summary.csv and callbacks.csv.
Target hits exclude execution failures; all 10 seeds remain in each denominator.
No new NLP solves. Estimated completion = measured search - lookup + repeated same-key point costs.
Missing cost keys stay null. Timing differences include host load/instrumentation and are not attributable solely to penalty.
Runtime, exact commands, input/source hashes and original attempts are retained.
