#!/usr/bin/env bash
set -Eeuo pipefail
RUNNER_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MODE="${1:-run}"
if [[ $# -gt 0 ]]; then shift; fi
for ARG in "$@"; do
  if [[ "$ARG" == --dataset || "$ARG" == --dataset=* ]]; then
    printf 'This script always uses QHDOpt grids; omit --dataset.\n' >&2
    exit 2
  fi
done
exec bash "$RUNNER_ROOT/run_fmqa_dantzig.sh" "$MODE" "$@" --dataset grid
