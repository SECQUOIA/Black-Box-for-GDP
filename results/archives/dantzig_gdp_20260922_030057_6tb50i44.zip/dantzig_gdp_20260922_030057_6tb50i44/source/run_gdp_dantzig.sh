#!/usr/bin/env bash
set -Eeuo pipefail

# setup: isolated Python environment + pinned original model checkouts
# check: verify sources/solver and print the selected enumeration matrix
# run:   run all selected cases sequentially and write a result ZIP
# resume --run-dir PATH: continue an interrupted run with its saved settings
# pack --run-dir PATH:   package existing (including partial) results

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MODE="${1:-run}"
if [[ $# -gt 0 ]]; then shift; fi
case "$MODE" in
  setup|check|run|resume|pack) ;;
  help|-h|--help)
    printf '%s\n' 'Usage: bash run_gdp_dantzig.sh {setup|check|run|resume|pack} [options]' \
      'Run defaults: IPOPT; Column, CSTR 5/10/15/20/25/30, Small Batch, Dynamic.' \
      'Options and transfer instructions: docs/gdp_dantzig.md'
    exit 0 ;;
  *) printf 'Unknown mode: %s\n' "$MODE" >&2; exit 2 ;;
esac
ENV_DIR="${DANTZIG_GDP_ENV:-$ROOT/.venv-dantzig-gdp}"
cd "$ROOT"
export PYTHONPATH="$ROOT" PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1 MPLBACKEND=Agg
export OMP_NUM_THREADS=1 OMP_THREAD_LIMIT=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export BLIS_NUM_THREADS=1 GOTO_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
export NUMEXPR_NUM_THREADS=1 NUMEXPR_MAX_THREADS=1 OMP_DYNAMIC=FALSE MKL_DYNAMIC=FALSE

if [[ "$MODE" == setup ]]; then
  BASE_PYTHON="${GDP_BASE_PYTHON:-$ROOT/.venv-dantzig/bin/python}"
  if [[ ! -x "$BASE_PYTHON" ]]; then
    if [[ -n "${GDP_BASE_PYTHON:-}" ]]; then
      printf 'GDP_BASE_PYTHON is not executable: %s\n' "$BASE_PYTHON" >&2; exit 2
    fi
    BASE_PYTHON="$(command -v python3)"
  fi
  "$BASE_PYTHON" -c 'import sys; assert sys.version_info >= (3, 10), "Python >=3.10 required"'
  if [[ -e "$ENV_DIR" && ! -f "$ENV_DIR/pyvenv.cfg" ]]; then
    printf 'Use a separate new venv directory: %s\n' "$ENV_DIR" >&2; exit 2
  fi
  if [[ ! -x "$ENV_DIR/bin/python" ]]; then "$BASE_PYTHON" -m venv "$ENV_DIR"; fi
  "$ENV_DIR/bin/python" -m pip install -r "$ROOT/requirements-gdp.txt"
  exec "$ENV_DIR/bin/python" -m gdp_models.dantzig setup "$@"
fi

RUN_PYTHON="${GDP_PYTHON:-$ENV_DIR/bin/python}"
if [[ ! -x "$RUN_PYTHON" ]]; then
  printf 'First run: bash run_gdp_dantzig.sh setup (or set GDP_PYTHON).\n' >&2; exit 2
fi
exec "$RUN_PYTHON" -m gdp_models.dantzig "$MODE" "$@"
