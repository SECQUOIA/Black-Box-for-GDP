# Four independent Grid-GDP SCIP packages

Each package uses the unchanged analytic GDP models and all 21 original 31-by-31
reference CSVs. The MINLP package runs Big-M and Hull (42 jobs); GLOA, LOA and RIC
each run 21 jobs. No fixed-point IPOPT timing sweep is performed.

Only BARON is replaced: Big-M/Hull use GAMS/SCIP MINLP, while GDPopt uses
GAMS/SCIP NLP and the existing GAMS/HiGHS MILP master. SCIP is not substituted
for the MILP master. All jobs use one thread, a shared 1,800-second method budget,
relative gap 1e-5 and absolute gap zero. Preparation/CSV validation is recorded
separately. The reference optimum is not supplied as a starting point.
SCIP receives no initial levels (`gams/mipstart = 0`); its wall-clock timer is
explicit. Internal LP/NLP solvers retain the installed GAMS/SCIP defaults;
their identities are visible in the solver logs.
See the [GAMS 52 SCIP manual](https://www.gams.com/52/docs/S_SCIP.html).

SCIP is the configured NLP subsolver. GDPopt retains its existing routing:
after both grid coordinates are fixed, preprocessing can make a subproblem
linear, in which case GDPopt calls HiGHS. In local Ackley/Sum-of-Squares smoke
runs all GDPopt optimization calls took this route. A configured NLP solver
replacement therefore need not change their runtime; `solver_calls.jsonl`
records the solver actually invoked. Reformulation jobs directly call SCIP.

The previous `pyomo610-grid-v1` FBBT and Alpine1/LOA convergence corrections apply
only to their ten diagnosed grid/method pairs. They do not alter the formulas.
The BARON sin/cos skip is disabled for SCIP. Preflight actually solves nonconvex
and trigonometric NLPs, plus the needed MINLP or HiGHS MIP. Failure stops the run;
there is no fallback to BARON. GLOA also checks the existing MC++ build.

## Dantzig execution

Existing paths are reused:

```text
Repository: /local/scratch/a/lee4382/repository/RBFopt_Test
Python:     /local/scratch/a/lee4382/repository/RBFopt_Test/.venv-dantzig-gdp/bin/python
GAMS:       /package/gams/52.2/gams
MC++:       /local/scratch/a/lee4382/repository/RBFopt_Test/.pyomo-gdp-comparison
```

No installation is performed. Overrides are `GRID_GDP_REPOSITORY`,
`GRID_GDP_PYTHON`, `GAMS_BIN`, `GDP_GAMS_VERSION`, and `PYOMO_CONFIG_DIR`.
The required Pyomo version remains 6.10.0. Default CPUs are MINLP=6, GLOA=8,
LOA=10, RIC=12; choose an available CPU with `GRID_GDP_CPU` or `--cpu`.
These are affinity settings, not reservations.

After verifying the ZIP sidecar and extracting it into a fresh directory:

```bash
sha256sum -c SHA256SUMS
bash run_grid_scip_dantzig.sh plan
bash run_grid_scip_dantzig.sh check > check.log 2>&1
nohup bash run_grid_scip_dantzig.sh run > run.log 2>&1 &
tail -f run.log
```

`run` repeats preflight automatically. It prints `RUN_DIR=...`, followed at the
end by `RESULT_ZIP=...`. Separate method directories and output roots prevent
the four packages from overwriting one another. Each new `run` gets a unique
directory. Use `--grids ackley` and `--time-limit 60` for an explicitly smaller
smoke run, which is labeled by its actual configuration.

```bash
bash run_grid_scip_dantzig.sh status --run-dir /absolute/RUN_DIR
bash run_grid_scip_dantzig.sh resume --run-dir /absolute/RUN_DIR
bash run_grid_scip_dantzig.sh pack --run-dir /absolute/RUN_DIR
```

Resume checks the original source/runtime, skips sealed jobs, and preserves
interrupted attempts separately. Errors are terminal results, not silently
repeated. Packing an active run is rejected. If the launcher is killed forcibly,
use `resume` after it has stopped to continue, or `pack` to export a partial run.
The theoretical method budgets total 21 hours for MINLP and 10.5 hours for each
GDPopt package; these are caps, not predictions.

## Results and download

Results are under `results/grid_scip_minlp`, `results/grid_scip_gloa`,
`results/grid_scip_loa`, and `results/grid_scip_ric` in the existing repository.
Each output root contains `result_zip.txt` with the last packed ZIP's absolute
path and `latest_result.json` with its completion state. Always check
`summary.json`: all jobs finished includes errors/time limits, not all successes.

The ZIP contains `run.json`, `summary.json`, `benchmark.csv`, all source/input
snapshots and hashes, original-coordinate solution checks, solver-call journals,
logs, incumbent records, and GDPopt `grid_path.jsonl` before/after subproblem
callbacks (after GDPopt preprocessing). Integer choices are separate from physical values, which can still
be starting values before a solve. A callback records a visited subproblem,
not an internal SCIP branch-and-bound node; full SCIP node coordinates are not
exposed by this GAMS interface. Failed or interrupted callbacks may have only a
before record. Preprocessing failures are retained in the job result and log.
Solver status, target hit, and global certification are distinct.
LOA on these nonconvex models is not automatically globally certified.

On the Mac, change `JOB` for each returned ZIP:

```bash
JOB=minlp  # or gloa, loa, ric
RESULT_ZIP=$(ssh lee4382@dantzig.ecn.purdue.edu "cat /local/scratch/a/lee4382/repository/RBFopt_Test/results/grid_scip_${JOB}/result_zip.txt")
scp "lee4382@dantzig.ecn.purdue.edu:${RESULT_ZIP}" "lee4382@dantzig.ecn.purdue.edu:${RESULT_ZIP}.sha256" ~/Downloads/
(cd ~/Downloads && shasum -a 256 -c "$(basename "$RESULT_ZIP").sha256")
```

Return the ZIP and its `.sha256` file for analysis. Exact upload/unzip/start
commands for this delivery are also provided in the adjacent `COMMANDS.txt`.
