# Two Dantzig GDPopt SCIP experiments (October 24, 2026)

The Grid package runs all 21 original analytic Grid GDPs with GLOA, LOA and
RIC (63 jobs). Both the MIP solver and the NLP solver are GAMS/SCIP. This
changes the solver actually used by the linear master and presolved Grid
subproblems; it is not a BARON-versus-SCIP NLP comparison.

The Process package runs CSTR sizes 5, 10, 15, 20, 25 and 30, Column, Small
Batch and Dynamic with the same three GDPopt methods (27 jobs). Its master
remains GAMS/HiGHS and its NLP solver is GAMS/SCIP instead of BARON. Actual
SCIP NLP calls are counted separately from linear subproblems and preflight.
No direct Big-M/Hull jobs or exhaustive IPOPT point sweeps are included.

Each job uses one thread, a 1,800-second shared worker budget, relative gap
1e-5 and absolute gap zero. Preparation and preflight are outside that budget.
Grid and Process run separately on CPUs 6 and 8 by default. The runner checks
that they are distinct allowed physical cores; affinity does not reserve a
core against unrelated workloads. Upper-bound job budgets are 31.5 hours for
Grid and 13.5 hours for Process, plus preparation and cleanup.

SCIP options are `gams/mipstart = 0` and `timing/clocktype = 2`. No previous
solution or known optimum is supplied as a SCIP start. Internal SCIP LP/NLP
components keep the installed GAMS defaults, and their identities appear in
logs. See the [GAMS 52 SCIP manual](https://www.gams.com/52/docs/S_SCIP.html).
Failed solver/license checks stop the run; there is no BARON fallback.

The original models, reference CSVs, Process initialization and Dynamic
collocation are preserved. Exact pinned upstream Process files are bundled
under their existing `external/...` relative paths and verified through
`PACKAGE_MANIFEST.json`; no server checkout or dependency is modified.
Pyomo 6.10.0, the existing MC++ build and GAMS 52.2 are required.

The ten existing `pyomo610-grid-v1` corrections remain restricted to their
previous Grid/method pairs. The later singleton-sine and GLOA slope candidate
patches are not applied. Changing the solver alone does not establish that
those presolve/cut defects are resolved; all GDPopt global-certificate flags
remain conservative.

## Execution

Default server paths:

- Repository: `/local/scratch/a/lee4382/repository/RBFopt_Test`
- Python: `.venv-dantzig-gdp/bin/python` under that repository
- GAMS: `/package/gams/52.2/gams`
- MC++: `.pyomo-gdp-comparison` under that repository

From either extracted package:

```bash
sha256sum -c SHA256SUMS
bash run_gdp_scip_experiment.sh plan
nohup bash run_gdp_scip_experiment.sh run > run.log 2>&1 < /dev/null &
echo $! > launcher.pid
tail -f run.log
```

`run` automatically performs real preflight solves before starting the jobs;
a separate `check` is optional and does not run the full benchmark. Existing
checks, smoke runs and full runs each get a new timestamped directory.

Results are written under `results/grid_gdpopt_scip` or
`results/process_gdpopt_scip` in the existing repository. The console prints
`RUN_DIR=...` at startup and `RESULT_ZIP=...` after completion or interruption.
A result ZIP and `.zip.sha256` are created even when preflight fails or no
feasible solution is returned. `latest_result.json` and `result_zip.txt` are
updated only after packaging. Inspect `all_jobs_finished` to distinguish a
complete run from a partial archive.

Optional subsets for smoke checks:

```bash
# Grid package only:
bash run_gdp_scip_experiment.sh run --grids ackley,sum_of_squares --time-limit 30
# Process package only:
bash run_gdp_scip_experiment.sh run --cases cstr --cstr-sizes 5 --time-limit 30
```

To resume an interrupted run using the exact same extracted package:

```bash
bash run_gdp_scip_experiment.sh resume --run-dir /absolute/RUN_DIR
```

Sealed completed jobs are verified and skipped. An incomplete previous attempt
is moved under `previous_attempts/`, never overwritten. Source/runtime changes
prevent a resume. Use `pack --run-dir ...` only after all workers have stopped.
Do not start a second full run on the same allocated CPU.

## Returned evidence

Each job is under `benchmark/<instance>/<method>/` and retains:

- `run.log`: complete solver output;
- `solver_calls.jsonl`: actual solver/model type, options, raw GAMS status,
  bounds and measured call time;
- `active_solver_call.json`, if a watchdog interrupted a call before its final
  journal entry; this is separate from the completed-call count;
- `solution.json`, when a candidate passes original-GDP feasibility at `1e-5`,
  including the full stored variable vector; absence is reported explicitly;
- `incumbents.jsonl`: feasibility and objective checks;
- `gdp_path.jsonl`: binary assignments after discrete solves and before/after
  subproblem calls, including iteration and the last solver-call status;
- Grid `grid_path.jsonl`: selected integer coordinate indices and physical
  coordinates for these callbacks;
- `terminal.json`: per-job artifact checksums.

An after-discrete record is a solver callback, not automatically a feasible
candidate; its last solver status must be inspected. Subproblem callbacks
occur after presolve and do not by themselves enumerate rejected candidates.
The logs retain the solver's own messages. No complete internal FBBT/no-good
trace is claimed.

`summary.json` and `summary.csv` distinguish returned solutions, feasibility,
termination, and actual SCIP NLP/MIP calls. All source snapshots, initialization
files and input hashes are included in the returned ZIP. `optimal` termination
alone is not promoted to a global-optimality certificate.
