#!/usr/bin/env bash
set -Eeuo pipefail
GRID_SCIP_RUNNER=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
GRID_GDP_REPOSITORY=${GRID_GDP_REPOSITORY:-/local/scratch/a/lee4382/repository/RBFopt_Test}
GRID_GDP_PYTHON=${GRID_GDP_PYTHON:-$GRID_GDP_REPOSITORY/.venv-dantzig-gdp/bin/python}
export GRID_GDP_REPOSITORY
export GAMS_BIN=${GAMS_BIN:-/package/gams/52.2/gams}
export GDP_GAMS_VERSION=${GDP_GAMS_VERSION:-52.2}
export PYOMO_CONFIG_DIR=${PYOMO_CONFIG_DIR:-$GRID_GDP_REPOSITORY/.pyomo-gdp-comparison}
export PYTHONUNBUFFERED=1 PYTHONNOUSERSITE=1
[[ -x "$GRID_GDP_PYTHON" ]] || { echo "Missing GDP Python: $GRID_GDP_PYTHON" >&2; exit 2; }
cd "$GRID_SCIP_RUNNER"
exec "$GRID_GDP_PYTHON" grid_scip_package.py "$@"
