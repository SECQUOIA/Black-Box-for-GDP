"""Build four standalone SCIP bundles, or operate the one extracted package."""

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import zipfile

import grid_gdp_benchmark as runner

PACKAGES = {
    "minlp": {"methods": ["bigm", "hull"], "cpu": 6},
    "gloa": {"methods": ["gloa"], "cpu": 8},
    "loa": {"methods": ["loa"], "cpu": 10},
    "ric": {"methods": ["ric"], "cpu": 12},
}
ROOT = Path(__file__).resolve().parent


def build(output, tag):
    """Package exact source, models, all reference CSVs, and member hashes."""
    if not tag or not all(c.isalnum() or c in "_-" for c in tag):
        raise ValueError("Use only letters, digits, underscore, or hyphen in tag")
    output.mkdir(parents=True, exist_ok=True)
    files = runner.source_files() + [
        ROOT / "tests/test_grid_scip.py",
        ROOT / "tests/test_grid_gdp.py",
        ROOT / "tests/test_grid_retry_fixes.py",
    ]
    paths = [output / f"grid_scip_{key}_dantzig_{tag}.zip" for key in PACKAGES]
    if any(path.exists() or path.with_suffix(".zip.sha256").exists() for path in paths):
        raise FileExistsError("Choose a fresh tag/output directory; bundles are immutable")
    for (key, specification), path in zip(PACKAGES.items(), paths):
        prefix = f"grid_scip_{key}_{tag}/"
        payloads = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in files}
        payloads["grid_scip_package.json"] = (json.dumps({
            "package": key, "tag": tag, "solver_profile": "scip-v1",
            **specification, "planned_jobs": 21 * len(specification["methods"]),
            "default_time_limit_s": 1800,
        }, indent=2) + "\n").encode()
        payloads["README.md"] = (ROOT / "docs/grid_gdp_scip.md").read_bytes()
        import hashlib

        payloads["SHA256SUMS"] = "".join(
            f"{hashlib.sha256(data).hexdigest()}  {name}\n"
            for name, data in sorted(payloads.items())
        ).encode()
        with zipfile.ZipFile(path, "x", compression=zipfile.ZIP_DEFLATED) as archive:
            for name, data in payloads.items():
                archive.writestr(prefix + name, data)
        with zipfile.ZipFile(path) as archive:
            if archive.testzip() is not None:
                raise ValueError(f"Corrupt bundle: {path}")
        path.with_suffix(".zip.sha256").write_text(f"{runner.sha(path)}  {path.name}\n")
        print(path.resolve())


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("build", "plan", "check", "run", "resume", "pack", "status"))
    parser.add_argument("--output", type=Path, default=ROOT / "results/runners")
    parser.add_argument("--tag", default=datetime.now(timezone.utc).strftime("%Y%m%d"))
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--grids")
    parser.add_argument("--cpu", type=int)
    parser.add_argument("--time-limit", type=float, default=1800)
    parser.add_argument("--output-root", type=Path)
    args = parser.parse_args(argv)
    if args.mode == "build":
        return build(args.output, args.tag)
    package = runner.read(ROOT / "grid_scip_package.json")
    key = package["package"]
    if key not in PACKAGES or package["methods"] != PACKAGES[key]["methods"]:
        raise ValueError("Package method assignment differs from its identity")
    if args.mode == "plan":
        print(json.dumps(package, indent=2))
        return
    if args.mode in {"resume", "pack", "status"}:
        if args.run_dir is None:
            parser.error("--run-dir is required; use RUN_DIR from the run log")
        config = runner.read(args.run_dir / "run.json")["config"]
        if config.get("solver_profile") != "scip-v1" or config["methods"] != package["methods"]:
            raise ValueError("This run belongs to a different package or solver profile")
        forwarded = [args.mode, "--run-dir", str(args.run_dir)]
    else:
        repository = Path(os.environ.get("GRID_GDP_REPOSITORY", "/local/scratch/a/lee4382/repository/RBFopt_Test"))
        forwarded = [
            "benchmark" if args.mode == "run" else "check",
            "--solver-profile", "scip-v1", "--methods", ",".join(package["methods"]),
            "--time-limit", str(args.time_limit),
            "--output-root", str(args.output_root or repository / f"results/grid_scip_{key}"),
        ]
        cpu = args.cpu
        if cpu is None and sys.platform == "linux":
            cpu = int(os.environ.get("GRID_GDP_CPU", package["cpu"]))
        if cpu is not None:
            forwarded += ["--cpu", str(cpu)]
        if args.grids:
            forwarded += ["--grids", args.grids]
    sys.argv = [str(ROOT / "grid_gdp_benchmark.py"), *forwarded]
    runner.main()


if __name__ == "__main__":
    main()
