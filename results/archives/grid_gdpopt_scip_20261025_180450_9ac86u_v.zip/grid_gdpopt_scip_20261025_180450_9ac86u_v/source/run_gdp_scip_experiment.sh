#!/usr/bin/env bash
set -Eeuo pipefail
GDP_SCIP_RUNNER=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
export GDP_SCIP_REPOSITORY=${GDP_SCIP_REPOSITORY:-/local/scratch/a/lee4382/repository/RBFopt_Test}
GDP_SCIP_PYTHON=${GDP_SCIP_PYTHON:-$GDP_SCIP_REPOSITORY/.venv-dantzig-gdp/bin/python}
export GAMS_BIN=${GAMS_BIN:-/package/gams/52.2/gams}
export GDP_GAMS_VERSION=${GDP_GAMS_VERSION:-52.2}
export PYOMO_CONFIG_DIR=${PYOMO_CONFIG_DIR:-$GDP_SCIP_REPOSITORY/.pyomo-gdp-comparison}
export PYTHONUNBUFFERED=1 PYTHONNOUSERSITE=1
[[ -x "$GDP_SCIP_PYTHON" ]] || { echo "Missing GDP Python: $GDP_SCIP_PYTHON" >&2; exit 2; }
cd "$GDP_SCIP_RUNNER"
exec "$GDP_SCIP_PYTHON" gdp_scip_experiments.py "$@"
