#!/usr/bin/env bash
set -Eeuo pipefail
GRID_METHOD_RUNNER=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
export GDP_SCIP_REPOSITORY=${GDP_SCIP_REPOSITORY:-/local/scratch/a/lee4382/repository/RBFopt_Test}
GRID_METHOD_PYTHON=${GDP_SCIP_PYTHON:-$GDP_SCIP_REPOSITORY/.venv-dantzig-gdp/bin/python}
export GAMS_BIN=${GAMS_BIN:-/package/gams/52.2/gams}
export GDP_GAMS_VERSION=${GDP_GAMS_VERSION:-52.2}
export PYOMO_CONFIG_DIR=${PYOMO_CONFIG_DIR:-$GDP_SCIP_REPOSITORY/.pyomo-gdp-comparison}
export PYTHONUNBUFFERED=1 PYTHONNOUSERSITE=1
[[ -x "$GRID_METHOD_PYTHON" ]] || { echo "Missing GDP Python: $GRID_METHOD_PYTHON" >&2; exit 2; }
cd "$GRID_METHOD_RUNNER"
[[ $# -gt 0 ]] || set -- run
exec "$GRID_METHOD_PYTHON" run_method.py "$@"
