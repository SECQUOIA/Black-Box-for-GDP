"""Routing, recorded selection paths and standalone package integrity."""
import argparse
import hashlib
import json
import subprocess
import sys
import time
import zipfile

import pytest

pytest.importorskip('pyomo.environ')
import pyomo.environ as pyo
from pyomo.gdp import Disjunct, Disjunction
from pyomo.opt import SolverResults

import gdp_scip_experiments as package
from gdp_models import comparison as impl


def arguments(**updates):
    values = dict(methods=None, time_limit=1800, cases=None, cstr_sizes=None, grids=None, cpu=None)
    values.update(updates)
    return argparse.Namespace(**values)


def specification(key):
    return {'kind': package.KIND, 'package': key, **package.PACKAGES[key],
            'methods': package.METHODS, 'relative_gap': 1e-5,
            'cases': ['cstr', 'column', 'small_batch', 'dynamic'],
            'cstr_sizes': [5, 10, 15, 20, 25, 30]}


def test_two_experiments_change_the_actual_relevant_solver():
    grid = package.make_config(specification('grid'), arguments())
    process = package.make_config(specification('process'), arguments())
    assert impl.solver_policy(grid, 'gloa')['mip'] == 'scip'
    assert impl.solver_policy(process, 'gloa')['mip'] == 'highs'
    assert grid['nlp_solver'] == process['nlp_solver'] == 'scip'
    assert len(package.specs(grid)) * len(grid['methods']) == 63
    assert len(package.specs(process)) * len(process['methods']) == 27
    assert set(s['instance_id'] for s in package.specs(process)) == {
        'cstr_5', 'cstr_10', 'cstr_15', 'cstr_20', 'cstr_25', 'cstr_30',
        'column', 'small_batch', 'dynamic'}


@pytest.mark.parametrize('options', [{'methods': 'bigm'}, {'grids': 'unknown'},
                                    {'cstr_sizes': '5,5'}, {'time_limit': float('nan')}])
def test_invalid_plan_rejected(options):
    with pytest.raises(ValueError):
        package.make_config(specification('grid'), arguments(**options))


@pytest.mark.parametrize('mip', ['scip', 'highs'])
def test_callbacks_retain_discrete_choices_and_nlp_route(tmp_path, monkeypatch, mip):
    model = pyo.ConcreteModel()
    model.x = pyo.Var(bounds=(0, 4), initialize=1)
    model.a = Disjunct()
    model.a.c = pyo.Constraint(expr=model.x == 1)
    model.b = Disjunct()
    model.b.c = pyo.Constraint(expr=model.x == 3)
    model.choice = Disjunction(expr=[model.a, model.b])
    model.obj = pyo.Objective(expr=model.x**2)
    model.a.indicator_var.set_value(True)
    model.b.indicator_var.set_value(False)

    class Algorithm:
        iteration = 1

        def solve(self, model, **kw):
            assert kw['mip_solver_args'] == {'solver': mip, 'mtype': 'mip'}
            assert kw['nlp_solver_args'] == {'solver': 'scip', 'mtype': 'nlp'}
            for name in ['call_after_discrete_problem_solve', 'call_before_subproblem_solve',
                         'call_after_subproblem_solve', 'call_after_subproblem_feasible']:
                kw[name](self, model, None)
            result = SolverResults()
            result.solver.termination_condition = 'optimal'
            result.solver.status = 'ok'
            result.problem.lower_bound = result.problem.upper_bound = 1
            return result

    original = pyo.SolverFactory
    monkeypatch.setattr(pyo, 'SolverFactory', lambda name: Algorithm() if name.startswith('gdpopt.') else original(name))
    config = {'executable': '/no/solver', 'nlp_solver': 'scip', 'mip_solver': mip,
              'time_limit': 30, 'relative_gap': 1e-5, 'record_gdp_path': True}
    report = impl.solve_method(impl.Template(model, {'case': 'test'}), 'ric', tmp_path, config, time.monotonic() + 30)
    assert report['has_feasible_solution'] and (tmp_path / 'solution.json').exists()
    path = [json.loads(row) for row in (tmp_path / 'gdp_path.jsonl').read_text().splitlines()]
    assert [r['event'] for r in path] == ['after_discrete_problem', 'before_subproblem', 'after_subproblem']
    assert path[0]['binary_values']['a.binary_indicator_var'] == 1
    assert not report['global_optimality_certified']


def test_independent_bundles_are_sealed_and_model_sources_portable(tmp_path, monkeypatch):
    package.build(tmp_path, 'test')
    for key in package.PACKAGES:
        stem = f'{key}_gdpopt_scip_dantzig_test'
        path = tmp_path / (stem + '.zip')
        assert path.with_suffix('.zip.sha256').read_text().split()[0] == hashlib.sha256(path.read_bytes()).hexdigest()
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            for row in archive.read(stem + '/SHA256SUMS').decode().splitlines():
                digest, name = row.split('  ', 1)
                assert hashlib.sha256(archive.read(stem + '/' + name)).hexdigest() == digest
            archive.extractall(tmp_path / 'extract')
        extracted = tmp_path / 'extract' / stem
        result = subprocess.run([sys.executable, str(extracted / 'gdp_scip_experiments.py'), 'plan'],
                                cwd=tmp_path, text=True, capture_output=True, check=True)
        assert json.loads(result.stdout)['planned_jobs'] == (63 if key == 'grid' else 27)
        if key == 'process':
            code = "from gdp_models.comparison import build_template; t=build_template('cstr', cstr_size=5); print(t.metadata['source']['commit'])"
            result = subprocess.run([sys.executable, '-c', code], cwd=extracted,
                                    text=True, capture_output=True, check=True,
                                    env={**__import__('os').environ, 'RBFOPT_GDP_SOURCES': str(extracted / 'external')})
            assert '3e469dbeea8931670b8cd6752014ab7a767d3af5' in result.stdout
        monkeypatch.setattr(package, 'ROOT', extracted)
        package.package_inventory()
        (extracted / 'gdp_scip_package.json').write_text('{}')
        with pytest.raises(ValueError, match='changed'):
            package.package_inventory()
    with pytest.raises(FileExistsError):
        package.build(tmp_path, 'test')
