#!/usr/bin/env bash
set -Eeuo pipefail

RUNNER_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPOSITORY="${FMQA_REPOSITORY:-/local/scratch/a/lee4382/repository/RBFopt_Test}"
FMQA_ENV="${FMQA_ENV:-$REPOSITORY/.venv-dantzig-fmqa}"
BASE_PYTHON="${FMQA_BASE_PYTHON:-$REPOSITORY/.venv-dantzig-gdp/bin/python}"
MODE="${1:-run}"
if [[ $# -gt 0 ]]; then shift; fi
cd "$RUNNER_ROOT"
export PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1 PYTHONPATH="$RUNNER_ROOT" MPLBACKEND=Agg
if [[ "$MODE" == setup ]]; then
  if [[ ! -x "$BASE_PYTHON" ]]; then BASE_PYTHON=python3; fi
  "$BASE_PYTHON" -c 'import sys; assert sys.version_info >= (3, 10), "FMQA needs Python >=3.10"'
  if [[ ! -x "$FMQA_ENV/bin/python" ]]; then "$BASE_PYTHON" -m venv "$FMQA_ENV"; fi
  "$FMQA_ENV/bin/python" -m pip install -r requirements-fmqa.txt
  exec "$FMQA_ENV/bin/python" fmqa_benchmark_runner.py check "$@"
fi
if [[ ! -x "$FMQA_ENV/bin/python" ]]; then
  printf 'Run bash run_fmqa_dantzig.sh setup first.\n' >&2
  exit 2
fi
if [[ "$MODE" == compare ]]; then
  exec "$FMQA_ENV/bin/python" fmqa_compare.py "$@"
fi
exec "$FMQA_ENV/bin/python" fmqa_benchmark_runner.py "$MODE" --output-root "$REPOSITORY/results" "$@"
