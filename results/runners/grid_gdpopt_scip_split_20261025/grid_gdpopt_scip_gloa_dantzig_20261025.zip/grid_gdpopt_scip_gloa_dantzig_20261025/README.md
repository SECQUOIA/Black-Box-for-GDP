Grid GDPopt SCIP GLOA package, 2026-10-25

This package starts all 21 Grid problems from the beginning with GLOA only.
It uses actual GAMS/SCIP for both MIP and NLP routing, retaining the original 1,800-second budget per problem, relative gap 1e-5, one thread, model definitions, corrections and trajectory recording.
It does not import results or resume attempts from the earlier combined 63-job run.
The cumulative worker budget is at most 10.5 hours, plus preflight, verification and packaging.
The packaged optimization source files are byte-identical to the verified October 24 Grid package.
Only the package selection metadata, this README, manifests and the added launch wrapper differ.
The retained docs/gdp_scip_experiments.md describes the original two-package experiment; this README governs the single-method launch.

Use CPU 16 for GLOA.
The launcher verifies that CPUs 12, 14 and 16 are distinct allowed physical cores and also distinct from earlier experiment CPUs 6, 8 and 10.
This prevents overlap among the selected experiment cores but does not reserve CPUs against other users.
Results are written under /local/scratch/a/lee4382/repository/RBFopt_Test/results/grid_gdpopt_scip_gloa/.
The method has its own result_zip.txt and latest_result.json, so parallel methods cannot overwrite one another's result pointers.
A per-method launcher lock rejects duplicate launches through this wrapper.

Run on Dantzig from this extracted directory:

```bash
sha256sum -c SHA256SUMS > verify.log
bash run_method.sh plan > plan.json
nohup bash run_method.sh run > run.log 2>&1 < /dev/null &
echo $! > launcher.pid
tail -f run.log
```

The launcher prints CPU_SEPARATION and METHOD before preflight, RUN_DIR when the result directory is created, START/DONE for each of the 21 jobs, and RESULT_ZIP when packaging completes.
The run.log file is unbuffered at the Python level.
Each job's detailed solver log is RUN_DIR/benchmark/GRID/gloa/run.log.
Solver calls, full returned solutions when available, GDP and Grid coordinate paths, and immutable source hashes remain in the result ZIP.
Preflight checks the existing Dantzig GAMS 52.2, Pyomo 6.10.0 and solver availability; there is no alternative-solver fallback.
Preflight is outside the benchmark budget and may take time before the first START line.
Inspect all_jobs_finished and the completed-job count before interpreting a packaged failure as a complete benchmark.

After completion, display the result path:

```bash
cat /local/scratch/a/lee4382/repository/RBFopt_Test/results/grid_gdpopt_scip_gloa/result_zip.txt
```

To resume this package's own interrupted run after the old controller has stopped:

```bash
bash run_method.sh resume --run-dir /absolute/RUN_DIR
```

The existing runner preserves incomplete attempts under previous_attempts and skips sealed completed jobs.
Every attempt must remain identifiable in later analysis.
The three split runs are independent new experiments; they do not select better outcomes from the earlier combined run.
No server execution was performed while creating these ZIPs.
