"""One Grid GDPopt method, separate result pointers, and distinct CPU cores."""
import argparse
from contextlib import contextmanager
import fcntl
from itertools import combinations
import json
import os
from pathlib import Path
import sys

import gdp_scip_experiments as experiment


@contextmanager
def launcher_lock(output):
    output.mkdir(parents=True, exist_ok=True)
    with (output / '.method_launcher.lock').open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError('This method already has an active launcher; inspect its run.log.') from None
        try:
            yield
        finally:
            fcntl.flock(lock, fcntl.LOCK_UN)


def arguments(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['plan', 'run', 'check', 'resume', 'status', 'pack'])
    parser.add_argument('--run-dir', type=Path)
    parser.add_argument('--grids', help='Optional subset; defaults to all 21 original Grid problems.')
    parser.add_argument('--time-limit', type=float, default=1800)
    args = parser.parse_args(argv)
    if args.mode in {'resume', 'status', 'pack'} and args.run_dir is None:
        parser.error('--run-dir is required for this mode')
    if args.mode in {'resume', 'status', 'pack'} and (args.grids or args.time_limit != 1800):
        parser.error('Existing runs retain their recorded grids and time limit')
    return args


def main(argv=None):
    args = arguments(argv)
    experiment.package_inventory()
    package = experiment.read(experiment.ROOT / 'gdp_scip_package.json')
    method = package['split_method']
    if package['methods'] != [method] or package['planned_jobs'] != 21:
        raise ValueError('Invalid single-method package')
    repository = Path(os.environ.get('GDP_SCIP_REPOSITORY', '/local/scratch/a/lee4382/repository/RBFopt_Test'))
    output = repository / 'results' / ('grid_gdpopt_scip_' + method)
    command = [args.mode, '--methods', method, '--cpu', str(package['cpu']),
               '--time-limit', str(args.time_limit), '--output-root', str(output)]
    if args.grids:
        command.extend(['--grids', args.grids])
    if args.run_dir:
        command.extend(['--run-dir', str(args.run_dir)])
    if args.mode in {'plan', 'status'}:
        return experiment.main(command)
    if sys.platform != 'linux':
        raise RuntimeError('Execute this benchmark on Dantzig; use plan for solver-free local validation.')
    from cpu_affinity import check_cpu_pair
    checks = [check_cpu_pair(a, b) for a, b in combinations(package['separate_cpu_ids'], 2)]
    print('CPU_SEPARATION=' + json.dumps({'requested_cpu': package['cpu'], 'checks': checks}), flush=True)
    print('METHOD=' + method + '; OUTPUT_ROOT=' + str(output), flush=True)
    with launcher_lock(output):
        return experiment.main(command)


if __name__ == '__main__':
    raise SystemExit(main())
