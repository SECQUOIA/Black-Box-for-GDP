# 기존 DFO 실행시간·좌표 기록과 좌표별 NLP 시간 측정

이 수정본은 기존 연구의 DFO 구현·설정·목적함수표를 그대로 사용합니다.
이전에 제공한 `dantzig_nlp_overnight_20261002.zip`은 확대된 실험이므로 사용하지 마세요.
이번 파일은 `dantzig_dfo_trace_nlp_20261002.zip`입니다.

## 실행 내용

1. **기존 DSDA·RBFOpt·BAM 각각 139회, 총 417회**를 Dantzig에서 실행하면서 실행시간과 모든 실제 방문 좌표·평가 순서를 기록합니다. 초기 좌표·seed·평가예산·lookup 목적함수·feasible 점 처리 방식은 기존 구현 그대로입니다.
2. **방문한 좌표만** 대상으로 NLP 평가시간을 확보합니다. 같은 모델·크기·solver·초기화 조건의 원본 Dantzig 측정값은 검증 후 재사용하고, 없는 좌표만 새로 측정합니다. Infeasible·전처리 탈락·solver 실패 시간도 기록합니다.
3. 기존 **FMQA 139회 원본 Dantzig 기록을 재사용**해 같은 형식의 표로 합칩니다. FMQA를 새로 돌리지 않습니다.

별도의 556회 online 실험, 전체 정수 격자 열거, GDPopt 재실행은 없습니다.
좌표별 NLP 결과를 DFO에 돌려주지 않으므로 NLP 풀이 결과에 따라 탐색 경로가 바뀌지 않습니다.

## 확인할 세 가지 표

| 파일 | 내용 |
|---|---|
| `analysis/dfo_runs.csv` | DFO 실행별 실제 기록 시간, 최종 해, 원자료 출처 |
| `analysis/evaluation_timings.csv` | 방문 순서·좌표·DFO 평가 시각과 그 좌표의 별도 NLP 시간 |
| `analysis/point_timings.csv` | 좌표별 NLP 평가시간·solver 호출시간·판정·측정 출처 |

`dfo_time_summary.csv`와 `analysis/README.md`에는 DFO 시간 비교 표를 저장합니다.
DFO 시간과 NLP 시간을 합쳐 실제로 한 번에 측정한 시간이라고 표시하지 않습니다.

- `nlp_evaluation_wall_s`: 해당 좌표의 모델 준비·전처리·NLP 풀이·해 검증 시간.
- `nlp_solve_wall_s`: 그중 GAMS solver를 호출한 구간. 위 평가시간에 이미 포함되므로 더하지 않습니다.
- 전처리에서 infeasible이면 solver 호출시간은 0일 수 있지만 평가시간은 실제 측정값을 기록합니다.
- 같은 좌표가 반복되면 방문 기록을 모두 남기고, 같은 별도 점별 측정값을 연결합니다.
- 초기화를 바꾼 별도 성공 재시도로 원래 시도의 비용을 대체하지 않습니다. 누락은 빈칸으로 남습니다.
- Dynamic의 일회성 모델 준비시간은 `dynamic_preparations.json`에 따로 보존합니다.
- NLP의 실패/시간초과와 infeasible 보고를 구분합니다. Local solver의 infeasible 보고를 전역적인 infeasibility 증명으로 취급하지 않습니다.

기본 CPU는 **6**, GAMS **52.2/IPOPT(MUMPS)**, 새 NLP 측정 제한은 **60초**입니다.
RBFOpt가 기존에 사용하던 BONMIN/IPOPT 설정도 그대로 유지합니다.
점별 비용용 solver를 BARON으로 명시적으로 바꿀 경우 `NLP_SOLVER=baron`을 사용하며,
그 경우 기존 IPOPT 비용은 재사용하지 않습니다. 이는 DFO 설정 변경이 아닙니다.

## 업로드와 실행

Mac:

```bash
scp /Users/albertlee0125/Repos/RBFopt_Test/results/runners/dantzig_dfo_trace_nlp_20261002.zip{,.sha256} \
  lee4382@dantzig.ecn.purdue.edu:/local/scratch/a/lee4382/repository/RBFopt_Test/
```

Dantzig:

```bash
cd /local/scratch/a/lee4382/repository/RBFopt_Test
sha256sum -c dantzig_dfo_trace_nlp_20261002.zip.sha256
unzip dantzig_dfo_trace_nlp_20261002.zip
cd dantzig_dfo_trace_nlp_20261002

bash run_dfo_trace_nlp_dantzig.sh setup
bash run_dfo_trace_nlp_dantzig.sh check > preflight.log 2>&1
```

점검이 성공한 뒤:

```bash
nohup bash run_dfo_trace_nlp_dantzig.sh run > dfo_trace_nlp.log 2>&1 < /dev/null &
echo $! > dfo_trace_nlp.pid
tail -f dfo_trace_nlp.log
```

이전 확대 실험 ZIP을 이미 실행했다면 새 작업을 겹쳐 실행하지 말고, 먼저 해당 작업 상태를 확인하세요.
수정본은 실행 중인 다른 작업을 자동으로 종료하지 않습니다.

`setup`은 기존 BAM 환경을 별도 환경으로 복제해 필요한 패키지를 설치합니다. 기존 DFO 환경이나
결과를 덮어쓰지 않습니다. 앞선 패키지의 setup을 이미 했다면 같은 복제 환경을 사용할 수 있습니다.
서버 경로가 다르면 `NLP_REPOSITORY`, `NLP_BASE_ENV`, `NLP_ENV`, `NLP_CONDA`, `COIN_BIN`,
`GAMS_BIN`, `BAM_LICENSE_FILE`, `RBFOPT_GDP_SOURCES`를 지정할 수 있습니다.

## 재개와 결과 다운로드

SSH 연결이 끊겨도 nohup 작업은 계속됩니다. 로그의 `RUN_DIR=...`가 결과 폴더입니다.
완료된 작업은 건너뛰고, 중간에 끊긴 작업만 다시 시작합니다. 이전 시도는 보존합니다.

```bash
RUN_DIR=/local/scratch/a/lee4382/repository/RBFopt_Test/results/dfo_trace_nlp/실제실행폴더
bash run_dfo_trace_nlp_dantzig.sh status --run-dir "$RUN_DIR"
# 기존 실행이 실제로 종료된 것을 확인한 후:
nohup bash run_dfo_trace_nlp_dantzig.sh resume --run-dir "$RUN_DIR" > resume.log 2>&1 < /dev/null &
```

완료 시 실행 폴더 옆에 `.zip`과 `.zip.sha256`을 자동으로 만듭니다. 원본 callback 기록,
NLP 결과·GAMS 로그, 조건·소스 체크섬과 비교 표를 함께 보존합니다.

```bash
# Mac에서 실제 생성된 이름으로 다운로드:
scp 'lee4382@dantzig.ecn.purdue.edu:/local/scratch/a/lee4382/repository/RBFopt_Test/results/dfo_trace_nlp/실제실행폴더.zip*' ~/Downloads/
```
