import os
import signal
import time
def _stop_process_group(process, grace_seconds=5):
    """Stop the session we created, including children outliving its leader."""
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        deadline = time.monotonic() + grace_seconds
        while time.monotonic() < deadline:
            process.poll()  # Reap the leader without assuming its children exited.
            try:
                os.killpg(process.pid, 0)
            except ProcessLookupError:
                break
            time.sleep(min(0.05, max(0, deadline - time.monotonic())))
    finally:
        # A cooperative leader can exit before a solver that ignores SIGTERM.
        # Always finish cleanup of our group, even if the grace wait is interrupted.
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait()


