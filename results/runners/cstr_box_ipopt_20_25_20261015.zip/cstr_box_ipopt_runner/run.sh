#!/usr/bin/env bash
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
mode=${1:-check}
if [[ $# -gt 0 ]]; then shift; fi
exec bash run_cstr_box_ipopt_dantzig.sh "$mode" --sizes 20 25 "$@"
